package dev.amble.lib.animation.client;

import dev.amble.lib.animation.AnimatedBlockEntity;
import dev.amble.lib.animation.AnimatedEntity;
import dev.amble.lib.client.bedrock.BedrockEntityModel;
import dev.amble.lib.client.bedrock.BedrockModel;
import dev.amble.lib.client.bedrock.BedrockModelReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_1944;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_827;

@Environment(EnvType.CLIENT)
public class BedrockBlockEntityRenderer<T extends class_2586 & AnimatedBlockEntity> implements class_827<T> {
	protected BedrockEntityModel model;

	public BedrockBlockEntityRenderer() {
	}

	public BedrockBlockEntityRenderer(class_5614.class_5615 context) {
		this();
	}

	@Override
	public void method_3569(T entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
		if (this.model == null) this.refreshModel(entity);

		matrices.method_22903();
		matrices.method_22904(0.5D, 0.0D, 0.5D);
		matrices.method_22907(class_7833.field_40714.rotationDegrees(180F));

		light = entity.method_10997().method_8314(class_1944.field_9284, entity.method_11016().method_10084().method_10084());
		light = class_765.method_23687(0, light);

		this.model.setAngles(entity, entity.getAge() + tickDelta);
		this.model.method_2828(matrices, vertexConsumers.getBuffer(class_1921.method_23578(this.getTexture(entity))), light, overlay, 1.0f, 1.0f, 1.0f, 1.0f);

		class_2960 emission = entity.getEmissionTexture();
		if (emission != null) {
			this.model.method_2828(matrices, vertexConsumers.getBuffer(class_1921.method_28116(emission)), class_765.field_32767, overlay, 1.0f, 1.0f, 1.0f, 1.0f);
		}

		matrices.method_22909();
	}

	public class_2960 getTexture(T entity) {
		return entity.getTexture();
	}

	protected BedrockEntityModel refreshModel(T entity) {
		BedrockModelReference ref = entity.getModel();
		if (ref == null) throw new IllegalStateException("BlockEntity " + entity + " does not have a BedrockModelReference");
		BedrockModel bedrock = ref.get().orElseThrow(() -> new IllegalStateException("BedrockModel " + ref.id() + " not found for block entity " + entity));

		this.model = new BedrockEntityModel<>(bedrock);
		return this.model;
	}
}
