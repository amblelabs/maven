package dev.amble.lib.container.impl;

import dev.amble.lib.container.RegistryContainer;
import net.minecraft.class_1761;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public interface ItemGroupContainer extends RegistryContainer<class_1761> {

    @Override
    default class_2378<class_1761> getRegistry() {
        return class_7923.field_44687;
    }

    @Override
    default Class<class_1761> getTargetClass() {
        return class_1761.class;
    }
}
