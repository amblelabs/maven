package dev.amble.lib.mixin.client;

import dev.amble.lib.animation.client.AnimationMetadata;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public class HeldItemRendererMixin {
	@Inject(method="renderFirstPersonItem", at=@At("HEAD"), cancellable = true)
	private void amblekit$renderFirstPersonItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
		AnimationMetadata metadata = AnimationMetadata.getFor((dev.amble.lib.animation.AnimatedEntity) player);
		if (metadata == null || !metadata.fpsCamera()) return;

		ci.cancel();
	}
}
