package dev.amble.lib.mixin.client;

import dev.amble.lib.skin.SkinData;
import dev.amble.lib.skin.SkinTracker;
import dev.amble.lib.skin.client.SkinGrabber;
import net.minecraft.class_2960;
import net.minecraft.class_742;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerMixin {
	@Unique @Nullable private SkinData lastSkin = null;

	@Inject(method="getSkinTexture", at=@At("HEAD"), cancellable = true)
	private void amblekit$getSkinTexture(CallbackInfoReturnable<class_2960> cir) {
		class_742 player = (class_742)(Object)this;

		SkinTracker tracker = SkinTracker.getInstance();

		SkinData data = tracker.get(player.method_5667());
		if (data == null) return;

		class_2960 id = data.get();
		if (id == null) return;

		if (SkinGrabber.isMissingTexture(id) && lastSkin != null) {
			id = lastSkin.get();
		} else {
			lastSkin = data;
		}

		cir.setReturnValue(id);
	}

	@Inject(method="getModel", at=@At("HEAD"), cancellable = true)
	private void amblekit$getModel(CallbackInfoReturnable<String> cir) {
		class_742 player = (class_742) (Object) this;

		SkinTracker tracker = SkinTracker.getInstance();

		SkinData data = tracker.get(player.method_5667());
		if (data == null) return;

		cir.setReturnValue(data.slim() ? "slim" : "default");
	}
}
