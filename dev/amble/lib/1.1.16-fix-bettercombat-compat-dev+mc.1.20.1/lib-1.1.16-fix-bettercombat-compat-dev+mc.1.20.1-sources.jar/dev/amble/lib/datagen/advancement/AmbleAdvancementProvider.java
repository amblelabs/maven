package dev.amble.lib.datagen.advancement;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.class_161;
import net.minecraft.class_1802;
import net.minecraft.class_184;
import net.minecraft.class_189;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class AmbleAdvancementProvider extends FabricAdvancementProvider {

    private final List<Builder> builders = new ArrayList<>();

    public AmbleAdvancementProvider(FabricDataOutput output) {
        super(output);
    }

    public Builder create(class_161 parent, String name) {
        Builder result = new Builder(parent, name);
        builders.add(result);
        return result;
    }

    public Builder create(String name) {
        return create(null, name);
    }

    public Builder task(class_161 parent, String name) {
        return create(parent, name);
    }

    public Builder task(String name) {
        return create(name);
    }

    public Builder challenge(class_161 parent, String name) {
        return create(parent, name).frame(class_189.field_1250);
    }

    public Builder goal(class_161 parent, String name) {
        return create(parent, name).frame(class_189.field_1249);
    }

    @Override
    public void generateAdvancement(Consumer<class_161> consumer) {
        for (Builder builder : builders) {
            consumer.accept(builder.build());
        }
    }

    public class Builder {

        private final class_161.class_162 builder;

        private class_1935 item = class_1802.field_8077;
        private boolean hidden = false;
        private class_189 frame = class_189.field_1254;
        private class_2960 background;
        private boolean announce = true;
        private boolean showToast = true;

        private final String name;

        public Builder(class_161 parent, String name) {
            this.builder = class_161.class_162.method_707().method_701(parent);
            this.name = name;
        }

        public Builder condition(String name, class_184 conditions) {
            this.builder.method_709(name, conditions);
            return this;
        }

        public Builder icon(class_1935 item) {
            this.item = item;
            return this;
        }

        public Builder hidden() {
            this.hidden = true;
            return this;
        }

        public Builder frame(class_189 frame) {
            this.frame = frame;
            return this;
        }

        public Builder background(class_2960 background) {
            this.background = background;
            return this;
        }

        public Builder background(String background) {
            return background(new class_2960(AmbleAdvancementProvider.this.output.getModId(), background));
        }

        public Builder silent() {
            this.announce = false;
            return this;
        }

        public Builder noToast() {
            this.showToast = false;
            return this;
        }

        public class_161 build() {
            String modId = AmbleAdvancementProvider.this.output.getModId();

            return builder
                    .method_697(item,
                            class_2561.method_43471("achievement." + modId + ".title." + name),
                            class_2561.method_43471("achievement." + modId + ".description." + name),
                            background, frame, showToast, announce, hidden)
                    .method_694(advancement -> {}, modId + ":" + name);
        }
    }
}
