package dev.amble.lib.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.amble.lib.block.ABlockSettings;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2248.class)
public abstract class BlockMixin {

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;appendProperties(Lnet/minecraft/state/StateManager$Builder;)V"))
    public void init(class_4970.class_2251 settings, CallbackInfo ci, @Local class_2689.class_2690<class_2248, class_2680> builder) {
        if (settings instanceof ABlockSettings abs && abs.properties() != null) builder.method_11667(abs.properties());
    }
}
