package dev.amble.lib.animation;

import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3419;

public interface EffectProvider {
	class_1937 getWorld();
	boolean isSilent();
	class_3419 getSoundCategory();
	float getHeadYaw();
	float getBodyYaw();
	float getPitch();
	class_243 getEffectPosition(float tickDelta);
}
