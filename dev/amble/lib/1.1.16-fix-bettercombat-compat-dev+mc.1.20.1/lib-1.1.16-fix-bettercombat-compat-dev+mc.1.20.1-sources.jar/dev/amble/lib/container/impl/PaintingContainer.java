package dev.amble.lib.container.impl;

import dev.amble.lib.container.RegistryContainer;
import net.minecraft.class_1535;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public interface PaintingContainer extends RegistryContainer<class_1535> {

    @Override
    default Class<class_1535> getTargetClass() {
        return class_1535.class;
    }

    @Override
    default class_2378<class_1535> getRegistry() {
        return class_7923.field_41182;
    }
}
