package dev.amble.lib.block.behavior;

import dev.amble.lib.block.behavior.base.RenderBlockBehavior;
import net.minecraft.class_2464;
import net.minecraft.class_2680;

public class InvisibleBlockBehavior extends RenderBlockBehavior {

    public static InvisibleBlockBehavior behavior = new InvisibleBlockBehavior();

    @Override
    public class_2464 getRenderType(class_2680 state) {
        return class_2464.field_11455;
    }
}
