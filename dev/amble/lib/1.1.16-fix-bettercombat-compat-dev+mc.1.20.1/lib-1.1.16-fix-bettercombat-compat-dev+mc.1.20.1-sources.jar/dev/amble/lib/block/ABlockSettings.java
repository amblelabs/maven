package dev.amble.lib.block;

import java.util.function.Function;
import java.util.function.ToIntFunction;

import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_1299;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7696;
import org.jetbrains.annotations.ApiStatus;

@SuppressWarnings("deprecation")
public class ABlockSettings extends FabricBlockSettings {

    public static ABlockSettings method_9637() {
        return new ABlockSettings();
    }

    private class_1792.class_1793 settings;
    private class_2769<?>[] properties;

    public ABlockSettings itemSettings(class_1792.class_1793 settings) {
        this.settings = settings;
        return this;
    }

    @ApiStatus.Internal
    public ABlockSettings properties(class_2769<?>[] properties) {
        this.properties = properties;
        return this;
    }

    @Override
    public ABlockSettings method_9634() {
        return (ABlockSettings) super.method_9634();
    }

    @Override
    public ABlockSettings method_22488() {
        return (ABlockSettings) super.method_22488();
    }

    @Override
    public ABlockSettings method_9628(float value) {
        return (ABlockSettings) super.method_9628(value);
    }

    @Override
    public ABlockSettings method_23351(float velocityMultiplier) {
        return (ABlockSettings) super.method_23351(velocityMultiplier);
    }

    @Override
    public ABlockSettings method_23352(float jumpVelocityMultiplier) {
        return (ABlockSettings) super.method_23352(jumpVelocityMultiplier);
    }

    @Override
    public ABlockSettings method_9626(class_2498 group) {
        return (ABlockSettings) super.method_9626(group);
    }

    @Override
    public ABlockSettings lightLevel(ToIntFunction<class_2680> levelFunction) {
        return (ABlockSettings) super.lightLevel(levelFunction);
    }

    @Override
    public ABlockSettings method_9631(ToIntFunction<class_2680> luminanceFunction) {
        return (ABlockSettings) super.method_9631(luminanceFunction);
    }

    @Override
    public ABlockSettings method_9629(float hardness, float resistance) {
        return (ABlockSettings) super.method_9629(hardness, resistance);
    }

    @Override
    public ABlockSettings method_9618() {
        return (ABlockSettings) super.method_9618();
    }

    @Override
    public ABlockSettings method_9632(float strength) {
        return (ABlockSettings) super.method_9632(strength);
    }

    @Override
    public ABlockSettings method_9640() {
        return (ABlockSettings) super.method_9640();
    }

    @Override
    public ABlockSettings method_9624() {
        return (ABlockSettings) super.method_9624();
    }

    @Override
    public ABlockSettings method_42327() {
        return (ABlockSettings) super.method_42327();
    }

    @Override
    public ABlockSettings method_16228(class_2248 block) {
        return (ABlockSettings) super.method_16228(block);
    }

    @Override
    public ABlockSettings method_26250() {
        return (ABlockSettings) super.method_26250();
    }

    @Override
    public ABlockSettings method_26235(class_4970.class_4972<class_1299<?>> predicate) {
        return (ABlockSettings) super.method_26235(predicate);
    }

    @Override
    public ABlockSettings method_26236(class_4970.class_4973 predicate) {
        return (ABlockSettings) super.method_26236(predicate);
    }

    @Override
    public ABlockSettings method_26243(class_4970.class_4973 predicate) {
        return (ABlockSettings) super.method_26243(predicate);
    }

    @Override
    public ABlockSettings method_26245(class_4970.class_4973 predicate) {
        return (ABlockSettings) super.method_26245(predicate);
    }

    @Override
    public ABlockSettings method_26247(class_4970.class_4973 predicate) {
        return (ABlockSettings) super.method_26247(predicate);
    }

    @Override
    public ABlockSettings method_26249(class_4970.class_4973 predicate) {
        return (ABlockSettings) super.method_26249(predicate);
    }

    @Override
    public ABlockSettings method_29292() {
        return (ABlockSettings) super.method_29292();
    }

    @Override
    public ABlockSettings method_31710(class_3620 color) {
        return (ABlockSettings) super.method_31710(color);
    }

    @Override
    public ABlockSettings method_36557(float hardness) {
        return (ABlockSettings) super.method_36557(hardness);
    }

    @Override
    public ABlockSettings method_36558(float resistance) {
        return (ABlockSettings) super.method_36558(resistance);
    }

    @Override
    public ABlockSettings method_49229(class_4970.class_2250 offsetType) {
        return (ABlockSettings) super.method_49229(offsetType);
    }

    @Override
    public ABlockSettings method_45477() {
        return (ABlockSettings) super.method_45477();
    }

    @Override
    public ABlockSettings method_45476(class_7696... features) {
        return (ABlockSettings) super.method_45476(features);
    }

    @Override
    public ABlockSettings method_51520(Function<class_2680, class_3620> mapColorProvider) {
        return (ABlockSettings) super.method_51520(mapColorProvider);
    }

    @Override
    public ABlockSettings method_50013() {
        return (ABlockSettings) super.method_50013();
    }

    @Override
    public ABlockSettings method_51177() {
        return (ABlockSettings) super.method_51177();
    }

    @Override
    public ABlockSettings method_51369() {
        return (ABlockSettings) super.method_51369();
    }

    @Override
    public ABlockSettings method_51370() {
        return (ABlockSettings) super.method_51370();
    }

    @Override
    public ABlockSettings method_50012(class_3619 pistonBehavior) {
        return (ABlockSettings) super.method_50012(pistonBehavior);
    }

    @Override
    public ABlockSettings method_51368(class_2766 instrument) {
        return (ABlockSettings) super.method_51368(instrument);
    }

    @Override
    public ABlockSettings method_51371() {
        return (ABlockSettings) super.method_51371();
    }

    @Override
    public ABlockSettings lightLevel(int lightLevel) {
        return (ABlockSettings) super.lightLevel(lightLevel);
    }

    @Override
    public ABlockSettings luminance(int luminance) {
        return (ABlockSettings) super.luminance(luminance);
    }

    @Override
    public ABlockSettings drops(class_2960 dropTableId) {
        return (ABlockSettings) super.drops(dropTableId);
    }

    @Override
    public ABlockSettings materialColor(class_3620 color) {
        return (ABlockSettings) super.materialColor(color);
    }

    @Override
    public ABlockSettings materialColor(class_1767 color) {
        return (ABlockSettings) super.materialColor(color);
    }

    @Override
    public ABlockSettings method_51517(class_1767 color) {
        return (ABlockSettings) super.method_51517(color);
    }

    @Override
    public ABlockSettings collidable(boolean collidable) {
        return (ABlockSettings) super.collidable(collidable);
    }

    public class_1792.class_1793 itemSettings() {
        return settings;
    }

    public class_2769<?>[] properties() {
        return properties;
    }
}
