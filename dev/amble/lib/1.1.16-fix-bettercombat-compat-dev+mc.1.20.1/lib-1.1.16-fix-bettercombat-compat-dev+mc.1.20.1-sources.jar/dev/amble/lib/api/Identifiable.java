package dev.amble.lib.api;

import net.minecraft.class_2960;

public interface Identifiable {
    class_2960 id();
}
