package dev.amble.lib.blockentity;

import net.minecraft.class_2487;

public interface StructurePlaceableBlockEntity {
    void amble$onStructurePlaced(class_2487 nbt);
}
