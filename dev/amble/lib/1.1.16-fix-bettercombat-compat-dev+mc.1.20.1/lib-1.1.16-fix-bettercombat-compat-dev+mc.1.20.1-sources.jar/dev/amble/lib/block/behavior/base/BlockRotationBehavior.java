package dev.amble.lib.block.behavior.base;

import dev.amble.lib.block.behavior.api.BlockBehavior;
import dev.amble.lib.block.behavior.api.BlockBehaviors;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;

public class BlockRotationBehavior implements BlockBehavior {

    public class_2680 rotate(class_2680 state, class_2470 rotation) {
        return state;
    }

    public class_2680 mirror(class_2680 state, class_2415 mirror) {
        return state;
    }

    @Override
    public int idx() {
        return BlockBehaviors.BLOCK_ROTATION;
    }
}
