package dev.amble.lib.block.behavior.horizontal;

import dev.amble.lib.block.behavior.api.Archetype;
import dev.amble.lib.block.behavior.base.BlockRotationBehavior;
import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2769;

public class HorizontalBlockBehavior extends BlockRotationBehavior {

    public static final HorizontalBlockBehavior behavior = new HorizontalBlockBehavior();
    public static final class_2753 FACING = class_2741.field_12481;

    @Override
    public class_2680 initDefaultState(class_2248 block, class_2680 state) {
        return state.method_11657(FACING, class_2350.field_11043);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 mirror(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    public void appendProperties(List<class_2769<?>> list) {
        list.add(FACING);
    }

    public static class_2350 getFacing(class_2680 state) {
        return state.method_11654(FACING);
    }

    private static final Archetype archFacePlayer = new Archetype(behavior, HorizontalBlockPlacementBehavior.behaviorFacePlayer);
    private static final Archetype arch = new Archetype(behavior, HorizontalBlockPlacementBehavior.behavior);

    public static Archetype withPlacement(boolean facePlayer) {
        return facePlayer ? archFacePlayer : arch;
    }
}
