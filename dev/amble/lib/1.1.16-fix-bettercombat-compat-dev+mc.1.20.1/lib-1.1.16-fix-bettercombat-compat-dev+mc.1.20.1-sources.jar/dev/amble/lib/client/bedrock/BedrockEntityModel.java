package dev.amble.lib.client.bedrock;

import dev.amble.lib.animation.AnimatedEntity;
import dev.amble.lib.animation.AnimatedInstance;
import dev.amble.lib.animation.client.AnimatedEntityModel;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_583;
import net.minecraft.class_630;

public class BedrockEntityModel<T extends class_1297 & AnimatedEntity> extends class_583<T> implements AnimatedEntityModel {
	private final BedrockModel model;
	private final class_630 root;

	public BedrockEntityModel(BedrockModel model) {
		this.model = model;
		this.root = model.create().method_32109();
	}

	@Override
	public void method_2819(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
		this.applyAnimationPre(entity, animationProgress);
		this.applyAnimation(entity, animationProgress);
	}

	public void setAngles(AnimatedInstance instance, float animationProgress) {
		this.applyAnimationPre(instance, animationProgress);
		this.applyAnimation(instance, animationProgress);
	}

	@Override
	public void method_2828(class_4587 matrices, class_4588 vertices, int light, int overlay, float red, float green, float blue, float alpha) {
		this.getPart().method_22699(matrices, vertices, light, overlay, red, green, blue, alpha);
	}

	@Override
	public class_630 getPart() {
		return root;
	}
}
