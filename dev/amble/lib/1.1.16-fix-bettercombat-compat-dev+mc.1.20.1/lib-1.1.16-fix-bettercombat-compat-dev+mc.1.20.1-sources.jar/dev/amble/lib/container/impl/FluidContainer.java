package dev.amble.lib.container.impl;

import dev.amble.lib.container.RegistryContainer;
import net.minecraft.class_2378;
import net.minecraft.class_3611;
import net.minecraft.class_7923;

public interface FluidContainer extends RegistryContainer<class_3611> {

    @Override
    default Class<class_3611> getTargetClass() {
        return class_3611.class;
    }

    @Override
    default class_2378<class_3611> getRegistry() {
        return class_7923.field_41173;
    }
}
