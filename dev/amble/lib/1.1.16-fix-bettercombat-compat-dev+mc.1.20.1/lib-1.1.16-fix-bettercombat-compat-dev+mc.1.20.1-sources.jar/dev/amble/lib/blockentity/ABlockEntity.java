package dev.amble.lib.blockentity;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3215;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

public abstract class ABlockEntity extends class_2586 {

    public ABlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public void onPlaced(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) { }

    public class_1269 onUse(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        return class_1269.field_5811;
    }

    public void onBreak(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState) { }

    protected void sync() {
        if (this.field_11863 != null && this.field_11863.method_8398() instanceof class_3215 chunkManager)
            chunkManager.method_14128(this.field_11867);
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887() {
        return method_38244();
    }

    public static <E extends class_2586> void tick(class_1937 world, class_2338 blockPos, class_2680 blockState, E e) {
        ((ABlockEntity) e).tick(world, blockPos, blockState);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) { }
}
