package dev.amble.lib.block.behavior.api;

import org.jetbrains.annotations.ApiStatus;

import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2769;

@ApiStatus.Experimental
public interface BlockBehavior extends BlockBehaviorLike {

    @Override
    default void unwrap(BlockBehavior[] behaviors) {
        behaviors[idx()] = this;
    }

    default void init(class_2248 block) { }

    default class_2680 initDefaultState(class_2248 block, class_2680 state) {
        return state;
    }

    default void appendProperties(List<class_2769<?>> list) { }

    int idx();
}
