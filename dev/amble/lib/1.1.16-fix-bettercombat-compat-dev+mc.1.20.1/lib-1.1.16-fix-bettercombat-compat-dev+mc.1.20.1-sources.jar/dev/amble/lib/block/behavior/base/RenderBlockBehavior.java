package dev.amble.lib.block.behavior.base;

import dev.amble.lib.block.behavior.api.BlockBehavior;
import dev.amble.lib.block.behavior.api.BlockBehaviors;
import net.minecraft.class_2464;
import net.minecraft.class_2680;

public class RenderBlockBehavior implements BlockBehavior {

    public class_2464 getRenderType(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public int idx() {
        return BlockBehaviors.RENDER_BLOCK;
    }
}
