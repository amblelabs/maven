package dev.amble.lib.client.model;

import net.minecraft.class_1297;
import net.minecraft.class_5597;

@SuppressWarnings("rawtypes")
public abstract class BlockEntityModel extends class_5597 {

    @Override
    public void method_2819(class_1297 entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) { }
}
