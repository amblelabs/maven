package dev.amble.lib.mixin.client;

import dev.amble.lib.duck.ModelPartDuck;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import net.minecraft.class_630;

@Mixin(class_630.class)
public class ModelPartAccessor implements ModelPartDuck {
	@Shadow
	@Final
	private Map<String, class_630> children;

	@Override
	public Map<String, class_630> amblekit$getChildren() {
		return this.children;
	}
}
