package dev.amble.lib.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import dev.amble.lib.api.ICantBreak;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_636;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {

    @Shadow
    @Final
    private class_310 client;

    @Inject(method = "breakBlock", at = @At(value = "HEAD"), cancellable = true)
    public void ait$breakBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        class_1937 world = this.client.field_1687;
        if (world == null)
            return;

        class_2248 block = world.method_8320(pos).method_26204();
        if (block instanceof ICantBreak cantBreak) {
            cantBreak.onTryBreak(world, pos, world.method_8320(pos), this.client.field_1724);
            cir.setReturnValue(false);
            cir.cancel();
        }
    }
}
