package dev.amble.lib.mixin;

import dev.amble.lib.animation.AnimatedEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1642;
import net.minecraft.class_1937;
import net.minecraft.class_7094;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1642.class)
public abstract class ZombieEntityMixin extends class_1588 implements AnimatedEntity {
	private ZombieEntityMixin(class_1299<? extends class_1588> type, class_1937 world) {
		super(type, world);
	}


	private class_7094 amblekit$animationState = new class_7094();
	@Override
	public class_7094 getAnimationState() {
		return amblekit$animationState;
	}
}