package dev.amble.lib.client.bedrock;

import dev.amble.lib.animation.AnimatedEntity;
import dev.amble.lib.animation.AnimatedInstance;
import dev.amble.lib.animation.client.AnimatedEntityModel;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_7833;

public class BedrockEntityModel<T extends class_1297 & AnimatedEntity> extends class_583<T> implements AnimatedEntityModel {
	private final BedrockModel model;
	private final class_630 root;
	private final int textureWidth;
	private final int textureHeight;

	public BedrockEntityModel(BedrockModel model) {
		this.model = model;
		this.root = model.create().method_32109();
		this.textureWidth = model.geometry.get(0).description.textureWidth;
		this.textureHeight = model.geometry.get(0).description.textureHeight;
	}

	@Override
	public void method_2819(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
		this.applyAnimationPre(entity, animationProgress);
		this.applyAnimation(entity, animationProgress);
	}

	public void setAngles(AnimatedInstance instance, float animationProgress) {
		this.applyAnimationPre(instance, animationProgress);
		this.applyAnimation(instance, animationProgress);
	}

	@Override
	public void method_2828(class_4587 matrices, class_4588 vertices, int light, int overlay, float red, float green, float blue, float alpha) {
		this.getPart().method_22699(matrices, vertices, light, overlay, red, green, blue, alpha);

		List<BedrockModel.PerFaceCube> deferred = model.deferredPerFaceCubes();
		if (deferred.isEmpty()) return;

		matrices.method_22903();
		matrices.method_22907(class_7833.field_40716.rotationDegrees(180f));

		BedrockPerFaceRenderer.render(
				this.root,
				deferred,
				matrices,
				vertices,
				light,
				overlay,
				red, green, blue, alpha,
				this.textureWidth,
				this.textureHeight
		);
		matrices.method_22909();
	}

	@Override
	public class_630 getPart() {
		return root;
	}
}