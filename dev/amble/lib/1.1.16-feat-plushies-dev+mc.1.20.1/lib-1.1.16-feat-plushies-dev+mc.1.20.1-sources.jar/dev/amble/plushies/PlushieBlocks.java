package dev.amble.plushies;

import dev.amble.lib.animation.HasBedrockModel;
import dev.amble.lib.block.ABlockSettings;
import dev.amble.lib.container.impl.BlockContainer;
import dev.amble.lib.item.AItemSettings;
import dev.amble.lib.mixin.AbstractBlockAccessor;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class PlushieBlocks extends BlockContainer {

    public static final List<String> DEVS = List.of(
            "loqor", "theo", "addie", "saturn",
            "avery", "wanzz", "ember", "max",
            "lake", "classic", "pursephone", "ben",
            "nyx", "rhyno", "monke", "kking",
            "cosmic", "dian", "tree", "echo",
            "lucien", "maggie", "segfault", "peanut"
    );

    public static final ArrayList<class_2248> MARKETABLE_PLUSHIES = new ArrayList<>();

    public static class_2248[] getAllMarketablePlushies() {
        return MARKETABLE_PLUSHIES.toArray(new class_2248[0]);
    }

    @Override
    public class_1792.class_1793 createBlockItemSettings(class_2248 block) {
        return new AItemSettings().group(PlushieItemGroups.PLUSHIES);
    }

    public static void registerAll(String namespace) {
        PlushieBlocks self = new PlushieBlocks();
        self.start(DEVS.size());

        for (String name : DEVS) {
            ABlockSettings settings = new ABlockSettings();
            class_2248 block = new MarketablePlushieBlock(settings, name);
            class_2960 id = new class_2960(namespace, name + "_marketable_plushie");

            class_2378.method_10230(class_7923.field_41175, id, block);

            class_1792 item = self.createBlockItem(block, settings.itemSettings());

            class_2378.method_10230(class_7923.field_41178, id, item);
            self.items.add(item);

            MARKETABLE_PLUSHIES.add(block);
        }

        self.finish();
    }

    public static final class_2248 GIFT_BOX = new GiftBoxBlock(ABlockSettings.method_9637().itemSettings(new AItemSettings().group(PlushieItemGroups.PLUSHIES).method_7889(16)).method_9618());
}