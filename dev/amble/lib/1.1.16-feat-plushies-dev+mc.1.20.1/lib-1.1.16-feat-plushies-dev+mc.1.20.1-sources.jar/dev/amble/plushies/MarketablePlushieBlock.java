package dev.amble.plushies;

import dev.amble.lib.AmbleKit;
import dev.amble.lib.animation.BedrockModelProvider;
import dev.amble.lib.block.ABlock;
import dev.amble.lib.block.ABlockSettings;
import dev.amble.lib.block.AWaterloggableBlock;
import dev.amble.lib.block.behavior.base.BlockWithEntityBehavior;
import dev.amble.lib.blockentity.ABlockEntity;
import dev.amble.lib.client.bedrock.BedrockEntityModel;
import dev.amble.lib.client.bedrock.BedrockModelReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_7718;
import org.jetbrains.annotations.Nullable;

public class MarketablePlushieBlock extends AWaterloggableBlock implements class_2343, BedrockModelProvider {

    public static final class_2758 ROTATION = class_2741.field_12532;
    public static final int MAX_ROTATION_INDEX = class_7718.method_45478();
    private static final int MAX_ROTATIONS = MAX_ROTATION_INDEX + 1;

    public static final class_2746 STACKED = class_2746.method_11825("stacked");
    protected static final class_265 SHAPE = class_2248.method_9541(4.0F, 0.0F, 4.0F, 12.0F, 8.0F, 12.0F);

    private final BedrockModelReference modelRef;

    @Environment(EnvType.CLIENT)
    public BedrockEntityModel<?> model;

    public MarketablePlushieBlock(ABlockSettings settings, String modelId) {
        super(settings, new BlockWithEntityBehavior.Ticking(MarketablePlushieBlockEntity::new));
        
        this.modelRef = new BedrockModelReference(AmbleKit.MOD_ID, modelId);
        this.method_9590(this.field_10647.method_11664()
                .method_11657(ROTATION, 0)
                .method_11657(STACKED, false)
                .method_11657(class_2741.field_12508, false));
    }

    @Override
    public String getTexturePrefix() {
        return "block";
    }

    @Override
    public BedrockModelReference getModel() {
        return this.modelRef;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11456;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new MarketablePlushieBlockEntity(PlushieBlockEntities.MARKETABLE_PLUSHIE_BLOCK_ENTITY_TYPE, pos, state);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.method_8321(pos) instanceof MarketablePlushieBlockEntity be)
            return be.onUse(state, world, pos, player, hand, hit);

        return super.method_9534(state, world, pos, player, hand, hit);
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 world, class_2338 pos) {
        return class_259.method_1073();
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2338 pos = ctx.method_8037();
        class_1937 world = ctx.method_8045();

        class_3610 fluidState = ctx.method_8045().method_8316(ctx.method_8037());
        
        boolean sameAbove = world.method_8320(pos.method_10084()).method_27852(this);

        return this.method_9564()
                .method_11657(ROTATION, class_7718.method_45479(ctx.method_8044()))
                .method_11657(STACKED, sameAbove)
                .method_11657(WATERLOGGED, fluidState.method_15772() == class_3612.field_15910);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(ROTATION, rotation.method_10502(state.method_11654(ROTATION), MAX_ROTATIONS));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_11657(ROTATION, mirror.method_10344(state.method_11654(ROTATION), MAX_ROTATIONS));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ROTATION, STACKED, class_2741.field_12508);
    }

    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        if (world.method_8608()) return;

        boolean sameAbove = world.method_8320(pos.method_10084()).method_27852(this);
        if (state.method_11654(STACKED) != sameAbove) {
            world.method_8652(pos, state.method_11657(STACKED, sameAbove), class_2248.field_31028);
        }
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        if (world.method_8321(pos) instanceof MarketablePlushieBlockEntity be)
            be.onPlaced(world, pos, state, placer, itemStack);
        if (world.method_8608()) return;
        boolean sameAbove = world.method_8320(pos.method_10084()).method_27852(this);
        if (state.method_11654(STACKED) != sameAbove) {
            world.method_8652(pos, state.method_11657(STACKED, sameAbove), class_2248.field_31028);
        }

        class_2338 below = pos.method_10074();
        class_2680 belowState = world.method_8320(below);
        if (belowState.method_27852(this)) {
            boolean belowSameAbove = world.method_8320(below.method_10084()).method_27852(this);
            world.method_8652(below, belowState.method_11657(STACKED, belowSameAbove), class_2248.field_31028);
        }
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (state.method_27852(newState.method_26204())) return;

        if (!world.method_8608()) {
            class_2338 below = pos.method_10074();
            class_2680 belowState = world.method_8320(below);
            if (belowState.method_27852(this)) {
                boolean belowSameAbove = world.method_8320(below.method_10084()).method_27852(this);
                world.method_8652(below, belowState.method_11657(STACKED, belowSameAbove), class_2248.field_31028);
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }
}
