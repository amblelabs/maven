package dev.amble.plushies;

import dev.amble.lib.AmbleKit;
import dev.amble.lib.animation.AnimatedBlockEntity;
import dev.amble.lib.blockentity.ABlockEntity;
import dev.amble.lib.client.bedrock.BedrockAnimationReference;
import dev.amble.lib.client.bedrock.BedrockModelReference;
import lombok.Getter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_7094;
import org.jetbrains.annotations.Nullable;

public class GiftBoxBlockEntity extends ABlockEntity implements AnimatedBlockEntity {

    private static final BedrockModelReference REF = new BedrockModelReference(AmbleKit.MOD_ID, "gift_box");

    @Getter
    private final class_7094 animationState = new class_7094();

    public GiftBoxBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public GiftBoxBlockEntity(class_2338 blockPos, class_2680 blockState) {
        this(PlushieBlockEntities.GIFT_BOX_BLOCK_ENTITY_TYPE, blockPos, blockState);
    }

    @Override
    @Environment(EnvType.CLIENT)
    public int getAge() {
        class_310 client = class_310.method_1551();
        return client.field_1724 != null ? client.field_1724.field_6012 : 0;
    }

    @Override
    public class_7094 getAnimationState() {
        return animationState;
    }

    @Override
    public String getTexturePrefix() {
        return "block";
    }

    @Override
    public @Nullable BedrockModelReference getModel() {
        return REF;
    }

    @Override
    public float getRenderYaw() {
        return this.method_11010().method_11654(GiftBoxBlock.ROTATION) * 22.5f;
    }
}
