package dev.amble.plushies;

import dev.amble.lib.AmbleKit;
import dev.amble.lib.container.impl.ItemGroupContainer;
import dev.amble.lib.itemgroup.AItemGroup;
import net.minecraft.class_1799;
import net.minecraft.class_2246;

public class PlushieItemGroups implements ItemGroupContainer {

    public static final AItemGroup PLUSHIES = AItemGroup.builder(AmbleKit.id("item_group"))
            .icon(() -> new class_1799(PlushieBlocks.MARKETABLE_PLUSHIES.get(0) == null ? class_2246.field_10102 : PlushieBlocks.MARKETABLE_PLUSHIES.get(0))).build();
}