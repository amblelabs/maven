package dev.amble.ait.client.screen.wheel;

import dev.amble.ait.client.screen.wheel.action.Action;
import dev.amble.ait.common.I18n;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * @author drtheodor
 * From hex-spell-wheel
 */
@SuppressWarnings("unused")
public final class Widget {

    private static final class_1799 EMPTY_STACK = new class_1799(class_1802.field_8077);

    public static final int NORMAL_COLOR = 0x2c2c2c;
    public static final int HOVER_COLOR = 0x3c8527;

    private final class_2561 label;
    private class_1799 preview;

    private final @Nullable Action actions;
    private final boolean keepOpened;

    private int normalColor = NORMAL_COLOR;
    private int hoverColor = HOVER_COLOR;

    public static Widget fromStack(class_1799 stack, @Nullable Action action, boolean keepOpened) {
        return new Widget(stack.method_7954(), stack, action, keepOpened);
    }

    public Widget(class_2561 label, class_1799 preview, @Nullable Action actions, boolean keepOpened) {
        this.label = label;
        this.preview = preview;
        this.actions = actions;
        this.keepOpened = keepOpened;
    }

    public Widget(class_2561 label, class_1792 item, Action... actions) {
        this(label, new class_1799(item), Action.and(actions), false);
    }

    public void run(class_310 client) {
        if (actions == null)
            return;

        actions.run(client, this);
    }

    public void runAlt(class_310 client) {
        if (actions == null)
            return;

        actions.runAlt(client, this);
    }

    public static Widget empty() {
        return new Widget(I18n.EMPTY_WIDGET, EMPTY_STACK, null, true);
    }

    public class_2561 label() {
        return label;
    }

    public class_1799 preview() {
        return preview;
    }

    public void setPreview(class_1799 preview) {
        this.preview = preview;
    }

    @Nullable
    public Action actions() {
        return actions;
    }

    public boolean keepOpened() {
        return keepOpened;
    }

    public int currentColor() {
        return normalColor;
    }

    public int hoverColor() {
        return hoverColor;
    }

    public void setNormalColor(int normalColor) {
        this.normalColor = normalColor;
    }

    public void setHoverColor(int hoverColor) {
        this.hoverColor = hoverColor;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (Widget) obj;
        return Objects.equals(this.label, that.label) &&
                Objects.equals(this.preview, that.preview) &&
                Objects.equals(this.actions, that.actions) &&
                this.keepOpened == that.keepOpened;
    }

    @Override
    public int hashCode() {
        return Objects.hash(label, preview, actions, keepOpened);
    }
}