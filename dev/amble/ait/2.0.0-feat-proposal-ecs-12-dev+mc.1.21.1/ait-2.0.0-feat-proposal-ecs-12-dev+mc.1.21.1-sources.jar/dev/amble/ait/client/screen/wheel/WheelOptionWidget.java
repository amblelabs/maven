package dev.amble.ait.client.screen.wheel;

import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_7919;

/**
 * @author drtheodor
 * From hex-spell-wheel
 */
public class WheelOptionWidget extends class_4185 {

    private static final float GAP_DEGREES = 2.0f;

    public final Widget widget;
    private final int centerX;
    private final int centerY;
    private final float innerRadius;
    private final float outerRadius;
    private final float startAngle; // degrees, 0=top, clockwise
    private final float endAngle;
    private final boolean hasIcon;

    public WheelOptionWidget(int centerX, int centerY, float innerRadius, float outerRadius,
                             WidgetSlot slot, Widget widget, boolean hasIcon) {
        super(0, 0, 1, 1, class_2561.method_43473(), button -> {}, field_40754);

        this.centerX = centerX;
        this.centerY = centerY;
        this.innerRadius = innerRadius;
        this.outerRadius = outerRadius;
        this.startAngle = slot.startAngle() + GAP_DEGREES;
        this.endAngle = slot.endAngle() - GAP_DEGREES;
        this.widget = widget;
        this.hasIcon = hasIcon;

        this.method_47400(class_7919.method_47407(widget.label()));

        // Compute a tight bounding box around the actual arc segment
        float sa = this.startAngle;
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
        float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;

        int steps = 16;
        for (int i = 0; i <= steps; i++) {
            float t = (float) i / steps;
            float deg = sa + t * (this.endAngle - sa);
            double rad = Math.toRadians(deg - 90);
            float cos = (float) Math.cos(rad);
            float sin = (float) Math.sin(rad);

            for (float r : new float[]{innerRadius, outerRadius}) {
                float px = centerX + r * cos;
                float py = centerY + r * sin;
                if (px < minX) minX = px;
                if (px > maxX) maxX = px;
                if (py < minY) minY = py;
                if (py > maxY) maxY = py;
            }
        }

        this.method_46421((int) Math.floor(minX));
        this.method_46419((int) Math.floor(minY));
        this.field_22758 = (int) Math.ceil(maxX) - this.method_46426();
        this.field_22759 = (int) Math.ceil(maxY) - this.method_46427();
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        field_22762 = method_25405(mouseX, mouseY);
        renderButton(context);
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        if (!this.field_22763 || !this.field_22764) return false;

        double dx = mouseX - centerX;
        double dy = mouseY - centerY;
        double dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < innerRadius || dist > outerRadius) return false;

        // Convert to our angle system (0=top, clockwise)
        double angleRad = Math.atan2(dx, -dy); // gives 0 at top, positive clockwise
        double angleDeg = Math.toDegrees(angleRad);
        if (angleDeg < 0) angleDeg += 360;

        return isAngleInRange(angleDeg, startAngle, endAngle);
    }

    private static boolean isAngleInRange(double angle, float start, float end) {
        // Normalize everything to [0, 360)
        angle = ((angle % 360) + 360) % 360;
        float s = ((start % 360) + 360) % 360;
        float e = ((end % 360) + 360) % 360;

        if (s <= e) {
            return angle >= s && angle <= e;
        } else {
            // Wraps around 0 (e.g., 350 to 10)
            return angle >= s || angle <= e;
        }
    }

    @Override
    protected boolean method_25361(double mouseX, double mouseY) {
        return method_25405(mouseX, mouseY);
    }

    protected void renderButton(class_332 context) {
        boolean displayHovered = method_49606() && widget.actions() != null;
        int color = (180 << 24) | (displayHovered ? widget.hoverColor() : widget.currentColor());

        drawArcSegment(context, color);

        if (!hasIcon) return;

        // Render item at the midpoint of the arc
        float midAngleDeg = (startAngle + endAngle) / 2f;
        float midRadius = (innerRadius + outerRadius) / 2f;
        double midAngleRad = Math.toRadians(midAngleDeg - 90);
        int iconX = centerX + (int) (midRadius * Math.cos(midAngleRad)) - 8;
        int iconY = centerY + (int) (midRadius * Math.sin(midAngleRad)) - 8;

        class_1799 preview = widget.preview();
        context.method_51427(preview, iconX, iconY);
    }

    /**
     * Draws the arc segment pixel-by-pixel using context.fill() for each scanline row.
     * This goes through MC's standard rendering pipeline and is guaranteed to be visible.
     */
    private void drawArcSegment(class_332 context, int color) {
        int oR = (int) Math.ceil(outerRadius);

        for (int dy = -oR; dy <= oR; dy++) {
            // For this row, find the horizontal extent within the arc
            int startX = Integer.MAX_VALUE;
            int endX = Integer.MIN_VALUE;

            for (int dx = -oR; dx <= oR; dx++) {
                double dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < innerRadius || dist > outerRadius) continue;

                // Angle check (0=top, clockwise)
                double angleRad = Math.atan2(dx, -dy);
                double angleDeg = Math.toDegrees(angleRad);
                if (angleDeg < 0) angleDeg += 360;

                if (isAngleInRange(angleDeg, startAngle, endAngle)) {
                    if (dx < startX) startX = dx;
                    if (dx > endX) endX = dx;
                }
            }

            if (startX <= endX) {
                context.method_25294(centerX + startX, centerY + dy, centerX + endX + 1, centerY + dy + 1, color);
            }
        }
    }

    @Override
    public boolean method_25402(double d, double e, int i) {
        if (this.field_22763 && this.field_22764) {
            if (i == 0 || i == 1) {
                if (this.method_25361(d, e)) {
                    this.method_25354(class_310.method_1551().method_1483());

                    if (i == 0) this.method_25306();
                    else this.onAltPress();

                    return true;
                }
            }
        }

        return false;
    }

    public void onAltPress() {
        class_310 client = class_310.method_1551();

        if (client.field_1755 instanceof WheelScreen wheelScreen)
            wheelScreen.altClick(widget);
    }

    @Override
    public void method_25306() {
        class_310 client = class_310.method_1551();

        if (client.field_1755 instanceof WheelScreen wheelScreen)
            wheelScreen.click(widget);
    }
}