package dev.amble.ait.fabric.interop.trinkets;

import com.google.common.collect.Multimap;
import dev.amble.ait.common.items.AitBaubleItem;
import dev.emi.trinkets.api.SlotReference;
import dev.emi.trinkets.api.Trinket;
import dev.emi.trinkets.api.TrinketsApi;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class TrinketsApiInterop {
    public static void init() {
        class_7923.field_41178.method_10220().forEach(item -> {
            if (item instanceof AitBaubleItem bauble) {
                TrinketsApi.registerTrinket(item, new Trinket() {

                    @Override
                    public Multimap<class_6880<class_1320>, class_1322> getModifiers(class_1799 stack, SlotReference slot, class_1309 entity, class_2960 slotIdentifier) {
                        var map = Trinket.super.getModifiers(stack, slot, entity, slotIdentifier);
                        map.putAll(bauble.getAttrs(stack));
                        return map;
                    }
                });
            }
        });
    }

    @Environment(EnvType.CLIENT)
    @SuppressWarnings("EmptyMethod")
    public static void clientInit() {
//        TrinketRendererRegistry.registerRenderer
    }
}
