package dev.amble.ait.client.renderer;

import net.minecraft.class_332;
import net.minecraft.class_9779;

public class AitAdditionalRenderers {

    @SuppressWarnings({"EmptyMethod", "unused"})
    public static void overlayGui(class_332 graphics, class_9779 deltaTracker) {
    }
}
