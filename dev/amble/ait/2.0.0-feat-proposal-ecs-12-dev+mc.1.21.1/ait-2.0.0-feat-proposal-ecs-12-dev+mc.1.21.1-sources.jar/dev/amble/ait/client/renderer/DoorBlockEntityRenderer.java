package dev.amble.ait.client.renderer;

import dev.amble.ait.client.model.DoorGeoModel;
import dev.amble.ait.common.blocks.DoorBlock;
import dev.amble.ait.common.blocks.DoorBlockEntity;
import net.minecraft.class_2350;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class DoorBlockEntityRenderer extends GeoBlockRenderer<DoorBlockEntity> {

    public DoorBlockEntityRenderer(class_5614.class_5615 ignoredContext) {
        super(new DoorGeoModel());
        addRenderLayer(new DoorEmissiveLayer(this));
    }

    @Override
    protected void rotateBlock(class_2350 facing, class_4587 poseStack) {
    }

    @Override
    public void preRender(class_4587 poseStack, DoorBlockEntity entity, BakedGeoModel model,
                          @Nullable class_4597 bufferSource, @Nullable class_4588 buffer,
                          boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                          int colour) {
        if (!isReRender) {
            int rotation = entity.method_11010().method_11654(DoorBlock.ROTATION);
            boolean onSlab = entity.isOnSlab();
            boolean between = entity.isBetween();

            double xOff = 0.5;
            double yOff = onSlab ? -0.5 : 0;
            double zOff = 0.5;

            if (between) {
                double[][] offsets = DoorBlock.BETWEEN_OFFSETS;
                xOff += offsets[rotation][0];
                zOff += offsets[rotation][2];
            }

            poseStack.method_22904(xOff, yOff, zOff);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation * -45f));
        }

        if (entity.needsSnap()) {
            DoorBlockEntity.DoorState state = entity.getDoorState();
            float rightY = (float) Math.toRadians(77.5);
            float leftY = (float) Math.toRadians(-77.5);

            if (state == DoorBlockEntity.DoorState.RIGHT_OPEN || state == DoorBlockEntity.DoorState.BOTH_OPEN) {
                setDoorBoneRotation(model, "door_r", rightY);
                setDoorBoneRotation(model, "RDoor", rightY);
            }
            if (state == DoorBlockEntity.DoorState.BOTH_OPEN) {
                setDoorBoneRotation(model, "door_l", leftY);
                setDoorBoneRotation(model, "LDoor", leftY);
            }
            entity.clearSnap();
        }
    }

    private static void setDoorBoneRotation(BakedGeoModel model, String boneName, float rotY) {
        model.getBone(boneName).ifPresent(bone -> bone.setRotY(rotY));
    }
}
