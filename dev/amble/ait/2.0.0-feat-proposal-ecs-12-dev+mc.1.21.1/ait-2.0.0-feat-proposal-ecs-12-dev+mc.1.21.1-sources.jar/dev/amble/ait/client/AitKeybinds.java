package dev.amble.ait.client;

import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class AitKeybinds {

    public static final class_304 SONIC_WHEEL = new class_304(
            "key.ait.sonic_wheel",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_R,
            "key.categories.ait"
    );

    public static final class_304 SONIC_TOGGLE = new class_304(
            "key.ait.sonic_toggle",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_V,
            "key.categories.ait"
    );
}

