package dev.amble.ait.common.items;

import com.google.common.collect.Multimap;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1799;
import net.minecraft.class_6880;

public interface AitBaubleItem {
    Multimap<class_6880<class_1320>, class_1322> getAttrs(class_1799 stack);
}
