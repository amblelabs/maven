package dev.amble.ait.fabric.datagen.tag;

import dev.amble.ait.xplat.IXplatTags;
import dev.amble.lib.fabric.datagen.FabricAmbleBlockTagProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class AitBlockTagProvider extends FabricAmbleBlockTagProvider {
    @SuppressWarnings({"FieldCanBeLocal", "unused"})
    private final IXplatTags xtags;

    public AitBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> lookupProvider, IXplatTags xtags) {
        super(output, lookupProvider);
        this.xtags = xtags;
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {

    }
}