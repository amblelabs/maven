package dev.amble.ait.xplat;

import dev.amble.ait.api.AitAPI;
import java.util.ServiceLoader;
import java.util.stream.Collectors;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1800;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_8710;

@SuppressWarnings("unused")
public interface IClientXplatAbstractions {
    void sendPacketToServer(class_8710 packet);

    void setRenderLayer(class_2248 block, class_1921 type);

    void initPlatformSpecific();

    <T extends class_1297> void registerEntityRenderer(class_1299<? extends T> type, class_5617<T> renderer);

    @SuppressWarnings("deprecation")
    void registerItemProperty(class_1792 item, class_2960 id, class_1800 func);

    IClientXplatAbstractions INSTANCE = find();

    private static IClientXplatAbstractions find() {
        var providers = ServiceLoader.load(IClientXplatAbstractions.class).stream().toList();

        if (providers.size() != 1) {
            var names = providers.stream().map(p -> p.type().getName()).collect(Collectors.joining(",", "[", "]"));
            throw new IllegalStateException(
                "There should be exactly one IClientXplatAbstractions implementation on the classpath. Found: " + names);
        } else {
            var provider = providers.getFirst();
            AitAPI.LOGGER.debug("Instantiating client xplat impl: {}", provider.type().getName());
            return provider.get();
        }
    }
}