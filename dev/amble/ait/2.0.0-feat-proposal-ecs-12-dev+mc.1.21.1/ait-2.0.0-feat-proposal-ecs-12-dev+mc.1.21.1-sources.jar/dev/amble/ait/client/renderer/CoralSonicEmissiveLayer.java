package dev.amble.ait.client.renderer;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.items.ItemSonic;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

public class CoralSonicEmissiveLayer extends GeoRenderLayer<ItemSonic> {

    private static final class_2960 GLOWMASK = AitAPI.modLoc("textures/item/sonic_tools/coral_glowmask.png");
    private static final int FULLBRIGHT = 0xF000F0;

    public CoralSonicEmissiveLayer(GeoRenderer<ItemSonic> renderer) {
        super(renderer);
    }

    @Override
    public void render(class_4587 poseStack, ItemSonic animatable, BakedGeoModel bakedModel,
                       @Nullable class_1921 renderType, class_4597 bufferSource,
                       @Nullable class_4588 buffer, float partialTick, int packedLight, int packedOverlay) {
        class_1657 player = class_310.method_1551().field_1724;
        if (player == null) return;

        if (!player.method_6115()) return;

        class_1799 usingItem = player.method_6030();
        if (!(usingItem.method_7909() instanceof ItemSonic)) return;

        if (class_310.method_1551().method_1478().method_14486(GLOWMASK).isEmpty()) return;

        class_1921 emissiveType = class_1921.method_23026(GLOWMASK);
        class_4588 emissiveConsumer = bufferSource.getBuffer(emissiveType);

        for (GeoBone bone : bakedModel.topLevelBones()) {
            getRenderer().renderRecursively(poseStack, animatable, bone, emissiveType, bufferSource,
                    emissiveConsumer, true, partialTick, FULLBRIGHT, packedOverlay, 0xFFFFFFFF);
        }
    }
}
