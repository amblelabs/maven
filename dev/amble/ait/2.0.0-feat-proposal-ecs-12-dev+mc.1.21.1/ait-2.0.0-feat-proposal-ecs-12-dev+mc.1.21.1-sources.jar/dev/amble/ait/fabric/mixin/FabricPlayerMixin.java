package dev.amble.ait.fabric.mixin;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class FabricPlayerMixin extends class_1309 {
    protected FabricPlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(at = @At("RETURN"), method = "createAttributes")
    private static void liquor$addAttributes(CallbackInfoReturnable<class_5132.class_5133> cir) {
        var out = cir.getReturnValue();
        //
    }
}