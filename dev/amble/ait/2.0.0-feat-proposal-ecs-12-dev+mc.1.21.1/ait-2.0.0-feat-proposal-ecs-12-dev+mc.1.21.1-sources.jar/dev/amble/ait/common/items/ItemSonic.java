package dev.amble.ait.common.items;

import dev.amble.ait.api.mod.AitTags;
import dev.amble.ait.client.renderer.CoralSonicItemRenderer;
import dev.amble.ait.common.items.components.SonicCrystals;
import dev.amble.ait.common.items.components.SonicData;
import dev.amble.ait.common.items.tooltips.SonicTooltip;
import dev.amble.ait.common.lib.AitComponents;
import dev.amble.ait.common.sonic.SonicCrystal;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_5328;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_5632;
import net.minecraft.class_756;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.apache.commons.lang3.math.Fraction;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class ItemSonic extends class_1792 implements GeoItem {

    private static final int BAR_COLOR = class_3532.method_15353(0.4F, 0.4F, 1.0F);
    public static final int TOOLTIP_MAX_WEIGHT = 4;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private static final RawAnimation OPEN = RawAnimation.begin().thenPlay("open");
    private static final RawAnimation CLOSE = RawAnimation.begin().thenPlay("close");

    public ItemSonic(class_1793 properties) {
        super(properties);
    }

    @Override
    public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        consumer.accept(new GeoRenderProvider() {
            private @Nullable CoralSonicItemRenderer renderer;

            @Override
            public class_756 getGeoItemRenderer() {
                if (this.renderer == null)
                    this.renderer = new CoralSonicItemRenderer();

                return this.renderer;
            }
        });
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "sonic_state", 2, state -> {
            class_1799 stack = state.getData(software.bernie.geckolib.constant.DataTickets.ITEMSTACK);
            if (stack != null && isOpened(stack)) {
                return state.setAndContinue(OPEN);
            }
            return state.setAndContinue(CLOSE);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public boolean method_31566(class_1799 screwdriver, class_1799 other, class_1735 slot, class_5536 clickAction, class_1657 player, class_5630 slotAccess) {
        if (clickAction != class_5536.field_27014 || !slot.method_32754(player))
            return false;

        if (other.method_7960())
            return false;

        if (!other.method_31573(AitTags.Items.ZEITON_SHARDS) || !(other.method_7909() instanceof ItemCrystal))
            return false;

        SonicCrystals contents = screwdriver.method_57824(AitComponents.SONIC_CRYSTALS);
        if (contents == null) return false;

        SonicCrystals.Mutable mutable = new SonicCrystals.Mutable(contents);

        int i = mutable.tryInsert(other);

        if (i > 0) {
            this.playInsertSound(player);
        }

        screwdriver.method_57379(AitComponents.SONIC_CRYSTALS, mutable.toImmutable());
        return true;
    }

    @Override
    public boolean method_31565(class_1799 itemStack, class_1735 slot, class_5536 clickAction, class_1657 player) {
        if (clickAction != class_5536.field_27014) return false;

        SonicCrystals bundleContents = itemStack.method_57824(AitComponents.SONIC_CRYSTALS);
        if (bundleContents == null) return false;

        class_1799 itemStack2 = slot.method_7677();
        if (!itemStack2.method_7960()) return false;

        SonicCrystals.Mutable mutable = new SonicCrystals.Mutable(bundleContents);
        this.playRemoveOneSound(player);

        class_1799 itemStack3 = mutable.removeOne();

        if (itemStack3 != null) {
            class_1799 itemStack4 = slot.method_32756(itemStack3);
            mutable.tryInsert(itemStack4);
        }

        itemStack.method_57379(AitComponents.SONIC_CRYSTALS, mutable.toImmutable());
        return true;
    }

    @Override
    public boolean method_31567(class_1799 itemStack) {
        SonicCrystals bundleContents = itemStack.method_57825(AitComponents.SONIC_CRYSTALS, SonicCrystals.EMPTY);
        return bundleContents.weight().compareTo(Fraction.ZERO) > 0;
    }

    @Override
    public int method_31569(class_1799 itemStack) {
        SonicCrystals bundleContents = itemStack.method_57825(AitComponents.SONIC_CRYSTALS, SonicCrystals.EMPTY);
        return Math.min(1 + class_3532.method_59515(bundleContents.weight(), 12), 13);
    }

    @Override
    public int method_31571(class_1799 itemStack) {
        return BAR_COLOR;
    }

    @Override
    public Optional<class_5632> method_32346(class_1799 itemStack) {
        return !itemStack.method_57826(class_9334.field_50074) && !itemStack.method_57826(class_9334.field_49638)
                ? Optional.ofNullable(itemStack.method_57824(AitComponents.SONIC_CRYSTALS)).map(SonicTooltip::new) : Optional.empty();
    }

    @Override
    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> lines, class_1836 flag) {
        SonicCrystals contents = stack.method_57824(AitComponents.SONIC_CRYSTALS);

        if (contents != null) {
            int i = class_3532.method_59515(contents.weight(), TOOLTIP_MAX_WEIGHT);
            lines.add(class_2561.method_43469("item.minecraft.bundle.fullness", i, TOOLTIP_MAX_WEIGHT).method_27692(class_124.field_1080));
        }

        SonicCrystal.SonicFunction function = function(stack);

        lines.add(function != null ? function.name() : class_2561.method_43473());
        lines.add(class_2561.method_43471(this.method_7876() + ".desc").method_27695(class_124.field_1080, class_124.field_1056));
    }

    @Override
    public void method_33261(class_1542 entity) {
        SonicCrystals contents = entity.method_6983().method_57824(AitComponents.SONIC_CRYSTALS);

        if (contents != null) {
            entity.method_6983().method_57379(AitComponents.SONIC_CRYSTALS, SonicCrystals.EMPTY);
            class_5328.method_33263(entity, contents.itemsCopy());
        }
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slotId, boolean isSelected) {
        if (!world.field_9236 && world instanceof net.minecraft.class_3218 serverLevel) {
            GeoItem.getOrAssignId(stack, serverLevel);
        }
    }

    @Override
    public class_1839 method_7853(class_1799 itemStack) {
        return class_1839.field_8953;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        SonicCrystal.SonicFunction mode = function(stack);

        if (mode == null)
            return class_1271.method_22431(stack);

        if (!checkCharge(stack))
            return class_1271.method_22431(stack);

        if (mode.startUsing(stack, world, user, hand)) {
            user.method_6019(hand);
            return class_1271.method_22428(stack);
        }

        return class_1271.method_22431(stack);
    }

    @Override
    public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks) {
        SonicCrystal.SonicFunction mode = function(stack);
        if (mode == null) return;

        int ticks = mode.maxTime() - remainingUseTicks;

        int fuelUsed = mode.tick(stack, world, user, ticks, remainingUseTicks);

        if (fuelUsed == SonicCrystal.SonicFunction.HALT) {
            user.method_6021();
            return;
        }

        removeCharge(stack, fuelUsed);

        if (!checkCharge(stack))
            user.method_6021();
    }

    @Override
    public void method_7840(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks) {
        SonicCrystal.SonicFunction mode = function(stack);
        if (mode == null) return;

        mode.stopUsing(stack, world, user, mode.maxTime() - remainingUseTicks, remainingUseTicks);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 user) {
        SonicCrystal.SonicFunction mode = function(stack);
        if (mode == null) return stack;

        mode.finishUsing(stack, level, user);
        return stack;
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 entity) {
        SonicCrystal.SonicFunction function = function(stack);
        return function != null ? function.maxTime() : 0;
    }

    @SuppressWarnings({"EmptyMethod", "unused"})
    private static void removeCharge(class_1799 stack, int amount) {
        // TODO: implement this
    }

    @SuppressWarnings({"EmptyMethod", "unused"})
    private static void addCharge(class_1799 stack, int amount) {
        // TODO: implement this
    }

    @SuppressWarnings({"BooleanMethodIsAlwaysInverted", "unused", "SameReturnValue"})
    private static boolean checkCharge(class_1799 stack) {
        // TODO: implement this
        return true;
    }

    private static @Nullable SonicCrystal.SonicFunction function(class_1799 stack) {
        int funcIdx = getFunction(stack);
        if (funcIdx == -1) return null;

        int relFuncIdx = funcIdx % 8;
        int crystalIdx = (funcIdx - relFuncIdx) / 8;

        SonicCrystal crystal = getCrystal(stack, crystalIdx);
        if (crystal == null || relFuncIdx >= crystal.functions().length) return null;

        return crystal.functions()[relFuncIdx];
    }

    public static @Nullable SonicCrystal getCrystal(class_1799 stack, int crystalIdx) {
        SonicCrystals crystals = stack.method_57824(AitComponents.SONIC_CRYSTALS);
        if (crystals == null) return null;

        class_1799 crystalStack = crystals.getItem(crystalIdx);
        if (crystalStack == null) return null;

        if (!(crystalStack.method_7909() instanceof ItemCrystal crystalItem)) return null;
        return crystalItem.getCrystal();
    }

    public static int getFunction(class_1799 itemStack) {
        return itemStack.method_57825(AitComponents.SONIC_DATA, SonicData.DEFAULT).function();
    }

    public static void setFunction(class_1799 stack, int funcIdx) {
        SonicData current = stack.method_57825(AitComponents.SONIC_DATA, SonicData.DEFAULT);
        stack.method_57379(AitComponents.SONIC_DATA, current.withFunction(funcIdx));
    }

    public static boolean isOpened(class_1799 stack) {
        return stack.method_57825(AitComponents.SONIC_DATA, SonicData.DEFAULT).opened();
    }

    public static void setOpened(class_1799 stack, boolean opened) {
        SonicData current = stack.method_57825(AitComponents.SONIC_DATA, SonicData.DEFAULT);
        stack.method_57379(AitComponents.SONIC_DATA, current.withOpened(opened));
    }

    public static boolean toggleOpened(class_1799 stack) {
        boolean newState = !isOpened(stack);
        setOpened(stack, newState);
        return newState;
    }

    private void playRemoveOneSound(class_1297 entity) {
        entity.method_5783(class_3417.field_34377, 0.8F, 0.8F + entity.method_37908().method_8409().method_43057() * 0.4F);
    }

    private void playInsertSound(class_1297 entity) {
        entity.method_5783(class_3417.field_34376, 0.8F, 0.8F + entity.method_37908().method_8409().method_43057() * 0.4F);
    }
}
