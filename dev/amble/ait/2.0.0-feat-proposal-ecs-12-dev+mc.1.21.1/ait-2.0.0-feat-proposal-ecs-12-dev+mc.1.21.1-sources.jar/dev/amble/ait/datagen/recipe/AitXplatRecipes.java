package dev.amble.ait.datagen.recipe;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.datagen.IXplatIngredients;
import dev.amble.lib.datagen.AmbleRecipeProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_3981;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import net.minecraft.data.recipes.*;
import java.util.concurrent.CompletableFuture;

@SuppressWarnings("unused")
public class AitXplatRecipes extends AmbleRecipeProvider {

    @SuppressWarnings("FieldCanBeLocal")
    private final IXplatIngredients ingredients;

    public AitXplatRecipes(class_7784 output, CompletableFuture<class_7225.class_7874> future, IXplatIngredients ingredients) {
        super(output, future, AitAPI.MOD_ID);

        this.ingredients = ingredients;
    }

    @Override
    public void method_10419(class_8790 recipeOutput) {

    }

    private void stoneCutterFromTag(class_8790 recipes, class_6862<class_1792> tagKey, class_1792... results) {
        for (class_1792 result : results) {
            class_3981.method_17968(class_1856.method_8106(tagKey), class_7800.field_40634, result)
                    .method_17970("has_item", hasItem(tagKey))
                    .method_17972(recipes, modLoc("stonecutting/" + result));
        }
    }
}