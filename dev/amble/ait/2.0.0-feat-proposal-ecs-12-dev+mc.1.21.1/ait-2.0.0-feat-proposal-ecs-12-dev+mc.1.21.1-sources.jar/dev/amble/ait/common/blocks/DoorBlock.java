package dev.amble.ait.common.blocks;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2482;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2771;
import net.minecraft.class_3532;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

public class DoorBlock extends class_2237 {

    public static final class_2758 ROTATION = class_2758.method_11867("rotation", 0, 7);
    public static final class_2758 TEXTURE = class_2758.method_11867("texture", 0, 4);
    public static final class_2758 LIGHT = class_2758.method_11867("light", 0, 7);
    public static final class_2746 ON_SLAB = class_2746.method_11825("on_slab");
    public static final class_2746 BETWEEN = class_2746.method_11825("between");
    public static final MapCodec<DoorBlock> field_46280 = method_54094(DoorBlock::new);

    public static final double[][] BETWEEN_OFFSETS = {
            { 0.5,   0,  0},
            { 0.354, 0,  0.354},
            { 0,     0,  0.5},
            { 0.354, 0, -0.354},
            { 0.5,   0,  0},
            { 0.354, 0,  0.354},
            { 0,     0,  0.5},
            { 0.354, 0, -0.354}
    };

    private static final class_265[] SHAPES = new class_265[8];
    private static final class_265[] SHAPES_SLAB = new class_265[8];
    private static final class_265[] SHAPES_BETWEEN = new class_265[8];
    private static final class_265[] SHAPES_BETWEEN_SLAB = new class_265[8];

    static {
        SHAPES[0] = class_2248.method_9541(0, 0, 0, 16, 39, 5);
        SHAPES[1] = class_2248.method_9541(4, 0, 4, 16, 39, 16);
        SHAPES[2] = class_2248.method_9541(11, 0, 0, 16, 39, 16);
        SHAPES[3] = class_2248.method_9541(4, 0, 0, 16, 39, 12);
        SHAPES[4] = class_2248.method_9541(0, 0, 11, 16, 39, 16);
        SHAPES[5] = class_2248.method_9541(0, 0, 0, 12, 39, 12);
        SHAPES[6] = class_2248.method_9541(0, 0, 0, 5, 39, 16);
        SHAPES[7] = class_2248.method_9541(0, 0, 4, 12, 39, 16);

        for (int i = 0; i < 8; i++) {
            SHAPES_SLAB[i] = SHAPES[i].method_1096(0, -0.5, 0);
            SHAPES_BETWEEN[i] = SHAPES[i].method_1096(BETWEEN_OFFSETS[i][0], 0, BETWEEN_OFFSETS[i][2]);
            SHAPES_BETWEEN_SLAB[i] = SHAPES_BETWEEN[i].method_1096(0, -0.5, 0);
        }
    }

    public DoorBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664()
                .method_11657(ROTATION, 0)
                .method_11657(TEXTURE, 0)
                .method_11657(LIGHT, 7)
                .method_11657(ON_SLAB, false)
                .method_11657(BETWEEN, false));
    }

    public static class_2251 defaultProps() {
        return class_2251.method_9637()
                .method_31710(class_3620.field_15984)
                .method_9629(50f, 1200f)
                .method_22488()
                .method_9624()
                .method_9634()
                .method_9631(state -> state.method_11654(LIGHT));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ROTATION, TEXTURE, LIGHT, ON_SLAB, BETWEEN);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        int rotation = (class_3532.method_15375((context.method_8044()) / 45.0f + 0.5f) + 4) & 7;
        class_2338 below = context.method_8037().method_10074();
        class_2680 belowState = context.method_8045().method_8320(below);
        boolean crouching = context.method_8036() != null && context.method_8036().method_5715();

        return this.method_9564()
                .method_11657(ROTATION, rotation)
                .method_11657(ON_SLAB, isSlabBottom(belowState))
                .method_11657(BETWEEN, crouching);
    }

    private boolean isSlabBottom(class_2680 state) {
        if (state.method_26204() instanceof class_2482
                && state.method_28498(class_2741.field_12485)) {
            return state.method_11654(class_2741.field_12485) == class_2771.field_12681;
        }
        return false;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        int rotation = state.method_11654(ROTATION);
        boolean slab = state.method_11654(ON_SLAB);
        boolean between = state.method_11654(BETWEEN);

        if (between && slab) return SHAPES_BETWEEN_SLAB[rotation];
        if (between) return SHAPES_BETWEEN[rotation];
        if (slab) return SHAPES_SLAB[rotation];
        return SHAPES[rotation];
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return class_259.method_1073();
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new DoorBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11456;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (level.method_8608()) return class_1269.field_5812;

        class_2586 be = level.method_8321(pos);
        if (be instanceof DoorBlockEntity door) {
            door.interact(player.method_5715());
        }

        return class_1269.field_21466;
    }
}
