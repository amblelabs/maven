package dev.amble.ait.xplat;

import dev.amble.ait.api.AitAPI;
import java.util.ServiceLoader;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3611;
import net.minecraft.class_5341;
import net.minecraft.class_8705;
import net.minecraft.class_8710;

@SuppressWarnings("unused")
public interface IXplatAbstractions {
    Platform platform();

    boolean isModPresent(String id);

    String getModName(String namespace);

    boolean isDev();

    boolean isPhysicalClient();

    void initPlatformSpecific();

    void sendPacketToPlayer(class_3222 target, class_8710 packet);

    void sendPacketNear(class_243 pos, double radius, class_3218 dimension, class_8710 packet);

    void sendPacketTracking(class_1297 entity, class_8710 packet);

    // https://github.com/VazkiiMods/Botania/blob/13b7bcd9cbb6b1a418b0afe455662d29b46f1a7f/Xplat/src/main/java/vazkii/botania/xplat/IXplatAbstractions.java#L157
    class_2596<class_8705> toVanilla(class_8710 message);

    // Blocks

    <T extends class_2586> class_2591<T> createBlockEntityType(BiFunction<class_2338, class_2680, T> func,
        class_2248... blocks);

    boolean tryPlaceFluid(class_1937 level, class_1268 hand, class_2338 pos, class_3611 fluid);

    boolean drainAllFluid(class_1937 level, class_2338 pos);

    // misc

    IXplatTags tags();

    class_5341.class_210 isShearsCondition();

    // TODO:
    // Registry<Stuff> getStuffRegistry();

    IXplatAbstractions INSTANCE = find();

    private static IXplatAbstractions find() {
        var providers = ServiceLoader.load(IXplatAbstractions.class).stream().toList();

        if (providers.size() != 1) {
            var names = providers.stream().map(p -> p.type().getName()).collect(Collectors.joining(",", "[", "]"));
            throw new IllegalStateException(
                "There should be exactly one IXplatAbstractions implementation on the classpath. Found: " + names);
        } else {
            var provider = providers.getFirst();
            AitAPI.LOGGER.debug("Instantiating xplat impl: {}", provider.type().getName());
            return provider.get();
        }
    }
}