package dev.amble.ait.common.lib;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_8177;

@SuppressWarnings("unused")
public class AitBlockSetTypes {
    public static void registerBlocks(Consumer<class_8177> r) {
        for (var type : TYPES) {
            r.accept(type);
        }
    }

    private static final List<class_8177> TYPES = new ArrayList<>();

    //

    private static class_8177 register(class_8177 type) {
        TYPES.add(type);
        return type;
    }
}