package dev.amble.ait.client.model;

import dev.amble.ait.api.AitAPI;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;


@SuppressWarnings("FieldCanBeLocal")
public class PoliceBoxModel<T extends class_1297> extends class_583<T> {
	// This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into this model's constructor
	public static final class_5601 LAYER_LOCATION = new class_5601(AitAPI.modLoc("policeboxmodel"), "main");
	private final class_630 base;
	private final class_630 roof;
	private final class_630 roof_default;
	private final class_630 roof_t;
	private final class_630 signs;
	private final class_630 sign_n;
	private final class_630 sign_e;
	private final class_630 sign_s;
	private final class_630 sign_w;
	private final class_630 lamp;
	private final class_630 glass;
	private final class_630 top;
	private final class_630 bottom;
	private final class_630 pillars;
	private final class_630 walls;
	private final class_630 doors;
	private final class_630 door_l;
	private final class_630 phone_box;
	private final class_630 sign_pto;
	private final class_630 telephone;
	private final class_630 cable;
	private final class_630 bell1;
	private final class_630 bell2;
	private final class_630 receiver;
	private final class_630 sign_pto_t;
	private final class_630 telephone_t;
	private final class_630 bell1_t;
	private final class_630 bell2_t;
	private final class_630 receiver_t;
	private final class_630 cable_t;
	private final class_630 door_r;
	private final class_630 wall_e;
	private final class_630 wall_s;
	private final class_630 wall_w;

	public PoliceBoxModel(class_630 root) {
		this.base = root.method_32086("base");
		this.roof = this.base.method_32086("roof");
		this.roof_default = this.roof.method_32086("roof_default");
		this.roof_t = this.roof.method_32086("roof_t");
		this.signs = this.roof.method_32086("signs");
		this.sign_n = this.signs.method_32086("sign_n");
		this.sign_e = this.signs.method_32086("sign_e");
		this.sign_s = this.signs.method_32086("sign_s");
		this.sign_w = this.signs.method_32086("sign_w");
		this.lamp = this.roof.method_32086("lamp");
		this.glass = this.lamp.method_32086("glass");
		this.top = this.lamp.method_32086("top");
		this.bottom = this.lamp.method_32086("bottom");
		this.pillars = this.base.method_32086("pillars");
		this.walls = this.base.method_32086("walls");
		this.doors = this.walls.method_32086("doors");
		this.door_l = this.doors.method_32086("door_l");
		this.phone_box = this.door_l.method_32086("phone_box");
		this.sign_pto = this.door_l.method_32086("sign_pto");
		this.telephone = this.sign_pto.method_32086("telephone");
		this.cable = this.telephone.method_32086("cable");
		this.bell1 = this.telephone.method_32086("bell1");
		this.bell2 = this.telephone.method_32086("bell2");
		this.receiver = this.telephone.method_32086("receiver");
		this.sign_pto_t = this.door_l.method_32086("sign_pto_t");
		this.telephone_t = this.sign_pto_t.method_32086("telephone_t");
		this.bell1_t = this.telephone_t.method_32086("bell1_t");
		this.bell2_t = this.telephone_t.method_32086("bell2_t");
		this.receiver_t = this.telephone_t.method_32086("receiver_t");
		this.cable_t = this.telephone_t.method_32086("cable_t");
		this.door_r = this.doors.method_32086("door_r");
		this.wall_e = this.walls.method_32086("wall_e");
		this.wall_s = this.walls.method_32086("wall_s");
		this.wall_w = this.walls.method_32086("wall_w");
	}

	public static class_5607 createBodyLayer() {
		class_5609 meshdefinition = new class_5609();
		class_5610 partdefinition = meshdefinition.method_32111();

		class_5610 base = partdefinition.method_32117("base", class_5606.method_32108().method_32101(0, 0).method_32098(-12.0F, 22.125F, -12.0F, 24.0F, 2.0F, 24.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, -0.125F, 0.0F));

		class_5610 roof = base.method_32117("roof", class_5606.method_32108(), class_5603.method_32090(12.0F, -10.875F, -12.0F));

		class_5610 roof_default = roof.method_32117("roof_default", class_5606.method_32108().method_32101(0, 58).method_32098(-10.0F, -6.0F, -10.0F, 20.0F, 2.0F, 20.0F, new class_5605(0.0F))
				.method_32101(0, 27).method_32098(-11.0F, -4.0F, -11.0F, 22.0F, 8.0F, 22.0F, new class_5605(0.0F)), class_5603.method_32090(-12.0F, -4.0F, 12.0F));

		class_5610 roof_t = roof.method_32117("roof_t", class_5606.method_32108().method_32101(0, 151).method_32098(-10.0F, -5.0F, -10.0F, 20.0F, 1.0F, 20.0F, new class_5605(0.0F))
				.method_32101(0, 173).method_32098(-9.0F, -6.0F, -9.0F, 18.0F, 1.0F, 18.0F, new class_5605(0.0F)), class_5603.method_32090(-12.0F, -4.0F, 12.0F));

		class_5610 signs = roof.method_32117("signs", class_5606.method_32108(), class_5603.method_32090(-12.0F, 0.0F, 12.0F));

		class_5610 sign_n = signs.method_32117("sign_n", class_5606.method_32108().method_32101(116, 28).method_32098(-9.5F, -4.5F, -12.6F, 19.0F, 3.0F, 0.0F, new class_5605(0.0F))
				.method_32101(116, 0).method_32098(-10.0F, -5.0F, -12.5F, 20.0F, 4.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 sign_e = signs.method_32117("sign_e", class_5606.method_32108().method_32101(119, 32).method_32098(-9.5F, -4.5F, -12.6F, 19.0F, 3.0F, 0.0F, new class_5605(0.0F))
				.method_32101(116, 7).method_32098(-10.0F, -5.0F, -12.5F, 20.0F, 4.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 sign_s = signs.method_32117("sign_s", class_5606.method_32108().method_32101(119, 36).method_32098(-9.5F, -4.5F, -12.6F, 19.0F, 3.0F, 0.0F, new class_5605(0.0F))
				.method_32101(116, 14).method_32098(-10.0F, -5.0F, -12.5F, 20.0F, 4.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 sign_w = signs.method_32117("sign_w", class_5606.method_32108().method_32101(119, 40).method_32098(-9.5F, -4.5F, -12.6F, 19.0F, 3.0F, 0.0F, new class_5605(0.0F))
				.method_32101(116, 21).method_32098(-10.0F, -5.0F, -12.5F, 20.0F, 4.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 lamp = roof.method_32117("lamp", class_5606.method_32108(), class_5603.method_32090(-12.0F, -9.0F, 12.0F));

		class_5610 glass = lamp.method_32117("glass", class_5606.method_32108().method_32101(119, 57).method_32098(-1.5F, -1.5F, -1.5F, 3.0F, 3.0F, 3.0F, new class_5605(0.0F))
				.method_32101(119, 64).method_32098(-1.5F, -0.5F, -1.5F, 3.0F, 1.0F, 3.0F, new class_5605(0.15F))
				.method_32101(131, 44).method_32098(-2.5F, 0.5F, -2.5F, 5.0F, 0.0F, 5.0F, new class_5605(0.0F))
				.method_32101(131, 49).method_32098(-2.5F, -0.5F, -2.5F, 5.0F, 0.0F, 5.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -3.5F, 0.0F, 0.0F, -0.7854F, 0.0F));

		class_5610 top = lamp.method_32117("top", class_5606.method_32108().method_32101(119, 44).method_32098(-3.4142F, -2.0F, -0.5858F, 4.0F, 2.0F, 4.0F, new class_5605(0.0F)), class_5603.method_32091(2.0F, -5.0F, 0.0F, 0.0F, -0.7854F, 0.0F));

		class_5610 cube_r1 = top.method_32117("cube_r1", class_5606.method_32108().method_32101(71, 81).method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-1.4142F, -2.0F, 1.4142F, 0.0F, -0.7854F, 0.0F));

		class_5610 bottom = lamp.method_32117("bottom", class_5606.method_32108().method_32101(119, 51).method_32098(-2.0F, 1.0F, -2.0F, 4.0F, 1.0F, 4.0F, new class_5605(0.0F))
				.method_32101(71, 85).method_32098(0.0F, -3.0F, -2.5F, 0.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -3.0F, 0.0F, 0.0F, -0.7854F, 0.0F));

		class_5610 cube_r2 = bottom.method_32117("cube_r2", class_5606.method_32108().method_32101(89, 27).method_32098(0.0F, -3.0F, -2.5F, 0.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 cube_r3 = bottom.method_32117("cube_r3", class_5606.method_32108().method_32101(77, 85).method_32098(0.0F, -3.0F, -2.5F, 0.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 cube_r4 = bottom.method_32117("cube_r4", class_5606.method_32108().method_32101(74, 85).method_32098(0.0F, -3.0F, -2.5F, 0.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 pillars = base.method_32117("pillars", class_5606.method_32108().method_32101(0, 81).method_32098(-11.5F, -39.0F, -11.5F, 3.0F, 39.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 22.125F, 0.0F));

		class_5610 cube_r5 = pillars.method_32117("cube_r5", class_5606.method_32108().method_32101(39, 81).method_32098(-11.5F, -39.0F, -11.5F, 3.0F, 39.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 cube_r6 = pillars.method_32117("cube_r6", class_5606.method_32108().method_32101(26, 81).method_32098(-11.5F, -39.0F, -11.5F, 3.0F, 39.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 cube_r7 = pillars.method_32117("cube_r7", class_5606.method_32108().method_32101(13, 81).method_32098(-11.5F, -39.0F, -11.5F, 3.0F, 39.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 walls = base.method_32117("walls", class_5606.method_32108(), class_5603.method_32090(0.0F, 5.625F, 0.0F));

		class_5610 doors = walls.method_32117("doors", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 door_l = doors.method_32117("door_l", class_5606.method_32108().method_32101(52, 81).method_32098(0.0F, -16.5F, 0.0F, 8.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(52, 116).method_32098(8.0F, -16.5F, -0.5F, 1.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(73, 8).method_32098(1.5F, -15.5F, -0.25F, 5.0F, 7.0F, 0.0F, new class_5605(0.025F))
				.method_32101(73, 1).method_32098(1.5F, -15.0F, -0.1F, 5.0F, 6.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32090(-8.5F, 0.0F, -10.5F));

		class_5610 phone_box = door_l.method_32117("phone_box", class_5606.method_32108().method_32101(67, 27).method_32098(1.0F, -7.5F, -1.0F, 6.0F, 7.0F, 0.0F, new class_5605(0.0F))
				.method_32101(65, 40).method_32098(1.0F, -0.5F, -3.0F, 6.0F, 0.0F, 2.0F, new class_5605(0.0F))
				.method_32101(81, 25).method_32098(1.0F, -7.5F, -3.0F, 0.0F, 7.0F, 2.0F, new class_5605(0.0F))
				.method_32101(65, 36).method_32098(1.0F, -7.5F, -3.0F, 6.0F, 0.0F, 2.0F, new class_5605(0.0F))
				.method_32101(81, 33).method_32098(7.0F, -7.5F, -3.0F, 0.0F, 7.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 3.0F));

		class_5610 sign_pto = door_l.method_32117("sign_pto", class_5606.method_32108().method_32101(73, 16).method_32098(0.0F, -3.5F, 0.0F, 6.0F, 7.0F, 0.0F, new class_5605(0.0F))
				.method_32101(84, 1).method_32098(1.5F, -2.0F, -0.1F, 3.0F, 4.0F, 0.0F, new class_5605(0.0F))
				.method_32101(84, 10).method_32098(5.5F, -1.5F, -1.0F, 0.0F, 3.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(1.0F, -4.0F, 0.0F));

		class_5610 telephone = sign_pto.method_32117("telephone", class_5606.method_32108().method_32101(61, 58).method_32098(1.0F, -2.5F, -1.0F, 5.0F, 6.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(-0.5F, -0.5F, 1.0F));

		class_5610 cable = telephone.method_32117("cable", class_5606.method_32108().method_32101(87, 34).method_32098(-2.0F, 0.0F, 0.0F, 4.0F, 6.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(3.0F, 3.0F, 0.0F, 0.0F, 0.3927F, 0.0F));

		class_5610 bell1 = telephone.method_32117("bell1", class_5606.method_32108(), class_5603.method_32090(4.75F, -1.0F, 0.5F));

		class_5610 cube_r8 = bell1.method_32117("cube_r8", class_5606.method_32108().method_32101(74, 64).method_32098(-1.0F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.7854F));

		class_5610 bell2 = telephone.method_32117("bell2", class_5606.method_32108(), class_5603.method_32090(4.75F, 2.0F, 0.5F));

		class_5610 cube_r9 = bell2.method_32117("cube_r9", class_5606.method_32108().method_32101(74, 64).method_32098(-1.0F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.7854F));

		class_5610 receiver = telephone.method_32117("receiver", class_5606.method_32108().method_32101(74, 58).method_32098(-1.0F, -2.5F, -0.5F, 2.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(2.25F, 0.5F, 0.5F));

		class_5610 sign_pto_t = door_l.method_32117("sign_pto_t", class_5606.method_32108().method_32101(7, 163).method_32098(-6.0F, -3.5F, 0.0F, 6.0F, 7.0F, 0.0F, new class_5605(0.0F))
				.method_32101(13, 158).method_32098(-4.5F, -2.0F, -0.1F, 3.0F, 4.0F, 0.0F, new class_5605(0.0F))
				.method_32101(10, 158).method_32098(-5.5F, -1.5F, -1.0F, 0.0F, 3.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(7.0F, -4.0F, 0.0F));

		class_5610 telephone_t = sign_pto_t.method_32117("telephone_t", class_5606.method_32108().method_32101(61, 68).method_32098(1.0F, -2.5F, -1.0F, 5.0F, 6.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(-6.5F, -0.5F, 1.0F));

		class_5610 bell1_t = telephone_t.method_32117("bell1_t", class_5606.method_32108(), class_5603.method_32090(4.75F, -1.0F, 0.5F));

		class_5610 cube_r10 = bell1_t.method_32117("cube_r10", class_5606.method_32108().method_32101(74, 74).method_32098(-1.0F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.7854F));

		class_5610 bell2_t = telephone_t.method_32117("bell2_t", class_5606.method_32108(), class_5603.method_32090(4.75F, 2.0F, 0.5F));

		class_5610 cube_r11 = bell2_t.method_32117("cube_r11", class_5606.method_32108().method_32101(74, 74).method_32098(-1.0F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.7854F));

		class_5610 receiver_t = telephone_t.method_32117("receiver_t", class_5606.method_32108().method_32101(74, 68).method_32098(-1.0F, -2.5F, -0.5F, 2.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(2.25F, 0.5F, 0.5F));

		class_5610 cable_t = telephone_t.method_32117("cable_t", class_5606.method_32108().method_32101(87, 41).method_32098(-2.0F, 0.0F, 0.0F, 4.0F, 6.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(3.0F, 3.0F, 0.0F, 0.0F, 0.3927F, 0.0F));

		class_5610 door_r = doors.method_32117("door_r", class_5606.method_32108().method_32101(81, 58).method_32098(-8.0F, -16.5F, 0.0F, 8.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(73, 8).method_32098(-6.5F, -15.5F, -0.25F, 5.0F, 7.0F, 0.0F, new class_5605(0.025F))
				.method_32101(73, 1).method_32098(-6.5F, -15.0F, -0.1F, 5.0F, 6.0F, 0.0F, new class_5605(0.0F))
				.method_32101(84, 6).method_32098(-6.0F, -6.0F, -0.1F, 4.0F, 4.0F, 0.0F, new class_5605(0.0F))
				.method_32101(87, 10).method_32098(-7.5F, -6.0F, -1.0F, 0.0F, 4.0F, 1.0F, new class_5605(0.0F))
				.method_32101(90, 10).method_32098(-7.5F, -2.0F, -1.0F, 0.0F, 4.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(8.5F, 0.0F, -10.5F));

		class_5610 wall_e = walls.method_32117("wall_e", class_5606.method_32108().method_32101(71, 93).method_32098(-8.5F, -16.5F, -10.5F, 8.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(57, 116).method_32098(-0.5F, -16.5F, -11.0F, 1.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(90, 93).method_32098(0.5F, -16.5F, -10.5F, 8.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(73, 8).method_32098(-7.0F, -15.5F, -10.75F, 5.0F, 7.0F, 0.0F, new class_5605(0.025F))
				.method_32101(73, 1).method_32098(-7.0F, -15.0F, -10.6F, 5.0F, 6.0F, 0.0F, new class_5605(0.0F))
				.method_32101(73, 8).method_32098(2.0F, -15.5F, -10.75F, 5.0F, 7.0F, 0.0F, new class_5605(0.025F))
				.method_32101(73, 1).method_32098(2.0F, -15.0F, -10.6F, 5.0F, 6.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 wall_s = walls.method_32117("wall_s", class_5606.method_32108().method_32101(97, 0).method_32098(-8.5F, -16.5F, -10.5F, 8.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(73, 1).method_32098(-7.0F, -15.0F, -10.6F, 5.0F, 6.0F, 0.0F, new class_5605(0.0F))
				.method_32101(73, 8).method_32098(-7.0F, -15.5F, -10.75F, 5.0F, 7.0F, 0.0F, new class_5605(0.01F))
				.method_32101(62, 116).method_32098(-0.5F, -16.5F, -11.0F, 1.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(100, 35).method_32098(0.5F, -16.5F, -10.5F, 8.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(73, 8).method_32098(2.0F, -15.5F, -10.75F, 5.0F, 7.0F, 0.0F, new class_5605(0.01F))
				.method_32101(73, 1).method_32098(2.0F, -15.0F, -10.6F, 5.0F, 6.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 wall_w = walls.method_32117("wall_w", class_5606.method_32108().method_32101(109, 70).method_32098(-8.5F, -16.5F, -10.5F, 8.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(0, 124).method_32098(-0.5F, -16.5F, -11.0F, 1.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(109, 105).method_32098(0.5F, -16.5F, -10.5F, 8.0F, 33.0F, 1.0F, new class_5605(0.0F))
				.method_32101(73, 8).method_32098(-7.0F, -15.5F, -10.75F, 5.0F, 7.0F, 0.0F, new class_5605(0.025F))
				.method_32101(73, 1).method_32098(-7.0F, -15.0F, -10.6F, 5.0F, 6.0F, 0.0F, new class_5605(0.0F))
				.method_32101(73, 8).method_32098(2.0F, -15.5F, -10.75F, 5.0F, 7.0F, 0.0F, new class_5605(0.025F))
				.method_32101(73, 1).method_32098(2.0F, -15.0F, -10.6F, 5.0F, 6.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.5708F, 0.0F));

		return class_5607.method_32110(meshdefinition, 256, 256);
	}

	@Override
	public void method_2819(T entity, float f, float g, float h, float i, float j) {

	}

	@Override
	public void method_2828(class_4587 poseStack, class_4588 vertexConsumer, int i, int j, int k) {
		base.method_22699(poseStack, vertexConsumer, i, j, k);
	}
}