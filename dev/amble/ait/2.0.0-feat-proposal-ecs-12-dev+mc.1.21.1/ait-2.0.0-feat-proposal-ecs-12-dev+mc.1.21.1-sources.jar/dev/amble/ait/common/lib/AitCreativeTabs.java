package dev.amble.ait.common.lib;

import dev.amble.ait.api.AitAPI;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

import static dev.amble.ait.api.AitAPI.modLoc;

public class AitCreativeTabs {
    public static void registerCreativeTabs(BiConsumer<class_1761, class_2960> r) {
        for (var e : TABS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_1761> TABS = new LinkedHashMap<>();

    public static final class_1761 AIT = register("main", class_1761.method_47307(class_1761.class_7915.field_41049, 7)
            .method_47320(() -> new class_1799(AitItems.SCREWDRIVER)));

    @SuppressWarnings("SameParameterValue")
    private static class_1761 register(String name, class_1761.class_7913 tabBuilder) {
        var tab = tabBuilder.method_47321(class_2561.method_43471("itemGroup." + AitAPI.MOD_ID + "." + name)).method_47324();
        var old = TABS.put(modLoc(name), tab);

        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }

        return tab;
    }
}