package dev.amble.ait.common.sonic;

import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public record SonicCrystal(SonicFunction... functions) {

    public static final SonicCrystal EMPTY = new SonicCrystal();
    public static final SonicCrystal BASIC = new SonicCrystal(new SetOnFireSonicFunction());
    public static final SonicCrystal OVERCHARGED = new SonicCrystal(new SetOnFireSonicFunction());
    public static final SonicCrystal RESONATING = new SonicCrystal(new SetOnFireSonicFunction());
    public static final SonicCrystal GRAVITY = new SonicCrystal(new GravitateSonicFunction(), new GravityPushSonicFunction());
    public static final SonicCrystal REFRACTION = new SonicCrystal(new LaserSonicFunction());
    public static final SonicCrystal AMETHYST = new SonicCrystal(new SetOnFireSonicFunction());
    public static final SonicCrystal QUARTZ = new SonicCrystal(new HighFrequencySonicFunction());
    public static final SonicCrystal ECHO_SHARD = new SonicCrystal(new DisarmSonicFunction());

    public interface SonicFunction {
        class_1799 preview();
        class_2561 name();

        int maxTime();

        default boolean startUsing(class_1799 stack, class_1937 level, class_1657 user, class_1268 hand) {
            return true;
        }

        // FIXME: fuel usage, halt, etc should be instead provided either via return type OR via a context arg
        //  instead of this silly magic number shit
        default int tick(class_1799 stack, class_1937 level, class_1309 user, int ticks, int ticksLeft) {
            return 0;
        }

        @SuppressWarnings("EmptyMethod")
        default void stopUsing(class_1799 stack, class_1937 level, class_1309 user, int ticks, int ticksLeft) { }

        default void finishUsing(class_1799 stack, class_1937 level, class_1309 user) {
            this.stopUsing(stack, level, user, this.maxTime(), 0);
        }

        int MAX_DISTANCE = 16;
        int HALT = -256;

        static class_239 getHitResultForOutline(class_1309 user) {
            return getHitResultForOutline(user, MAX_DISTANCE);
        }

        static class_239 getHitResult(class_1309 user) {
            return getHitResult(user, MAX_DISTANCE);
        }

        // FIXME: ported from AIT 1.x
        static class_239 getHitResultForOutline(class_1309 user, double distance) {
            class_243 eyePos = user.method_5836(1.0F);
            class_243 rotation = user.method_5828(1.0F);
            class_243 end = eyePos.method_1019(rotation.method_1021(distance));

            return user.method_37908().method_17742(new class_3959(eyePos, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, user));
        }

        static class_239 getHitResult(class_1309 user, double distance) {
            class_243 eyePos = user.method_5836(1.0F);
            class_243 rotation = user.method_5828(1.0F);
            class_243 end = eyePos.method_1019(rotation.method_1021(distance));

            class_3965 blockHit = user.method_37908().method_17742(new class_3959(eyePos, end, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, user));

            double blockDist = blockHit.method_17783() != class_239.class_240.field_1333
                    ? blockHit.method_17784().method_1025(eyePos) : distance * distance;

            class_3966 entityHit = null;
            double closestEntityDist = blockDist;

            for (var entity : user.method_37908().method_8335(user, user.method_5829().method_18804(rotation.method_1021(distance)).method_1014(1.0))) {
                var aabb = entity.method_5829().method_1014(entity.method_5871());
                var optional = aabb.method_992(eyePos, end);

                if (optional.isPresent()) {
                    double entityDist = eyePos.method_1025(optional.get());
                    if (entityDist < closestEntityDist) {
                        closestEntityDist = entityDist;
                        entityHit = new class_3966(entity, optional.get());
                    }
                }
            }

            return entityHit != null ? entityHit : blockHit;
        }
    }
}
