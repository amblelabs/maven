package dev.amble.ait.datagen;

import dev.amble.ait.api.AitAPI;
import dev.amble.lib.datagen.AmbleLootTableSubProvider;
import net.minecraft.class_104;
import net.minecraft.class_141;
import net.minecraft.class_212;
import net.minecraft.class_2248;
import net.minecraft.class_2482;
import net.minecraft.class_2771;
import net.minecraft.class_44;
import net.minecraft.class_4559;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.world.level.storage.loot.predicates.*;
import java.util.Map;

@SuppressWarnings("unused")
public class AitLootTables extends AmbleLootTableSubProvider {

    public AitLootTables() {
        super(AitAPI.MOD_ID);
    }

    @Override
    protected void makeLootTables(Map<class_2248, class_52.class_53> blockTables, Map<class_5321<class_52>, class_52.class_53> lootTables) {

    }

    private void makeSlabTable(Map<class_2248, class_52.class_53> lootTables, class_2248 block) {
        var leafPool = dropThisPool(block, 1)
            .method_353(class_141.method_621(class_44.method_32448(2))
                .method_524(new class_212.class_213(block).method_22584(
                    class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682)
                )))
            .method_353(class_104.method_478());
        lootTables.put(block, class_52.method_324().method_336(leafPool));
    }
}