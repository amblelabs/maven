package dev.amble.ait.client.screen.wheel.action;

import dev.amble.ait.client.screen.wheel.Widget;
import net.minecraft.class_310;

/**
 * @author drtheodor
 * From hex-spell-wheel
 */
public record AndAction(Action... actions) implements Action {

    @Override
    public void run(class_310 client, Widget widget) {
        for (Action action : actions) {
            action.run(client, widget);
        }
    }

    @Override
    public void runAlt(class_310 client, Widget widget) {
        for (Action action : actions) {
            action.runAlt(client, widget);
        }
    }
}