package dev.amble.ait.common.blocks.behavior;

import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_3962;

public final class AitComposting {

    @SuppressWarnings("EmptyMethod")
    public static void setup() {

    }

    @SuppressWarnings("unused")
    private static void compost(class_1935 itemLike, float chance) {
        class_1792 item = itemLike.method_8389();

        if (item != class_1802.field_8162) {
            class_3962.field_17566.put(item, chance);
        }
    }
}