package dev.amble.ait.common.sonic;

import dev.amble.ait.common.I18n;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class HighFrequencySonicFunction implements SonicCrystal.SonicFunction {

    private static final double RANGE = 8.0;
    private static final int STUN_DURATION = 100;

    @Override
    public class_1799 preview() {
        return new class_1799(class_1802.field_8643);
    }

    @Override
    public class_2561 name() {
        return I18n.FUNC_ON_HIGH_FREQ;
    }

    @Override
    public int maxTime() {
        return 2 * 20;
    }

    @Override
    public int tick(class_1799 stack, class_1937 level, class_1309 user, int ticks, int ticksLeft) {
        if (!canActivate(ticks)) return 1;
        if (!(user instanceof class_1657 player)) return SonicCrystal.SonicFunction.HALT;

        class_238 area = user.method_5829().method_1014(RANGE);
        List<class_1309> targets = level.method_8390(class_1309.class, area, e -> e != user && e.method_5805());

        if (targets.isEmpty()) return SonicCrystal.SonicFunction.HALT;

        for (class_1309 target : targets) {
            target.method_26082(new class_1293(class_1294.field_5909, STUN_DURATION, 5), player);
            target.method_26082(new class_1293(class_1294.field_5919, STUN_DURATION, 0), player);
            target.method_26082(new class_1293(class_1294.field_5911, STUN_DURATION, 2), player);
        }

        level.method_8396(null, user.method_24515(), class_3417.field_19167, class_3419.field_15248, 2.0F, 0.1F);
        level.method_8396(null, user.method_24515(), class_3417.field_38830, class_3419.field_15248, 0.6F, 2.0F);

        if (level instanceof class_3218 serverLevel) {
            spawnShockwave(serverLevel, user);
        }

        return SonicCrystal.SonicFunction.HALT;
    }

    private static void spawnShockwave(class_3218 level, class_1309 user) {
        double cx = user.method_23317();
        double cy = user.method_23318() + user.method_17682() / 2;
        double cz = user.method_23321();

        for (int i = 0; i < 60; i++) {
            double angle = Math.toRadians(i * 6.0);
            double radius = RANGE * 0.8;
            double px = cx + Math.cos(angle) * radius;
            double pz = cz + Math.sin(angle) * radius;

            level.method_14199(class_2398.field_38908, px, cy, pz, 1, 0, 0, 0, 0);
        }

        level.method_14199(class_2398.field_17909, cx, cy, cz, 1, 0, 0, 0, 0);
    }

    private static boolean canActivate(int ticks) {
        return ticks >= 10;
    }
}

