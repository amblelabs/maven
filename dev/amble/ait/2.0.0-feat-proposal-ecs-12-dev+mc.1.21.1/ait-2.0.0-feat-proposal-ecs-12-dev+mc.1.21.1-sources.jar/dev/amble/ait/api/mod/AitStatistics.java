package dev.amble.ait.api.mod;

import static dev.amble.ait.api.AitAPI.modLoc;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3446;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

@SuppressWarnings("unused")
public class AitStatistics {

    //

    @SuppressWarnings("EmptyMethod")
    public static void register() {
    }

    private static class_2960 makeCustomStat(String key, class_3446 formatter) {
        class_2960 resourcelocation = modLoc(key);
        class_2378.method_10226(class_7923.field_41183, key, resourcelocation);
        class_3468.field_15419.method_14955(resourcelocation, formatter);
        return resourcelocation;
    }
}