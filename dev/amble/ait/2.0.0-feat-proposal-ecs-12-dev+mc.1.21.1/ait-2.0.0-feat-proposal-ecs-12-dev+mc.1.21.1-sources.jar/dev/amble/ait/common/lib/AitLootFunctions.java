package dev.amble.ait.common.lib;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_5339;

import static dev.amble.ait.api.AitAPI.modLoc;

@SuppressWarnings("unused")
public class AitLootFunctions {
    public static void registerSerializers(BiConsumer<class_5339<?>, class_2960> r) {
        for (var e : LOOT_FUNCS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_5339<?>> LOOT_FUNCS = new LinkedHashMap<>();

    //

    private static class_5339<?> register(String id, class_5339<?> lift) {
        var old = LOOT_FUNCS.put(modLoc(id), lift);
        if (old != null) throw new IllegalArgumentException("Duplicate id " + id);

        return lift;
    }
}