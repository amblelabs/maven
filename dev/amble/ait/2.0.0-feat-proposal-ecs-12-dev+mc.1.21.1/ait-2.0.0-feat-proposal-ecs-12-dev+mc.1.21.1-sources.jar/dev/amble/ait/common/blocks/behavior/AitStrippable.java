package dev.amble.ait.common.blocks.behavior;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2248;

public class AitStrippable {

    public static final Map<class_2248, class_2248> STRIPPABLE = new HashMap<>();

    @SuppressWarnings("EmptyMethod")
    public static void init() {

    }
}