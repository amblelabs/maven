package dev.amble.ait.common.network;

import dev.amble.ait.api.AitAPI;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SonicTogglePayload(boolean opened) implements class_8710 {

    public static final class_2960 ID = AitAPI.modLoc("sonic_toggle");
    public static final class_9154<SonicTogglePayload> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, SonicTogglePayload> STREAM_CODEC =
            class_9139.method_56434(class_9135.field_48547, SonicTogglePayload::opened, SonicTogglePayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
