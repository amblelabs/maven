package dev.amble.ait.common.lib;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1842;
import net.minecraft.class_2960;

import static dev.amble.ait.api.AitAPI.modLoc;

@SuppressWarnings("unused")
public class AitPotions {
    public static void register(BiConsumer<class_1842, class_2960> r) {
        for (var e : POTIONS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
        AitPotions.addRecipes();
    }

    private static final Map<class_2960, class_1842> POTIONS = new LinkedHashMap<>();

    //

    @SuppressWarnings("EmptyMethod")
    public static void addRecipes() {

    }

    private static <T extends class_1842> T make(String id, T potion) {
        var old = POTIONS.put(modLoc(id), potion);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + id);
        }
        return potion;
    }
}