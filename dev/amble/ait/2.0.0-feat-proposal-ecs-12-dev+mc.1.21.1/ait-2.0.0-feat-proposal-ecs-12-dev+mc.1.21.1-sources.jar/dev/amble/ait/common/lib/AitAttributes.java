package dev.amble.ait.common.lib;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1320;
import net.minecraft.class_2960;

import static dev.amble.ait.api.AitAPI.modLoc;

public class AitAttributes {
    public static void register(BiConsumer<class_1320, class_2960> r) {
        for (var e : ATTRIBUTES.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_1320> ATTRIBUTES = new LinkedHashMap<>();

    //

    @SuppressWarnings("unused")
    private static <T extends class_1320> T make(String id, T attr) {
        var old = ATTRIBUTES.put(modLoc(id), attr);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + id);
        }
        return attr;
    }
}