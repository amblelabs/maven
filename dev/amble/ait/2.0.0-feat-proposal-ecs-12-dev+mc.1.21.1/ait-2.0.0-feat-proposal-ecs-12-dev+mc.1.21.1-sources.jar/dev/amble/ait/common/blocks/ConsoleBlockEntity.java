package dev.amble.ait.common.blocks;

import dev.amble.ait.common.lib.AitBlockEntities;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public class ConsoleBlockEntity extends class_2586 implements GeoBlockEntity {

    private static final String ANIM_KEY = "Animation";

    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("Idle");
    private static final RawAnimation FLIGHT = RawAnimation.begin().thenLoop("Flight");
    private static final RawAnimation[] ANIMATIONS = { IDLE, FLIGHT };

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private int animationIndex = 0;

    public ConsoleBlockEntity(class_2338 pos, class_2680 state) {
        super(AitBlockEntities.CONSOLE_BLOCK_ENTITY, pos, state);
    }

    public int getAnimationIndex() {
        return animationIndex;
    }

    public boolean isOnSlab() {
        return this.method_11010().method_11654(ConsoleBlock.ON_SLAB);
    }

    public void cycleAnimation() {
        this.animationIndex = (this.animationIndex + 1) % ANIMATIONS.length;
        this.method_5431();
        if (this.field_11863 != null) {
            this.field_11863.method_8413(this.field_11867, this.method_11010(), this.method_11010(), 3);
        }
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        tag.method_10569(ANIM_KEY, this.animationIndex);
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        this.animationIndex = tag.method_10545(ANIM_KEY) ? tag.method_10550(ANIM_KEY) % ANIMATIONS.length : 0;
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        class_2487 tag = super.method_16887(registries);
        method_11007(tag, registries);
        return tag;
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "console", 5, state -> state.setAndContinue(ANIMATIONS[this.animationIndex % ANIMATIONS.length])));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}


