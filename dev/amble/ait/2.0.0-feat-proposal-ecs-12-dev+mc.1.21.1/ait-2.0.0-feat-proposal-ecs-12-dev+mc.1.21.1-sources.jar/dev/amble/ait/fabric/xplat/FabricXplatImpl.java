package dev.amble.ait.fabric.xplat;

import dev.amble.ait.api.mod.AitTags;
import dev.amble.ait.fabric.interop.trinkets.TrinketsApiInterop;
import dev.amble.ait.interop.AitInterop;
import dev.amble.ait.xplat.IXplatAbstractions;
import dev.amble.ait.xplat.IXplatTags;
import dev.amble.ait.xplat.Platform;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2073;
import net.minecraft.class_223;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3611;
import net.minecraft.class_5341;
import net.minecraft.class_8551;
import net.minecraft.class_8705;
import net.minecraft.class_8710;
import net.minecraft.core.*;
import java.util.Collection;
import java.util.Optional;
import java.util.function.BiFunction;

public class FabricXplatImpl implements IXplatAbstractions {

    @Override
    public Platform platform() {
        return Platform.FABRIC;
    }

    @Override
    public boolean isPhysicalClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }

    @Override
    public boolean isModPresent(String id) {
        return FabricLoader.getInstance().isModLoaded(id);
    }

    @Override
    public void initPlatformSpecific() {
        if (this.isModPresent(AitInterop.Fabric.TRINKETS_API_ID)) {
            TrinketsApiInterop.init();
        }
    }

    @Override
    public void sendPacketToPlayer(class_3222 target, class_8710 packet) {
        ServerPlayNetworking.send(target, packet);
    }

    @Override
    public void sendPacketNear(class_243 pos, double radius, class_3218 dimension, class_8710 packet) {
        sendPacketToPlayers(PlayerLookup.around(dimension, pos, radius), packet);
    }

    @Override
    public void sendPacketTracking(class_1297 entity, class_8710 packet) {
        sendPacketToPlayers(PlayerLookup.tracking(entity), packet);
    }

    private void sendPacketToPlayers(Collection<class_3222> players, class_8710 packet) {
        class_2596<?> pkt = this.toVanilla(packet);

        for (var p : players) {
            p.field_13987.method_14364(pkt);
        }
    }

    @Override
    public class_2596<class_8705> toVanilla(class_8710 message) {
        return ServerPlayNetworking.createS2CPacket(message);
    }

    @Override
    @SuppressWarnings("deprecation")
    public <T extends class_2586> class_2591<T> createBlockEntityType(BiFunction<class_2338, class_2680, T> func, class_2248... blocks) {
        return FabricBlockEntityTypeBuilder.create(func::apply, blocks).build();
    }

    @Override
    public boolean tryPlaceFluid(class_1937 level, class_1268 hand, class_2338 pos, class_3611 fluid) {
        Storage<FluidVariant> target = FluidStorage.SIDED.find(level, pos, class_2350.field_11036);
        if (target == null) {
            return false;
        }
        try (Transaction transaction = Transaction.openOuter()) {
            long insertedAmount = target.insert(FluidVariant.of(fluid), FluidConstants.BUCKET, transaction);
            if (insertedAmount > 0) {
                transaction.commit();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean drainAllFluid(class_1937 level, class_2338 pos) {
        Storage<FluidVariant> target = FluidStorage.SIDED.find(level, pos, class_2350.field_11036);
        if (target == null) {
            return false;
        }
        try (Transaction transaction = Transaction.openOuter()) {
            boolean any = false;
            for (var view : target) {
                long extracted = view.extract(view.getResource(), view.getAmount(), transaction);
                if (extracted > 0) {
                    any = true;
                }
            }

            if (any) {
                transaction.commit();
                return true;
            }
        }
        return false;
    }

    private static final IXplatTags TAGS = new IXplatTags() {

    };

    @Override
    public IXplatTags tags() {
        return TAGS;
    }

    @Override
    public class_5341.class_210 isShearsCondition() {
        return class_8551.method_51727(
            class_223.method_945(class_2073.class_2074.method_8973().method_8977(class_1802.field_8868)),
            class_223.method_945(class_2073.class_2074.method_8973().method_8975(
                AitTags.Items.create(class_2960.method_60655("c", "shears"))))
        );
    }

    @Override
    public String getModName(String namespace) {
        if (namespace.equals("c")) return "Common";

        Optional<ModContainer> container = FabricLoader.getInstance().getModContainer(namespace);
        if (container.isPresent()) return container.get().getMetadata().getName();

        return namespace;
    }

    @Override
    public boolean isDev() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

//    private static final Supplier<Registry<>>  = Suppliers.memoize(() ->
//        FabricRegistryBuilder.from(new DefaultedMappedRegistry<>(
//                LiquorAPI.MOD_ID + ":nothing", LiquorRegistries.,
//                Lifecycle.stable(), false))
//            .buildAndRegister()
//    );
}