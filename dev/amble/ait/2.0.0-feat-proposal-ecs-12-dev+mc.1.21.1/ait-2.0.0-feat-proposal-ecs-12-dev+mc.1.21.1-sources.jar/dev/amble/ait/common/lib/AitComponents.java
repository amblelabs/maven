package dev.amble.ait.common.lib;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.items.components.SonicCrystals;
import dev.amble.ait.common.items.components.SonicData;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.UnaryOperator;
import net.minecraft.class_2960;
import net.minecraft.class_9331;

public class AitComponents {

    public static void registerComponents(BiConsumer<class_9331<?>, class_2960> r) {
        for (var e : COMPONENTS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_9331<?>> COMPONENTS = new LinkedHashMap<>();

    public static final class_9331<SonicCrystals> SONIC_CRYSTALS = make("sonic_crystals",
            builder -> builder.method_57881(SonicCrystals.CODEC)
                    .method_57882(SonicCrystals.STREAM_CODEC).method_59871());

    public static final class_9331<SonicData> SONIC_DATA = make("sonic",
            builder -> builder.method_57881(SonicData.CODEC)
                    .method_57882(SonicData.STREAM_CODEC).method_59871());

    private static <T> class_9331<T> make(String name, UnaryOperator<class_9331.class_9332<T>> unaryOperator) {
        return make(AitAPI.modLoc(name), unaryOperator);
    }

    private static <T> class_9331<T> make(class_2960 loc, UnaryOperator<class_9331.class_9332<T>> unaryOperator) {
        class_9331<T> type = unaryOperator.apply(class_9331.method_57873()).method_57880();
        COMPONENTS.put(loc, type);

        return type;
    }
}