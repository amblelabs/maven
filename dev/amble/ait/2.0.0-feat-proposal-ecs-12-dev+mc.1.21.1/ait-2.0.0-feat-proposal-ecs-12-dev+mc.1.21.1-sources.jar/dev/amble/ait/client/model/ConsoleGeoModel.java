package dev.amble.ait.client.model;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.blocks.ConsoleBlockEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class ConsoleGeoModel extends GeoModel<ConsoleBlockEntity> {

    private static final class_2960 MODEL = AitAPI.modLoc("geo/blockentities/renaissance_console.geo.json");
    private static final class_2960 ANIMATION = AitAPI.modLoc("animations/blockentities/renaissance_console.animation.json");
    private static final class_2960 TEXTURE = AitAPI.modLoc("textures/blockentities/consoles/renaissance_default.png");

    @SuppressWarnings("removal")
    @Override
    public class_2960 getModelResource(ConsoleBlockEntity entity) {
        return MODEL;
    }

    @SuppressWarnings("removal")
    @Override
    public class_2960 getTextureResource(ConsoleBlockEntity entity) {
        return TEXTURE;
    }

    @Override
    public class_2960 getAnimationResource(ConsoleBlockEntity entity) {
        return ANIMATION;
    }
}

