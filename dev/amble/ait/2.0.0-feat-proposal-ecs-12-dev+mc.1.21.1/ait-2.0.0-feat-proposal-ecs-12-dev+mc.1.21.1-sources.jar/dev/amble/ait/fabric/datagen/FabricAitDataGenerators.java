package dev.amble.ait.fabric.datagen;

import dev.amble.ait.datagen.AitLootTables;
import dev.amble.ait.datagen.AitAdvancements;
import dev.amble.ait.datagen.IXplatIngredients;
import dev.amble.ait.datagen.recipe.AitXplatRecipes;
import dev.amble.ait.fabric.datagen.lang.FabricAitLangProvider;
import dev.amble.ait.fabric.datagen.tag.AitBlockTagProvider;
import dev.amble.ait.fabric.datagen.tag.AitItemTagProvider;
import dev.amble.ait.xplat.IXplatAbstractions;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.class_173;
import net.minecraft.class_1792;
import net.minecraft.class_2409;
import net.minecraft.class_2438;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.world.item.*;
import java.util.List;
import java.util.Set;

@SuppressWarnings({"SameParameterValue", "unused"})
public class FabricAitDataGenerators implements DataGeneratorEntrypoint {

    @Override
    public void onInitializeDataGenerator(FabricDataGenerator gen) {
        var pack = gen.createPack();
        var tags = IXplatAbstractions.INSTANCE.tags();

        pack.addProvider((output, lookup) -> new AitXplatRecipes(
                output, lookup, INGREDIENTS));

        var blockTags = new BlockTagProviderWrapper();
        pack.addProvider((output, lookup) -> blockTags.provider = new AitBlockTagProvider(output, lookup, tags));
        pack.addProvider((output, lookup) -> new AitItemTagProvider(output, lookup, blockTags.provider, tags));

        pack.addProvider((output, lookup) -> new class_2438(
                output, Set.of(), List.of(new class_2438.class_7790(provider -> new AitLootTables(),
                class_173.field_1177)), lookup
        ));

        pack.addProvider((output, lookup) -> new class_2409(
                output, lookup, List.of(new AitAdvancements())
        ));

        pack.addProvider((output, lookup) -> new FabricAitModelProvider(output));

        pack.addProvider(FabricAitLangProvider.EnUs::new);
    }

    private static class BlockTagProviderWrapper {
        AitBlockTagProvider provider;
    }

    private static final IXplatIngredients INGREDIENTS = new IXplatIngredients() {

    };

    private static class_6862<class_1792> tag(String s) {
        return tag("c", s);
    }

    private static class_6862<class_1792> tag(String namespace, String s) {
        return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(namespace, s));
    }
}