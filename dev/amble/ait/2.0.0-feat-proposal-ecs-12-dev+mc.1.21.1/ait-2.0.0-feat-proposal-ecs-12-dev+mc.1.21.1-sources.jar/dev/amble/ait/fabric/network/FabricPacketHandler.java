package dev.amble.ait.fabric.network;

import dev.amble.ait.common.items.ItemSonic;
import dev.amble.ait.common.network.SonicTogglePayload;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;

public class FabricPacketHandler {

    public static void init() {
        PayloadTypeRegistry.playC2S().register(SonicTogglePayload.TYPE, SonicTogglePayload.STREAM_CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SonicTogglePayload.TYPE, (payload, context) -> context.player().field_13995.execute(() -> {
            class_1799 mainHand = context.player().method_6047();
            if (mainHand.method_7909() instanceof ItemSonic) {
                ItemSonic.setOpened(mainHand, payload.opened());
            }
        }));
    }

    @SuppressWarnings("EmptyMethod")
    public static void initClient() {
    }
}
