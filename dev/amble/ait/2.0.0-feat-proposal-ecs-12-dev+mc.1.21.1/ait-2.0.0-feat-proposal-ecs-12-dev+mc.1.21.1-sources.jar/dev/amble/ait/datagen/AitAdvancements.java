package dev.amble.ait.datagen;

import dev.amble.ait.api.AitAPI;
import dev.amble.lib.datagen.AmbleAdvancementSubProvider;
import java.util.function.Consumer;
import net.minecraft.class_7225;
import net.minecraft.class_8779;

public class AitAdvancements extends AmbleAdvancementSubProvider {

    public AitAdvancements() {
        super(AitAPI.MOD_ID);
    }

    @Override
    public void method_10335(class_7225.class_7874 provider, Consumer<class_8779> consumer) { }
}