package dev.amble.ait.common.tardis;

import dev.amble.ait.common.tardis.event.init.TardisLifecycleEvents;
import java.util.UUID;
import net.minecraft.class_2487;

public class ServerTardis extends Tardis {

    public ServerTardis(UUID id) {
        super(id);
        TardisLifecycleEvents.handleCreated(this);
    }

    public ServerTardis(UUID id, class_2487 nbt) {
        super(id, nbt, false);
    }

    public void remove() {
        TardisLifecycleEvents.handleRemoved(this);
        this.clearStates();
    }
}