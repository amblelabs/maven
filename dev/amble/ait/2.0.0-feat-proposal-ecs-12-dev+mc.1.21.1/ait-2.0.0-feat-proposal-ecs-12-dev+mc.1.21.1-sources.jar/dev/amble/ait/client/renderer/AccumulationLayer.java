package dev.amble.ait.client.renderer;

import net.minecraft.class_1044;
import net.minecraft.class_1921;
import net.minecraft.class_2586;
import net.minecraft.class_284;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5944;
import org.joml.Matrix4f;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

public class AccumulationLayer<T extends GeoAnimatable> extends GeoRenderLayer<T> {

    private final class_2960 texture;
    private final float textureRes;
    private final float bottomY;
    private final float topY;
    private final float density;
    private final float cutoffVariation;

    public AccumulationLayer(GeoRenderer<T> renderer, class_2960 texture, float textureRes) {
        this(renderer, texture, textureRes, 0.0f, 1.5f, 4.0f, 1.2f);
    }

    public AccumulationLayer(GeoRenderer<T> renderer, class_2960 texture, float textureRes, float bottomY, float topY) {
        this(renderer, texture, textureRes, bottomY, topY, 4.0f, 1.2f);
    }

    public AccumulationLayer(GeoRenderer<T> renderer, class_2960 texture, float textureRes, float bottomY, float topY, float density) {
        this(renderer, texture, textureRes, bottomY, topY, density, 1.2f);
    }

    public AccumulationLayer(GeoRenderer<T> renderer, class_2960 texture, float textureRes, float bottomY, float topY, float density, float cutoffVariation) {
        super(renderer);
        this.texture = texture;
        this.textureRes = textureRes;
        this.bottomY = bottomY;
        this.topY = topY;
        this.density = density;
        this.cutoffVariation = cutoffVariation;
    }

    @Override
    public void render(class_4587 poseStack, T animatable, BakedGeoModel bakedModel,
                       class_1921 renderType, class_4597 bufferSource,
                       class_4588 buffer, float partialTick, int packedLight, int packedOverlay) {

        class_5944 shader = AITShaders.getAccumulationShader();
        if (shader == null) return;

        // Extract block position for per-block noise randomisation
        long blockSeed = 0L;
        if (animatable instanceof class_2586 be) {
            blockSeed = be.method_11016().method_10063();
        }

        float seedLo = (float)(blockSeed & 0xFFFFL) / 65536.0f;
        float seedHi = (float)((blockSeed >>> 16) & 0xFFFFL) / 65536.0f;

        Matrix4f invModel = new Matrix4f(poseStack.method_23760().method_23761()).invert();

        class_284 invModelUniform = shader.method_34582("InvModelMat");
        if (invModelUniform != null) invModelUniform.method_1250(invModel);

        class_284 textureResUniform = shader.method_34582("TextureRes");
        if (textureResUniform != null) textureResUniform.method_1251(textureRes);

        class_284 heightUniform = shader.method_34582("HeightParams");
        if (heightUniform != null) heightUniform.method_1255(bottomY, topY);

        class_284 densityUniform = shader.method_34582("Density");
        if (densityUniform != null) densityUniform.method_1251(density);

        class_284 blockSeedUniform = shader.method_34582("BlockSeed");
        if (blockSeedUniform != null) blockSeedUniform.method_1255(seedLo, seedHi);

        class_284 cutoffVarUniform = shader.method_34582("CutoffVariation");
        if (cutoffVarUniform != null) cutoffVarUniform.method_1251(cutoffVariation);

        // Bind the model's own texture as Sampler1 so the shader can skip invisible pixels
        class_2960 modelTexture = getGeoModel().getTextureResource(animatable, getRenderer());
        class_1044 modelTex = class_310.method_1551().method_1531().method_4619(modelTexture);
        shader.method_34583("Sampler1", modelTex);

        class_1921 accumulationType = AITRenderLayers.accumulation(texture);
        class_4588 accumulationConsumer = bufferSource.getBuffer(accumulationType);

        for (GeoBone bone : bakedModel.topLevelBones()) {
            getRenderer().renderRecursively(poseStack, animatable, bone, accumulationType, bufferSource,
                    accumulationConsumer, true, partialTick, packedLight, packedOverlay, 0xFFFFFFFF);
        }

        if (bufferSource instanceof class_4597.class_4598 immediate) {
            immediate.method_22994(accumulationType);
        }
    }
}
