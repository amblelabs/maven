package dev.amble.ait.client.model;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.blocks.DoorBlockEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class DoorGeoModel extends GeoModel<DoorBlockEntity> {

    private static final class_2960 MODEL = AitAPI.modLoc("geo/blockentities/police_box_door.geo.json");
    private static final class_2960 ANIMATION = AitAPI.modLoc("animations/blockentities/police_box_door.animation.json");

    private static final class_2960[] TEXTURES = {
            AitAPI.modLoc("textures/blockentities/exteriors/police_box_default.png"),
            AitAPI.modLoc("textures/blockentities/exteriors/police_box_coral.png"),
            AitAPI.modLoc("textures/blockentities/exteriors/police_box_renaissance.png"),
            AitAPI.modLoc("textures/blockentities/exteriors/police_box_crystalline.png"),
            AitAPI.modLoc("textures/blockentities/exteriors/police_box_future.png"),
    };

    @SuppressWarnings("removal")
    @Override
    public class_2960 getModelResource(DoorBlockEntity entity) {
        return MODEL;
    }

    @SuppressWarnings("removal")
    @Override
    public class_2960 getTextureResource(DoorBlockEntity entity) {
        return TEXTURES[entity.getTextureIndex() % TEXTURES.length];
    }

    @Override
    public class_2960 getAnimationResource(DoorBlockEntity entity) {
        return ANIMATION;
    }
}

