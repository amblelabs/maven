package dev.amble.ait.common.lib;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public class AitCommands {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        var mainCmd = class_2170.method_9247("ait");

        // CommandImpl.add(mainCmd)

        dispatcher.register(mainCmd);
    }
}