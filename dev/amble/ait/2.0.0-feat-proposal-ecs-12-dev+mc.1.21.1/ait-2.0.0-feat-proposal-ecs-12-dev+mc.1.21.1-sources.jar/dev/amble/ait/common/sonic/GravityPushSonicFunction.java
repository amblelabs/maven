package dev.amble.ait.common.sonic;

import dev.amble.ait.common.I18n;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3966;
import net.minecraft.class_5743;
import org.joml.Vector3f;

public class GravityPushSonicFunction implements SonicCrystal.SonicFunction {

    private static final float PUSH_STRENGTH = 2.5f;
    private static final float PUSH_UPWARD = 0.4f;

    private static final Vector3f BRIGHT_BLUE = new Vector3f(0.2f, 0.6f, 1.0f);
    private static final Vector3f DARK_BLUE = new Vector3f(0.02f, 0.02f, 0.15f);

    @Override
    public class_1799 preview() {
        return new class_1799(class_1802.field_19059);
    }

    @Override
    public class_2561 name() {
        return I18n.FUNC_ON_PUSH;
    }

    @Override
    public int maxTime() {
        return 2 * 20;
    }

    @Override
    public int tick(class_1799 stack, class_1937 level, class_1309 user, int ticks, int ticksLeft) {
        if (!canActivate(ticks)) return 1;

        class_239 hitResult = SonicCrystal.SonicFunction.getHitResult(user);

        if (hitResult instanceof class_3966 entityHitResult) {
            if (!(user instanceof class_1657)) return SonicCrystal.SonicFunction.HALT;

            class_1297 entity = entityHitResult.method_17782();

            class_243 direction = entity.method_19538().method_1020(user.method_19538()).method_1029();
            class_243 push = direction.method_18805(PUSH_STRENGTH, PUSH_STRENGTH, PUSH_STRENGTH)
                    .method_1031(0, PUSH_UPWARD, 0);

            entity.method_18799(entity.method_18798().method_1019(push));
            entity.field_6037 = true;

            level.method_8396(null, user.method_24515(), class_3417.field_26980, class_3419.field_15248, 1.5F, 0.5F);
            level.method_8396(null, entity.method_24515(), class_3417.field_49044.comp_349(), class_3419.field_15248, 1.0F, 0.8F);

            if (level instanceof class_3218 serverLevel) {
                spawnPushWave(serverLevel, user.method_30950(0), entity.method_19538().method_1031(0, entity.method_17682() / 2, 0));
            }

            return SonicCrystal.SonicFunction.HALT;
        }

        return 1;
    }

    private static void spawnPushWave(class_3218 level, class_243 origin, class_243 target) {
        class_243 direction = target.method_1020(origin);
        double distance = direction.method_1033();
        class_243 step = direction.method_1029();

        int particleCount = (int) (distance * 4);
        class_5743 dustOptions = new class_5743(
                BRIGHT_BLUE, DARK_BLUE, 1.5f
        );

        for (int i = 0; i < particleCount; i++) {
            double progress = (double) i / particleCount;
            class_243 pos = origin.method_1019(step.method_1021(distance * progress));

            double spread = 0.15 + progress * 0.6;

            level.method_14199(
                    dustOptions,
                    pos.field_1352, pos.field_1351, pos.field_1350,
                    3,
                    spread, spread, spread,
                    0.02
            );
        }
    }

    private static boolean canActivate(int ticks) {
        return ticks >= 10;
    }
}
