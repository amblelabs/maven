package dev.amble.ait.common.sonic;

import dev.amble.ait.common.I18n;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2530;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_4770;
import net.minecraft.class_5540;
import net.minecraft.class_5712;

public class SetOnFireSonicFunction implements SonicCrystal.SonicFunction {
    @Override
    public class_1799 preview() {
        return new class_1799(class_1802.field_8814);
    }

    @Override
    public class_2561 name() {
        return I18n.FUNC_ON_FIRE;
    }

    @Override
    public int maxTime() {
        return 2 * 20; // 2 seconds
    }

    @Override
    public int tick(class_1799 stack, class_1937 level, class_1309 user, int ticks, int ticksLeft) {
        if (canLight(ticks)) {
            class_239 hitResult = SonicCrystal.SonicFunction.getHitResultForOutline(user);

            if (hitResult instanceof class_3965 blockHit) {
                if (!(user instanceof class_1657 player)) return SonicCrystal.SonicFunction.HALT;
                class_1838 context = new class_1838(player, player.method_6058(), blockHit);
                class_2338 pos = context.method_8037();
                class_2680 state = level.method_8320(pos);
                class_2248 block = state.method_26204();

                if (block instanceof class_2530) {
                    class_2530.method_10738(level, pos);
                    level.method_8650(pos, false);
                    level.method_33596(user, class_5712.field_28165, pos);

                    return SonicCrystal.SonicFunction.HALT;
                }

                if (state.method_26204() instanceof class_5540) {
                    level.method_8652(pos, state.method_11657(class_5540.field_27083, true), class_2248.field_31036);
                    level.method_33596(user, class_5712.field_28733, pos);

                    return SonicCrystal.SonicFunction.HALT;
                }

                class_2338 blockPos2 = pos.method_10093(context.method_8038());
                if (class_4770.method_30032(level, blockPos2, context.method_8042())) {
                    level.method_45445(user, blockPos2, class_3417.field_15145, class_3419.field_15245, 1.0F, level.method_8409().method_43057() * 0.4F + 0.8F);
                    class_2680 blockState2 = class_4770.method_24416(level, blockPos2);
                    level.method_8652(blockPos2, blockState2, 11);
                    level.method_33596(user, class_5712.field_28164, pos);

                    return SonicCrystal.SonicFunction.HALT;
                }
            }
        }

        return 1;
    }

    private static boolean canLight(int ticks) {
        return ticks >= 10;
    }
}
