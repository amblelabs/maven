package dev.amble.ait.client.renderer;

import net.minecraft.class_5944;
import org.jetbrains.annotations.Nullable;

public class AITShaders {

    @Nullable
    private static class_5944 accumulationShader;

    public static void setAccumulationShader(@Nullable class_5944 shader) {
        accumulationShader = shader;
    }

    @Nullable
    public static class_5944 getAccumulationShader() {
        return accumulationShader;
    }
}

