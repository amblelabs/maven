package dev.amble.ait.common.lib;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_3414;

import static dev.amble.ait.api.AitAPI.modLoc;

public class AitSounds {
    public static void registerSounds(BiConsumer<class_3414, class_2960> r) {
        for (var e : SOUNDS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_3414> SOUNDS = new LinkedHashMap<>();

    //
    public static final class_3414 DOOR_OPEN = sound("tardis/door_open");
    public static final class_3414 DOOR_CLOSE = sound("tardis/door_close");
    public static final class_3414 LAND_THUD = sound("tardis/land_thud");

    private static class_3414 sound(String name) {
        var id = modLoc(name);
        var sound = class_3414.method_47908(id);
        var old = SOUNDS.put(id, sound);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        return sound;
    }
}
