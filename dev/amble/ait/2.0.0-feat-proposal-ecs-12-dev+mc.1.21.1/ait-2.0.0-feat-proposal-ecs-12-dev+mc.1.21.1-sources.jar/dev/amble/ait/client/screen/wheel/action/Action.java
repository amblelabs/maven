package dev.amble.ait.client.screen.wheel.action;

import dev.amble.ait.client.screen.wheel.Widget;
import net.minecraft.class_310;

/**
 * @author drtheodor
 * From hex-spell-wheel
 */
public interface Action {
    default void run(class_310 client, Widget widget) { }
    default void runAlt(class_310 client, Widget widget) { }

    static Action and(Action... actions) {
        return actions.length == 1 ? actions[0] : new AndAction(actions);
    }
}