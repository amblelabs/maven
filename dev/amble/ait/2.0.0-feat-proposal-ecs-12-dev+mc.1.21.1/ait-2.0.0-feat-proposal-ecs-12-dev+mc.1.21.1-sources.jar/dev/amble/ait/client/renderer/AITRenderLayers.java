package dev.amble.ait.client.renderer;

import java.util.function.BiFunction;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4668;

public abstract class AITRenderLayers extends class_1921 {

    private AITRenderLayers(String string, class_293 vertexFormat, class_293.class_5596 mode, int i, boolean bl, boolean bl2, Runnable runnable, Runnable runnable2) {
        super(string, vertexFormat, mode, i, bl, bl2, runnable, runnable2);
    }

    private static final Function<class_2960, class_1921> TARDIS_DEPTH = class_156
            .method_34866((texture) -> {
                class_4688 compositeState = class_4688.method_23598()
                        .method_34578(field_29406)
                        .method_34577(new class_4668.class_4683(texture, false, false))
                        .method_23603(field_21344)
                        .method_23615(field_21364)
                        .method_23608(field_21383)
                        .method_23611(field_21385)
                        .method_23604(field_21348)
                        .method_23616(field_21351)
                        .method_23617(false);
                return new class_4687("tardis_depth",
                        class_290.field_1580, class_293.class_5596.field_27382, 256,
                        false, false, compositeState);
            });

    public static class_1921 tardisDepth(class_2960 texture) {
        return TARDIS_DEPTH.apply(texture);
    }

    private static final Function<class_2960, class_1921> TARDIS_TRANSLUCENT = class_156
            .method_34866((texture) -> {
                class_4688 compositeState = class_4688.method_23598()
                        .method_34578(field_29406)
                        .method_34577(new class_4668.class_4683(texture, false, false))
                        .method_23603(field_21344)
                        .method_23615(field_21370)
                        .method_23608(field_21383)
                        .method_23611(field_21385)
                        .method_23604(field_21348)
                        .method_23616(field_21349)
                        .method_23617(true);
                return new class_4687("tardis_translucent",
                        class_290.field_1580, class_293.class_5596.field_27382, 256,
                        true, true, compositeState);
            });

    public static class_1921 tardisTranslucent(class_2960 texture) {
        return TARDIS_TRANSLUCENT.apply(texture);
    }

    private static final BiFunction<class_2960, Boolean, class_1921> EMISSIVE_CULL_Z_OFFSET = class_156
            .method_34865((texture, affectsOutline) -> {
                class_4688 compositeState = class_4688.method_23598()
                        .method_34578(field_29414)
                        .method_34577(new class_4668.class_4683(texture, false, false))
                        .method_23603(field_21344)
                        .method_23615(field_21370)
                        .method_23607(field_22241)
                        .method_23608(field_21383)
                        .method_23616(field_21350)
                        .method_23604(field_21348)
                        .method_23617(false);
                return new class_4687("emissive_cull_z_offset",
                        class_290.field_1580, class_293.class_5596.field_27382, 256,
                        false, true, compositeState);
            });

    public static class_1921 tardisEmissiveCullZOffset(class_2960 texture, boolean affectsOutline) {
        return EMISSIVE_CULL_Z_OFFSET.apply(texture, affectsOutline);
    }

    private static final class_5942 ACCUMULATION_SHADER =
            new class_5942(AITShaders::getAccumulationShader);

    private static final Function<class_2960, class_1921> ACCUMULATION = class_156
            .method_34866((texture) -> {
                class_4688 compositeState = class_4688.method_23598()
                        .method_34578(ACCUMULATION_SHADER)
                        .method_34577(new class_4668.class_4683(texture, false, false))
                        .method_23603(field_21344)
                        .method_23615(field_21370)
                        .method_23608(field_21383)
                        .method_23611(field_21385)
                        .method_23607(field_22241)
                        .method_23604(field_21348)
                        .method_23616(field_21349)
                        .method_23617(false);
                return new class_4687("accumulation",
                        class_290.field_1580, class_293.class_5596.field_27382, 256,
                        true, true, compositeState);
            });

    public static class_1921 accumulation(class_2960 texture) {
        return ACCUMULATION.apply(texture);
    }
}
