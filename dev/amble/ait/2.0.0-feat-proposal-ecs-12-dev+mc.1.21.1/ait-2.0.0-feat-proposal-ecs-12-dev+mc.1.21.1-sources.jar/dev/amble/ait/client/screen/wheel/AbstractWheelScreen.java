package dev.amble.ait.client.screen.wheel;

import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_437;

/**
 * @author drtheodor
 * From hex-spell-wheel
 */
public abstract class AbstractWheelScreen extends class_437 implements WheelScreen {

    protected AbstractWheelScreen() {
        super(class_2561.method_43473());
    }

    @Override
    public boolean method_25404(int i, int j, int k) {
        if (super.method_25404(i, j, k))
            return true;

        if (Objects.requireNonNull(field_22787).field_1690.field_1822.method_1417(i, j)) {
            super.method_25419();
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void click(Widget widget) {
        if (!widget.keepOpened() && !class_437.method_25442())
            this.method_25419();

        widget.run(Objects.requireNonNull(field_22787));
    }

    @Override
    public void altClick(Widget widget) {
        widget.runAlt(Objects.requireNonNull(field_22787));
    }
}