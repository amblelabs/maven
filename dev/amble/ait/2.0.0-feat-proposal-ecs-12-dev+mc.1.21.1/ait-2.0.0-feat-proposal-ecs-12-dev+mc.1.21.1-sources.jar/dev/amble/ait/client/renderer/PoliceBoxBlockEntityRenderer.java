package dev.amble.ait.client.renderer;

import dev.amble.ait.client.model.PoliceBoxGeoModel;
import dev.amble.ait.common.blocks.PoliceBoxBlock;
import dev.amble.ait.common.blocks.PoliceBoxBlockEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class PoliceBoxBlockEntityRenderer extends GeoBlockRenderer<PoliceBoxBlockEntity> {

    public PoliceBoxBlockEntityRenderer(class_5614.class_5615 context) {
        super(new PoliceBoxGeoModel());
        addRenderLayer(new PoliceBoxEmissiveLayer(this));
        addRenderLayer(new AccumulationLayer<PoliceBoxBlockEntity>(this,
                class_2960.method_60656("textures/block/sand.png"), 256));
    }

    @Override
    protected void rotateBlock(class_2350 facing, class_4587 poseStack) {
        // No-op: we handle rotation via ROTATION blockstate in preRender
    }

    @Override
    public class_1921 getRenderType(PoliceBoxBlockEntity entity, class_2960 texture,
                                    @Nullable class_4597 bufferSource, float partialTick) {
        return AITRenderLayers.tardisTranslucent(texture);
    }

    @Override
    public void preRender(class_4587 poseStack, PoliceBoxBlockEntity entity, BakedGeoModel model,
                          @Nullable class_4597 bufferSource, @Nullable class_4588 buffer,
                          boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                          int colour) {
        if (!isReRender) {
            int rotation = entity.method_11010().method_11654(PoliceBoxBlock.ROTATION);
            boolean onSlab = entity.isOnSlab();
            poseStack.method_22904(0.5, onSlab ? -0.5 : 0, 0.5);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation * -45f));
        }

        if (entity.needsSnap()) {
            PoliceBoxBlockEntity.DoorState state = entity.getDoorState();
            float rightY = (float) Math.toRadians(77.5);
            float leftY = (float) Math.toRadians(-77.5);

            if (state == PoliceBoxBlockEntity.DoorState.RIGHT_OPEN || state == PoliceBoxBlockEntity.DoorState.BOTH_OPEN) {
                setDoorBoneRotation(model, "door_r", rightY);
                setDoorBoneRotation(model, "RDoor", rightY);
            }
            if (state == PoliceBoxBlockEntity.DoorState.BOTH_OPEN) {
                setDoorBoneRotation(model, "door_l", leftY);
                setDoorBoneRotation(model, "LDoor", leftY);
            }
            entity.clearSnap();
        }
    }

    private static void setDoorBoneRotation(BakedGeoModel model, String boneName, float rotY) {
        model.getBone(boneName).ifPresent(bone -> bone.setRotY(rotY));
    }

    @Override
    public void actuallyRender(class_4587 poseStack, PoliceBoxBlockEntity entity, BakedGeoModel model,
                               @Nullable class_1921 renderType, class_4597 bufferSource, @Nullable class_4588 buffer,
                               boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                               int colour) {
        float alpha = entity.getAlpha();
        int packedColor = ((int) (alpha * 255) << 24) | 0xFFFFFF;

        if (alpha < 1.0f && bufferSource instanceof class_4597.class_4598 immediate) {
            class_2960 texture = getGeoModel().getTextureResource(entity, this);

            class_1921 depthType = AITRenderLayers.tardisDepth(texture);
            class_4588 depthConsumer = bufferSource.getBuffer(depthType);
            super.actuallyRender(poseStack, entity, model, depthType, bufferSource, depthConsumer,
                    isReRender, partialTick, packedLight, packedOverlay, 0xFFFFFFFF);
            immediate.method_22994(depthType);

            class_4588 frontConsumer = bufferSource.getBuffer(renderType);
            super.actuallyRender(poseStack, entity, model, renderType, bufferSource, frontConsumer,
                    isReRender, partialTick, packedLight, packedOverlay, packedColor);
            immediate.method_22994(renderType);
        } else {
            super.actuallyRender(poseStack, entity, model, renderType, bufferSource, buffer,
                    isReRender, partialTick, packedLight, packedOverlay, packedColor);
        }
    }
}
