package dev.amble.ait.common.lib;

import dev.amble.ait.common.blocks.ConsoleBlock;
import dev.amble.ait.common.blocks.DoorBlock;
import dev.amble.ait.common.blocks.PoliceBoxBlock;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import static dev.amble.ait.api.AitAPI.modLoc;

@SuppressWarnings({"UnusedReturnValue", "unused"})
public class AitBlocks {
    public static void registerBlocks(BiConsumer<class_2248, class_2960> r) {
        for (var e : BLOCKS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    public static void registerBlockItems(BiConsumer<class_1792, class_2960> r) {
        for (var e : BLOCK_ITEMS.entrySet()) {
            r.accept(new class_1747(e.getValue().getFirst(), e.getValue().getSecond()), e.getKey());
        }
    }

    public static void registerBlockCreativeTab(Consumer<class_2248> r, class_1761 tab) {
        for (var block : BLOCK_TABS.getOrDefault(tab, List.of())) {
            r.accept(block);
        }
    }

    private static final Map<class_2960, class_2248> BLOCKS = new LinkedHashMap<>();
    private static final Map<class_2960, Pair<class_2248, class_1792.class_1793>> BLOCK_ITEMS = new LinkedHashMap<>();
    private static final Map<class_1761, List<class_2248>> BLOCK_TABS = new LinkedHashMap<>();

    private static class_4970.class_2251 papery(class_3620 color) {
        return class_4970.class_2251
            .method_9637()
            .method_31710(color)
            .method_9626(class_2498.field_11535)
            .method_9618()
            .method_50013()
            .method_50012(class_3619.field_15971);
    }

    private static class_4970.class_2251 woodyHard(class_3620 color) {
        return class_4970.class_2251
            .method_9630(class_2246.field_10431)
            .method_31710(color)
            .method_9626(class_2498.field_11547)
            .method_9629(3f, 4f);
    }

    private static class_4970.class_2251 woody(class_3620 color) {
        return class_4970.class_2251
            .method_9630(class_2246.field_10431)
            .method_31710(color)
            .method_9626(class_2498.field_11547)
            .method_9632(2f);
    }

    private static class_4970.class_2251 leaves(class_3620 color) {
        return class_4970.class_2251
            .method_9630(class_2246.field_10503)
            .method_9632(0.2F)
            .method_9640()
            .method_9626(class_2498.field_11535)
            .method_22488()
            .method_26235((bs, level, pos, type) -> type == class_1299.field_6081 || type == class_1299.field_6104)
            .method_26243(AitBlocks::never)
            .method_26245(AitBlocks::never);
    }

    //

    public static final PoliceBoxBlock POLICE_BOX = blockItem("police_box", new PoliceBoxBlock(PoliceBoxBlock.defaultProps()));
    public static final DoorBlock POLICE_BOX_DOOR = blockItem("police_box_door", new DoorBlock(DoorBlock.defaultProps()));
    public static final ConsoleBlock CONSOLE = blockItem("console", new ConsoleBlock(ConsoleBlock.defaultProps()));

    @SuppressWarnings("SameReturnValue") // intended
    private static boolean never(Object... args) {
        return false;
    }

    private static <T extends class_2248> T blockNoItem(String name, T block) {
        var old = BLOCKS.put(modLoc(name), block);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        return block;
    }

    private static <T extends class_2248> T blockItem(String name, T block) {
        return blockItem(name, block, AitItems.props(), AitCreativeTabs.AIT);
    }

    private static <T extends class_2248> T blockItem(String name, T block, @Nullable class_1761 tab) {
        return blockItem(name, block, AitItems.props(), tab);
    }

    private static <T extends class_2248> T blockItem(String name, T block, class_1792.class_1793 props) {
        return blockItem(name, block, props, AitCreativeTabs.AIT);
    }

    private static <T extends class_2248> T blockItem(String name, T block, class_1792.class_1793 props, @Nullable class_1761 tab) {
        blockNoItem(name, block);

        var old = BLOCK_ITEMS.put(modLoc(name), new Pair<>(block, props));
        if (old != null) throw new IllegalArgumentException("Duplicate id " + name);

        if (tab != null) {
            BLOCK_TABS.computeIfAbsent(tab, t -> new ArrayList<>()).add(block);
        }

        return block;
    }
}

