package dev.amble.ait.fabric.xplat;

import dev.amble.ait.fabric.interop.trinkets.TrinketsApiInterop;
import dev.amble.ait.interop.AitInterop;
import dev.amble.ait.xplat.IClientXplatAbstractions;
import dev.amble.ait.xplat.IXplatAbstractions;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_5617;
import net.minecraft.class_638;
import net.minecraft.class_6395;
import net.minecraft.class_8710;
import org.jetbrains.annotations.Nullable;

public class FabricClientXplatImpl implements IClientXplatAbstractions {

    @Override
    public void sendPacketToServer(class_8710 packet) {
        ClientPlayNetworking.send(packet);
    }

    @Override
    public void setRenderLayer(class_2248 block, class_1921 type) {
        BlockRenderLayerMap.INSTANCE.putBlock(block, type);
    }

    @Override
    public void initPlatformSpecific() {
        if (IXplatAbstractions.INSTANCE.isModPresent(AitInterop.Fabric.TRINKETS_API_ID)) {
            TrinketsApiInterop.clientInit();
        }
    }

    @Override
    public <T extends class_1297> void registerEntityRenderer(class_1299<? extends T> type,
                                                          class_5617<T> renderer) {
        EntityRendererRegistry.register(type, renderer);
    }

    @SuppressWarnings("deprecation")
    private record UnclampedClampedItemPropFunc(class_1800 inner) implements class_6395 {
        @Override
        public float unclampedCall(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity,
                                   int seed) {
            return inner.call(stack, level, entity, seed);
        }

        @Override
        public float call(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            return this.unclampedCall(stack, level, entity, seed);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void registerItemProperty(class_1792 item, class_2960 id, class_1800 func) {
        class_5272.method_27879(item, id, new UnclampedClampedItemPropFunc(func));
    }
}
