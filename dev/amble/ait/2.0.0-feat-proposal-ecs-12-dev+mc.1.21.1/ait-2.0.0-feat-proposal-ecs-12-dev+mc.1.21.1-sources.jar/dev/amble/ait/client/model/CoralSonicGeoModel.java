package dev.amble.ait.client.model;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.items.ItemSonic;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class CoralSonicGeoModel extends GeoModel<ItemSonic> {

    private static final class_2960 MODEL = AitAPI.modLoc("geo/items/coral.geo.json");
    private static final class_2960 TEXTURE = AitAPI.modLoc("textures/item/sonic_tools/coral.png");
    private static final class_2960 ANIMATION = AitAPI.modLoc("animations/items/coral.animation.json");

    @SuppressWarnings("removal")
    @Override
    public class_2960 getModelResource(ItemSonic animatable) {
        return MODEL;
    }

    @SuppressWarnings("removal")
    @Override
    public class_2960 getTextureResource(ItemSonic animatable) {
        return TEXTURE;
    }

    @Override
    public class_2960 getAnimationResource(ItemSonic animatable) {
        return ANIMATION;
    }
}

