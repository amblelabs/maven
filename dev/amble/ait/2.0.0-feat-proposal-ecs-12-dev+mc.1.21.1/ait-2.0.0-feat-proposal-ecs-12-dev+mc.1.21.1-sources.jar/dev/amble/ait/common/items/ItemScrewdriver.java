package dev.amble.ait.common.items;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

public class ItemScrewdriver extends class_1792 {

    public ItemScrewdriver(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> lines, class_1836 flag) {
        lines.add(class_2561.method_43473());
        lines.add(class_2561.method_43471(this.method_7876() + ".desc").method_27695(class_124.field_1080, class_124.field_1056));
    }
}
