package dev.amble.ait.common;

import dev.amble.ait.api.AitAPI;
import net.minecraft.class_124;
import net.minecraft.class_2561;

public class I18n {

    public static final class_2561 EMPTY_WIDGET = class_2561.method_43471("widget." + AitAPI.MOD_ID + ".empty")
            .method_10852(class_2561.method_43470("\n"))
            .method_10852(class_2561.method_43471("widget." + AitAPI.MOD_ID + ".empty.desc")
                    .method_27692(class_124.field_1080));

    public static final class_2561 FUNC_ON_FIRE = class_2561.method_43471("sonic." + AitAPI.MOD_ID + ".set_on_fire");
    public static final class_2561 FUNC_ON_GRAVITATE = class_2561.method_43471("sonic." + AitAPI.MOD_ID + ".on_gravitate");
    public static final class_2561 FUNC_ON_PUSH = class_2561.method_43471("sonic." + AitAPI.MOD_ID + ".on_push");
    public static final class_2561 FUNC_ON_DISARM = class_2561.method_43471("sonic." + AitAPI.MOD_ID + ".on_disarm");
    public static final class_2561 FUNC_ON_LASER = class_2561.method_43471("sonic." + AitAPI.MOD_ID + ".on_laser");
    public static final class_2561 FUNC_ON_HIGH_FREQ = class_2561.method_43471("sonic." + AitAPI.MOD_ID + ".on_high_freq");
}
