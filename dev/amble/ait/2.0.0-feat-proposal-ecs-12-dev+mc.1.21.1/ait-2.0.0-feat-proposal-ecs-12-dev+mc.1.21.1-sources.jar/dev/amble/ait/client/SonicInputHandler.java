package dev.amble.ait.client;

import dev.amble.ait.client.screen.SonicWheelScreen;
import dev.amble.ait.common.items.ItemSonic;
import dev.amble.ait.common.network.SonicTogglePayload;
import dev.amble.ait.xplat.IClientXplatAbstractions;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class SonicInputHandler {

    public static void clientTick(class_310 client) {
        if (client.field_1724 == null)
            return;

        if (client.field_1755 != null && !(client.field_1755 instanceof SonicWheelScreen))
            return;

        class_1657 player = client.field_1724;
        class_1799 mainHand = player.method_6047();

        if (!(mainHand.method_7909() instanceof ItemSonic))
            return;

        while (AitKeybinds.SONIC_WHEEL.method_1436()) {
            if (client.field_1755 instanceof SonicWheelScreen) {
                client.method_1507(null);
            } else {
                client.method_1507(SonicWheelScreen.tryCreate(mainHand));
            }
        }

        while (AitKeybinds.SONIC_TOGGLE.method_1436()) {
            boolean nowOpened = ItemSonic.toggleOpened(mainHand);
            IClientXplatAbstractions.INSTANCE.sendPacketToServer(new SonicTogglePayload(nowOpened));
        }
    }
}
