package dev.amble.ait.common.blocks;

import dev.amble.ait.common.lib.AitBlockEntities;
import dev.amble.ait.common.lib.AitSounds;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3419;
import net.minecraft.class_7225;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public class DoorBlockEntity extends class_2586 implements GeoBlockEntity {

    public enum DoorState {
        CLOSED,
        RIGHT_OPEN,
        BOTH_OPEN
    }

    private static final String DOOR_STATE_KEY = "DoorState";

    private static final RawAnimation RIGHT_OPEN = RawAnimation.begin().thenPlay("right door open");
    private static final RawAnimation LEFT_OPEN = RawAnimation.begin().thenPlay("left door open");
    private static final RawAnimation RIGHT_CLOSE = RawAnimation.begin().thenPlay("right door close");
    private static final RawAnimation LEFT_CLOSE = RawAnimation.begin().thenPlay("left door close");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private DoorState doorState = DoorState.CLOSED;
    private boolean rightHasOpened = false;
    private boolean leftHasOpened = false;
    private boolean needsSnap = false;

    public DoorBlockEntity(class_2338 pos, class_2680 state) {
        super(AitBlockEntities.DOOR_BLOCK_ENTITY, pos, state);
    }

    public int getTextureIndex() {
        return this.method_11010().method_11654(DoorBlock.TEXTURE);
    }

    public DoorState getDoorState() {
        return doorState;
    }

    public boolean isOnSlab() {
        return this.method_11010().method_11654(DoorBlock.ON_SLAB);
    }

    public boolean isBetween() {
        return this.method_11010().method_11654(DoorBlock.BETWEEN);
    }

    public boolean needsSnap() {
        return needsSnap;
    }

    public void clearSnap() {
        this.needsSnap = false;
    }

    public void interact(boolean crouching) {
        if (this.method_10997() == null) return;
        switch (doorState) {
            case CLOSED -> {
                if (crouching) {
                    doorState = DoorState.BOTH_OPEN;
                } else {
                    doorState = DoorState.RIGHT_OPEN;
                }
                this.method_10997().method_8396(null, this.method_11016(), AitSounds.DOOR_OPEN, class_3419.field_15245, 0.5f, 1.0f);
            }
            case RIGHT_OPEN -> {
                if (crouching) {
                    doorState = DoorState.CLOSED;
                } else {
                    doorState = DoorState.BOTH_OPEN;
                }
                this.method_10997().method_8396(null, this.method_11016(), AitSounds.DOOR_OPEN, class_3419.field_15245, 0.5f, 1.0f);
            }
            case BOTH_OPEN -> {
                doorState = DoorState.CLOSED;
                this.method_10997().method_8396(null, this.method_11016(), AitSounds.DOOR_CLOSE, class_3419.field_15245, 0.6f, 1.0f);
            }
        }

        this.method_5431();
        if (this.field_11863 != null) {
            this.field_11863.method_8413(this.field_11867, this.method_11010(), this.method_11010(), 3);
        }
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        tag.method_10569(DOOR_STATE_KEY, this.doorState.ordinal());
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        int doorOrdinal = tag.method_10550(DOOR_STATE_KEY);
        this.doorState = DoorState.values()[Math.clamp(doorOrdinal, 0, DoorState.values().length - 1)];

        if (doorState != DoorState.CLOSED) {
            needsSnap = true;
            rightHasOpened = true;
            if (doorState == DoorState.BOTH_OPEN) {
                leftHasOpened = true;
            }
        }
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        class_2487 tag = super.method_16887(registries);
        method_11007(tag, registries);
        return tag;
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "right_door", 0, state -> {
            if (needsSnap) return PlayState.STOP;
            if (doorState == DoorState.RIGHT_OPEN || doorState == DoorState.BOTH_OPEN) {
                rightHasOpened = true;
                return state.setAndContinue(RIGHT_OPEN);
            }
            if (!rightHasOpened) return PlayState.STOP;
            return state.setAndContinue(RIGHT_CLOSE);
        }));
        controllers.add(new AnimationController<>(this, "left_door", 0, state -> {
            if (needsSnap) return PlayState.STOP;
            if (doorState == DoorState.BOTH_OPEN) {
                leftHasOpened = true;
                return state.setAndContinue(LEFT_OPEN);
            }
            if (!leftHasOpened) return PlayState.STOP;
            return state.setAndContinue(LEFT_CLOSE);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
