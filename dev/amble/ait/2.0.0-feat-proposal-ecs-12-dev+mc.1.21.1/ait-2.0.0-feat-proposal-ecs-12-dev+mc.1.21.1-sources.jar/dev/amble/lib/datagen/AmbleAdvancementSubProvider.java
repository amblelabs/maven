package dev.amble.lib.datagen;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_185;
import net.minecraft.class_189;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7785;

@SuppressWarnings({"OptionalUsedAsFieldOrParameterType", "SameParameterValue", "unused"})
public abstract class AmbleAdvancementSubProvider implements class_7785 {

    protected final String modId;

    protected AmbleAdvancementSubProvider(String modId) {
        this.modId = modId;
    }

    protected class_185 simple(class_1935 icon, String name, class_189 frameType) {
        return simpleBg(icon, name, frameType, Optional.empty());
    }

    protected class_185 simpleBg(class_1935 icon, String name, class_189 frameType, Optional<class_2960> background) {
        return display(new class_1799(icon), name, frameType, background, true, true, false);
    }

    protected class_185 display(class_1799 icon, String name, class_189 frameType, Optional<class_2960> background, boolean showToast, boolean announceChat, boolean hidden) {
        name = "advancement." + this.modId + ":" + name;

        return new class_185(icon,
            class_2561.method_43471(name),
            class_2561.method_43471(name + ".desc"),
            background, frameType, showToast, announceChat, hidden);
    }

    protected class_2960 modLoc(String name) {
        return class_2960.method_60655(modId, name);
    }
}