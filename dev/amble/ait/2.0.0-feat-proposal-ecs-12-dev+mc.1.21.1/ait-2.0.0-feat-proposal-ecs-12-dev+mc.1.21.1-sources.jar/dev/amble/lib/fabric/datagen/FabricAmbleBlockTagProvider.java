package dev.amble.lib.fabric.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public abstract class FabricAmbleBlockTagProvider extends FabricTagProvider.BlockTagProvider {

    public FabricAmbleBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }
}
