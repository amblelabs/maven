package dev.amble.lib.fabric.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

@SuppressWarnings("SameParameterValue")
public class FabricAmbleLangProvider extends FabricLanguageProvider {

    protected FabricAmbleLangProvider(FabricDataOutput dataOutput, String languageCode, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, languageCode, registryLookup);
    }

    @Override
    public void generateTranslations(class_7225.class_7874 provider, TranslationBuilder translationBuilder) {

    }
}
