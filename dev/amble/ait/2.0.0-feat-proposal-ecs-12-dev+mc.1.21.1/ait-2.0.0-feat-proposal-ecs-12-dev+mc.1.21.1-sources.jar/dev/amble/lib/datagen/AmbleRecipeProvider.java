package dev.amble.lib.datagen;

import net.minecraft.advancements.critereon.*;
import net.minecraft.class_174;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2066;
import net.minecraft.class_2073;
import net.minecraft.class_2096;
import net.minecraft.class_2446;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import net.minecraft.data.recipes.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@SuppressWarnings({"SameParameterValue", "unused"})
public abstract class AmbleRecipeProvider extends class_2446 {

    protected final String modId;

    protected AmbleRecipeProvider(class_7784 out, CompletableFuture<class_7225.class_7874> future, String modId) {
        super(out, future);
        this.modId = modId;
    }

    protected class_2447 ring(class_7800 category, class_1935 out, int count, class_1856 outer, @Nullable class_1856 inner) {
        return ringCornered(category, out, count, outer, outer, inner);
    }

    protected class_2447 ring(class_7800 category, class_1935 out, int count, class_1935 outer, @Nullable class_1935 inner) {
        return ring(category, out, count, class_1856.method_8091(outer), ingredientOf(inner));
    }

    protected class_2447 ring(class_7800 category, class_1935 out, int count, class_6862<class_1792> outer, @Nullable class_6862<class_1792> inner) {
        return ring(category, out, count, class_1856.method_8106(outer), ingredientOf(inner));
    }

    protected class_2447 ringCornerless(class_7800 category, class_1935 out, int count, class_1856 outer,
        @Nullable class_1856 inner) {
        return ringCornered(category, out, count, outer, null, inner);
    }

    protected class_2447 ringCornerless(class_7800 category, class_1935 out, int count, class_1935 outer, @Nullable class_1935 inner) {
        return ringCornerless(category, out, count, class_1856.method_8091(outer), ingredientOf(inner));
    }

    protected class_2447 ringCornerless(class_7800 category, class_1935 out, int count, class_6862<class_1792> outer,
        @Nullable class_6862<class_1792> inner) {
        return ringCornerless(category, out, count, class_1856.method_8106(outer), ingredientOf(inner));
    }

    protected class_2447 ringAll(class_7800 category, class_1935 out, int count, class_1856 outer, @Nullable class_1856 inner) {
        return ringCornered(category, out, count, outer, outer, inner);
    }

    protected class_2447 ringAll(class_7800 category, class_1935 out, int count, class_1935 outer, @Nullable class_1935 inner) {
        return ringAll(category, out, count, class_1856.method_8091(outer), ingredientOf(inner));
    }

    protected class_2447 ringAll(class_7800 category, class_1935 out, int count, class_6862<class_1792> outer, @Nullable class_6862<class_1792> inner) {
        return ringAll(category, out, count, class_1856.method_8106(outer), ingredientOf(inner));
    }

    protected class_2447 ringCornered(class_7800 category, class_1935 out, int count, @Nullable class_1856 cardinal,
                                               @Nullable class_1856 diagonal, @Nullable class_1856 inner) {
        if (cardinal == null && diagonal == null && inner == null) {
            throw new IllegalArgumentException("at least one ingredient must be non-null");
        }
        if (inner != null && cardinal == null && diagonal == null) {
            throw new IllegalArgumentException("if inner is non-null, either cardinal or diagonal must not be");
        }

        var builder = class_2447.method_10436(category, out, count);
        char C = ' ';
        if (cardinal != null) {
            builder.method_10428('C', cardinal);
            C = 'C';
        }
        char D = ' ';
        if (diagonal != null) {
            builder.method_10428('D', diagonal);
            D = 'D';
        }
        char I = ' ';
        if (inner != null) {
            builder.method_10428('I', inner);
            I = 'I';
        }

        builder
            .method_10439("" + D + C + D)
            .method_10439("" + C + I + C)
            .method_10439("" + D + C + D);

        return builder;
    }

    protected class_2447 ringCornered(class_7800 category, class_1935 out, int count, @Nullable class_1935 cardinal,
        @Nullable class_1935 diagonal, @Nullable class_1935 inner) {
        return ringCornered(category, out, count, ingredientOf(cardinal), ingredientOf(diagonal), ingredientOf(inner));
    }

    protected class_2447 ringCornered(class_7800 category, class_1935 out, int count, @Nullable class_6862<class_1792> cardinal,
        @Nullable class_6862<class_1792> diagonal, @Nullable class_6862<class_1792> inner) {
        return ringCornered(category, out, count, ingredientOf(cardinal), ingredientOf(diagonal), ingredientOf(inner));
    }

    protected class_2447 stack(class_7800 category, class_1935 out, int count, class_1856 top, class_1856 bottom) {
        return class_2447.method_10436(category, out, count)
            .method_10428('T', top)
            .method_10428('B', bottom)
            .method_10439("T")
            .method_10439("B");
    }

    protected class_2447 stack(class_7800 category, class_1935 out, int count, class_1935 top, class_1935 bottom) {
        return stack(category, out, count, class_1856.method_8091(top), class_1856.method_8091(bottom));
    }

    protected class_2447 stack(class_7800 category, class_1935 out, int count, class_6862<class_1792> top, class_6862<class_1792> bottom) {
        return stack(category, out, count, class_1856.method_8106(top), class_1856.method_8106(bottom));
    }

    protected class_2447 stick(class_7800 category, class_1935 out, int count, class_1856 input) {
        return stack(category, out, count, input, input);
    }

    protected class_2447 stick(class_7800 category, class_1935 out, int count, class_1935 input) {
        return stick(category, out, count, class_1856.method_8091(input));
    }

    protected class_2447 stick(class_7800 category, class_1935 out, int count, class_6862<class_1792> input) {
        return stick(category, out, count, class_1856.method_8106(input));
    }

    /**
     * @param largeSize True for a 3x3, false for a 2x2
     */
    protected void packing(class_7800 category, class_1935 free, class_1935 compressed, String freeName, boolean largeSize, class_8790 recipes) {
        var pack = class_2447.method_10437(category, compressed)
            .method_10434('X', free);

        if (largeSize) {
            pack.method_10439("XXX").method_10439("XXX").method_10439("XXX");
        } else {
            pack.method_10439("XX").method_10439("XX");
        }

        pack.method_10429("has_item", hasItem(free)).method_17972(recipes, modLoc(freeName + "_packing"));

        class_2450.method_10448(category, free, largeSize ? 9 : 4)
            .method_10454(compressed)
            .method_10442("has_item", hasItem(free)).method_17972(recipes, modLoc(freeName + "_unpacking"));
    }

    protected class_2960 modLoc(String path) {
        return class_2960.method_60655(modId, path);
    }

    @Nullable
    protected class_1856 ingredientOf(@Nullable class_1935 item) {
        return item == null ? null : class_1856.method_8091(item);
    }

    @Nullable
    protected class_1856 ingredientOf(@Nullable class_6862<class_1792> item) {
        return item == null ? null : class_1856.method_8106(item);
    }

    protected static class_175<class_2066.class_2068> hasItem(class_2096.class_2100 bounds, class_1935 itemLike) {
        return ambleInventoryTrigger(class_2073.class_2074.method_8973().method_8977(itemLike).method_35233(bounds).method_8976());
    }

    protected static class_175<class_2066.class_2068> hasItem(class_1935 itemLike) {
        return ambleInventoryTrigger(class_2073.class_2074.method_8973().method_8977(itemLike).method_8976());
    }

    protected static class_175<class_2066.class_2068> hasItem(class_6862<class_1792> itemTag) {
        return ambleInventoryTrigger(class_2073.class_2074.method_8973().method_8975(itemTag).method_8976());
    }

    protected static class_175<class_2066.class_2068> ambleInventoryTrigger(class_2073... predicates) {
        return class_174.field_1195.method_53699(new class_2066.class_2068(Optional.empty(), class_2066.class_2068.class_8948.field_47265, List.of(predicates)));
    }
}