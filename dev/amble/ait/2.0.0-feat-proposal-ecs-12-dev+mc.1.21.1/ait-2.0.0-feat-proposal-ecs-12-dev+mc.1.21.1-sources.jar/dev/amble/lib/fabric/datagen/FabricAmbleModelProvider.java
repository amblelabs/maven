package dev.amble.lib.fabric.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_4910;
import net.minecraft.class_4915;

public abstract class FabricAmbleModelProvider extends FabricModelProvider {

    public FabricAmbleModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 gen) {

    }

    @Override
    public void generateItemModels(class_4915 gen) {

    }
}
