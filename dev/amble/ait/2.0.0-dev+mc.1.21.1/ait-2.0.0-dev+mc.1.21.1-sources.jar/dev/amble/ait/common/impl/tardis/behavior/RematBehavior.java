package dev.amble.ait.common.impl.tardis.behavior;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.common.blocks.ExteriorBlockEntity;
import dev.amble.ait.common.impl.tardis.state.DesktopState;
import dev.amble.ait.common.impl.tardis.state.DimensionState;
import dev.amble.ait.common.impl.tardis.state.ExteriorState;
import dev.amble.ait.common.impl.tardis.state.TravelState;
import dev.amble.ait.common.lib.AitBlockEntities;
import dev.amble.ait.common.lib.AitBlocks;
import dev.amble.ait.common.lib.AitSounds;
import dev.drtheo.ecs.behavior.TBehavior;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_4208;
import net.minecraft.server.MinecraftServer;

public class RematBehavior implements TBehavior {

    public static RematBehavior getInstance() {
        return new RematBehavior();
    }

    public void rematerialize(ServerTardis tardis, MinecraftServer server) {
        TravelState travel = tardis.state(TravelState.state);
        DimensionState dim = tardis.state(DimensionState.state);
        DesktopState desktop = tardis.state(DesktopState.state);

        class_4208 destination = travel.destinationPos;
        int rotation = travel.destinationRot;

        class_3218 tardisWorld = dim.level.get();
        class_3218 destinationWorld = server.method_3847(destination.comp_2207());

        AitAPI.LOGGER.info("Rematerializing in {} at {}", destination.comp_2207(), destination.comp_2208());

        tardisWorld.method_45447(null, desktop.doorPos, AitSounds.MAT, class_3419.field_15245);
        destinationWorld.method_45447(null, destination.comp_2208(), AitSounds.MAT, class_3419.field_15245);

        ExteriorState exterior = new ExteriorState(destination, rotation);
        tardis.addState(exterior);

        class_2680 blockState = exterior.writeBlockState(AitBlocks.EXTERIOR_BLOCK.method_9564());
        destinationWorld.method_8652(destination.comp_2208(), blockState, class_2248.field_31031);

        // unnecessary???
        ExteriorBlockEntity blockEntity = AitBlockEntities.EXTERIOR_BLOCK_ENTITY.method_11032(destination.comp_2208(), blockState);
        destinationWorld.method_8438(blockEntity);

        blockEntity.link(tardis);
    }
}
