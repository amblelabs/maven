package dev.amble.ait.common.blocks;

import dev.amble.ait.api.mod.block.entity.LinkableBlockEntity;
import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.common.impl.tardis.state.DematState;
import dev.amble.ait.common.impl.tardis.state.DoorState;
import dev.amble.ait.common.lib.AitBlockEntities;
import dev.amble.ait.common.lib.AitVariants;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public class ExteriorBlockEntity extends LinkableBlockEntity implements GeoBlockEntity {

    private static final String MODEL_KEY = "ModelVariant";
    private static final String TEXTURE_KEY = "TextureVariant";

    private static final RawAnimation RIGHT_OPEN = RawAnimation.begin().thenPlay("right door open");
    private static final RawAnimation LEFT_OPEN = RawAnimation.begin().thenPlay("left door open");
    private static final RawAnimation RIGHT_CLOSE = RawAnimation.begin().thenPlay("right door close");
    private static final RawAnimation LEFT_CLOSE = RawAnimation.begin().thenPlay("left door close");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private int modelVariant = 0;
    private int textureVariant;

    public ExteriorBlockEntity(class_2338 pos, class_2680 state) {
        super(AitBlockEntities.EXTERIOR_BLOCK_ENTITY, pos, state);
        this.textureVariant = state.method_28498(ExteriorBlock.TEXTURE) ? state.method_11654(ExteriorBlock.TEXTURE) : 0;
    }

    public String getModelName() {
        return AitVariants.EXTERIOR_MODEL_NAMES[
                AitVariants.wrap(this.modelVariant, AitVariants.EXTERIOR_MODEL_NAMES.length)
                ];
    }

    public String getTextureName() {
        return AitVariants.EXTERIOR_TEXTURE_NAMES[
                AitVariants.wrap(this.textureVariant, AitVariants.EXTERIOR_TEXTURE_NAMES.length)
                ];
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        tag.method_10569(MODEL_KEY, this.modelVariant);
        tag.method_10569(TEXTURE_KEY, this.textureVariant);
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        this.modelVariant = tag.method_10545(MODEL_KEY)
                ? AitVariants.wrap(tag.method_10550(MODEL_KEY), AitVariants.EXTERIOR_MODEL_NAMES.length)
                : 0;
        this.textureVariant = tag.method_10545(TEXTURE_KEY)
                ? AitVariants.wrap(tag.method_10550(TEXTURE_KEY), AitVariants.EXTERIOR_TEXTURE_NAMES.length)
                : (this.method_11010().method_28498(ExteriorBlock.TEXTURE)
                ? this.method_11010().method_11654(ExteriorBlock.TEXTURE)
                : 0);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        class_2487 tag = super.method_16887(registries);
        method_11007(tag, registries);
        return tag;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "right_door", 0, state -> {

            Tardis tardis = this.tardis();
            if (tardis == null) return PlayState.STOP;

            DoorState door = tardis.resolveState(DoorState.state);

            if (door.rightOpen) {
                return state.setAndContinue(RIGHT_OPEN);
            }

            return state.setAndContinue(RIGHT_CLOSE);
        }));

        controllers.add(new AnimationController<>(this, "left_door", 0, state -> {

            Tardis tardis = this.tardis();
            if (tardis == null) return PlayState.STOP;

            DoorState door = tardis.resolveState(DoorState.state);

            if (door.leftOpen) {
                return state.setAndContinue(LEFT_OPEN);
            }

            return state.setAndContinue(LEFT_CLOSE);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}


