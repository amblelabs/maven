package dev.amble.ait.common.lib;

import dev.amble.ait.common.entities.ConsoleControlEntity;
import dev.amble.ait.common.entities.FallingTardisBlockEntity;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2960;

import static dev.amble.ait.api.AitAPI.modLoc;

public class AitEntities {
    public static void registerEntities(BiConsumer<class_1299<?>, class_2960> r) {
        for (var e : ENTITIES.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_1299<?>> ENTITIES = new LinkedHashMap<>();

    //

    public static final class_1299<FallingTardisBlockEntity> FALLING_TARDIS_BLOCK =
            register("falling_tardis_block", class_1299.class_1300
                    .<FallingTardisBlockEntity>method_5903(FallingTardisBlockEntity::new, class_1311.field_17715)
                    .method_17687(0.98F, 0.98F)
                    .method_27299(10)
                    .method_27300(20)
                    .method_5905("falling_tardis_block"));

    public static final class_1299<ConsoleControlEntity> CONSOLE_CONTROL =
            register("console_control", class_1299.class_1300.<ConsoleControlEntity>method_5903(ConsoleControlEntity::new, class_1311.field_17715)
                    .method_17687(0.125F, 0.125F)
                    .method_5901()
                    .method_5905("console_control"));

    @SuppressWarnings("SameParameterValue")
    private static <T extends class_1297> class_1299<T> register(String id, class_1299<T> type) {
        var old = ENTITIES.put(modLoc(id), type);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + id);
        }
        return type;
    }
}