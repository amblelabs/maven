package dev.amble.ait.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.common.blocks.ExteriorBlockEntity;
import dev.amble.ait.common.impl.tardis.state.DematState;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

public class ExteriorEmissiveLayer extends GeoRenderLayer<ExteriorBlockEntity> {

    private static final int FULLBRIGHT = 0xF000F0;

    public ExteriorEmissiveLayer(GeoRenderer<ExteriorBlockEntity> renderer) {
        super(renderer);
    }

    @Override
    public void render(class_4587 poseStack, ExteriorBlockEntity entity, BakedGeoModel bakedModel,
                       @Nullable class_1921 renderType, class_4597 bufferSource,
                       @Nullable class_4588 buffer, float partialTick, int packedLight, int packedOverlay) {
        class_2960 baseTexture = getGeoModel().getTextureResource(entity, getRenderer());
        String basePath = baseTexture.method_12832();
        String emissivePath = basePath.replace(".png", "_e.png");
        class_2960 emissiveTexture = AitAPI.modLoc(emissivePath);

        if (class_310.method_1551().method_1478().method_14486(emissiveTexture).isEmpty()) return;

        float alpha = 1;

        Tardis tardis = entity.tardis();

        if (tardis != null) {
            DematState demat = tardis.stateOrNull(DematState.state);
            if (demat != null) {
                alpha -= Math.clamp((float) demat.dematTimerTicks / DematState.DEMAT_TIME, 0f, 1f);
            }
        }

        if (alpha <= 0.01) return;

        int packedColor = ((int) (alpha * 255) << 24) | 0xFFFFFF;

        class_1921 emissiveType = AITRenderLayers.tardisEmissiveCullZOffset(emissiveTexture, true);
        // TODO figure out why -> AITRenderLayers.consoleCutoutNoCullZOffset(emissiveTexture); works for iris but not the tardisemissivenocullzoffset doesnt - loqor

        if (alpha < 1.0f && bufferSource instanceof class_4597.class_4598 immediate) {
            class_1921 depthType = AITRenderLayers.tardisDepth(emissiveTexture);
            class_4588 depthConsumer = bufferSource.getBuffer(depthType);

            for (GeoBone bone : bakedModel.topLevelBones()) {
                getRenderer().renderRecursively(poseStack, entity, bone, depthType, bufferSource,
                        depthConsumer, true, partialTick, FULLBRIGHT, packedOverlay, 0xFFFFFFFF);
            }
            immediate.method_22994(depthType);

            class_4588 emissiveConsumer = bufferSource.getBuffer(emissiveType);
            for (GeoBone bone : bakedModel.topLevelBones()) {
                getRenderer().renderRecursively(poseStack, entity, bone, emissiveType, bufferSource,
                        emissiveConsumer, true, partialTick, FULLBRIGHT, packedOverlay, packedColor);
            }
            immediate.method_22994(emissiveType);
        } else {
            class_4588 emissiveConsumer = bufferSource.getBuffer(emissiveType);
            for (GeoBone bone : bakedModel.topLevelBones()) {
                getRenderer().renderRecursively(poseStack, entity, bone, emissiveType, bufferSource,
                        emissiveConsumer, true, partialTick, FULLBRIGHT, packedOverlay, packedColor);
            }
        }
    }
}
