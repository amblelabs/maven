package dev.amble.ait.fabric;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.mod.AitStatistics;
import dev.amble.ait.common.lib.amblekit.AitEcs;
import dev.amble.ait.common.lib.tardis.AitControls;
import dev.amble.ait.common.lib.tardis.AitRoomPrototypes;
import dev.amble.ait.common.blocks.behavior.AitComposting;
import dev.amble.ait.common.blocks.behavior.AitStrippable;
import dev.amble.ait.common.lib.*;
import dev.drtheo.multidim.api.VoidChunkGenerator;
import dev.amble.ait.fabric.network.FabricPacketHandler;
import dev.amble.ait.interop.AitInterop;
import dev.amble.ait.xplat.IXplatAbstractions;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_8177;
import java.util.function.BiConsumer;

public final class FabricAitInit implements ModInitializer {

    @Override
    public void onInitialize() {
        FabricAitConfig.setup();
        FabricPacketHandler.init();

        this.initListeners();
        this.initRegistries();

        AitComposting.setup();
        AitStrippable.init();

        AitInterop.init();

        AitEcs.init();
    }

    private void initListeners() {
        CommandRegistrationCallback.EVENT.register((dispatcher, a, b) -> {
            var root = AitCommands.root();
            dispatcher.register(root);
        });

        ItemGroupEvents.MODIFY_ENTRIES_ALL.register((tab, entries) -> {
            AitBlocks.registerBlockCreativeTab(entries::method_45421, tab);
            AitItems.registerItemCreativeTab(entries, tab);
        });
    }

    private void initRegistries() {
        class_2378.method_10230(class_7923.field_41157, AitAPI.modLoc("void"), VoidChunkGenerator.CODEC);

        AitBlockSetTypes.registerBlocks(class_8177::method_49233);

        AitCreativeTabs.registerCreativeTabs(bind(class_7923.field_44687));

        AitSounds.registerSounds(bind(class_7923.field_41172));
        AitBlocks.registerBlocks(bind(class_7923.field_41175));
        AitBlocks.registerBlockItems(bind(class_7923.field_41178));
        AitBlockEntities.registerTiles(bind(class_7923.field_41181));
        AitItems.registerItems(bind(class_7923.field_41178));

        AitEntities.registerEntities(bind(class_7923.field_41177));
        AitAttributes.register(bind(class_7923.field_41190));
        AitMobEffects.register(bind(class_7923.field_41174));
        AitPotions.register(bind(class_7923.field_41179));

        AitComponents.registerComponents(bind(class_7923.field_49658));

        AitParticles.registerParticles(bind(class_7923.field_41180));

        AitLootFunctions.registerSerializers(bind(class_7923.field_41134));

        AitRoomPrototypes.registerRooms(bind(IXplatAbstractions.INSTANCE.getRoomRegistry()));
        AitControls.registerControls(bind(IXplatAbstractions.INSTANCE.getControlRegistry()));

        this.dieInAFire();

        AitStatistics.register();
    }

    private void dieInAFire() {
        FlammableBlockRegistry.getDefaultInstance();
    }

    private <T> BiConsumer<T, class_2960> bind(class_2378<T> registry) {
        return (t, id) -> class_2378.method_10230(registry, id, t);
    }
}
