package dev.amble.ait.client.renderer;

import dev.amble.ait.common.entities.ConsoleControlEntity;
import net.minecraft.class_1059;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class ConsoleControlEntityRenderer extends class_897<ConsoleControlEntity> {

    public ConsoleControlEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public void render(ConsoleControlEntity entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight) {
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }

    @Override
    public class_2960 getTextureLocation(ConsoleControlEntity entity) {
        return class_1059.field_5275;
    }
}
