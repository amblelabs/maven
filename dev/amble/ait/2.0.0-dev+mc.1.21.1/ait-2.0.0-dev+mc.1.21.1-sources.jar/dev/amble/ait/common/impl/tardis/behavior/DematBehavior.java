package dev.amble.ait.common.impl.tardis.behavior;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.event.tick.TardisTickEvents;
import dev.amble.ait.common.impl.tardis.state.*;
import dev.amble.ait.common.impl.tardis.state.controlstates.HandbrakeState;
import dev.amble.ait.common.lib.AitSounds;
import dev.drtheo.ecs.behavior.TBehavior;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_4208;
import net.minecraft.server.MinecraftServer;

public class DematBehavior implements TBehavior, TardisTickEvents {
    public static DematBehavior getInstance() {
        return new DematBehavior();
    }

    public void dematerialize(ServerTardis tardis, MinecraftServer server) {
        DematState state = tardis.state(DematState.state);
        ExteriorState exterior = tardis.state(ExteriorState.state);
        DesktopState desktop = tardis.state(DesktopState.state);
        DimensionState dim = tardis.state(DimensionState.state);
        HandbrakeState handbrake = tardis.stateOrNull(HandbrakeState.state);

        class_3218 tardisWorld = dim.level.get();

        if (handbrake != null) {
            if (handbrake.handbrake) {
                if (tardisWorld != null) {
                    tardisWorld.method_18456().forEach(player -> {
                        player.method_7353(class_2561.method_43470("Handbrake is active!"), true);
                    });
                }
                return;
            }
        }

        class_3218 exteriorWorld = server.method_3847(exterior.pos.comp_2207());

        if (tardisWorld != null) {
            tardisWorld.method_8396(null, desktop.doorPos, AitSounds.DEMAT, class_3419.field_15245, 1.0f, 1.0f);
        }

        if (exteriorWorld != null) {
            exteriorWorld.method_8396(null, exterior.pos.comp_2208(), AitSounds.DEMAT, class_3419.field_15245, 1.0f, 1.0f);
        }

        state.dematTimerTicks = 0;

        tardis.markDirty();
    }

    public void finishDemat(ServerTardis tardis, MinecraftServer server) {
        ExteriorState exteriorState = tardis.state(ExteriorState.state);
        class_4208 position = exteriorState.pos;

        class_3218 currentWorld = server.method_3847(position.comp_2207());

        class_2338 currentPosition = position.comp_2208();

        AitAPI.LOGGER.info("Dematerializing from {} at {}", position.comp_2207(), currentPosition);

        if (currentWorld == null) return;

        currentWorld.method_8650(currentPosition, false);

        tardis.removeState(exteriorState);
    }

    @Override
    public void tick(Tardis tardis) {
        DematState dematState = tardis.state(DematState.state);

        if (dematState.dematTimerTicks < 0) return;

        if (dematState.dematTimerTicks++ >= DematState.DEMAT_TIME) {
            if (tardis instanceof ServerTardis serverTardis) {
                DimensionState dim = tardis.state(DimensionState.state);

                class_3218 tardisWorld = dim.level.get();

                // We don't have to check if its null since we're already on the server side - Loqor
                finishDemat(serverTardis, tardisWorld.method_8503());
            }

            AitAPI.LOGGER.info("dematting done");
            dematState.dematTimerTicks = -1;
        }
    }
}
