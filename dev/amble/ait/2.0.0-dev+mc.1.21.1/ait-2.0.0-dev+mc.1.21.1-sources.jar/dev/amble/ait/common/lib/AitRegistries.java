package dev.amble.ait.common.lib;

import dev.amble.ait.api.tardis.ars.RoomPrototype;
import dev.amble.ait.api.tardis.control.Control;
import net.minecraft.class_2378;
import net.minecraft.class_5321;

import static dev.amble.ait.api.AitAPI.modLoc;

@SuppressWarnings("unused")
public class AitRegistries {
//    public static final ResourceKey<Registry<>>  = ResourceKey.createRegistryKey(modLoc(""));
    public static final class_5321<class_2378<RoomPrototype>> ROOMS = class_5321.method_29180(modLoc("rooms"));
    public static final class_5321<class_2378<Control>> CONTROLS = class_5321.method_29180(modLoc("controls"));
}
