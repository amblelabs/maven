@NullMarked
package dev.amble.ait.api.util;

import org.jspecify.annotations.NullMarked;