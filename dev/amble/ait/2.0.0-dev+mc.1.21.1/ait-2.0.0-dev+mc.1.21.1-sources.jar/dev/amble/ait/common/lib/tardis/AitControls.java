package dev.amble.ait.common.lib.tardis;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.control.Control;
import dev.amble.ait.common.impl.tardis.control.HandbrakeControl;
import dev.amble.ait.xplat.IXplatAbstractions;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class AitControls {
    public static final class_2378<Control> REGISTRY = IXplatAbstractions.INSTANCE.getControlRegistry();
    private static final Map<class_2960, Control> TYPES = new LinkedHashMap<>();

    public static final Control HANDBRAKE_CONTROL = type(new HandbrakeControl());

    public static void registerControls(BiConsumer<Control, class_2960> r) {
        for (var e : TYPES.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static Control type(Control control) {
        var old = TYPES.put(control.id(), control);
        if (old != null) {
            throw new IllegalArgumentException("Duplicate room prototype id/resource location: " + control.id());
        }
        return control;
    }
}
