package dev.amble.ait.common.entities;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.mod.block.entity.LinkableEntity;
import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.control.Control;
import dev.amble.ait.common.impl.tardis.state.controlstates.HandbrakeState;
import dev.amble.ait.common.lib.AitEntities;
import dev.amble.ait.common.lib.tardis.AitControls;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_2960;
import org.jspecify.annotations.Nullable;

public class ConsoleControlEntity extends LinkableEntity {

    private static final class_2940<String> CONTROL_ID =
            class_2945.method_12791(ConsoleControlEntity.class, class_2943.field_13326);
    public Control control;

    public ConsoleControlEntity(class_1299<?> type, class_1937 level) {
        super(type, level);
    }

    public ConsoleControlEntity(class_1937 level, Tardis tardis, Control control) {
        super(AitEntities.CONSOLE_CONTROL, level);
        this.link(tardis);
        this.control = control;
        this.syncToClient();
    }

    public void syncToClient() {
        this.field_6011.method_12778(CONTROL_ID, this.control != null ? this.control.id().toString() : "");
    }

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        if (this.control != null && this.tardis() != null) {
            this.control.run(this.tardis());
        }
        return class_1269.field_5812;
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (this.control != null && this.tardis() != null) {
            this.control.run(this.tardis());
            System.out.println(this.tardis().state(HandbrakeState.state).handbrake);
            return true;
        }
        return false;
    }

    @Override
    public boolean method_5863() {
        return !this.method_31481();
    }

    @Override
    public boolean method_5732() {
        return true;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(CONTROL_ID, "");
    }

    @Override
    protected void method_5749(class_2487 compound) {
        super.method_5749(compound);
        this.control = null;

        if (compound.method_10545("Control")) {
            String controlId = compound.method_10558("Control");
            if (!controlId.isBlank()) {
                try {
                    class_2960 id = class_2960.method_60654(controlId);
                    this.control = AitControls.REGISTRY.method_10223(id);

                    if (this.control == null) {
                        AitAPI.LOGGER.warn("Could not find console control '{}'; registry lookup returned null", controlId);
                    }
                } catch (Exception e) {
                    AitAPI.LOGGER.warn("Failed to parse console control id '{}'", controlId, e);
                }
            }
        }

        syncToClient();
    }

    @Override
    protected void method_5652(class_2487 compound) {
        super.method_5652(compound);
        if (this.control != null) {
            compound.method_10582("Control", this.control.id().toString());
        }
    }
}
