package dev.amble.ait.api.util;

import net.minecraft.class_2350;
import net.minecraft.class_3542;

public enum SubDirection implements class_3542 {
    NORTH {
        @Override
        public class_2350 toDirectionX() {
            return class_2350.field_11043;
        }

        @Override
        public class_2350 toDirectionY() {
            return class_2350.field_11043;
        }

        @Override
        public String method_15434() {
            return "north";
        }
    },
    NORTH_EAST {
        @Override
        public class_2350 toDirectionX() {
            return class_2350.field_11034;
        }

        @Override
        public class_2350 toDirectionY() {
            return class_2350.field_11043;
        }

        @Override
        public String method_15434() {
            return "north_east";
        }
    },
    EAST {
        @Override
        public class_2350 toDirectionX() {
            return class_2350.field_11034;
        }

        @Override
        public class_2350 toDirectionY() {
            return class_2350.field_11034;
        }

        @Override
        public String method_15434() {
            return "east";
        }
    },
    SOUTH_EAST {
        @Override
        public class_2350 toDirectionX() {
            return class_2350.field_11034;
        }

        @Override
        public class_2350 toDirectionY() {
            return class_2350.field_11035;
        }

        @Override
        public String method_15434() {
            return "south_east";
        }
    },
    SOUTH {
        @Override
        public class_2350 toDirectionX() {
            return class_2350.field_11035;
        }

        @Override
        public class_2350 toDirectionY() {
            return class_2350.field_11035;
        }

        @Override
        public String method_15434() {
            return "south";
        }
    },
    SOUTH_WEST {
        @Override
        public class_2350 toDirectionX() {
            return class_2350.field_11039;
        }

        @Override
        public class_2350 toDirectionY() {
            return class_2350.field_11035;
        }

        @Override
        public String method_15434() {
            return "south_west";
        }
    },
    WEST {
        @Override
        public class_2350 toDirectionX() {
            return class_2350.field_11039;
        }

        @Override
        public class_2350 toDirectionY() {
            return class_2350.field_11039;
        }

        @Override
        public String method_15434() {
            return "west";
        }
    },
    NORTH_WEST {
        @Override
        public class_2350 toDirectionX() {
            return class_2350.field_11039;
        }

        @Override
        public class_2350 toDirectionY() {
            return class_2350.field_11043;
        }

        @Override
        public String method_15434() {
            return "north_west";
        }
    };

    public static final SubDirection[] VALUES = SubDirection.values();

    public int toDeg() {
        return this.ordinal() * 45;
    }

    /**
     * @return north-east => east
     */
    public abstract class_2350 toDirectionX();

    /**
     * @return north-east => north
     */
    public abstract class_2350 toDirectionY();

    private static final class_2350[] DIRECTIONS = class_2350.values();

    public static class_2350 degToDir(int deg) {
        deg = deg % 360;
        if (deg == 0) return class_2350.field_11043;

        return DIRECTIONS[Math.floorDiv(deg, 90)];
    }

    public static SubDirection degToSubDir(int deg) {
        deg = deg % 360;
        if (deg == 0) return SubDirection.NORTH;

        return VALUES[Math.floorDiv(deg, 45)];
    }
}
