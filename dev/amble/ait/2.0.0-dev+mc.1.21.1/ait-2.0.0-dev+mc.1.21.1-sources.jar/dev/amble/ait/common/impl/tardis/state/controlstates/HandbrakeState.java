package dev.amble.ait.common.impl.tardis.state.controlstates;

import dev.amble.ait.api.AitAPI;
import dev.drtheo.ecs.state.NbtSerializer;
import dev.drtheo.ecs.state.TState;
import net.minecraft.class_2487;

public class HandbrakeState implements TState<HandbrakeState>, NbtSerializer {

    public boolean handbrake = false;

    public static final Type<HandbrakeState> state = new NbtBacked<>(AitAPI.modLoc("handbrake"), 0) {
        @Override
        public HandbrakeState fromNbt(class_2487 nbt, boolean isClient) {
            HandbrakeState state = new HandbrakeState();

            state.handbrake = nbt.method_10577("Handbrake");

            return state;
        }
    };

    @Override
    public void toNbt(class_2487 nbt, boolean isClient) {
        nbt.method_10556("Handbrake", handbrake);
    }

    @Override
    public Type<HandbrakeState> type() {
        return state;
    }
}