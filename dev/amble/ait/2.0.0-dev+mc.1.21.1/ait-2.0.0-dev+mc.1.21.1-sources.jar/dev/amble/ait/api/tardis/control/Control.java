package dev.amble.ait.api.tardis.control;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.Tardis;
import net.minecraft.class_2960;

public interface Control {

    class_2960 id();
    void run(Tardis tardis);

    abstract class Toggle implements Control {
        private boolean toggled = false;

        @Override
        public void run(Tardis tardis) {
            this.toggled = !this.toggled;
            this.run(this.toggled, tardis);
            AitAPI.LOGGER.info("I ran!");
        }

        public abstract boolean run(boolean toggled, Tardis tardis);
    }
}
