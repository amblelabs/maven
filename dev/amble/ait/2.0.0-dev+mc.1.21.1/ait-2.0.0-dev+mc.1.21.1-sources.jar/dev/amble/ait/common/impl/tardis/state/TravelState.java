package dev.amble.ait.common.impl.tardis.state;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.util.NbtUtil;
import dev.drtheo.ecs.state.NbtSerializer;
import dev.drtheo.ecs.state.TState;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_4208;
import net.minecraft.class_5321;

public class TravelState implements TState<TravelState>, NbtSerializer {

    public TravelState(class_4208 blockPos, int rot, class_4208 lastPos, int lastRot) {
        this.destinationPos = blockPos;
        this.destinationRot = rot;
        this.lastPos = lastPos;
        this.lastRot = lastRot;
    }

    // I'll have to come back to this as this could cause potential travel problems, but the TravelState should never be null, so this is a placeholder to prevent crashes. - Loqor
    public TravelState() {
        this.destinationPos = new class_4208(class_1937.field_25179, new class_2338(0, 64, 0));
        this.destinationRot = 0;
        this.lastPos = new class_4208(class_1937.field_25179, new class_2338(0, 64, 0));
        this.lastRot = 0;
    }

    public class_4208 destinationPos;
    /**
     * FULL rotation, aka `[0; 360]`
     */
    public int destinationRot;

    public int flightTime;
    public int maxFlightTime;

    public class_4208 lastPos; // Used for fast return, unimplemented. - Loqor
    public int lastRot;

    public static final Type<TravelState> state = new NbtBacked<>(AitAPI.modLoc("travel"), 0) {
        @Override
        public TravelState fromNbt(class_2487 nbt, boolean isClient) {
            TravelState travelState = new TravelState();

            class_2520 dimTag = nbt.method_10580("Dimension");
            class_5321<class_1937> dimension = NbtUtil.dimensionCodec(dimTag).getOrThrow();

            class_2338 blockPos = class_2512.method_10691(nbt, "Position").orElse(new class_2338(0, 64, 0));
            travelState.destinationPos = class_4208.method_19443(dimension, blockPos);

            travelState.destinationRot = nbt.method_10550("Rotation");

            travelState.flightTime = nbt.method_10550("FlightTime");
            travelState.maxFlightTime = nbt.method_10550("MaxFlightTime");

            return travelState;
        }
    };

    @Override
    public void toNbt(class_2487 nbt, boolean isClient) {
        nbt.method_10582("Dimension", destinationPos.comp_2207().method_29177().toString());
        nbt.method_10566("Position", class_2512.method_10692(destinationPos.comp_2208()));
        nbt.method_10569("Rotation", destinationRot);
        nbt.method_10569("FlightTime", flightTime);
        nbt.method_10569("MaxFlightTime", maxFlightTime);
    }

    @Override
    public Type<TravelState> type() {
        return state;
    }

    public void setMaxFlightTime(int maxTime) {
        this.maxFlightTime = maxTime;
    }

    public void setFlightTime(int time) {
        this.maxFlightTime = time;
    }

    public void updateDestinationPos(class_4208 globalPos) {
        updateDestinationPos(globalPos, this.destinationRot);
    }

    public void updateDestinationPos(int rot) {
        updateDestinationPos(this.destinationPos, rot);
    }

    public void updateDestinationPos(class_4208 globalPos, int rot) {
        this.destinationPos = globalPos;
        this.destinationRot = rot;
    }
}
