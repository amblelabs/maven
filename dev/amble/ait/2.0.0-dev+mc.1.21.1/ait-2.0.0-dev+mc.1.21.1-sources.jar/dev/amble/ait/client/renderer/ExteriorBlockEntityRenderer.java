package dev.amble.ait.client.renderer;

import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.client.model.PoliceBoxGeoModel;
import dev.amble.ait.common.blocks.ExteriorBlock;
import dev.amble.ait.common.blocks.ExteriorBlockEntity;
import dev.amble.ait.common.impl.tardis.state.DematState;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoBlockRenderer;
import software.bernie.geckolib.util.Color;

public class ExteriorBlockEntityRenderer extends GeoBlockRenderer<ExteriorBlockEntity> {

    public ExteriorBlockEntityRenderer(class_5614.class_5615 ctx) {
        super(new PoliceBoxGeoModel());
        addRenderLayer(new ExteriorEmissiveLayer(this));
        // TODO finish this someday lel
        // addRenderLayer(new AccumulationLayer<PoliceBoxBlockEntity>(this,
        //         ResourceLocation.withDefaultNamespace("textures/block/sand.png"), 256));
    }


    // No-op: we handle rotation via ROTATION blockstate in preRender
    @Override
    protected void rotateBlock(class_2350 facing, class_4587 poseStack) { }

    // No-op: we handle rotation via ROTATION blockstate in preRender
    @Override
    protected class_2350 getFacing(ExteriorBlockEntity block) {
        return class_2350.field_11043;
    }

    @Override
    public class_1921 getRenderType(ExteriorBlockEntity entity, class_2960 texture,
                                    @Nullable class_4597 bufferSource, float partialTick) {
        return AITRenderLayers.tardisTranslucent(texture);
    }

    @Override
    public void preRender(class_4587 poseStack, ExteriorBlockEntity entity, BakedGeoModel model,
                          @Nullable class_4597 bufferSource, @Nullable class_4588 buffer,
                          boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                          int colour) {
        if (isReRender) return;

        class_2680 state = entity.method_11010();

        boolean onSlab = state.method_11654(ExteriorBlock.ON_SLAB);
        int rot = ExteriorBlock.getRotation(state);

        poseStack.method_22904(0.5, onSlab ? -0.5 : 0, 0.5);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-rot));
    }

    @Override
    public void actuallyRender(class_4587 poseStack, ExteriorBlockEntity entity, BakedGeoModel model,
                               @Nullable class_1921 renderType, class_4597 bufferSource, @Nullable class_4588 buffer,
                               boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                               int colour) {
        float alpha = 1f;

        Tardis tardis = entity.tardis();
        if (tardis == null) return;

        DematState demat = tardis.stateOrNull(DematState.state);

        if (demat != null)
            alpha -= Math.clamp((float) demat.dematTimerTicks / DematState.DEMAT_TIME, 0f, 1f);

        if (alpha <= 0.01) return;

        int packedColor = ((int) (alpha * 255) << 24) | 0xFFFFFF;

        if (alpha < 1.0f && bufferSource instanceof class_4597.class_4598 immediate) {
            class_2960 texture = getGeoModel().getTextureResource(entity, this);

            class_1921 depthType = AITRenderLayers.tardisDepth(texture);
            class_4588 depthConsumer = bufferSource.getBuffer(depthType);
            super.actuallyRender(poseStack, entity, model, depthType, bufferSource, depthConsumer,
                    isReRender, partialTick, packedLight, packedOverlay, 0xFFFFFFFF);
            immediate.method_22994(depthType);

            class_4588 frontConsumer = bufferSource.getBuffer(renderType);
            super.actuallyRender(poseStack, entity, model, renderType, bufferSource, frontConsumer,
                    isReRender, partialTick, packedLight, packedOverlay, packedColor);
            immediate.method_22994(renderType);
        } else {
            super.actuallyRender(poseStack, entity, model, renderType, bufferSource, buffer,
                    isReRender, partialTick, packedLight, packedOverlay, packedColor);
        }

        // TODO: DEBATE ON WHETHER OR NOT TO KEEP THIS. - Loqor
        class_327 font = class_310.method_1551().field_1772;
        String text = "POLICE -=- BOX";
        int textWidth = font.method_1727(text);

        poseStack.method_22903();
        poseStack.method_46416(0, 2.425f, 0);

        for (int side = 0; side < 4; side++) {
            poseStack.method_22903();
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * 90f));
            poseStack.method_46416(0, 0, -0.79f);
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(180f));
            poseStack.method_22905(0.014f, 0.014f, 0.014f);

            font.method_27521(text, -textWidth / 2f, 0, Color.ofRGBA(255, 255, 255, 0).getColor(), false,
                    poseStack.method_23760().method_23761(), bufferSource, class_327.class_6415.field_33995, 0, 0xF000F0);

            poseStack.method_22909();
        }

        poseStack.method_22909();
    }

    @Override
    public int method_33893() {
        return 256;
    }
}
