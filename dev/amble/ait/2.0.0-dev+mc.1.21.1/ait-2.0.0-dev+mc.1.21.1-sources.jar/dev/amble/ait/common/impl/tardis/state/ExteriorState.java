package dev.amble.ait.common.impl.tardis.state;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.util.NbtUtil;
import dev.amble.ait.api.util.SubDirection;
import dev.amble.ait.common.blocks.ExteriorBlock;
import dev.drtheo.ecs.state.NbtSerializer;
import dev.drtheo.ecs.state.TState;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_4208;
import net.minecraft.class_5321;

public class ExteriorState implements TState<ExteriorState>, NbtSerializer {

    public static final Type<ExteriorState> state = new NbtBacked<>(AitAPI.modLoc("exterior"), 0) {
        @Override
        public ExteriorState fromNbt(class_2487 nbt, boolean isClient) {
            class_2520 dimTag = nbt.method_10580("dimension");
            class_5321<class_1937> dimension = NbtUtil.dimensionCodec(dimTag).getOrThrow();

            class_2338 blockPos = class_2512.method_10691(nbt, "position").orElse(new class_2338(0, 64, 0));

            return new ExteriorState(class_4208.method_19443(dimension, blockPos), nbt.method_10550("rotation"));
        }
    };

    public class_4208 pos;

    private SubDirection dir = SubDirection.NORTH;
    private int angle; // GlobalPos doesn't store the direction, so we can use a separate value. - Loqor

    public ExteriorState(class_4208 globalPos, SubDirection dir, int angle) {
        this.pos = globalPos;
        this.dir = dir;
        this.angle = angle;
    }

    public ExteriorState(class_4208 globalPos, int rotation) {
        this.pos = globalPos;
        this.setRotation(rotation);
    }

    // Prevents null stuff, basically a bullshit location. - Loqor
    public ExteriorState() {
        this(new class_4208(class_1937.field_25179, new class_2338(0, 64, 0)), 0);
    }

    @Override
    public Type<ExteriorState> type() {
        return state;
    }

    @Override
    public void toNbt(class_2487 nbt, boolean isClient) {
        nbt.method_10582("dimension", pos.comp_2207().method_29177().toString());
        nbt.method_10566("position", class_2512.method_10692(pos.comp_2208()));
        nbt.method_10569("rotation", angle);
    }

    public int getRotation() {
        return dir.toDeg() + angle;
    }

    public int getAdditiveAngle() {
        return angle;
    }

    public SubDirection getDir() {
        return dir;
    }

    public void setRotation(SubDirection dir, int angle) {
        this.dir = dir;
        this.angle = angle;
    }

    public void setRotation(int deg) {
        deg = deg % 360;
        this.setRotation(SubDirection.degToSubDir(deg), deg % 45);
    }

    public class_2680 writeBlockState(class_2680 state) {
        return state.method_11657(ExteriorBlock.ROTATION, dir)
                .method_11657(ExteriorBlock.ANGLE, angle);
    }
}
