package dev.amble.ait.api.mod.block.entity;

import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.TardisManager;
import org.jspecify.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2945;
import net.minecraft.class_3218;

public class LinkableEntity extends class_1297 {

    private static final String ID_TAG = "Tardis";

    private @Nullable UUID tardisId;

    /**
     * Lazily initialized, prefer to use the getter ({@link #tardis()}.
     */
    private @Nullable Tardis tardis;

    public LinkableEntity(class_1299<?> type, class_1937 level) {
        super(type, level);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        this.tryMark();
    }

    @Override
    protected void method_5749(class_2487 compound) {
        if (!compound.method_25928(field_29985)) return;
        this.tardisId = compound.method_25926(field_29985);
        this.tryMark();
    }

    @Override
    protected void method_5652(class_2487 compound) {
        if (this.tardisId != null)
            compound.method_25927(field_29985, this.tardisId);
    }

    public @Nullable Tardis tardis() {
        if (this.tardis != null) return this.tardis;

        if (this.tardisId != null)
            return this.tardis = TardisManager.apply(this.method_37908(),
                    manager -> manager.get(this.tardisId));

        return null;
    }

    @Override
    public void method_5650(class_5529 reason) {
        super.method_5650(reason);
        this.tryUnmark();
    }

    public void link(Tardis tardis) {
        this.tardisId = tardis.id();
        this.tardis = tardis;

        this.handleLink();
    }

    public void link(UUID id) {
        this.tardisId = id;
        this.tardis = TardisManager.apply(this.method_37908(), manager -> manager.get(id));

        this.handleLink();
    }

    private void tryMark() {
        if (this.method_37908() instanceof class_3218 serverWorld && this.tardis() != null)
            TardisManager.asChunkTracker(serverWorld).ait$mark(new class_1923(this.method_24515()), (ServerTardis) this.tardis);
    }

    
    private void tryUnmark() {
        if (this.method_37908() instanceof class_3218 serverWorld && this.tardis() != null)
            TardisManager.asChunkTracker(serverWorld).ait$unmark(new class_1923(this.method_24515()), (ServerTardis) this.tardis);
    }

    private void handleLink() {
        this.tryMark();
    }
}