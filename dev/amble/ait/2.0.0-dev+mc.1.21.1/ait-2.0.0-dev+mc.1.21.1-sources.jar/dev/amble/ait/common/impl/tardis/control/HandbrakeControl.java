package dev.amble.ait.common.impl.tardis.control;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.control.Control;
import dev.amble.ait.common.impl.tardis.state.controlstates.HandbrakeState;
import net.minecraft.class_2960;

public class HandbrakeControl extends Control.Toggle {

    @Override
    public void run(Tardis tardis) {
        HandbrakeState state = tardis.resolveState(HandbrakeState.state);
        this.run(!state.handbrake, tardis);
    }

    @Override
    public boolean run(boolean toggled, Tardis tardis) {
        HandbrakeState state = tardis.resolveState(HandbrakeState.state);

        state.handbrake = toggled;
        tardis.markDirty();

        return state.handbrake;
    }

    @Override
    public class_2960 id() {
        return AitAPI.modLoc("handbrake");
    }
}
