package dev.drtheo.multidim;

import com.mojang.serialization.Lifecycle;
import dev.drtheo.multidim.api.MultiDimServer;
import dev.drtheo.multidim.api.MultiDimServerLevel;
import dev.drtheo.multidim.api.MutableRegistry;
import dev.drtheo.multidim.api.WorldBlueprint;
import dev.drtheo.multidim.impl.SimpleWorldProgressListener;
import dev.drtheo.multidim.util.MultiDimUtil;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.jspecify.annotations.Nullable;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MultiDim {

    private static @Nullable MultiDim instance;

    private final Map<class_2960, WorldBlueprint> blueprints = new HashMap<>();
    private final MinecraftServer server;

    private final Set<class_3218> toDelete = new ReferenceOpenHashSet<>();
    private final Set<class_3218> toUnload = new ReferenceOpenHashSet<>();

    private MultiDim(MinecraftServer server) {
        this.server = server;
    }

    public MinecraftServer server() {
        return this.server;
    }

    public void tick() {
        if (!this.toDelete.isEmpty()) {
            this.toDelete.removeIf(this::tickDeleteWorld);
        }
        if (!this.toUnload.isEmpty()) {
            this.toUnload.removeIf(this::tickUnloadWorld);
        }
    }

    public boolean isWorldUnloaded(class_3218 world) {
        return world.method_18456().isEmpty() && world.method_14178().method_21694() <= 0;
    }

    private boolean prepareForUnload(class_3218 world) {
        if (this.isWorldUnloaded(world)) {
            return true;
        }

        this.kickPlayers(world);
        return false;
    }

    public void kickPlayers(class_3218 world) {
        if (world.method_18456().isEmpty()) {
            return;
        }

        class_3218 overworld = this.server.method_30002();
        class_2338 spawnPos = overworld.method_43126();

        for (class_3222 player : world.method_18456()) {
            player.method_14251(overworld, spawnPos.method_10263() + 0.5D, spawnPos.method_10264(), spawnPos.method_10260() + 0.5D, player.method_36454(), player.method_36455());
        }
    }

    private boolean tickDeleteWorld(class_3218 world) {
        if (!this.prepareForUnload(world)) {
            return false;
        }

        this.remove(world.method_27983());
        return true;
    }

    private boolean tickUnloadWorld(class_3218 world) {
        if (!this.prepareForUnload(world)) {
            return false;
        }

        this.unload(world.method_27983());
        return true;
    }

    public void register(WorldBlueprint blueprint) {
        this.blueprints.put(blueprint.id(), blueprint);
    }

    public static MultiDim get(MinecraftServer server) {
        if (instance == null || instance.server != server) {
            instance = new MultiDim(server);
        }

        return instance;
    }

    public MultiDimServerLevel add(WorldBlueprint blueprint, class_2960 id) {
        return this.addOrLoad(blueprint, id, true);
    }

    public MultiDimServerLevel load(WorldBlueprint blueprint, class_2960 id) {
        return this.addOrLoad(blueprint, id, false);
    }

    public MultiDimServerLevel addOrLoad(WorldBlueprint blueprint, class_2960 id, boolean created) {
        return this.addOrLoad(blueprint, class_5321.method_29179(class_7924.field_41223, id), created);
    }

    public MultiDimServerLevel add(WorldBlueprint blueprint, class_5321<class_1937> id) {
        return this.addOrLoad(blueprint, id, true);
    }

    public MultiDimServerLevel load(WorldBlueprint blueprint, class_5321<class_1937> id) {
        return this.addOrLoad(blueprint, id, false);
    }

    public MultiDimServerLevel addOrLoad(WorldBlueprint blueprint, class_5321<class_1937> id, boolean created) {
        class_3218 existing = this.server.method_3847(id);

        if (existing != null) {
            if (existing instanceof MultiDimServerLevel multiDimServerLevel) {
                return multiDimServerLevel;
            }

            throw new IllegalStateException("World " + id.method_29177() + " is already loaded as " + existing.getClass().getName());
        }

        MutableRegistry<class_5363> dimensionsRegistry = MultiDimUtil.getMutableDimensionsRegistry(this.server);
        boolean wasFrozen = dimensionsRegistry.multidim$isFrozen();
        if (wasFrozen) {
            dimensionsRegistry.multidim$unfreeze();
        }

        class_5363 options = blueprint.createOptions(this.server);
        class_5321<class_5363> key = class_5321.method_29179(class_7924.field_41224, id.method_29177());
        if (!dimensionsRegistry.multidim$contains(key)) {
            dimensionsRegistry.multidim$add(key, options, Lifecycle.stable());
        }

        if (wasFrozen) {
            dimensionsRegistry.multidim$freeze();
        }

        MultiDimServerLevel world = blueprint.createWorld(this.server, id, options, created);
        this.load(world);
        return world;
    }

    public void queueUnload(MultiDimServerLevel world) {
        this.toUnload.add(world);
    }

    public void queueUnload(class_5321<class_1937> key) {
        class_3218 world = this.server.method_3847(key);
        if (world != null) {
            this.toUnload.add(world);
        }
    }

    private void unload(class_5321<class_1937> key) {
        class_3218 world = ((MultiDimServer) this.server).multidim$removeWorld(key);
        if (world == null) return;

        world.method_14176(new SimpleWorldProgressListener(() -> {
            MultiDimUtil.getMutableDimensionsRegistry(this.server).multidim$remove(key.method_29177());
            this.refreshCommandTrees();
        }), true, false);
    }

    public void queueRemove(MultiDimServerLevel world) {
        this.toDelete.add(world);
    }

    public void queueRemove(class_5321<class_1937> key) {
        class_3218 world = this.server.method_3847(key);
        if (world != null) {
            this.toDelete.add(world);
        }
    }

    private void remove(class_5321<class_1937> key) {
        class_3218 world = ((MultiDimServer) this.server).multidim$removeWorld(key);

        if (world == null) return;

        MultiDimUtil.getMutableDimensionsRegistry(this.server).multidim$remove(key.method_29177());
        this.refreshCommandTrees();

        Path worldDirectory = ((MultiDimServer) this.server).multidim$getSession().method_27424(key);

        if (!Files.exists(worldDirectory)) {
            return;
        }

        try (var walk = Files.walk(worldDirectory)) {
            walk.sorted(Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.deleteIfExists(path);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        } catch (Throwable e) {
            MultiDimMod.LOGGER.warn("Failed to delete world directory {}", worldDirectory, e);
        }
    }

    private void load(MultiDimServerLevel world) {
        MultiDimMod.LOGGER.info("Loading world {}", world.method_27983().method_29177());

        if (((MultiDimServer) this.server).multidim$hasWorld(world.method_27983())) {
            MultiDimMod.LOGGER.warn("World {} is already loaded", world.method_27983().method_29177());
            return;
        }

        ((MultiDimServer) this.server).multidim$addWorld(world);
        world.method_18765(() -> true);
        this.refreshCommandTrees();
    }

    private void refreshCommandTrees() {
        this.server.method_3760().method_14571().forEach(player -> this.server.method_3734().method_9241(player));
    }

    public @Nullable WorldBlueprint getBlueprint(class_2960 id) {
        return this.blueprints.get(id);
    }
}


