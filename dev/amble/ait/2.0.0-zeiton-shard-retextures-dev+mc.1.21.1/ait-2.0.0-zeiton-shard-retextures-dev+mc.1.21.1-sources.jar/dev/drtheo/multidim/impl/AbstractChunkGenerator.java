package dev.drtheo.multidim.impl;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1966;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_3233;
import net.minecraft.class_4543;
import net.minecraft.class_4966;
import net.minecraft.class_5138;
import net.minecraft.class_5281;
import net.minecraft.class_5539;
import net.minecraft.class_6748;
import net.minecraft.class_7138;

public abstract class AbstractChunkGenerator extends class_2794 {

    public AbstractChunkGenerator(class_1966 biomeSource) {
        super(biomeSource);
    }

    @Override
    public void method_12108(class_3233 region, long seed, class_7138 randomState,
                              class_4543 biomeManager, class_5138 structureManager,
                              class_2791 chunk, class_2893.class_2894 carverStep) { }

    @Override
    public void method_12110(class_3233 region, class_5138 structureManager,
                              class_7138 randomState, class_2791 chunk) { }

    @Override
    public void method_12107(class_3233 region) { }

    @Override
    public int method_12104() {
        return 0;
    }

    @Override
    public int method_16398() {
        return 0;
    }

    @Override
    public int method_33730() {
        return 0;
    }

    @Override
    public int method_16397(int x, int z, class_2902.class_2903 heightmap, class_5539 world,
                              class_7138 randomState) {
        return 0;
    }

    @Override
    public class_4966 method_26261(int x, int z, class_5539 world, class_7138 randomState) {
        return new class_4966(0, new class_2680[0]);
    }

    @Override
    public void method_40450(List<String> info, class_7138 randomState, class_2338 pos) { }

    @Override
    public CompletableFuture<class_2791> method_12088(class_6748 blender, class_7138 randomState,
                                                         class_5138 structureManager,
                                                         class_2791 chunk) {
        return CompletableFuture.completedFuture(chunk);
    }

    @Override
    public void method_12102(class_5281 world, class_2791 chunk,
                                      class_5138 structureManager) { }

    @Override
    public void method_16130(class_5281 world, class_5138 structureManager,
                                  class_2791 chunk) { }
}


