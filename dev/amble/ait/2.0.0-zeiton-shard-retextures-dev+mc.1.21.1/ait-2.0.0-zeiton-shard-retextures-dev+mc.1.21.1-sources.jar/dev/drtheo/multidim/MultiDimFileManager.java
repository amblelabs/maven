package dev.drtheo.multidim;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.drtheo.multidim.api.MultiDimServerLevel;
import dev.drtheo.multidim.api.WorldBlueprint;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5218;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.jspecify.annotations.Nullable;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

public final class MultiDimFileManager {

    private static final Gson GSON = new Gson();

    private MultiDimFileManager() {
    }

    public static Path getRootSavePath(Path root) {
        return root.resolve(".multidim2");
    }

    public static Path getRootSavePath(MinecraftServer server) {
        return getRootSavePath(server.method_27050(class_5218.field_24188));
    }

    public static Path getSavePath(MinecraftServer server, class_2960 id) {
        return getRootSavePath(server).resolve(id.method_12836()).resolve(id.method_12832() + ".json");
    }

    public static void init() {
        // platform bootstrap wires lifecycle hooks in loader-specific modules
    }

    public static void writeIfNeeded(MinecraftServer server, class_3218 world) {
        if (world instanceof MultiDimServerLevel multiDimLevel && multiDimLevel.getBlueprint().persistent()) {
            write(server, multiDimLevel);
        }
    }

    public static void write(MinecraftServer server, MultiDimServerLevel world) {
        class_5321<class_1937> key = world.method_27983();
        Path file = getSavePath(server, key.method_29177());

        try {
            if (!Files.exists(file)) {
                Files.createDirectories(file.getParent());
                Files.createFile(file);
            }

            JsonObject root = new JsonObject();
            root.addProperty("blueprint", world.getBlueprint().id().toString());
            Files.writeString(file, GSON.toJson(root));
        } catch (IOException e) {
            MultiDimMod.LOGGER.warn("Couldn't create world file {}", key.method_29177(), e);
        }
    }

    public static void readAll(MinecraftServer server) {
        if (!server.method_3806()) return;

        Path root = getRootSavePath(server);
        if (!Files.exists(root)) {
            return;
        }

        MultiDim multidim = MultiDim.get(server);

        try (Stream<Path> stream = Files.list(root)) {
            stream.forEach(namespace -> {
                if (Files.isDirectory(namespace)) {
                    readNamespace(multidim, namespace);
                }
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void readNamespace(MultiDim multidim, Path namespace) {
        try (Stream<Path> stream = Files.list(namespace)) {
            stream.forEach(file -> {
                Saved saved = readFromFile(multidim, namespace.getFileName().toString(), file);

                if (saved == null) {
                    MultiDimMod.LOGGER.warn("Failed to load world from file {}", file);
                    return;
                }

                WorldBlueprint blueprint = multidim.getBlueprint(saved.blueprint());
                if (blueprint != null && blueprint.persistent() && blueprint.autoLoad()) {
                    if (multidim.server().method_3847(saved.world()) != null) {
                        return;
                    }

                    multidim.load(blueprint, saved.world());
                }
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static @Nullable Saved readFromFile(MultiDim multidim, String namespace, Path file) {
        String fileName = file.getFileName().toString();
        class_2960 id = class_2960.method_60655(namespace, fileName.substring(0, fileName.length() - 5));
        return read(multidim.server(), id);
    }

    private static @Nullable Saved read(MinecraftServer server, class_2960 id) {
        Path file = getSavePath(server, id);

        try {
            JsonObject element = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            class_2960 blueprint = class_2960.method_60654(element.get("blueprint").getAsString());
            return new Saved(blueprint, class_5321.method_29179(net.minecraft.class_7924.field_41223, id));
        } catch (Throwable e) {
            MultiDimMod.LOGGER.warn("Couldn't read world file {}", id, e);
            return null;
        }
    }

    public record Saved(class_2960 blueprint, class_5321<class_1937> world) {
    }
}





