package dev.drtheo.multidim.mixin;

import com.mojang.serialization.Lifecycle;
import dev.drtheo.multidim.api.MutableRegistry;
import it.unimi.dsi.fastutil.objects.ObjectList;
import it.unimi.dsi.fastutil.objects.Reference2IntMap;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import java.util.Optional;
import net.minecraft.class_2370;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9248;

@Mixin(class_2370.class)
public abstract class MappedRegistryMixin<T> implements MutableRegistry<T> {

    @Shadow @Final private Map<class_2960, class_6880.class_6883<T>> byLocation;
    @Shadow @Final private Map<T, class_6880.class_6883<T>> byValue;
    @Shadow @Final private Reference2IntMap<T> toId;
    @Shadow @Final private ObjectList<class_6880.@Nullable class_6883<T>> byId;
    @Shadow @Final private Map<class_5321<T>, class_6880.class_6883<T>> byKey;
    @Shadow @Final private Map<T, class_9248> registrationInfos;
    @Shadow private boolean frozen;

    @Shadow public abstract class_6880.class_6883<T> register(class_5321<T> key, T entry, class_9248 registrationInfo);
    @Shadow public abstract boolean containsKey(class_5321<T> key);

    @Override
    public boolean multidim$remove(T entry) {
        class_6880.class_6883<T> holder = this.byValue.get(entry);
        int rawId = this.toId.removeInt(entry);
        if (holder == null || rawId == -1) {
            return false;
        }

        this.byLocation.remove(holder.method_40237().method_29177());
        this.byKey.remove(holder.method_40237());
        this.registrationInfos.remove(entry);
        this.byValue.remove(entry);

        if (rawId < this.byId.size()) {
            this.byId.set(rawId, null);
        }

        return true;
    }

    @Override
    public boolean multidim$remove(class_2960 key) {
        class_6880.class_6883<T> holder = this.byLocation.get(key);
        return holder != null && this.multidim$remove(holder.comp_349());
    }

    @Override
    public void multidim$freeze() {
        this.frozen = true;
    }

    @Override
    public void multidim$unfreeze() {
        this.frozen = false;
    }

    @Override
    public boolean multidim$isFrozen() {
        return this.frozen;
    }

    @Override
    public boolean multidim$contains(class_5321<T> key) {
        return this.containsKey(key);
    }

    @Override
    public class_6880.class_6883<T> multidim$add(class_5321<T> key, T entry, Lifecycle lifecycle) {
        return this.register(key, entry, new class_9248(Optional.empty(), lifecycle));
    }
}

