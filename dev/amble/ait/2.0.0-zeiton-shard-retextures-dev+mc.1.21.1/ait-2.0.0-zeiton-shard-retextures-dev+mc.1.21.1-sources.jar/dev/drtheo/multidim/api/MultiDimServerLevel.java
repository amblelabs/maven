package dev.drtheo.multidim.api;

import dev.drtheo.multidim.MultiDimFileManager;
import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3536;
import net.minecraft.class_3949;
import net.minecraft.class_5268;
import net.minecraft.class_5304;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_8565;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.concurrent.Executor;

public class MultiDimServerLevel extends class_3218 {

    private final WorldBlueprint blueprint;

    public MultiDimServerLevel(WorldBlueprint blueprint, MinecraftServer server, Executor workerExecutor,
                               class_32.class_5143 session, class_5268 properties,
                               class_5321<class_1937> worldKey, class_5363 levelStem,
                               class_3949 worldGenerationProgressListener,
                               List<class_5304> spawners, boolean shouldTickTime,
                               @Nullable class_8565 randomSequences, boolean created) {
        super(server, workerExecutor, session, properties, worldKey, levelStem,
                worldGenerationProgressListener, false, blueprint.seed(), spawners,
                blueprint.shouldTickTime(), randomSequences);
        this.blueprint = blueprint;
    }

    public WorldBlueprint getBlueprint() {
        return blueprint;
    }

    @Override
    public void method_14176(@Nullable class_3536 progress, boolean flush, boolean skipSave) {
        MultiDimFileManager.writeIfNeeded(this.method_8503(), this);
        super.method_14176(progress, flush, skipSave);
    }
}



