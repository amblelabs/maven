package dev.drtheo.multidim.api;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.drtheo.multidim.impl.AbstractChunkGenerator;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_1992;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2794;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_5138;
import net.minecraft.class_5483;
import net.minecraft.class_6012;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import org.jetbrains.annotations.Nullable;

public class VoidChunkGenerator extends AbstractChunkGenerator {

    public static final MapCodec<VoidChunkGenerator> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            class_1959.field_24677.fieldOf("biome").forGetter(generator -> generator.biome)
    ).apply(instance, VoidChunkGenerator::new));

    private final class_6880<class_1959> biome;

    public VoidChunkGenerator(class_6880<class_1959> biome) {
        super(new class_1992(biome));
        this.biome = biome;
    }

    public VoidChunkGenerator(class_2378<class_1959> biomeRegistry) {
        this(biomeRegistry, class_1972.field_9473);
    }

    public VoidChunkGenerator(class_2378<class_1959> biomeRegistry, net.minecraft.class_5321<class_1959> biome) {
        this(biomeRegistry.method_40290(biome));
    }

    @Override
    protected MapCodec<? extends class_2794> method_28506() {
        return CODEC;
    }

    @Nullable
    @Override
    public Pair<class_2338, class_6880<class_3195>> method_12103(class_3218 world, class_6885<class_3195> structures, class_2338 center, int radius, boolean skipReferencedStructures) {
        return null;
    }

    @Override
    public class_6012<class_5483.class_1964> method_12113(class_6880<class_1959> biome, class_5138 structureManager, class_1311 group, class_2338 pos) {
        return class_6012.method_34990();
    }
}


