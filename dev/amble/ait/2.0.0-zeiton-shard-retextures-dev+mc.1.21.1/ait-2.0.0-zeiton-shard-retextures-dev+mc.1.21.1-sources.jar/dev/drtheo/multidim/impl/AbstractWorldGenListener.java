package dev.drtheo.multidim.impl;

import net.minecraft.class_1923;
import net.minecraft.class_2806;
import net.minecraft.class_3949;
import org.jetbrains.annotations.Nullable;

public class AbstractWorldGenListener implements class_3949 {

    @Override
    public void method_17669(class_1923 spawnPos) { }

    @Override
    public void method_17670(class_1923 pos, @Nullable class_2806 status) { }

    @Override
    public void method_17675() { }

    @Override
    public void method_17671() { }
}


