package dev.drtheo.multidim.mixin;

import com.google.common.collect.Maps;
import dev.drtheo.multidim.api.MultiDimServer;
import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

import java.util.LinkedHashMap;
import java.util.Map;

@Mixin(MinecraftServer.class)
public class MinecraftServerMixin implements MultiDimServer {

    @Shadow @Final protected class_32.class_5143 storageSource;
    @Shadow @Final @Mutable private Map<class_5321<class_1937>, class_3218> levels;

    @Override
    public void multidim$addWorld(class_3218 world) {
        LinkedHashMap<class_5321<class_1937>, class_3218> newMap = Maps.newLinkedHashMap();
        newMap.putAll(this.levels);
        newMap.put(world.method_27983(), world);
        this.levels = newMap;
    }

    @Override
    public boolean multidim$hasWorld(class_5321<class_1937> key) {
        return this.levels.containsKey(key);
    }

    @Override
    public class_3218 multidim$removeWorld(class_5321<class_1937> key) {
        LinkedHashMap<class_5321<class_1937>, class_3218> newMap = Maps.newLinkedHashMap();
        Map<class_5321<class_1937>, class_3218> oldMap = this.levels;

        for (Map.Entry<class_5321<class_1937>, class_3218> entry : oldMap.entrySet()) {
            if (!entry.getKey().equals(key)) {
                newMap.put(entry.getKey(), entry.getValue());
            }
        }

        this.levels = newMap;
        return oldMap.get(key);
    }

    @Override
    public class_32.class_5143 multidim$getSession() {
        return this.storageSource;
    }
}
