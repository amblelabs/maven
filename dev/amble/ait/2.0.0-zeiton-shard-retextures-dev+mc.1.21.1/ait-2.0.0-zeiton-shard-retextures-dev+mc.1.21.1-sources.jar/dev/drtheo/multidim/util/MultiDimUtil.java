package dev.drtheo.multidim.util;

import dev.drtheo.multidim.api.MutableRegistry;
import net.minecraft.class_2370;
import net.minecraft.class_5363;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;

public final class MultiDimUtil {

    private MultiDimUtil() {
    }

    public static class_2370<class_5363> getDimensionsRegistry(MinecraftServer server) {
        return (class_2370<class_5363>) server.method_30611().method_30530(class_7924.field_41224);
    }

    @SuppressWarnings("unchecked")
    public static MutableRegistry<class_5363> getMutableDimensionsRegistry(MinecraftServer server) {
        return (MutableRegistry<class_5363>) getDimensionsRegistry(server);
    }
}


