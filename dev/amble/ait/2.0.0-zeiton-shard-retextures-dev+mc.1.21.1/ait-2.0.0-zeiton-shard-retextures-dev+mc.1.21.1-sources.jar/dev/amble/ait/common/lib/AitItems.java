package dev.amble.ait.common.lib;

import com.google.common.base.Suppliers;
import dev.amble.ait.common.items.*;
import dev.amble.ait.common.components.SonicCrystals;
import dev.amble.ait.common.components.SonicData;
import dev.amble.ait.api.mod.sonic.SonicCrystal;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

import static dev.amble.ait.api.AitAPI.modLoc;

// https://github.com/VazkiiMods/Botania/blob/2c4f7fdf9ebf0c0afa1406dfe1322841133d75fa/Common/src/main/java/vazkii/botania/common/item/ModItems.java
@SuppressWarnings("unused")
public class AitItems {
    public static void registerItems(BiConsumer<class_1792, class_2960> r) {
        for (var e : ITEMS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    public static void registerItemCreativeTab(class_1761.class_7704 r, class_1761 tab) {
        for (var item : ITEM_TABS.getOrDefault(tab, List.of())) {
            item.register(r);
        }
    }

    private static final Map<class_2960, class_1792> ITEMS = new LinkedHashMap<>(); // preserve insertion order
    private static final Map<class_1761, List<TabEntry>> ITEM_TABS = new LinkedHashMap<>();

    public static final class_1792 SCREWDRIVER = make("screwdriver", new ItemScrewdriver(unstackable()));
    public static final class_1792 SONIC_SCREWDRIVER = make("sonic_screwdriver", new ItemSonic(unstackable()
            .method_57349(AitComponents.SONIC_CRYSTALS, SonicCrystals.EMPTY)
            .method_57349(AitComponents.SONIC, SonicData.DEFAULT)
            .method_57349(AitComponents.ARTRON, ItemSonic.ARTRON)));

    public static final class_1792 SHARD_BASIC = make("zeiton_shard/basic", new ItemCrystal(unstackable(), SonicCrystal.BASIC));
    public static final class_1792 SHARD_OVERCHARGED = make("zeiton_shard/overcharged", new ItemCrystal(unstackable(), SonicCrystal.OVERCHARGED));
    public static final class_1792 SHARD_RESONATING = make("zeiton_shard/resonating", new ItemCrystal(unstackable(), SonicCrystal.RESONATING));
    public static final class_1792 SHARD_GRAVITY = make("zeiton_shard/gravity", new ItemCrystal(unstackable(), SonicCrystal.GRAVITY));
    public static final class_1792 SHARD_REFRACTION = make("zeiton_shard/refraction", new ItemCrystal(unstackable(), SonicCrystal.REFRACTION));
    public static final class_1792 SHARD_AMETHYST = make("zeiton_shard/amethyst", new ItemCrystal(unstackable(), SonicCrystal.AMETHYST));
    public static final class_1792 SHARD_QUARTZ = make("zeiton_shard/quartz", new ItemCrystal(unstackable(), SonicCrystal.QUARTZ));
    public static final class_1792 SHARD_SCULK = make("zeiton_shard/sculk", new ItemCrystal(unstackable(), SonicCrystal.ECHO_SHARD));

    public static final class_1792 IRON_KEY = make("iron_key", new ItemKey(unstackable()));
    public static final class_1792 GOLD_KEY = make("gold_key", new ItemKey(unstackable()));
    public static final class_1792 NETHERITE_KEY = make("netherite_key", new ItemKey(unstackable()));
    public static final class_1792 CLASSIC_KEY = make("classic_key", new ItemKey(unstackable()));
    public static final class_1792 KEY_CHAIN = make("key_chain", new ItemKeychain(unstackable()));

    public static final class_1792 LIGHTBULB = make("lightbulb",
            new class_1792(new class_1792.class_1793().method_19265(AitComponents.LIGHTBULB_FOOD_COMPONENT)));

    public static class_1792.class_1793 props() {
        return new class_1792.class_1793();
    }

    public static class_1792.class_1793 unstackable() {
        return props().method_7889(1);
    }

    private static <T extends class_1792> T make(class_2960 id, T item, @Nullable class_1761 tab) {
        var old = ITEMS.put(id, item);
        if (old != null) throw new IllegalArgumentException("Duplicate id " + id);

        if (tab != null) ITEM_TABS.computeIfAbsent(tab, t -> new ArrayList<>())
                .add(new TabEntry.ItemEntry(item));

        return item;
    }

    @SuppressWarnings("SameParameterValue")
    private static <T extends class_1792> T make(String id, T item, @Nullable class_1761 tab) {
        return make(modLoc(id), item, tab);
    }

    private static <T extends class_1792> T make(String id, T item) {
        return make(id, item, AitCreativeTabs.AIT);
    }

    private static Supplier<class_1799> addToTab(Supplier<class_1799> stack, class_1761 tab) {
        var memoised = Suppliers.memoize(stack::get);
        ITEM_TABS.computeIfAbsent(tab, t -> new ArrayList<>()).add(new TabEntry.StackEntry(memoised));
        return memoised;
    }

    private static abstract class TabEntry {
        abstract void register(class_1761.class_7704 r);

        static class ItemEntry extends TabEntry {
            private final class_1792 item;

            ItemEntry(class_1792 item) {
                this.item = item;
            }

            @Override
            void register(class_1761.class_7704 r) {
                r.method_45421(item);
            }
        }

        static class StackEntry extends TabEntry {
            private final Supplier<class_1799> stack;

            StackEntry(Supplier<class_1799> stack) {
                this.stack = stack;
            }

            @Override
            void register(class_1761.class_7704 r) {
                r.method_45420(stack.get());
            }
        }
    }
}