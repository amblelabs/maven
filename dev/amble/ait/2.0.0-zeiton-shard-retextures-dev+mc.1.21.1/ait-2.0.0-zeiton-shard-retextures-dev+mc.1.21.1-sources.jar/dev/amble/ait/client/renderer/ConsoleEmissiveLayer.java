package dev.amble.ait.client.renderer;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.blocks.ConsoleBlockEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

public class ConsoleEmissiveLayer extends GeoRenderLayer<ConsoleBlockEntity> {

    private static final int FULLBRIGHT = 0xF000F0;

    public ConsoleEmissiveLayer(GeoRenderer<ConsoleBlockEntity> renderer) {
        super(renderer);
    }

    @Override
    public void render(class_4587 poseStack, ConsoleBlockEntity entity, BakedGeoModel bakedModel,
                       @Nullable class_1921 renderType, class_4597 bufferSource,
                       @Nullable class_4588 buffer, float partialTick, int packedLight, int packedOverlay) {
        class_2960 baseTexture = getGeoModel().getTextureResource(entity, getRenderer());
        String basePath = baseTexture.method_12832();
        String emissivePath = basePath.replace(".png", "_e.png");
        class_2960 emissiveTexture = AitAPI.modLoc(emissivePath);

        if (class_310.method_1551().method_1478().method_14486(emissiveTexture).isEmpty()) return;

        class_1921 emissiveType = AITRenderLayers.tardisEmissiveNoCullZOffset(emissiveTexture, true);
        class_4588 emissiveConsumer = bufferSource.getBuffer(emissiveType);

        for (GeoBone bone : bakedModel.topLevelBones()) {
            getRenderer().renderRecursively(poseStack, entity, bone, emissiveType, bufferSource,
                    emissiveConsumer, true, partialTick, FULLBRIGHT, packedOverlay, 0xFFFFFFFF);
        }
    }
}

