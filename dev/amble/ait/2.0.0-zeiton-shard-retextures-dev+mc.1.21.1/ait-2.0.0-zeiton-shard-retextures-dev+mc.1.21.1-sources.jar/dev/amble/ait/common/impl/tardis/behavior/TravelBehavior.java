package dev.amble.ait.common.impl.tardis.behavior;

import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.api.tardis.event.travel.TardisTravelEvents;
import dev.amble.ait.common.impl.tardis.state.DoorState;
import dev.drtheo.ecs.behavior.TBehavior;
import net.minecraft.server.MinecraftServer;

// FIXME: not sure whether or not to keep the pre/post states here and the actual logical events in the other named behaviors. - Loqor
public class TravelBehavior implements TBehavior, TardisTravelEvents {
    @Override
    public boolean preDemat(ServerTardis tardis, MinecraftServer server) {
        DoorState door = tardis.state(DoorState.state);
        return door.closed();
    }
}
