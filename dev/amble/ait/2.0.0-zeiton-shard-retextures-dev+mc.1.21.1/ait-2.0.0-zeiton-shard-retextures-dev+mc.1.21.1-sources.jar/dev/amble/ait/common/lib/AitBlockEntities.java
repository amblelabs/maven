package dev.amble.ait.common.lib;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.blocks.ConsoleBlockEntity;
import dev.amble.ait.common.blocks.DoorBlockEntity;
import dev.amble.ait.common.blocks.ExteriorBlockEntity;
import dev.amble.ait.xplat.IXplatAbstractions;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;

public class AitBlockEntities {
    public static void registerTiles(BiConsumer<class_2591<?>, class_2960> r) {
        for (var e : BLOCK_ENTITIES.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_2591<?>> BLOCK_ENTITIES = new LinkedHashMap<>();

    //

    public static final class_2591<ExteriorBlockEntity> EXTERIOR_BLOCK_ENTITY =
            register("exterior", ExteriorBlockEntity::new, AitBlocks.EXTERIOR_BLOCK);

    public static final class_2591<DoorBlockEntity> DOOR_BLOCK_ENTITY =
            register("tardis_door", DoorBlockEntity::new, AitBlocks.TARDIS_DOOR);

    public static final class_2591<ConsoleBlockEntity> CONSOLE_BLOCK_ENTITY =
            register("console", ConsoleBlockEntity::new, AitBlocks.CONSOLE);

    private static <T extends class_2586> class_2591<T> register(String id,
        BiFunction<class_2338, class_2680, T> func, class_2248... blocks) {
        var ret = IXplatAbstractions.INSTANCE.createBlockEntityType(func, blocks);

        var old = BLOCK_ENTITIES.put(AitAPI.modLoc(id), ret);
        if (old != null) {
            throw new IllegalArgumentException("Duplicate id " + id);
        }
        return ret;
    }
}