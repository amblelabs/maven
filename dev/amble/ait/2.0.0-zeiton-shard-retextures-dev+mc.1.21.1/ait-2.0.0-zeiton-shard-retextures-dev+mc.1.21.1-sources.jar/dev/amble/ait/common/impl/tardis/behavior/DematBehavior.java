package dev.amble.ait.common.impl.tardis.behavior;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.event.tick.TardisTickEvents;
import dev.amble.ait.common.impl.tardis.state.*;
import dev.amble.ait.common.lib.AitSounds;
import dev.drtheo.ecs.behavior.TBehavior;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_4208;
import net.minecraft.server.MinecraftServer;

public class DematBehavior implements TBehavior, TardisTickEvents {
    public static DematBehavior getInstance() {
        return new DematBehavior();
    }

    public void dematerialize(ServerTardis tardis, MinecraftServer server) {
        DematState state = tardis.state(DematState.state);
        ExteriorState exterior = tardis.state(ExteriorState.state);
        DesktopState desktop = tardis.state(DesktopState.state);
        DimensionState dim = tardis.state(DimensionState.state);

        class_3218 tardisWorld = dim.level.get();
        class_3218 exteriorWorld = server.method_3847(exterior.exteriorPos.comp_2207());

        if (tardisWorld != null) {
            tardisWorld.method_8396(null, desktop.doorPos, AitSounds.DEMAT, class_3419.field_15245, 1.0f, 1.0f);
        }

        if (exteriorWorld != null) {
            exteriorWorld.method_8396(null, exterior.exteriorPos.comp_2208(), AitSounds.DEMAT, class_3419.field_15245, 1.0f, 1.0f);
        }

        state.dematTimerTicks = 0;

        tardis.markDirty();
    }

    public void _dematerialize(ServerTardis tardis, MinecraftServer server) {
        ExteriorState exteriorState = tardis.state(ExteriorState.state);
        class_4208 position = exteriorState.exteriorPos;

        class_3218 currentWorld = server.method_3847(position.comp_2207());

        class_2338 currentPosition = position.comp_2208();

        AitAPI.LOGGER.info("Dematerializing from {} at {}", position.comp_2207(), currentPosition);

        if (currentWorld == null) return;

        currentWorld.method_8652(currentPosition, class_2246.field_10124.method_9564(), class_2248.field_31031);

        tardis.removeState(exteriorState);
    }

    @Override
    public void tick(Tardis tardis) {
        DematState dematState = tardis.state(DematState.state);

        if (dematState.dematTimerTicks < 0) return;

        DimensionState dim = tardis.state(DimensionState.state);
        class_3218 tardisWorld = dim.level.get();

        if (tardisWorld == null) return;
        if (dematState.dematTimerTicks++ >= DematState.DEMAT_TIME) {

            if (tardis instanceof ServerTardis serverTardis) {
                _dematerialize(serverTardis, tardisWorld.method_8503());
            }

            AitAPI.LOGGER.info("dematting done");
            dematState.dematTimerTicks = -1;
        }
    }
}
