package dev.amble.ait.common.blocks;

import com.mojang.serialization.MapCodec;
import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.api.tardis.event.travel.TardisTravelEvents;
import dev.amble.ait.common.impl.tardis.TardisServerWorld;
import dev.amble.ait.common.impl.tardis.behavior.DematBehavior;
import dev.amble.ait.common.impl.tardis.behavior.RematBehavior;
import dev.amble.ait.common.impl.tardis.state.DematState;
import dev.amble.ait.common.impl.tardis.state.ExteriorState;
import dev.amble.ait.common.impl.tardis.state.RematState;
import dev.amble.ait.common.impl.tardis.state.TravelState;
import dev.drtheo.ecs.behavior.Resolve;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2482;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2771;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4208;
import net.minecraft.class_9062;
import net.minecraft.server.MinecraftServer;

public class ConsoleBlock extends class_2237 {

    public static final class_2758 ROTATION = class_2758.method_11867("rotation", 0, 7);
    public static final class_2758 LIGHT = class_2758.method_11867("light", 0, 15);
    public static final class_2746 ON_SLAB = class_2746.method_11825("on_slab");
    public static final class_2746 BETWEEN = class_2746.method_11825("between");
    public static final class_2758 BETWEEN_CORNER = class_2758.method_11867("between_corner", 0, 3);
    public static final MapCodec<ConsoleBlock> CODEC = method_54094(ConsoleBlock::new);

    @Resolve
    private static final DematBehavior demat = DematBehavior.getInstance();
    private static final RematBehavior remat = RematBehavior.getInstance();

    public static final double[][] BETWEEN_OFFSETS = {
            { -0.5, -0.5 },
            {  0.5, -0.5 },
            { -0.5,  0.5 },
            {  0.5,  0.5 }
    };

    private static final class_265 SHAPE = class_2248.method_9541(0, 0, 0, 16, 16, 16);
    private static final class_265 SHAPE_SLAB = SHAPE.method_1096(0, -0.5, 0);
    private static final class_265[] SHAPES_BETWEEN = new class_265[4];
    private static final class_265[] SHAPES_BETWEEN_SLAB = new class_265[4];

    static {
        for (int i = 0; i < 4; i++) {
            SHAPES_BETWEEN[i] = SHAPE.method_1096(BETWEEN_OFFSETS[i][0], 0, BETWEEN_OFFSETS[i][1]);
            SHAPES_BETWEEN_SLAB[i] = SHAPES_BETWEEN[i].method_1096(0, -0.5, 0);
        }
    }

    public ConsoleBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664()
                .method_11657(ROTATION, 0)
                .method_11657(LIGHT, 0)
                .method_11657(ON_SLAB, false)
                .method_11657(BETWEEN, false)
                .method_11657(BETWEEN_CORNER, 3));
    }

    public static class_2251 defaultProps() {
        return class_2251.method_9637()
                .method_31710(class_3620.field_16026)
                .method_9629(5f, 6f)
                .method_22488()
                .method_9624()
                .method_9631(state -> state.method_11654(LIGHT));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ROTATION, LIGHT, ON_SLAB, BETWEEN, BETWEEN_CORNER);
    }

    @Override
    protected void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        level.method_39279(pos, this, 2);

        if (!(level instanceof class_3218 serverLevel)) return;

        // We're only linking the console in the current TARDIS dimension. - Loqor
        if (!(serverLevel instanceof TardisServerWorld tsl)) return;

        if (!(level.method_8321(pos) instanceof ConsoleBlockEntity console)) return;

        console.link(tsl.tardis());
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        int rotation = class_3532.method_15375((context.method_8044()) / 45.0f + 0.5f) & 7;
        class_2338 below = context.method_8037().method_10074();
        class_2680 belowState = context.method_8045().method_8320(below);
        boolean crouching = context.method_8036() != null && context.method_8036().method_5715();
        int betweenCorner = getBetweenCorner(context);

        return this.method_9564()
                .method_11657(ROTATION, rotation)
                .method_11657(ON_SLAB, isSlabBottom(belowState))
                .method_11657(BETWEEN, crouching)
                .method_11657(BETWEEN_CORNER, betweenCorner);
    }

    private static int getBetweenCorner(class_1750 context) {
        class_243 clickPos = context.method_17698();
        class_2338 blockPos = context.method_8037();
        double relX = clickPos.field_1352 - blockPos.method_10263();
        double relZ = clickPos.field_1350 - blockPos.method_10260();

        boolean east = relX >= 0.5;
        boolean south = relZ >= 0.5;

        return (south ? 2 : 0) + (east ? 1 : 0);
    }

    private boolean isSlabBottom(class_2680 state) {
        if (state.method_26204() instanceof class_2482
                && state.method_28498(class_2741.field_12485)) {
            return state.method_11654(class_2741.field_12485) == class_2771.field_12681;
        }
        return false;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        boolean slab = state.method_11654(ON_SLAB);
        boolean between = state.method_11654(BETWEEN);
        int betweenCorner = state.method_11654(BETWEEN_CORNER);

        if (between && slab) return SHAPES_BETWEEN_SLAB[betweenCorner];
        if (between) return SHAPES_BETWEEN[betweenCorner];
        if (slab) return SHAPE_SLAB;
        return SHAPE;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ConsoleBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11456;
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos,
                                              class_1657 player, class_1268 hand, class_3965 hit) {

        if (level.method_8608()) {
            return class_9062.field_47728;
        }

        class_3218 serverLevel = (class_3218) level;
        MinecraftServer server = serverLevel.method_8503();

        class_2586 be = level.method_8321(pos);
        if (be instanceof ConsoleBlockEntity console) {
            /*if (player.isShiftKeyDown()) {
                console.cycleTextureVariant();
            } else {
                console.cycleModelVariant();
            }*/
            ServerTardis tardis = (ServerTardis) console.tardis();

            if (tardis != null) {
                TravelState travelState = tardis.state(TravelState.state);
                DematState dematState = new DematState();
                RematState rematState = new RematState();

                if (tardis.hasState(ExteriorState.state)) {
                    if (TardisTravelEvents.handlePreDematerialization(tardis, server)) {
                        tardis.addState(dematState);
                        if (tardis.hasState(DematState.state)) {
                            demat.dematerialize(tardis, server);
                            travelState.updateDestinationPos(new class_4208(
                                    class_1937.field_25179,
                                    new class_2338(0, 120, 0)));
                            player.method_7353(class_2561.method_43470("Dematerialized."), false);
                        }
                    } else {
                        player.method_7353(class_2561.method_43470("Doors must be closed!"), true);
                    }
                } else if (player.method_5715()) {
                    tardis.removeState(dematState);
                    tardis.addState(rematState);
                    if (tardis.hasState(RematState.state)) {
                        remat.rematerialize(tardis, serverLevel.method_8503());
                        player.method_7353(class_2561.method_43470("Rematerialized."), false);
                    }
                    tardis.removeState(rematState);
                }
            }

            return class_9062.field_47728;
        }

        return class_9062.field_47731;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (level.method_8608()) return class_1269.field_5812;

        class_2586 be = level.method_8321(pos);
        if (be instanceof ConsoleBlockEntity console) {
            console.cycleAnimation();
        }

        return class_1269.field_21466;
    }
}
