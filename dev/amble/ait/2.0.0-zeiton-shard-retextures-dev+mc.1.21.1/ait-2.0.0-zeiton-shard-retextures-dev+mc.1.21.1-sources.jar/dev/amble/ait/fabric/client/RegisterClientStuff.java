package dev.amble.ait.fabric.client;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.client.renderer.*;
import dev.amble.ait.common.components.SonicCrystals;
import dev.amble.ait.common.items.tooltips.KeychainTooltip;
import dev.amble.ait.common.items.tooltips.SonicTooltip;
import dev.amble.ait.common.lib.AitBlockEntities;
import dev.amble.ait.common.lib.AitEntities;
import dev.amble.ait.xplat.IClientXplatAbstractions;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_290;
import net.minecraft.class_322;
import net.minecraft.class_326;
import net.minecraft.class_5614;
import org.jetbrains.annotations.NotNull;

import java.util.function.BiConsumer;

public class RegisterClientStuff {

    public static void init() {
        TooltipComponentCallback.EVENT.register(component -> {
            if (component instanceof SonicTooltip(SonicCrystals contents))
                return new ClientSonicTooltip(contents);

            return null;
        });

        TooltipComponentCallback.EVENT.register(component -> {
            if (component instanceof KeychainTooltip tooltip) {
                return new ClientKeychainTooltip(tooltip);
            }
            return null;
        });

        //noinspection CodeBlock2Expr
        CoreShaderRegistrationCallback.EVENT.register(context -> {
            context.register(
                    AitAPI.modLoc("rendertype_accumulation"),
                    class_290.field_1580,
                    AITShaders::setAccumulationShader
            );
        });

        var x = IClientXplatAbstractions.INSTANCE;
        x.registerEntityRenderer(AitEntities.FALLING_TARDIS_BLOCK, FallingTardisBlockRenderer::new);

    }

    @SuppressWarnings("EmptyMethod")
    public static void registerColorProviders(BiConsumer<class_326, class_1792> itemColorRegistry,
                                              BiConsumer<class_322, class_2248> blockColorRegistry) {

    }

    public static void registerBlockEntityRenderers(@NotNull BlockEntityRendererRegisterer registerer) {
        registerer.registerBlockEntityRenderer(AitBlockEntities.EXTERIOR_BLOCK_ENTITY, ExteriorBlockEntityRenderer::new);
        registerer.registerBlockEntityRenderer(AitBlockEntities.DOOR_BLOCK_ENTITY, DoorBlockEntityRenderer::new);
        registerer.registerBlockEntityRenderer(AitBlockEntities.CONSOLE_BLOCK_ENTITY, ConsoleBlockEntityRenderer::new);
    }

    @FunctionalInterface
    public interface BlockEntityRendererRegisterer {
        <T extends class_2586> void registerBlockEntityRenderer(class_2591<T> type,
            class_5614<? super T> provider);
    }
}