package dev.amble.ait.common.items.tooltips;

import dev.amble.ait.common.components.SonicCrystals;
import net.minecraft.class_5632;

public record SonicTooltip(SonicCrystals contents) implements class_5632 {
}