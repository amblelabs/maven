package dev.amble.ait.common.impl.tardis.state;

public class CrashState {
}
