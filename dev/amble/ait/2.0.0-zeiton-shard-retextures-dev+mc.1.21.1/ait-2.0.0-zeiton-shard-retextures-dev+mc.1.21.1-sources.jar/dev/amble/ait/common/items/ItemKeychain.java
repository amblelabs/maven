package dev.amble.ait.common.items;

import dev.amble.ait.api.mod.AitTags;
import dev.amble.ait.common.items.tooltips.KeychainTooltip;
import dev.amble.ait.common.lib.AitComponents;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_5328;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_5632;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9334;

public class ItemKeychain extends class_1792 {

    private static final int BAR_COLOR = 0x6666FF;
    public static final int MAX_SIZE = 5;

    public ItemKeychain(class_1793 properties) {
        super(properties);
    }

    public record KeychainContents(List<class_1799> items, int selectedIndex) {
        public static final KeychainContents EMPTY = new KeychainContents(List.of(), -1);

        public static final Codec<KeychainContents> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        class_1799.field_24671.listOf().fieldOf("items").forGetter(KeychainContents::items),
                        Codec.INT.optionalFieldOf("selected_index", -1).forGetter(KeychainContents::selectedIndex)
                ).apply(instance, KeychainContents::new)
        );

        public static final class_9139<class_9129, KeychainContents> STREAM_CODEC =
                class_9139.method_56435(
                        class_1799.field_48349.method_56433(class_9135.method_56363()),
                        KeychainContents::items,
                        class_9135.field_49675,
                        KeychainContents::selectedIndex,
                        KeychainContents::new
                );

        public int size() { return items.size(); }
        public boolean isEmpty() { return items.isEmpty(); }

        public class_1799 getItem(int index) {
            return index >= 0 && index < items.size() ? items.get(index) : class_1799.field_8037;
        }

        public class_1799 getSelectedItem() {
            return selectedIndex >= 0 && selectedIndex < items.size() ? items.get(selectedIndex) : class_1799.field_8037;
        }

        public List<class_1799> itemsCopy() { return new ArrayList<>(items); }

        public class_1799 removeOne() {
            if (items.isEmpty()) return class_1799.field_8037;
            return items.get(items.size() - 1).method_7972();
        }

        public KeychainContents withRemovedLast() {
            if (items.isEmpty()) return this;

            List<class_1799> newItems = new ArrayList<>(items.subList(0, items.size() - 1));
            int newSelected = selectedIndex;

            if (selectedIndex >= items.size() - 1) {
                newSelected = newItems.isEmpty() ? -1 : Math.min(selectedIndex, newItems.size() - 1);
            }

            return new KeychainContents(newItems, newSelected);
        }

        public KeychainContents withSelected(int index) {
            if (index < -1 || index >= items.size()) return this;
            return new KeychainContents(items, index);
        }

        public KeychainContents withAdded(class_1799 stack) {
            List<class_1799> newItems = new ArrayList<>(items);
            newItems.add(stack);
            return new KeychainContents(newItems, selectedIndex);
        }

        public Mutable mutable() { return new Mutable(this); }

        public static class Mutable {
            private final List<class_1799> items;
            private int selectedIndex;

            public Mutable(KeychainContents contents) {
                this.items = new ArrayList<>(contents.items);
                this.selectedIndex = contents.selectedIndex;
            }

            public int tryInsert(class_1799 stack) {
                if (stack.method_7960() || items.size() >= MAX_SIZE) return 0;

                int canInsert = Math.min(stack.method_7947(), MAX_SIZE - items.size());
                if (canInsert <= 0) return 0;

                class_1799 toInsert = stack.method_7972();
                toInsert.method_7939(canInsert);
                items.add(toInsert);
                stack.method_7934(canInsert);

                if (items.size() == 1) {
                    selectedIndex = 0;
                }

                return canInsert;
            }

            public void setSelected(int index) {
                if (index >= -1 && index < items.size()) {
                    this.selectedIndex = index;
                }
            }

            public KeychainContents toImmutable() {
                return new KeychainContents(List.copyOf(items), selectedIndex);
            }
        }
    }

    @Override
    public boolean method_31565(class_1799 keychain, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014) return false;

        class_1799 other = slot.method_7677();

        if (other.method_7960()) {
            handleRemoveFromKeychain(keychain, slot, player);
        } else if (isKey(other)) {
            handleInsertIntoKeychain(keychain, slot, player);
        }

        return true;
    }

    private void handleRemoveFromKeychain(class_1799 keychain, class_1735 slot, class_1657 player) {
        KeychainContents contents = keychain.method_57824(AitComponents.KEYCHAIN_CONTENTS);

        if (contents == null || contents.isEmpty()) return;

        class_1799 removed = contents.removeOne();
        if (removed.method_7960()) return;

        playRemoveOneSound(player);
        class_1799 remaining = slot.method_32756(removed);

        if (!remaining.method_7960()) {
            KeychainContents.Mutable mutable = contents.mutable();
            mutable.tryInsert(remaining);
            keychain.method_57379(AitComponents.KEYCHAIN_CONTENTS, mutable.toImmutable());
            playInsertSound(player);
        } else {
            keychain.method_57379(AitComponents.KEYCHAIN_CONTENTS, contents.withRemovedLast());
        }
    }

    private void handleInsertIntoKeychain(class_1799 keychain, class_1735 slot, class_1657 player) {
        KeychainContents contents = keychain.method_57825(AitComponents.KEYCHAIN_CONTENTS, KeychainContents.EMPTY);

        if (contents.size() >= MAX_SIZE) return;

        KeychainContents.Mutable mutable = contents.mutable();
        int spaceLeft = MAX_SIZE - contents.size();

        class_1799 slotStack = slot.method_7677();
        int takeCount = Math.min(slotStack.method_7947(), spaceLeft);

        if (takeCount <= 0) return;

        class_1799 taken = slotStack.method_7972();
        taken.method_7939(takeCount);
        slotStack.method_7934(takeCount);

        int inserted = mutable.tryInsert(taken);
        if (inserted > 0) {
            playInsertSound(player);
            keychain.method_57379(AitComponents.KEYCHAIN_CONTENTS, mutable.toImmutable());
        }
    }

    @Override
    public boolean method_31566(class_1799 keychain, class_1799 other, class_1735 slot, class_5536 action, class_1657 player, class_5630 access) {
        if (action != class_5536.field_27014 || !slot.method_32754(player)) return false;

        if (other.method_7960()) {
            handleRemoveToCursor(keychain, access, player);
        } else if (isKey(other)) {
            handleInsertFromCursor(keychain, other, player);
        }

        return true;
    }

    private void handleRemoveToCursor(class_1799 keychain, class_5630 access, class_1657 player) {
        KeychainContents contents = keychain.method_57824(AitComponents.KEYCHAIN_CONTENTS);

        if (contents == null || contents.isEmpty()) return;

        class_1799 removed = contents.removeOne();
        if (removed.method_7960()) return;

        playRemoveOneSound(player);
        access.method_32332(removed);
        keychain.method_57379(AitComponents.KEYCHAIN_CONTENTS, contents.withRemovedLast());
    }

    private void handleInsertFromCursor(class_1799 keychain, class_1799 other, class_1657 player) {
        KeychainContents contents = keychain.method_57825(AitComponents.KEYCHAIN_CONTENTS, KeychainContents.EMPTY);

        if (contents.size() >= MAX_SIZE) return;

        KeychainContents.Mutable mutable = contents.mutable();
        int spaceLeft = MAX_SIZE - contents.size();
        int takeCount = Math.min(other.method_7947(), spaceLeft);

        if (takeCount <= 0) return;

        class_1799 taken = other.method_7972();
        taken.method_7939(takeCount);
        other.method_7934(takeCount);

        int inserted = mutable.tryInsert(taken);
        if (inserted > 0) {
            playInsertSound(player);
            keychain.method_57379(AitComponents.KEYCHAIN_CONTENTS, mutable.toImmutable());
        }
    }

    private boolean isKey(class_1799 stack) {
        return stack.method_31573(AitTags.Items.KEYS) && stack.method_7909() instanceof ItemKey;
    }

    @Override
    public Optional<class_5632> method_32346(class_1799 stack) {
        if (stack.method_57826(class_9334.field_50074) || stack.method_57826(class_9334.field_49638)) {
            return Optional.empty();
        }

        KeychainContents contents = stack.method_57824(AitComponents.KEYCHAIN_CONTENTS);
        return contents != null && !contents.isEmpty()
                ? Optional.of(new KeychainTooltip(contents))
                : Optional.empty();
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        KeychainContents contents = stack.method_57824(AitComponents.KEYCHAIN_CONTENTS);
        if (contents != null && !contents.isEmpty()) {

            if (contents.selectedIndex() >= 0) {
                class_1799 selected = contents.getSelectedItem();
            }
        }
    }

    @Override
    public void method_33261(class_1542 entity) {
        KeychainContents contents = entity.method_6983().method_57824(AitComponents.KEYCHAIN_CONTENTS);
        if (contents != null && !contents.isEmpty()) {
            entity.method_6983().method_57379(AitComponents.KEYCHAIN_CONTENTS, KeychainContents.EMPTY);
            class_5328.method_33263(entity, contents.itemsCopy());
        }
    }

    @Override
    public boolean method_31567(class_1799 stack) {
        KeychainContents contents = stack.method_57824(AitComponents.KEYCHAIN_CONTENTS);
        return contents != null && !contents.isEmpty();
    }

    @Override
    public int method_31569(class_1799 stack) {
        KeychainContents contents = stack.method_57824(AitComponents.KEYCHAIN_CONTENTS);
        if (contents == null) return 0;
        return Math.min(1 + (contents.size() * 12) / MAX_SIZE, 13);
    }

    @Override
    public int method_31571(class_1799 stack) {
        return BAR_COLOR;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (player.method_5715()) {
            KeychainContents contents = stack.method_57824(AitComponents.KEYCHAIN_CONTENTS);
            if (contents != null && !contents.isEmpty()) {
                KeychainContents.Mutable mutable = contents.mutable();
                int nextIndex = (contents.selectedIndex() + 1) % contents.size();
                mutable.setSelected(nextIndex);
                stack.method_57379(AitComponents.KEYCHAIN_CONTENTS, mutable.toImmutable());

                player.method_5783(class_3417.field_24062, 1F, 1.2F);

                return class_1271.method_22427(stack);
            }
        }

        return class_1271.method_22430(stack);
    }

    private void playRemoveOneSound(class_1297 entity) {
        entity.method_5783(class_3417.field_24065, 1F, 1.2F + entity.method_37908().method_8409().method_43057() * 0.4F);
    }

    private void playInsertSound(class_1297 entity) {
        entity.method_5783(class_3417.field_24063, 1F, 1.2F + entity.method_37908().method_8409().method_43057() * 0.4F);
    }

    public static void selectSlot(class_1799 stack, int slotIndex) {
        KeychainContents contents = stack.method_57824(AitComponents.KEYCHAIN_CONTENTS);
        if (contents != null) {
            KeychainContents.Mutable mutable = contents.mutable();
            mutable.setSelected(slotIndex);
            stack.method_57379(AitComponents.KEYCHAIN_CONTENTS, mutable.toImmutable());
        }
    }

}