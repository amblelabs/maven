package dev.amble.ait.common.impl.tardis;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.ServerTardis;
import dev.drtheo.multidim.MultiDim;
import dev.drtheo.multidim.api.MultiDimServer;
import dev.drtheo.multidim.api.MultiDimServerLevel;
import dev.drtheo.multidim.api.WorldBlueprint;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3949;
import net.minecraft.class_5268;
import net.minecraft.class_5304;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_8565;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.function.BooleanSupplier;

public class TardisServerWorld extends MultiDimServerLevel {

    public static final String NAMESPACE = AitAPI.MOD_ID + "-tardis";

    private @Nullable ServerTardis tardis;
    private @Nullable class_6880<class_1959> cachedBiome;

    public TardisServerWorld(WorldBlueprint blueprint, MinecraftServer server, Executor workerExecutor, class_32.class_5143 session, class_5268 properties, class_5321<class_1937> worldKey, class_5363 levelStem, class_3949 worldGenerationProgressListener, List<class_5304> spawners, boolean shouldTickTime, @Nullable class_8565 randomSequences, boolean created) {
        super(blueprint, server, workerExecutor, session, properties, worldKey, levelStem, worldGenerationProgressListener, spawners, shouldTickTime, randomSequences, created);
        super.method_8424(false, false);
    }

    @Override
    public void method_18765(BooleanSupplier shouldKeepTicking) {
        if (this.shouldTick()) {
            super.method_18765(shouldKeepTicking);
        }
    }

    public boolean shouldTick() {
        return this.tardis != null && (
                !MultiDim.get(this.method_8503()).isWorldUnloaded(this)
        );
    }

    @Override
    public String toString() {
        return "Tardis" + super.toString();
    }

    @Override
    public class_6880<class_1959> method_23753(class_2338 pos) {
        if (this.cachedBiome != null)
            return cachedBiome;

        return this.cachedBiome = super.method_23753(pos);
    }

    public @Nullable ServerTardis tardis() {
        return tardis;
    }

    public static TardisServerWorld create(MinecraftServer server, WorldBlueprint blueprint, ServerTardis tardis) {
        AitAPI.LOGGER.info("Creating a dimension for TARDIS {}", tardis.id());

        MultiDimServerLevel loaded = MultiDim.get(server)
                .add(blueprint, idForTardis(tardis));
        if (!(loaded instanceof TardisServerWorld created)) {
            throw new IllegalStateException("Expected TardisServerWorld for " + loaded.method_27983().method_29177() + " but got " + loaded.getClass().getName());
        }

        created.tardis = tardis;
        return created;
    }

    public static TardisServerWorld getOrLoad(MinecraftServer server, WorldBlueprint blueprint, ServerTardis tardis) {
        class_5321<class_1937> key = keyForTardis(tardis);
        class_3218 existing = server.method_3847(key);

        if (existing instanceof TardisServerWorld result) {
            result.tardis = tardis;
            return result;
        }

        if (existing != null) {
            AitAPI.LOGGER.warn("Replacing non-TARDIS world instance {} for {}", existing.getClass().getName(), key.method_29177());
            ((MultiDimServer) server).multidim$removeWorld(key);
        }

        return load(server, blueprint, tardis);
    }

    public static TardisServerWorld load(MinecraftServer server, WorldBlueprint blueprint, ServerTardis tardis) {
        MultiDim multidim = MultiDim.get(server);

        class_5321<class_1937> key = keyForTardis(tardis);
        MultiDimServerLevel loaded = multidim.load(blueprint, key);
        if (!(loaded instanceof TardisServerWorld result)) {
            throw new IllegalStateException("Expected TardisServerWorld for " + key.method_29177() + " but got " + loaded.getClass().getName());
        }

        result.tardis = tardis;
        return result;
    }

    public static class_5321<class_1937> keyForTardis(ServerTardis tardis) {
        return class_5321.method_29179(class_7924.field_41223, idForTardis(tardis));
    }

    private static class_2960 idForTardis(ServerTardis tardis) {
        return class_2960.method_60655(NAMESPACE, tardis.id().toString());
    }

    public static boolean isTardisDimension(class_5321<class_1937> key) {
        return NAMESPACE.equals(key.method_29177().method_12836());
    }

    public static boolean isTardisDimension(class_1937 world) {
        return world.method_8608() ? isTardisDimension((class_638) world) : isTardisDimension((class_3218) world);
    }

    public static boolean isTardisDimension(class_3218 world) {
        return world instanceof TardisServerWorld;
    }

    public static @Nullable UUID getTardisId(@Nullable class_1937 world) {
        if (world == null || !isTardisDimension(world))
            return null;

        return getTardisId(world.method_27983());
    }

    public static UUID getTardisId(class_5321<class_1937> key) {
        return UUID.fromString(key.method_29177().method_12832());
    }

    @Environment(EnvType.CLIENT)
    public static boolean isTardisDimension(class_638 world) {
        return isTardisDimension(world.method_27983());
    }
}