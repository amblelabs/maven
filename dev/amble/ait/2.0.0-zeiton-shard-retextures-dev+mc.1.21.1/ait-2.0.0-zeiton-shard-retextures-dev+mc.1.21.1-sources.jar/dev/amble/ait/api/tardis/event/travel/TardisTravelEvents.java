package dev.amble.ait.api.tardis.event.travel;

import dev.amble.ait.api.tardis.ServerTardis;
import dev.drtheo.ecs.event.TEvents;
import net.minecraft.server.MinecraftServer;

public interface TardisTravelEvents extends TEvents {

    static boolean handlePreDematerialization(ServerTardis tardis, MinecraftServer server) {
        return TEvents.handle(new TravelResultEvent(handler -> handler.preDemat(tardis, server)));
    }

    static boolean handleDematerialization(ServerTardis tardis, MinecraftServer server) {
        return TEvents.handle(new TravelResultEvent(handler -> handler.demat(tardis, server)));
    }

    static boolean handlePostDematerialization(ServerTardis tardis, MinecraftServer server) {
        return TEvents.handle(new TravelResultEvent(handler -> handler.postDemat(tardis, server)));
    }

    static boolean handlePreFlight(ServerTardis tardis, MinecraftServer server) {
        return TEvents.handle(new TravelResultEvent(handler -> handler.preFlight(tardis, server)));
    }

    static boolean handleFlight(ServerTardis tardis, MinecraftServer server) {
        return TEvents.handle(new TravelResultEvent(handler -> handler.flight(tardis, server)));
    }

    static boolean handlePostFlight(ServerTardis tardis, MinecraftServer server) {
        return TEvents.handle(new TravelResultEvent(handler -> handler.postFlight(tardis, server)));
    }

    static boolean handlePreRematerialization(ServerTardis tardis, MinecraftServer server) {
        return TEvents.handle(new TravelResultEvent(handler -> handler.preRemat(tardis, server)));
    }

    static boolean handleRematerialization(ServerTardis tardis, MinecraftServer server) {
        return TEvents.handle(new TravelResultEvent(handler -> handler.remat(tardis, server)));
    }

    static boolean handlePostRematerialization(ServerTardis tardis, MinecraftServer server) {
        return TEvents.handle(new TravelResultEvent(handler -> handler.postRemat(tardis, server)));
    }

    Type<TardisTravelEvents> event = new Type<>(TardisTravelEvents.class);

    default boolean preDemat(ServerTardis tardis, MinecraftServer server) { return true; }
    default boolean demat(ServerTardis tardis, MinecraftServer server) { return true; }
    default boolean postDemat(ServerTardis tardis, MinecraftServer server) { return true; }
    default boolean preFlight(ServerTardis tardis, MinecraftServer server) { return true; }
    default boolean flight(ServerTardis tardis, MinecraftServer server) { return true; }
    default boolean postFlight(ServerTardis tardis, MinecraftServer server) { return true; }
    default boolean preRemat(ServerTardis tardis, MinecraftServer server) { return true; }
    default boolean remat(ServerTardis tardis, MinecraftServer server) { return true; }
    default boolean postRemat(ServerTardis tardis, MinecraftServer server) { return true; }
}
