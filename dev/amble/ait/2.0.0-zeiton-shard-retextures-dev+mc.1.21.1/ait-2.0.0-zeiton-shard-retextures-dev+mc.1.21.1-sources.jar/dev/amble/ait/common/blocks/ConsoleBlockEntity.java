package dev.amble.ait.common.blocks;

import dev.amble.ait.api.mod.block.entity.LinkableBlockEntity;
import dev.amble.ait.common.lib.AitVariants;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import dev.amble.ait.common.lib.AitBlockEntities;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public class ConsoleBlockEntity extends LinkableBlockEntity implements GeoBlockEntity {

    private static final String MODEL_KEY = "ModelVariant";
    private static final String TEXTURE_KEY = "TextureVariant";

    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("idle");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private int modelVariant = 0;
    private int textureVariant = 0;

    public ConsoleBlockEntity(class_2338 pos, class_2680 state) {
        super(AitBlockEntities.CONSOLE_BLOCK_ENTITY, pos, state);
    }

    public String getModelName() {
        int idx = AitVariants.wrap(this.modelVariant, AitVariants.CONSOLE_VARIANTS.length);
        return AitVariants.CONSOLE_VARIANTS[idx].modelName();
    }

    public String getAnimationName() {
        int idx = AitVariants.wrap(this.modelVariant, AitVariants.CONSOLE_VARIANTS.length);
        return AitVariants.CONSOLE_VARIANTS[idx].animationName();
    }

    public String getTextureName() {
        AitVariants.ConsoleVariant variant = AitVariants.CONSOLE_VARIANTS[
                AitVariants.wrap(this.modelVariant, AitVariants.CONSOLE_VARIANTS.length)
                ];
        String[] textures = variant.textureNames();
        return textures[AitVariants.wrap(this.textureVariant, textures.length)];
    }

    public boolean isOnSlab() {
        return this.method_11010().method_11654(ConsoleBlock.ON_SLAB);
    }

    public boolean isBetween() {
        return this.method_11010().method_11654(ConsoleBlock.BETWEEN);
    }

    public void cycleAnimation() {
        // Consoles now always run idle; keep method for call-site compatibility.
    }

    public void cycleModelVariant() {
        this.modelVariant = (this.modelVariant + 1) % AitVariants.CONSOLE_VARIANTS.length;
        this.textureVariant = 0;
        this.sync();
    }

    public void cycleTextureVariant() {
        AitVariants.ConsoleVariant variant = AitVariants.CONSOLE_VARIANTS[
                AitVariants.wrap(this.modelVariant, AitVariants.CONSOLE_VARIANTS.length)
                ];
        this.textureVariant = (this.textureVariant + 1) % Math.max(variant.textureNames().length, 1);
        this.sync();
    }

    private void sync() {
        this.method_5431();
        if (this.field_11863 != null) {
            this.field_11863.method_8413(this.field_11867, this.method_11010(), this.method_11010(), 3);
        }
    }

    public void cycleLight() {
        if (this.field_11863 == null) return;

        class_2680 current = this.method_11010();
        int light = (current.method_11654(ConsoleBlock.LIGHT) + 1) % 16;
        class_2680 updated = current.method_11657(ConsoleBlock.LIGHT, light);

        this.method_5431();
        this.field_11863.method_8652(this.field_11867, updated, class_2248.field_31036);
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        tag.method_10569(MODEL_KEY, this.modelVariant);
        tag.method_10569(TEXTURE_KEY, this.textureVariant);
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        this.modelVariant = tag.method_10545(MODEL_KEY)
                ? AitVariants.wrap(tag.method_10550(MODEL_KEY), AitVariants.CONSOLE_VARIANTS.length)
                : 0;

        AitVariants.ConsoleVariant variant = AitVariants.CONSOLE_VARIANTS[this.modelVariant];
        int textureCount = Math.max(variant.textureNames().length, 1);
        this.textureVariant = tag.method_10545(TEXTURE_KEY)
                ? AitVariants.wrap(tag.method_10550(TEXTURE_KEY), textureCount)
                : 0;
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        class_2487 tag = super.method_16887(registries);
        method_11007(tag, registries);
        return tag;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "console", 5, state -> state.setAndContinue(IDLE)));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}


