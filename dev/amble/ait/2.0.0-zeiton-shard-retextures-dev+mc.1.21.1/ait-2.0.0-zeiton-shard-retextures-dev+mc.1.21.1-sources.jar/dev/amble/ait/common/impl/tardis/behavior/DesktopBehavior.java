package dev.amble.ait.common.impl.tardis.behavior;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.api.tardis.ars.ArsContext;
import dev.amble.ait.api.tardis.ars.Room;
import dev.amble.ait.api.tardis.ars.RoomPrototype;
import dev.amble.ait.api.tardis.event.desktop.DesktopPlacementEvents;
import dev.amble.ait.api.tardis.event.init.TardisLifecycleEvents;
import dev.amble.ait.common.blocks.DoorBlock;
import dev.amble.ait.common.impl.tardis.state.DimensionState;
import dev.amble.ait.common.impl.tardis.state.DesktopState;
import dev.amble.ait.common.lib.AitBlocks;
import dev.amble.ait.common.lib.tardis.AitRoomPrototypes;
import dev.drtheo.ecs.behavior.TBehavior;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3485;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class DesktopBehavior implements TBehavior, DesktopPlacementEvents, TardisLifecycleEvents {

    private List<RoomPrototype> roomPrototypes = new ArrayList<>();

    @Override
    public void onPostCreated(ServerTardis tardis, MinecraftServer server) {
        // Unused at the moment.
    }

    @Override
    public void startDesktopPlacing(ServerTardis tardis, MinecraftServer server) {
        DimensionState dimensionState = tardis.state(DimensionState.state);
        DesktopState desktopState = tardis.state(DesktopState.state);
        class_3218 level = dimensionState.level.get();

        if (level == null) return;

        ArsContext arsContext = new ArsContext(tardis, desktopState.uuidRoomMap);

        class_2338 position = new class_2338(0, 63, 0);

        roomPrototypes.add(AitRoomPrototypes.CORAL);
        roomPrototypes.add(AitRoomPrototypes.PROGRESS);
        roomPrototypes.add(AitRoomPrototypes.COPPER);

        for (int i = 0; i < roomPrototypes.size(); i++) {
            RoomPrototype proto = roomPrototypes.get(i);
            this.placeRoom(arsContext, position.method_10069(0, 0, (int) (i * proto.size().field_1324)), proto, desktopState, level);
        }
    }

    private static final class_3492 SETTINGS = new class_3492().method_15131(false);

    private boolean placeRoom(ArsContext arsContext, class_2338 position, RoomPrototype protoType, DesktopState desktopState, class_3218 level) {
        class_3485 manager = level.method_14183();

        Room room = new Room(UUID.randomUUID(), Set.of(),
                protoType, position);

        class_2960 structureToPlace = room.prototype().id();

        class_3499 template = manager.method_15091(structureToPlace);

        if (template == null) return false;

        boolean bl = template.method_15172(level, position, class_2338.field_10980,
                SETTINGS, level.method_8409(), class_2248.field_31031);

        if (bl) {
            AitAPI.LOGGER.debug("Successfully placed structure: {}", structureToPlace);

            arsContext.rooms().put(room.id(), room);

            if (desktopState.rootId == null) {
                if (protoType.doorPos() != null) {
                    this.placeInteriorDoor(level, desktopState, position.method_10081(protoType.doorPos()), protoType.doorRotation());

                }
                desktopState.rootId = room.id();
            }

            return true;
        }

        AitAPI.LOGGER.debug("Failed to place structure: {}", structureToPlace);

        return false;
    }

    private void placeInteriorDoor(class_3218 level, DesktopState desktopState, class_2338 doorPos, int rotation) {
        class_2680 doorState = AitBlocks.TARDIS_DOOR.method_9564()
                .method_11657(DoorBlock.ROTATION, rotation)
                .method_11657(DoorBlock.BETWEEN, false)
                .method_11657(DoorBlock.ON_SLAB, false);

        level.method_8652(doorPos, doorState, class_2248.field_31036);

        // Store the interior door position and rotation in DesktopState
        desktopState.doorPos = doorPos;
        desktopState.doorRot = rotation;
    }

    @Override
    public void duringDesktopPlacement(ServerTardis tardis, MinecraftServer server) {
        // probably gonna go unused tbf. - Loqor
    }

    @Override
    public void endDesktopPlaced(ServerTardis tardis, MinecraftServer server) {
        // Also unused ig. - Loqor
    }
}
