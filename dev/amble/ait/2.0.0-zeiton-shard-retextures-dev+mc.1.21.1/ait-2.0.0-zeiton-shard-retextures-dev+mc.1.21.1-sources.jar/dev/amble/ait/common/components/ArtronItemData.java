package dev.amble.ait.common.components;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_3532;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ArtronItemData(int maxCharge, int charge) {

    public static final Codec<ArtronItemData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.fieldOf("max_charge").forGetter(ArtronItemData::maxCharge),
            Codec.INT.fieldOf("charge").forGetter(ArtronItemData::charge)
    ).apply(instance, ArtronItemData::new));

    public static final class_9139<class_9129, ArtronItemData> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_49675, ArtronItemData::maxCharge,
            class_9135.field_49675, ArtronItemData::charge,
            ArtronItemData::new);

    public static ArtronItemData withMaxCharge(int maxCharge) {
        return new ArtronItemData(maxCharge, 0);
    }

    public ArtronItemData remove(int charge) {
        return this.add(-charge);
    }

    public ArtronItemData add(int charge) {
        return new ArtronItemData(this.maxCharge, class_3532.method_15340(this.charge + charge, 0, this.maxCharge));
    }

    public boolean charged() {
        return this.charge > 0;
    }

    public boolean empty() {
        return this.charge == 0;
    }
}
