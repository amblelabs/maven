package dev.amble.ait.common.sonic;

import dev.amble.ait.api.mod.sonic.SonicCrystal;
import dev.amble.ait.common.I18n;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3966;
import net.minecraft.class_5743;
import org.joml.Vector3f;

public class LaserSonicFunction implements SonicCrystal.SonicFunction {

    private static final float DAMAGE = 8.0f;
    private static final int FUEL_COST = 4;

    private static final Vector3f RED = new Vector3f(1.0f, 0.1f, 0.1f);
    private static final Vector3f WHITE = new Vector3f(1.0f, 0.8f, 0.8f);

    @Override
    public class_1799 preview() {
        return new class_1799(class_1802.field_8894);
    }

    @Override
    public class_2561 name() {
        return I18n.FUNC_ON_LASER;
    }

    @Override
    public int maxTime() {
        return 2 * 20;
    }

    @Override
    public int tick(class_1799 stack, class_1937 level, class_1309 user, int ticks, int ticksLeft) {
        if (!canActivate(ticks)) return 1;

        class_239 hitResult = SonicCrystal.SonicFunction.getHitResult(user);

        if (hitResult instanceof class_3966 entityHitResult) {
            if (!(user instanceof class_1657 player)) return SonicCrystal.SonicFunction.HALT;

            class_1297 entity = entityHitResult.method_17782();
            entity.method_5643(level.method_48963().method_48802(player), DAMAGE);
            entity.method_20803(40);

            level.method_8396(null, user.method_24515(), class_3417.field_14970, class_3419.field_15248, 1.0F, 1.8F);

            if (level instanceof class_3218 serverLevel) {
                spawnBeam(serverLevel, user.method_33571(), entityHitResult.method_17784());
            }

            return FUEL_COST;
        }

        return 1;
    }

    private static void spawnBeam(class_3218 level, class_243 origin, class_243 target) {
        class_243 direction = target.method_1020(origin);
        double distance = direction.method_1033();
        class_243 step = direction.method_1029();

        int particleCount = (int) (distance * 6);
        class_5743 dust = new class_5743(WHITE, RED, 0.8f);

        for (int i = 0; i < particleCount; i++) {
            double progress = (double) i / particleCount;
            class_243 pos = origin.method_1019(step.method_1021(distance * progress));

            level.method_14199(dust, pos.field_1352, pos.field_1351, pos.field_1350, 1, 0.02, 0.02, 0.02, 0.0);
        }
    }

    private static boolean canActivate(int ticks) {
        return ticks >= 10;
    }
}

