package dev.amble.ait.api.mod.storage;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.DataFixer;
import com.mojang.logging.LogUtils;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_148;
import net.minecraft.class_2487;
import net.minecraft.class_2522;
import net.minecraft.class_3218;
import net.minecraft.class_7225;
import net.minecraft.class_8910;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Objects;

/**
 * Plain-text Lazy Directory Dimension Data Storage
 */
public class PlainLazyDirectoryDimensionDataStorage {

    private static final Logger LOGGER = LogUtils.getLogger();

    private final File dataFolder;

    public PlainLazyDirectoryDimensionDataStorage(File dataFolder, DataFixer fixerUpper, class_7225.class_7874 registries) {
        this.dataFolder = dataFolder;
    }

    public static PlainLazyDirectoryDimensionDataStorage get(MinecraftServer server) {
        return get(server.method_30002());
    }

    public static PlainLazyDirectoryDimensionDataStorage get(class_3218 world) {
        if (!(world.method_17983() instanceof Provider level)) {
            class_128 crashReport = class_128.method_560(new ClassCastException("Level " + world + " does not implement PlainLazyDirectoryDimensionDataStorage!"), "Getting Level Data Storage");
            class_129 crashReportCategory = crashReport.method_562("Data Storage");
            crashReportCategory.method_578("Level", world);
            throw new class_148(crashReport);
        }

        return level.ait$getOrCreate();
    }

    private File getDataFile(@Nullable String folder, String name) {
        return new File(this.dataFolder, (folder != null ? folder + File.pathSeparator : "") + name + ".nbt");
    }

    public @Nullable class_2487 readSavedData(@Nullable String folder, String filename) {
        try {
            File file = this.getDataFile(folder, filename);

            if (file.exists()) {
                class_2487 compoundTag = this.readTagFromDisk(folder, filename);
                return Objects.requireNonNull(compoundTag, "read tag must not be null");
            }
        } catch (Exception exception) {
            LOGGER.error("Error loading saved data: {}", filename, exception);
        }

        return null;
    }

    public @Nullable class_2487 readSavedData(String filename) {
        return this.readSavedData(null, filename);
    }

    private class_2487 readTagFromDisk(@Nullable String folder, String filename) throws IOException {
        File file = this.getDataFile(folder, filename);

        try (
                InputStream inputStream = new FileInputStream(file)
//                PushbackInputStream pushbackInputStream = new PushbackInputStream(new FastBufferedInputStream(inputStream), 2);
        ) {
            // FIXME: this is very inefficient. Instead of reading the entire (perhaps malformed) InputStream we can use the stuff above.
            return class_2522.method_10718(new String(inputStream.readAllBytes()));
        } catch (CommandSyntaxException e) {
            throw new class_8910(e.getMessage());
        }
    }

    public void save(@Nullable String folder, String name, class_2487 tag) {
        try {
            // Again, not great. See NbtIo#SYNC_OUTPUT_OPTIONS
            Files.writeString(this.getDataFile(folder, name).toPath(), tag.toString(), StandardOpenOption.CREATE);
        } catch (IOException iOException) {
            LOGGER.error("Could not save data {}", this, iOException);
        }
    }

    public void save(String name, class_2487 tag) {
        this.save(null, name, tag);
    }

    public interface Provider {
        PlainLazyDirectoryDimensionDataStorage ait$getOrCreate();
    }
}
