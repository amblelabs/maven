package dev.amble.ait.common.entities;

import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.common.blocks.ExteriorBlock;
import dev.amble.ait.common.blocks.ExteriorBlockEntity;
import dev.amble.ait.common.impl.tardis.state.ExteriorState;
import dev.amble.ait.common.lib.AitEntities;
import dev.amble.ait.common.lib.AitSounds;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2482;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_2771;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3419;
import net.minecraft.class_4208;
import net.minecraft.class_7924;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.util.GeckoLibUtil;

// FIXME: this looks like a remnant of ait 1
public class FallingTardisBlockEntity extends class_1297 implements GeoEntity {

    private static final class_2940<class_2487> DATA_BLOCK_STATE_TAG =
            class_2945.method_12791(FallingTardisBlockEntity.class, class_2943.field_13318);
    private static final class_2940<class_2487> DATA_BLOCK_ENTITY_TAG =
            class_2945.method_12791(FallingTardisBlockEntity.class, class_2943.field_13318);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private class_2680 blockState = class_2246.field_10124.method_9564();
    private @Nullable class_2487 blockEntityData;
    private int time;

    public FallingTardisBlockEntity(class_1299<?> type, class_1937 level) {
        super(type, level);
    }

    public FallingTardisBlockEntity(class_1937 level, double x, double y, double z, class_2680 state, class_2487 blockEntityData) {
        this(AitEntities.FALLING_TARDIS_BLOCK, level);
        this.blockState = state;
        this.blockEntityData = blockEntityData;
        this.field_23807 = true;
        this.method_5814(x, y, z);
        this.method_18799(class_243.field_1353);
        this.field_6014 = x;
        this.field_6036 = y;
        this.field_5969 = z;
        syncToClient();
    }

    @SuppressWarnings("UnusedReturnValue")
    public static @Nullable FallingTardisBlockEntity fall(class_1937 level, class_2338 pos, class_2680 state) {
        class_2586 be = level.method_8321(pos);
        if (be == null) return null;

        class_2487 beData = be.method_38244(level.method_30349());

        level.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31036);

        FallingTardisBlockEntity entity = new FallingTardisBlockEntity(
                level, pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5, state, beData);
        level.method_8649(entity);

        return entity;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(DATA_BLOCK_STATE_TAG, new class_2487());
        builder.method_56912(DATA_BLOCK_ENTITY_TAG, new class_2487());
    }

    private void syncToClient() {
        this.field_6011.method_12778(DATA_BLOCK_STATE_TAG, class_2512.method_10686(this.blockState));
        this.field_6011.method_12778(DATA_BLOCK_ENTITY_TAG, this.blockEntityData != null ? this.blockEntityData : new class_2487());
    }

    public class_2680 getClientBlockState() {
        if (!this.method_37908().method_8608()) return this.blockState;
        class_2487 tag = this.field_6011.method_12789(DATA_BLOCK_STATE_TAG);
        if (tag.method_33133()) return this.blockState;
        return class_2512.method_10681(this.method_37908().method_45448(class_7924.field_41254), tag);
    }

    public class_2487 getClientBlockEntityData() {
        return this.field_6011.method_12789(DATA_BLOCK_ENTITY_TAG);
    }

    public int getTextureIndex() {
        class_2680 state = this.method_37908().method_8608() ? getClientBlockState() : this.blockState;
        if (state.method_28498(ExteriorBlock.TEXTURE)) {
            return state.method_11654(ExteriorBlock.TEXTURE);
        }
        return 0;
    }

    public int getRotation() {
        class_2680 state = this.method_37908().method_8608() ? getClientBlockState() : this.blockState;
        if (state.method_28498(ExteriorBlock.ROTATION)) {
            return state.method_11654(ExteriorBlock.ROTATION);
        }
        return 0;
    }

    public float getAlpha() {
        class_2487 data = this.method_37908().method_8608() ? getClientBlockEntityData() : this.blockEntityData;
        if (data.method_10545("Alpha")) {
            return data.method_10583("Alpha");
        }
        return 1.0f;
    }

    public int getDoorStateOrdinal() {
        class_2487 data = this.method_37908().method_8608() ? getClientBlockEntityData() : this.blockEntityData;
        if (data.method_10545("DoorState")) {
            return data.method_10550("DoorState");
        }
        return 0;
    }

    @Override
    public void method_5773() {
        if (!this.method_37908().method_8608() && this.blockState.method_26215()) {
            this.method_31472();
            return;
        }

        this.time++;

        if (!this.method_5740()) {
            this.method_18799(this.method_18798().method_1031(0.0, -0.04, 0.0));
        }

        this.method_5784(class_1313.field_6308, this.method_18798());

        if (!this.method_37908().method_8608()) {
            class_2338 landingPos = this.method_24515();

            if (this.method_24828()) {
                class_2680 stateAtPos = this.method_37908().method_8320(landingPos);
                this.method_18799(this.method_18798().method_18805(0.7, -0.5, 0.7));

                if (!stateAtPos.method_27852(class_2246.field_10008)) {
                    if (stateAtPos.method_45474()) {
                        class_2680 toPlace = setOnSlab(this.blockState, false);

                        if (this.method_37908().method_8652(landingPos, toPlace, class_2248.field_31036)) {
                            this.method_37908().method_8396(null, landingPos, AitSounds.LAND_THUD, class_3419.field_15245, 1.0f, 1.0f);
                            this.restorePlacedBlockData(landingPos, toPlace);
                            this.method_31472();
                            return;
                        }
                    } else if (isBottomSlab(stateAtPos)) {
                        class_2338 abovePos = landingPos.method_10084();
                        class_2680 aboveState = this.method_37908().method_8320(abovePos);

                        if (aboveState.method_45474()) {
                            class_2680 toPlace = setOnSlab(this.blockState, true);

                            if (this.method_37908().method_8652(abovePos, toPlace, class_2248.field_31036)) {
                                this.method_37908().method_8396(null, abovePos, AitSounds.LAND_THUD, class_3419.field_15245, 1.0f, 1.0f);
                                this.restorePlacedBlockData(abovePos, toPlace);
                                this.method_31472();
                                return;
                            }
                        }
                    }
                }
            }

            if (this.time > 600) {
                this.method_31472();
            }
        }

        this.method_18799(this.method_18798().method_1021(0.98));
    }

    private void restorePlacedBlockData(class_2338 placedPos, class_2680 placedState) {
        class_2586 be = this.method_37908().method_8321(placedPos);
        if (be != null && this.blockEntityData != null) {
            be.method_58690(this.blockEntityData, this.method_37908().method_30349());
            be.method_5431();
        }

        this.method_37908().method_8413(placedPos, placedState, placedState, class_2248.field_31036);

        if (be instanceof ExteriorBlockEntity exteriorBlockEntity) {
            Tardis tardis = exteriorBlockEntity.tardis();
            if (tardis != null) {
                ExteriorState exteriorState = tardis.state(ExteriorState.state);
                exteriorState.updateExteriorPos(new class_4208(this.method_37908().method_27983(), placedPos), this.getRotation());
            }
        }
    }

    private static boolean isBottomSlab(class_2680 state) {
        return state.method_26204() instanceof class_2482
                && state.method_28498(class_2741.field_12485)
                && state.method_11654(class_2741.field_12485) == class_2771.field_12681;
    }

    private static class_2680 setOnSlab(class_2680 state, boolean onSlab) {
        class_2769<?> prop = state.method_26204().method_9595().method_11663("on_slab");
        if (prop instanceof class_2746 bp) {
            return state.method_11657(bp, onSlab);
        }
        return state;
    }

    @Override
    protected void method_5652(class_2487 tag) {
        tag.method_10566("BlockState", class_2512.method_10686(this.blockState));
        tag.method_10569("Time", this.time);
        if (this.blockEntityData != null) {
            tag.method_10566("TileEntityData", this.blockEntityData);
        }
    }

    @Override
    protected void method_5749(class_2487 tag) {
        this.blockState = class_2512.method_10681(
                this.method_37908().method_45448(class_7924.field_41254), tag.method_10562("BlockState"));
        this.time = tag.method_10550("Time");
        if (tag.method_10573("TileEntityData", 10)) {
            this.blockEntityData = tag.method_10562("TileEntityData");
        }
        if (this.blockState.method_26215()) {
            this.blockState = class_2246.field_10124.method_9564();
        }
        syncToClient();
    }

    @Override
    public boolean method_5732() {
        return false;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "idle", 0, state -> PlayState.STOP));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
