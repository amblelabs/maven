package dev.amble.ait.common.impl.tardis.state;

import dev.amble.ait.api.AitAPI;
import dev.drtheo.ecs.state.NbtSerializer;
import dev.drtheo.ecs.state.TState;
import net.minecraft.class_2487;

public class RematState implements TState<RematState>, NbtSerializer {
    public int rematTimerTicks = -1;
    public static final int REMAT_TIME = 14 * 20;

    public static final TState.Type<RematState> state = new TState.NbtBacked<>(AitAPI.modLoc("remat"), 0) {
        @Override
        public RematState fromNbt(class_2487 nbt, boolean isClient) {
            RematState rematState = new RematState();

            rematState.rematTimerTicks = nbt.method_10550("RematTimerTicks");

            return rematState;
        }
    };

    @Override
    public void toNbt(class_2487 nbt, boolean isClient) {
        nbt.method_10569("RematTimerTicks", rematTimerTicks);
    }

    @Override
    public TState.Type<RematState> type() {
        return state;
    }
}