package dev.amble.ait.common.impl.tardis;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.mod.storage.PlainLazyDirectoryDimensionDataStorage;
import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.api.tardis.TardisManager;
import dev.amble.ait.api.tardis.event.init.TardisLifecycleEvents;
import dev.amble.ait.common.network.tardis.manager.TardisSyncPayload;
import dev.amble.ait.xplat.IXplatAbstractions;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.class_2487;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.jspecify.annotations.Nullable;

import java.util.*;
import java.util.stream.Stream;

public class ServerTardisManager implements TardisManager<ServerTardis> {

	private static final String STORAGE_PREFIX = AitAPI.MOD_ID;

	private final Object2ObjectMap<UUID, @Nullable ServerTardis> lookup = new Object2ObjectOpenHashMap<>();
	private final MinecraftServer server; // lives just as long as the world, shouldn't explode

	public ServerTardisManager(MinecraftServer server) {
		this.server = server;
	}

	public MinecraftServer server() {
		return server;
	}

	public void tick() {
		for (ServerTardis tardis : this.lookup.values()) {
			if (tardis == null) continue;

			tardis.tick();

			if (tardis.dirty()) {
				// FIXME: don't sync to everyone on the server
				this.syncPartial(tardis, server.method_3760().method_14571().stream());
				tardis.unmarkDirty();
			}
		}
	}

	public void sendInChunk(class_3222 player, class_3218 level, class_2818 chunk) {
		Collection<ServerTardis> marked = TardisManager.asChunkTracker(level).ait$getMarked(chunk.method_12004());
		if (marked == null) return;

		for (ServerTardis tardis : marked) {
			this.syncPartial(tardis, Stream.of(player));
		}
	}

	public void syncPartial(ServerTardis tardis, Stream<class_3222> targets) {
		class_2487 nbt = new class_2487();
		tardis.toNbt(nbt, true);

		TardisSyncPayload payload = new TardisSyncPayload(nbt);
		IXplatAbstractions.INSTANCE.sendPacketToAll(targets, payload);
	}

	@Override
	public boolean contains(UUID id) {
		return lookup.containsKey(id);
	}

	private @Nullable ServerTardis load(UUID id) {
		PlainLazyDirectoryDimensionDataStorage storage = PlainLazyDirectoryDimensionDataStorage.get(server);

		class_2487 data = storage.readSavedData(STORAGE_PREFIX, id.toString());
		if (data == null) return null;

		ServerTardis tardis = ServerTardis.fromNbt(data);
		TardisLifecycleEvents.handleLoaded(this, tardis);
		return tardis;
	}

	@Override
	public @Nullable ServerTardis get(UUID id) {
		return lookup.computeIfAbsent(id, this::load);
	}

	@Override
	public void remove(UUID id) {
		lookup.remove(id);
	}

	@Override
	public void add(ServerTardis tardis) {
		lookup.put(tardis.id(), tardis);

		// FIXME: don't sync to everyone on the server
		this.syncPartial(tardis, server.method_3760().method_14571().stream());
	}

	public void save() {
		PlainLazyDirectoryDimensionDataStorage storage = PlainLazyDirectoryDimensionDataStorage.get(server);

		for (ServerTardis tardis : this.lookup.values()) {
			if (tardis == null) continue;

			class_2487 tag = new class_2487();
			tardis.toNbt(tag, false);

			storage.save(STORAGE_PREFIX, tardis.id().toString(), tag);
		}
	}

	public static @Nullable ServerTardisManager get(class_3218 level) {
		return (ServerTardisManager) TardisManager.<ServerTardis>asManagerLevel(level).ait$getTardisManager();
	}
}