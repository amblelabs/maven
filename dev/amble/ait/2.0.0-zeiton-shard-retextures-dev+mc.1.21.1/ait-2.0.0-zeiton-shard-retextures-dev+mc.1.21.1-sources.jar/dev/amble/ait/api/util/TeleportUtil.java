package dev.amble.ait.api.util;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2709;
import net.minecraft.class_3218;

public class TeleportUtil {

    public static void teleportWithOffset(class_1297 entity, class_3218 serverLevel, class_2338 blockPos, int yaw) {
        class_2338 offsetPos = positionOffset(blockPos, yaw);
        teleportWithOffset(entity, serverLevel, offsetPos, yaw * 45f, 0.0f);
    }

    public static void teleportWithOffset(class_1297 entity, class_3218 serverLevel, class_2338 blockPos, float yaw, float pitch) {
        entity.method_48105(serverLevel,
                blockPos.method_10263() + 0.5,
                blockPos.method_10264(),
                blockPos.method_10260() + 0.5,
                class_2709.field_40711,
                yaw,
                pitch);
    }

    private static class_2338 positionOffset(class_2338 pos, int rotation) {
        return switch (rotation) {
            case 0 -> pos.method_10069(0, 0, 1);
            case 1 -> pos.method_10069(-1, 0, 1);
            case 2 -> pos.method_10069(-1, 0, 0);
            case 3 -> pos.method_10069(-1, 0, -1);
            case 4 -> pos.method_10069(0, 0, -1);
            case 5 -> pos.method_10069(1, 0, -1);
            case 6 -> pos.method_10069(1, 0, 0);
            case 7 -> pos.method_10069(1, 0, 1);
            default -> pos;
        };
    }
}
