package dev.amble.ait.common.network.tardis.manager;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.client.impl.tardis.ClientTardisManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record TardisSyncPayload(class_2487 tag) implements class_8710 {

    public static final class_2960 ID = AitAPI.modLoc("tardis/sync");
    public static final class_8710.class_9154<TardisSyncPayload> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, TardisSyncPayload> STREAM_CODEC =
            class_9139.method_56434(class_9135.field_49677, TardisSyncPayload::tag, TardisSyncPayload::new);

    @Environment(EnvType.CLIENT)
    public void handle(class_310 minecraft, class_746 player) {
        ClientTardisManager.get(minecraft.field_1687).upsert(tag);
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
