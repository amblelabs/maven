package dev.amble.ait.api.mod.block.entity;

import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.TardisManager;
import org.jspecify.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public class LinkableBlockEntity extends class_2586 {

    private static final String ID_TAG = "Tardis";

    private @Nullable UUID tardisId;

    /**
     * Lazily initialized, prefer to use the getter ({@link #tardis()}.
     */
    private @Nullable Tardis tardis;

    public LinkableBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public @Nullable Tardis tardis() {
        if (this.tardis != null) return this.tardis;

        if (this.tardisId != null)
            return this.tardis = TardisManager.apply(this.method_10997(),
                    manager -> manager.get(this.tardisId));

        return null;
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);

        if (this.tardisId != null)
            tag.method_25927(ID_TAG, this.tardisId);
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);

        if (!tag.method_25928(ID_TAG)) return;
        this.tardisId = tag.method_25926(ID_TAG);
    }

    @Override
    public void method_11012() {
        super.method_11012();
        this.tryUnmark();
    }

    public void link(Tardis tardis) {
        this.tardisId = tardis.id();
        this.tardis = tardis;

        this.handleLink();
    }

    public void link(UUID id) {
        this.tardisId = id;
        this.tardis = TardisManager.apply(this.method_10997(), manager -> manager.get(id));

        this.handleLink();
    }

    private void tryMark() {
        if (this.method_10997() instanceof class_3218 serverWorld && this.tardis() != null)
            TardisManager.asChunkTracker(serverWorld).ait$mark(new class_1923(this.method_11016()), (ServerTardis) this.tardis);
    }

    /**
     * This may seem like it would explode immediately in multiplayer. But it actually doesn't!
     * {@link #tryMark()} gets called in {@link #method_16887(class_7225.class_7874)}, which would get called when player starts watching a chunk.
     * This means, it'll be marked back up, in case there are other {@link LinkableBlockEntity}s.
     */
    private void tryUnmark() {
        if (this.method_10997() instanceof class_3218 serverWorld && this.tardis() != null)
            TardisManager.asChunkTracker(serverWorld).ait$unmark(new class_1923(this.method_11016()), (ServerTardis) this.tardis);
    }

    private void handleLink() {
        this.tryMark();
        this.markUpdated();
    }

    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        this.tryMark();

        class_2487 tag = super.method_16887(registries);

        if (this.tardisId != null)
            tag.method_25927(ID_TAG, this.tardisId);

        return tag;
    }

    private void markUpdated() {
        this.method_5431();
        this.method_10997().method_8413(this.method_11016(), this.method_11010(), this.method_11010(), 3);
    }
}