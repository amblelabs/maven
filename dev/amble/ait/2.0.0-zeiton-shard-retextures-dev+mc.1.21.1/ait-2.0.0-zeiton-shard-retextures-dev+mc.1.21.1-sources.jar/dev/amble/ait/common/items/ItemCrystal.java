package dev.amble.ait.common.items;

import dev.amble.ait.api.mod.sonic.SonicCrystal;
import net.minecraft.class_1792;

public class ItemCrystal extends class_1792 {

    private final SonicCrystal crystal;

    public ItemCrystal(class_1793 properties, SonicCrystal crystal) {
        super(properties);

        this.crystal = crystal;
    }

    public SonicCrystal getCrystal() {
        return crystal;
    }
}
