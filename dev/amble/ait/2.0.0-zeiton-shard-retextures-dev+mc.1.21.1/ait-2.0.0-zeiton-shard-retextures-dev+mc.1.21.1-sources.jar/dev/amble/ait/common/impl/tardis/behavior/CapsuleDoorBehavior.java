package dev.amble.ait.common.impl.tardis.behavior;

import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.event.block.DoorInteractionEvents;
import dev.amble.ait.api.util.TeleportUtil;
import dev.amble.ait.common.impl.tardis.state.DoorState;
import dev.amble.ait.common.impl.tardis.state.ExteriorState;
import dev.drtheo.ecs.behavior.TBehavior;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_4208;

public class CapsuleDoorBehavior implements TBehavior, DoorInteractionEvents {

    @Override
    public void door$useWithoutItem(Tardis tardis, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        CapsuleExteriorBehavior.openDoors(tardis, level, pos, player);
    }

    @Override
    public void door$useWithItem(Tardis tardis, class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        CapsuleExteriorBehavior.openDoors(tardis, level, pos, player);
    }

    @Override
    public void door$entityInside(Tardis tardis, class_1937 level, class_2680 state, class_2338 blockPos, class_1297 entity) {
        ExteriorState exteriorState = tardis.state(ExteriorState.state);
        DoorState doorState = tardis.state(DoorState.state);

        if (doorState.closed()) return;

        if (!(level instanceof class_3218 serverLevel)) return;

        class_4208 globalPos = exteriorState.exteriorPos;
        int direction = (exteriorState.exteriorRot + 4) & 7;
        class_2338 finalPos = globalPos.comp_2208();

        class_3218 exteriorLevel = serverLevel.method_8503().method_3847(globalPos.comp_2207());

        if (exteriorLevel == null) return;

        TeleportUtil.teleportWithOffset(entity, exteriorLevel, finalPos, direction);
    }
}
