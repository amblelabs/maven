package dev.amble.ait.common.impl.tardis.state;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.ars.Room;
import dev.amble.ait.api.tardis.ars.RoomPrototype;
import dev.amble.ait.common.lib.tardis.AitRoomPrototypes;
import dev.drtheo.ecs.state.NbtSerializer;
import dev.drtheo.ecs.state.TState;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2495;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.nbt.*;
import org.jspecify.annotations.Nullable;

import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.UUID;

public class DesktopState implements TState<DesktopState>, NbtSerializer {

    public @Nullable class_2338 doorPos; // door position is null so that we can test if the door is there or not. - Loqor
    public int doorRot;
    public LinkedHashMap<UUID, Room> uuidRoomMap;
    public @Nullable UUID rootId;

    public DesktopState() {
        this.doorRot = 0;
        this.doorPos = null;
        this.uuidRoomMap = new LinkedHashMap<>();
        this.rootId = null;
    }

    public static final Type<DesktopState> state = new NbtBacked<>(AitAPI.modLoc("desktop"), 0) {
        @Override
        public DesktopState fromNbt(class_2487 nbt, boolean isClient) {
            DesktopState desktopState = new DesktopState();

            if (nbt.method_10545("door_position")) {
                class_2512.method_10691(nbt, "door_position").ifPresent(pos -> desktopState.doorPos = pos);
            }

            desktopState.doorRot = nbt.method_10550("door_rotation");

            if (nbt.method_10573("room_data", class_2520.field_33259)) {
                class_2499 rooms = nbt.method_10554("room_data", class_2520.field_33260);
                for (int i = 0; i < rooms.size(); i++) {
                    Room room = readRoom(rooms.method_10602(i));
                    desktopState.uuidRoomMap.put(room.id(), room);
                }
            }

            if (nbt.method_25928("root_id")) {
                UUID id = nbt.method_25926("root_id");
                if (desktopState.uuidRoomMap.containsKey(id)) {
                    desktopState.rootId = id;
                }
            }

            if (desktopState.rootId == null && !desktopState.uuidRoomMap.isEmpty()) {
                desktopState.rootId = desktopState.uuidRoomMap.keySet().iterator().next();
            }

            return desktopState;
        }
    };

    @Override
    public void toNbt(class_2487 nbt, boolean isClient) {
        if (doorPos != null) {
            nbt.method_10566("door_position", class_2512.method_10692(doorPos));
        }

        nbt.method_10569("door_rotation", doorRot);

        class_2499 listTag = new class_2499();
        for (Room room : uuidRoomMap.values()) {
            class_2487 tag = new class_2487();
            room.toNbt(tag, false);
            listTag.add(tag);
        }

        nbt.method_10566("room_data", listTag);

        if (rootId != null) {
            nbt.method_25927("root_id", rootId);
        }
    }

    @Override
    public Type<DesktopState> type() {
        return state;
    }

    public void updateDoorPos(class_2338 pos) {
        updateDoorPos(pos, this.doorRot);
    }

    public void updateDoorPos(int rot) {
        updateDoorPos(this.doorPos, rot);
    }

    public void updateDoorPos(class_2338 pos, int rot) {
        this.doorPos = pos;
        this.doorRot = rot;
    }

    private static Room readRoom(class_2487 tag) {
        UUID id = tag.method_25926("id");
        class_2338 position = class_2512.method_10691(tag, "position").orElse(class_2338.field_10980);

        class_2960 prototypeId = class_2960.method_12829(tag.method_10558("prototype"));
        RoomPrototype prototype = prototypeId != null
                ? AitRoomPrototypes.REGISTRY.method_10223(prototypeId)
                : AitRoomPrototypes.DEFAULT;

        Set<UUID> connections = new LinkedHashSet<>();
        if (tag.method_10573("connections", class_2520.field_33259)) {
            class_2499 connectionTag = tag.method_10554("connections", class_2520.field_33261);
            for (class_2520 entry : connectionTag) {
                if (entry instanceof class_2495 arr) {
                    try {
                        connections.add(class_2512.method_25930(arr));
                    } catch (IllegalArgumentException ignored) {
                        // Skip malformed UUID entries so one bad connection doesn't break room loading.
                    }
                }
            }
        }

        return new Room(id, connections, prototype, position);
    }
}
