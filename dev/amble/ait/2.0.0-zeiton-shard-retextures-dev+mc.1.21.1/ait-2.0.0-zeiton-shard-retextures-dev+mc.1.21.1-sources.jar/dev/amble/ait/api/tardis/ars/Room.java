package dev.amble.ait.api.tardis.ars;

import dev.drtheo.ecs.state.NbtSerializer;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2512;

public record Room(UUID id, Set<UUID> connections,
                   RoomPrototype prototype, class_2338 position) implements NbtSerializer {

    public void forEachConnection(ArsContext ctx, Consumer<Room> consumer) {
        for (UUID id : this.connections) {
            consumer.accept(ctx.getRoomById(id));
        }
    }

    public boolean collides(Room room) {
        return this.asBox().method_994(room.asBox());
    }

    public class_238 asBox() {
        return this.prototype().size().method_996(this.position);
    }

    @Override
    public void toNbt(@NotNull class_2487 nbt, boolean isClient) {
        nbt.method_25927("id", this.id);
        nbt.method_10566("position", class_2512.method_10692(this.position));
        nbt.method_10582("prototype", this.prototype.id().toString());
        // Connections are stored in the parent Tardis state, so we don't need to serialize them here.
    }

    public void fromNbt(@NotNull class_2487 nbt, boolean isClient) {

    }
}
