package dev.amble.ait.api.tardis;

import dev.amble.ait.common.lib.amblekit.AitEcs;
import dev.amble.ait.api.tardis.event.state.TardisStateEvents;
import dev.amble.ait.api.tardis.event.tick.TardisTickEvents;
import dev.drtheo.ecs.state.NbtSerializer;
import dev.drtheo.ecs.state.TState;
import dev.drtheo.ecs.state.TStateContainer;
import org.jetbrains.annotations.Contract;
import org.jspecify.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_2481;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2960;

public class Tardis extends TStateContainer.Delegate implements NbtSerializer {

    public static final String ID_TAG = "Id";
    public static final String STATES_TAG = "States";

    protected final UUID id;

    protected final boolean isClient;
    protected boolean dirty;

    protected Tardis(UUID id) {
        super(AitEcs.States.createArrayHolder());

        this.id = id;
        this.isClient = false;
    }

    public static Tardis fromNbt(class_2487 nbt, boolean isClient) {
        UUID id = nbt.method_25926(ID_TAG);
        return new Tardis(id, nbt, isClient, false);
    }

    public Tardis(UUID id, class_2487 nbt, boolean isClient, boolean fix) {
        super(AitEcs.States.createArrayHolder());

        this.id = id;
        this.isClient = isClient;

        this.updateStates(nbt, isClient, fix);
    }

    public void tick() {
        TardisTickEvents.handleTick(this);
    }

    public UUID id() {
        return id;
    }

    public boolean isClient() {
        return isClient;
    }

    //region State handling & serialization
    public boolean dirty() {
        return dirty;
    }

    public void markDirty() {
        this.dirty = true;
    }

    public void unmarkDirty() {
        this.dirty = false;
    }

    public void updateStates(class_2487 nbt, boolean isClient, boolean fix) {
        class_2487 states = nbt.method_10562(STATES_TAG);

        for (String key : states.method_10541()) {
            if (AitEcs.States.get(class_2960.method_60654(key)) instanceof TState.NbtBacked<?> serializable) {
                class_2520 state = states.method_10580(key);

                if (state instanceof class_2487 compound) {
                    this.addState(serializable.decode(fix ? serializable.update(compound, 0) : compound, isClient));
                } else {
                    this.removeState(serializable);
                }
            }
        }
    }

    @Override
    @Contract(mutates = "this")
    public boolean addState(TState<?> state) {
        boolean result = super.addState(state);

        if (result)
            TardisStateEvents.handleAdd(this, state);

        return result;
    }

    @Override
    @Contract(mutates = "this")
    public <T extends TState<T>> @Nullable T removeState(TState.Type<T> type) {
        T result = super.removeState(type);

        if (result != null)
            TardisStateEvents.handleRemove(this, result);

        return result;
    }

    @Contract(mutates = "this")
    public <T extends TState<T>> @Nullable T removeState(T state) {
        return this.removeState(state.type());
    }

    @Override
    public void toNbt(class_2487 nbt, boolean isClient) {
        nbt.method_25927(ID_TAG, this.id);

        class_2487 states = new class_2487();

        // FIXME: this only works once. by this i mean diffing.
        this.forEachState((i, state) -> stateToNbt(states, i, state, isClient));

        nbt.method_10566(STATES_TAG, states);
    }

    @SuppressWarnings("rawtypes")
    private <T extends TState<T>> void stateToNbt(class_2487 nbt, int i, @Nullable TState<T> state, boolean isClient) {
        if (state == null) {
            // do the diffing only if we're serializing for client
            if (isClient) nbt.method_10566(AitEcs.States.get(i).id().toString(), class_2481.field_21026);

            return;
        }

        TState.Type<T> type = state.type();

        if (!(type instanceof TState.NbtBacked backed))
            return;

        //noinspection unchecked
        class_2487 tag = backed.encode(state, isClient);
        if (tag == null) return;

        nbt.method_10566(type.id().toString(), tag);
    }
    //endregion

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;

        if (obj instanceof Tardis tardis)
            return this.id.equals(tardis.id);

        return false;
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}