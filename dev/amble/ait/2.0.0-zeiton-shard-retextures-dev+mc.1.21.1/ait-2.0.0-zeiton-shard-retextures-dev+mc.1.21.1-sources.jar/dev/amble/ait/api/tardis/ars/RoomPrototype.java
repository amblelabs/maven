package dev.amble.ait.api.tardis.ars;

import dev.amble.ait.api.AitAPI;
import java.util.Objects;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2960;

/**
 * Typically the ID and structure location should be the same, but this allows for some flexibility if needed.
 * @author Loqor
 * @param size
 * @param id
 */
public record RoomPrototype(class_238 size, class_2960 id, class_2338 doorPos, int doorRotation) {
	public static final class Builder {
		private class_238 size;
		private class_2960 id;
		private class_2338 doorPos;
		private int doorRotation;

		public Builder() { }

		public Builder bounds(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
			this.size = new class_238(minX, minY, minZ, maxX, maxY, maxZ);
			return this;
		}

		public Builder size(class_238 size) {
			this.size = size;
			return this;
		}

		public Builder doorPos(class_2338 pos) {
			this.doorPos = pos;
			return this;
		}

		public Builder doorRotation(int rotation) {
			this.doorRotation = rotation;
			return this;
		}

		public Builder id(class_2960 id) {
			this.id = id;
			return this;
		}

		public Builder id(String path) {
			this.id = AitAPI.modLoc(path);
			return this;
		}

		public RoomPrototype build() {
			return new RoomPrototype(
					Objects.requireNonNull(this.size, "Room prototype is missing size"),
					Objects.requireNonNull(this.id, "Room prototype is missing id/structure location"),
					Objects.requireNonNull(this.doorPos, "Room prototype is missing default door position"),
                    this.doorRotation
			);
		}
	}
}
