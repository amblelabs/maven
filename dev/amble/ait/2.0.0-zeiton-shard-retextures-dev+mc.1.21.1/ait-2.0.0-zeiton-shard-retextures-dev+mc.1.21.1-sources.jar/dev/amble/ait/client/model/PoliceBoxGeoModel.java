package dev.amble.ait.client.model;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.blocks.ExteriorBlockEntity;
import net.minecraft.class_2960;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.model.GeoModel;

public class PoliceBoxGeoModel extends GeoModel<ExteriorBlockEntity> {

    @SuppressWarnings("removal")
    @Override
    public class_2960 getModelResource(ExteriorBlockEntity entity) {
        return AitAPI.modLoc("geo/blockentities/" + entity.getModelName() + ".geo.json");
    }

    @SuppressWarnings("removal")
    @Override
    public class_2960 getTextureResource(@Nullable ExteriorBlockEntity entity) {
        if (entity == null) return AitAPI.modLoc("textures/blockentities/exteriors/police_box_default.png");
        return AitAPI.modLoc("textures/blockentities/exteriors/" + entity.getTextureName() + ".png");
    }

    @Override
    public class_2960 getAnimationResource(ExteriorBlockEntity entity) {
        return AitAPI.modLoc("animations/blockentities/" + entity.getModelName() + ".animation.json");
    }
}
