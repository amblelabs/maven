package dev.amble.ait.api.tardis;

import org.jspecify.annotations.Nullable;

import java.util.Collection;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_148;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_3218;

public interface TardisManager<T extends Tardis> {

    static <T extends Tardis> void accept(class_1937 world, Consumer<TardisManager<T>> consumer) {
        TardisManager<T> manager = get(world);
        if (manager == null) return;

        consumer.accept(manager);
    }

    static <T extends Tardis, R> @Nullable R apply(class_1937 world, Function<TardisManager<T>, @Nullable R> func) {
        TardisManager<T> manager = get(world);
        if (manager == null) return null;

        return func.apply(manager);
    }

    static <T extends Tardis> TardisManager<T> getOrCreate(class_1937 world) {
        TardisManager<T> result = TardisManager.get(world);
        if (result != null) return result;

        result = TardisManager.<T>asManagerLevel(world).ait$initTardisManager();
        return result;
    }

    static <T extends Tardis> @Nullable TardisManager<T> get(class_1937 world) {
        return TardisManager.<T>asManagerLevel(world).ait$getTardisManager();
    }

    @SuppressWarnings("unchecked")
    static <T extends Tardis> ManagerLevel<T> asManagerLevel(Object world) {
        if (!(world instanceof ManagerLevel<?> level)) {
            class_128 crashReport = class_128.method_560(new ClassCastException("Level " + world + " does not implement ManagerLevel!"), "Getting Tardis Manager");
            class_129 crashReportCategory = crashReport.method_562("Tardis Manager");
            crashReportCategory.method_578("Level", world);
            throw new class_148(crashReport);
        }

        try {
            return (ManagerLevel<T>) level;
        } catch (ClassCastException e) {
            class_128 crashReport = class_128.method_560(new IllegalStateException("Tried getting Tardis Manager with improper type!"), "Getting TardisManager");
            class_129 crashReportCategory = crashReport.method_562("Tardis Manager");
            crashReportCategory.method_578("Level", world);
            crashReportCategory.method_578("Tardis Manager", level);
            throw new class_148(crashReport);
        }
    }

    static ChunkTracker asChunkTracker(class_3218 level) {
        if (!(level instanceof ChunkTracker tracker)) {
            class_128 crashReport = class_128.method_560(new ClassCastException("Level " + level + " does not implement ChunkTracker!"), "Getting Tardis Manager");
            class_129 crashReportCategory = crashReport.method_562("Tardis Manager");
            crashReportCategory.method_578("Level", level);
            throw new class_148(crashReport);
        }

        return tracker;
    }

    void remove(UUID id);
    void add(T tardis);

    boolean contains(UUID id);
    @Nullable T get(UUID id);

    interface ManagerLevel<T extends Tardis> {
        TardisManager<T> ait$initTardisManager();
        @Nullable TardisManager<T> ait$getTardisManager();
    }

    interface ChunkTracker {
        default void ait$mark(class_1923 pos, ServerTardis tardis) {
            ait$mark(pos.method_8324(), tardis);
        }

        void ait$mark(long pos, ServerTardis tardis);

        default void ait$unmark(class_1923 pos, ServerTardis tardis) {
            ait$unmark(pos.method_8324(), tardis);
        }

        void ait$unmark(long pos, ServerTardis tardis);

        default @Nullable Collection<ServerTardis> ait$getMarked(class_1923 pos) {
            return ait$getMarked(pos.method_8324());
        }

        @Nullable Collection<ServerTardis> ait$getMarked(long pos);
    }
}
