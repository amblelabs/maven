package dev.amble.ait.common.lib;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public class AitCommands {
    public static LiteralArgumentBuilder<class_2168> root() {
        // CommandImpl.add(mainCmd)
        return class_2170.method_9247("ait");
    }

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(root());
    }
}