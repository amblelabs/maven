package dev.amble.ait.api.tardis.event.block;

import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.event.NotifyEvent;
import dev.drtheo.ecs.event.TEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public interface DoorInteractionEvents extends TEvents {

    static void useWithoutItem(Tardis tardis, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        TEvents.handle(new NotifyEvent<>(event, handler -> handler.door$useWithoutItem(tardis, state, level, pos, player, hit)));
    }

    static void useWithItem(Tardis tardis, class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        TEvents.handle(new NotifyEvent<>(event, handler -> handler.door$useWithItem(tardis, stack, state, level, pos, player, hand, hit)));
    }

    static void entityInside(Tardis tardis, class_1937 level, class_2680 state, class_2338 blockPos, class_1297 entity) {
        TEvents.handle(new NotifyEvent<>(event, handler -> handler.door$entityInside(tardis, level, state, blockPos, entity)));
    }

    Type<DoorInteractionEvents> event = new Type<>(DoorInteractionEvents.class);

    void door$useWithoutItem(Tardis tardis, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit);
    void door$useWithItem(Tardis tardis, class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit);
    void door$entityInside(Tardis tardis, class_1937 level, class_2680 state, class_2338 blockPos, class_1297 entity);
}
