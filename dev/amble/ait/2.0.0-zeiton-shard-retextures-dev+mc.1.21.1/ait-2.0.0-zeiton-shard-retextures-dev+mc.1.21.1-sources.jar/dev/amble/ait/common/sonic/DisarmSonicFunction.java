package dev.amble.ait.common.sonic;

import dev.amble.ait.api.mod.sonic.SonicCrystal;
import dev.amble.ait.common.I18n;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3966;
import net.minecraft.class_5743;
import org.joml.Vector3f;

public class DisarmSonicFunction implements SonicCrystal.SonicFunction {

    private static final Vector3f GOLD = new Vector3f(1.0f, 0.85f, 0.2f);
    private static final Vector3f WHITE = new Vector3f(1f, 1f, 1f);

    @Override
    public class_1799 preview() {
        return new class_1799(class_1802.field_8371);
    }

    @Override
    public class_2561 name() {
        return I18n.FUNC_ON_DISARM;
    }

    @Override
    public int maxTime() {
        return 2 * 20;
    }

    @Override
    public int tick(class_1799 stack, class_1937 level, class_1309 user, int ticks, int ticksLeft) {
        if (!canActivate(ticks)) return 1;

        class_239 hitResult = SonicCrystal.SonicFunction.getHitResult(user);

        if (hitResult instanceof class_3966 entityHitResult) {
            if (!(user instanceof class_1657)) return SonicCrystal.SonicFunction.HALT;

            class_1297 entity = entityHitResult.method_17782();
            if (!(entity instanceof class_1309 livingEntity)) return SonicCrystal.SonicFunction.HALT;

            class_1799 droppedStack = livingEntity.method_6047().method_7972();
            if (droppedStack.method_7960()) return SonicCrystal.SonicFunction.HALT;

            livingEntity.method_5673(class_1304.field_6173, class_1799.field_8037);

            class_1542 itemEntity = new class_1542(
                    level,
                    livingEntity.method_23317(), livingEntity.method_23318() + livingEntity.method_17682() / 2, livingEntity.method_23321(),
                    droppedStack
            );

            class_243 lookDir = livingEntity.method_5720();
            itemEntity.method_18800(lookDir.field_1352 * 0.2, 0.3, lookDir.field_1350 * 0.2);
            itemEntity.method_6982(40);
            level.method_8649(itemEntity);

            level.method_8396(null, livingEntity.method_24515(), class_3417.field_15075, class_3419.field_15248, 1.0F, 0.8F);

            if (level instanceof class_3218 serverLevel) {
                spawnDisarmEffect(serverLevel, livingEntity);
            }

            return SonicCrystal.SonicFunction.HALT;
        }

        return 1;
    }

    private static void spawnDisarmEffect(class_3218 level, class_1309 target) {
        double x = target.method_23317();
        double y = target.method_23318() + target.method_17682() / 2;
        double z = target.method_23321();

        class_5743 dust = new class_5743(GOLD, WHITE, 1.5f);

        level.method_14199(dust, x, y, z, 15, 0.4, 0.5, 0.4, 0.05);
        level.method_14199(class_2398.field_29644, x, y, z, 8, 0.3, 0.4, 0.3, 0.1);
    }

    private static boolean canActivate(int ticks) {
        return ticks >= 10;
    }
}
