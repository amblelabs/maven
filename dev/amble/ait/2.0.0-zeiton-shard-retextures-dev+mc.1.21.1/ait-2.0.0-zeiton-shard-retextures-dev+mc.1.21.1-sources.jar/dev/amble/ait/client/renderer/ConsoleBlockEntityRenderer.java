package dev.amble.ait.client.renderer;

import dev.amble.ait.client.model.ConsoleGeoModel;
import dev.amble.ait.common.blocks.ConsoleBlock;
import dev.amble.ait.common.blocks.ConsoleBlockEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class ConsoleBlockEntityRenderer extends GeoBlockRenderer<ConsoleBlockEntity> {

    public ConsoleBlockEntityRenderer(class_5614.class_5615 ignoredContext) {
        super(new ConsoleGeoModel());
        addRenderLayer(new ConsoleEmissiveLayer(this));
    }

    @Override
    protected void rotateBlock(class_2350 facing, class_4587 poseStack) {
        // No-op: we handle rotation via ROTATION blockstate in preRender
    }

    @Override
    public class_1921 getRenderType(ConsoleBlockEntity entity, class_2960 texture,
                                    @Nullable class_4597 bufferSource, float partialTick) {
        return AITRenderLayers.consoleCutoutNoCullZOffset(texture);
    }

    @Override
    public void preRender(class_4587 poseStack, ConsoleBlockEntity entity, BakedGeoModel model,
                          @Nullable class_4597 bufferSource, @Nullable class_4588 buffer,
                          boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                          int colour) {
        if (!isReRender) {
            int rotation = entity.method_11010().method_11654(ConsoleBlock.ROTATION);
            boolean onSlab = entity.isOnSlab();
            boolean between = entity.isBetween();
            int betweenCorner = entity.method_11010().method_11654(ConsoleBlock.BETWEEN_CORNER);

            double xOff = 0.5;
            double yOff = onSlab ? -0.5 : 0;
            double zOff = 0.5;

            if (between) {
                double[][] offsets = ConsoleBlock.BETWEEN_OFFSETS;
                xOff += offsets[betweenCorner][0];
                zOff += offsets[betweenCorner][1];
            }

            poseStack.method_22904(xOff, yOff, zOff);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation * -45f));
        }
    }
}

