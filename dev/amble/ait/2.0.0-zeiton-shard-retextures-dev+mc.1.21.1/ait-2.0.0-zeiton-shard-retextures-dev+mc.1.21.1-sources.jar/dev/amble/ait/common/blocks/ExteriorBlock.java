package dev.amble.ait.common.blocks;

import com.mojang.serialization.MapCodec;
import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.event.block.ExteriorInteractionEvents;
import dev.amble.ait.common.entities.FallingTardisBlockEntity;
import dev.amble.ait.common.impl.tardis.state.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2482;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2771;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4208;
import net.minecraft.class_5819;
import net.minecraft.class_9062;
import org.jetbrains.annotations.Nullable;

public class ExteriorBlock extends class_2237 {

    public static final class_2758 ROTATION = class_2758.method_11867("rotation", 0, 7);
    public static final class_2758 TEXTURE = class_2758.method_11867("texture", 0, 4);
    public static final class_2758 LIGHT = class_2758.method_11867("light", 0, 7);
    public static final class_2746 ON_SLAB = class_2746.method_11825("on_slab");
    public static final MapCodec<ExteriorBlock> CODEC = method_54094(ExteriorBlock::new);

    // ── Cardinal shapes ──────────────────────────────────────────────────────
    // Each shape is 16 wide × 32 tall (≈2 blocks) × 12 deep, with a 1 px high
    // ledge covering the front 4 px strip.
    // Convention: ROTATION 0 = player placed while facing South → front = south (+Z).

    /** R0 – front faces south (+Z): body backs against north, ledge at south. */
    private static final class_265 SHAPE_R0 = class_259.method_1084(
            class_2248.method_9541(0, 0,  0, 16, 32, 12),   // main body (back 12 px)
            class_2248.method_9541(0, 0, 12, 16,  1, 16));   // front ledge (1 px high, 4 px deep)

    /** R2 – front faces west (−X): body backs against east, ledge at west. */
    private static final class_265 SHAPE_R2 = class_259.method_1084(
            class_2248.method_9541( 4, 0, 0, 16, 32, 16),
            class_2248.method_9541( 0, 0, 0,  4,  1, 16));

    /** R4 – front faces north (−Z): body backs against south, ledge at north. */
    private static final class_265 SHAPE_R4 = class_259.method_1084(
            class_2248.method_9541(0, 0, 4, 16, 32, 16),
            class_2248.method_9541(0, 0, 0, 16,  1,  4));

    /** R6 – front faces east (+X): body backs against west, ledge at east. */
    private static final class_265 SHAPE_R6 = class_259.method_1084(
            class_2248.method_9541(0, 0, 0, 12, 32, 16),
            class_2248.method_9541(12, 0, 0, 16,  1, 16));

    // ── Diagonal shapes (approximated) ───────────────────────────────────────
    // Each diagonal is the union of the two adjacent cardinal bodies, leaving
    // just the opposite corner open as a 1 px ledge.

    /** R1 – front faces SW (back = NE corner). */
    private static final class_265 SHAPE_R1 = class_259.method_1084(
            class_259.method_1084(
                    class_2248.method_9541(0, 0,  0, 16, 32, 12),   // R0 body
                    class_2248.method_9541(4, 0, 12, 16, 32, 16)),  // R2 body extension (NE fill)
            class_2248.method_9541(0, 0, 12,  4,  1, 16));          // SW ledge

    /** R3 – front faces NW (back = SE corner). */
    private static final class_265 SHAPE_R3 = class_259.method_1084(
            class_259.method_1084(
                    class_2248.method_9541(4, 0, 0, 16, 32, 16),    // R2 body
                    class_2248.method_9541(0, 0, 4,  4, 32, 16)),   // R4 body extension (SE fill)
            class_2248.method_9541(0, 0, 0,  4,  1,  4));           // NW ledge

    /** R5 – front faces NE (back = SW corner). */
    private static final class_265 SHAPE_R5 = class_259.method_1084(
            class_259.method_1084(
                    class_2248.method_9541( 0, 0, 4, 16, 32, 16),   // R4 body
                    class_2248.method_9541( 0, 0, 0, 12, 32,  4)),  // R6 body extension (SW fill)
            class_2248.method_9541(12, 0, 0, 16,  1,  4));          // NE ledge

    /** R7 – front faces SE (back = NW corner). */
    private static final class_265 SHAPE_R7 = class_259.method_1084(
            class_259.method_1084(
                    class_2248.method_9541( 0, 0,  0, 12, 32, 16),  // R6 body
                    class_2248.method_9541(12, 0,  0, 16, 32, 12)), // R0 body extension (NW fill)
            class_2248.method_9541(12, 0, 12, 16,  1, 16));         // SE ledge

    // ── Lookup arrays ─────────────────────────────────────────────────────────

    private static final class_265[] SHAPES = {
            SHAPE_R0, SHAPE_R1, SHAPE_R2, SHAPE_R3,
            SHAPE_R4, SHAPE_R5, SHAPE_R6, SHAPE_R7
    };

    /** Slab variants: each shape shifted 0.5 blocks down so the box sits on the slab's top surface. */
    private static final class_265[] SLAB_SHAPES;

    static {
        SLAB_SHAPES = new class_265[8];
        for (int i = 0; i < 8; i++) {
            SLAB_SHAPES[i] = SHAPES[i].method_1096(0, -0.5, 0);
        }
    }

    public ExteriorBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664()
                .method_11657(ROTATION, 0)
                .method_11657(TEXTURE, 0)
                .method_11657(LIGHT, 7)
                .method_11657(ON_SLAB, false));
    }

    public static class_2251 defaultProps() {
        return class_2251.method_9637()
                .method_31710(class_3620.field_15984)
                .method_9629(50f, 1200f)
                .method_22488()
                .method_9624()
                .method_9631(state -> state.method_11654(LIGHT));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ROTATION, TEXTURE, LIGHT, ON_SLAB);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        int rotation = class_3532.method_15375((context.method_8044()) / 45.0f + 0.5f) & 7;
        class_2338 below = context.method_8037().method_10074();
        class_2680 belowState = context.method_8045().method_8320(below);

        return this.method_9564()
                .method_11657(ROTATION, rotation)
                .method_11657(ON_SLAB, isSlabBottom(belowState));
    }

    private boolean isSlabBottom(class_2680 state) {
        if (state.method_26204() instanceof class_2482
                && state.method_28498(class_2741.field_12485)) {
            return state.method_11654(class_2741.field_12485) == class_2771.field_12681;
        }
        return false;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        // Geometry in SHAPES is defined 180 degrees opposite the renderer's base orientation.
        int rotation = (state.method_11654(ROTATION) + 4) & 7;
        return state.method_11654(ON_SLAB) ? SLAB_SHAPES[rotation] : SHAPES[rotation];
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ExteriorBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11456;
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos,
                                              class_1657 player, class_1268 hand, class_3965 hit) {
        if (!(level.method_8321(pos) instanceof ExteriorBlockEntity policeBox))
            return class_9062.field_47731;

        Tardis tardis = policeBox.tardis();
        if (tardis == null) return class_9062.field_47731;

        ExteriorInteractionEvents.useWithItem(tardis, stack, state, level, pos, player, hand, hit);
        return class_9062.field_47728;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!(level.method_8321(pos) instanceof ExteriorBlockEntity policeBox))
            return class_1269.field_21466;

        Tardis tardis = policeBox.tardis();
        if (tardis == null) return class_1269.field_21466;

        ExteriorInteractionEvents.useWithoutItem(tardis, state, level, pos, player, hit);
        return class_1269.field_21466;
    }

    @Override
    public void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        level.method_39279(pos, this, 2);
        if (level instanceof class_3218 serverLevel && level.method_8321(pos) instanceof ExteriorBlockEntity exterior) {
            Tardis tardis = exterior.tardis();
            if (tardis == null) return;
            ExteriorState exteriorState = tardis.state(ExteriorState.state);
            class_4208 globalPosition = class_4208.method_19443(level.method_27983(), pos);
            int rotation = state.method_11654(ROTATION);
            exteriorState.updateExteriorPos(globalPosition, rotation);
        }
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        super.method_9567(level, pos, state, placer, stack);

        if (level instanceof class_3218 serverLevel && level.method_8321(pos) instanceof ExteriorBlockEntity exterior) {

            // TODO: clean this up to be a single little thing for setting the location. - Loqor
            class_4208 globalPosition = class_4208.method_19443(level.method_27983(), pos);
            int rotation = state.method_11654(ROTATION);
            ExteriorState exteriorState = new ExteriorState(globalPosition, rotation);
            TravelState travelState = new TravelState(globalPosition, rotation, globalPosition, rotation);

            ServerTardis tardis = ServerTardis.create(serverLevel, new DoorState(), new DimensionState(), new DesktopState(), exteriorState, travelState);

            exterior.link(tardis);
        }
    }

    @Override
    protected void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_2338 neighborPos, boolean movedByPiston) {
        level.method_39279(pos, this, 2);
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (canFallThrough(level.method_8320(pos.method_10074())) && pos.method_10264() >= level.method_31607()) {
            FallingTardisBlockEntity.fall(level, pos, state);
        }
    }

    @Override
    protected void method_9548(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity) {
        super.method_9548(state, level, pos, entity);

        if (level.method_8321(pos) instanceof ExteriorBlockEntity exterior) {
            Tardis tardis = exterior.tardis();
            if (tardis == null) return;

            ExteriorInteractionEvents.entityInside(tardis, level, state, pos, entity);
        }
    }

    private static boolean canFallThrough(class_2680 state) {
        return state.method_26215() || state.method_45474();
    }
}
