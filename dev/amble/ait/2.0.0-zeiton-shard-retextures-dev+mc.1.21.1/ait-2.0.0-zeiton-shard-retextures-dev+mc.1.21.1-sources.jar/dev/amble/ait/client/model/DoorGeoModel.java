package dev.amble.ait.client.model;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.blocks.DoorBlockEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class DoorGeoModel extends GeoModel<DoorBlockEntity> {

    @SuppressWarnings("removal")
    @Override
    public class_2960 getModelResource(DoorBlockEntity entity) {
        return AitAPI.modLoc("geo/blockentities/" + entity.getModelName() + "_door.geo.json");
    }

    @SuppressWarnings("removal")
    @Override
    public class_2960 getTextureResource(DoorBlockEntity entity) {
        return AitAPI.modLoc("textures/blockentities/exteriors/" + entity.getTextureName() + ".png");
    }

    @Override
    public class_2960 getAnimationResource(DoorBlockEntity entity) {
        return AitAPI.modLoc("animations/blockentities/" + entity.getModelName() + "_door.animation.json");
    }
}

