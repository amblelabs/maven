package dev.amble.ait.common.lib.tardis;

import dev.amble.ait.api.tardis.ars.RoomPrototype;
import dev.amble.ait.xplat.IXplatAbstractions;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_238;
import net.minecraft.class_2960;

public class AitRoomPrototypes {
    public static final class_2378<RoomPrototype> REGISTRY = IXplatAbstractions.INSTANCE.getRoomRegistry();
    private static final Map<class_2960, RoomPrototype> TYPES = new LinkedHashMap<>();

    // Here to prevent null crashes :al_clueless - Loqor
    public static final RoomPrototype DEFAULT = type(new RoomPrototype.Builder()
            .id("default")
            .doorPos(new class_2338(0, 0, 0))
            .doorRotation(0)
            .size(new class_238(0, 0, 0, 0, 0, 0))
            .build()
    );

    public static final RoomPrototype COPPER = type(new RoomPrototype.Builder()
            .id("copper")
            .doorPos(new class_2338(28, 5, 9))
            .doorRotation(0)
            .size(new class_238(0, 0, 0, 48, 48, 48))
            .build()
    );

    public static final RoomPrototype PROGRESS = type(new RoomPrototype.Builder()
            .id("progress")
            .doorPos(new class_2338(4, 3, 27))
            .doorRotation(4)
            .size(new class_238(0, 0, 0, 48, 48, 48))
            .build()
    );

    public static final RoomPrototype CORAL = type(new RoomPrototype.Builder()
            .id("coral")
            .doorPos(new class_2338(15, 4, 26))
            .doorRotation(4)
            .size(new class_238(0, 0, 0, 48, 48, 48))
            .build()
    );

    public static void registerRooms(BiConsumer<RoomPrototype, class_2960> r) {
        for (var e : TYPES.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static RoomPrototype type(RoomPrototype proto) {
        var old = TYPES.put(proto.id(), proto);
        if (old != null) {
            throw new IllegalArgumentException("Duplicate room prototype id/resource location: " + proto.id());
        }
        return proto;
    }

}

