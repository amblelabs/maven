package dev.amble.ait.common.components;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import dev.amble.ait.common.items.ItemSonic;
import org.apache.commons.lang3.math.Fraction;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_5632;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SonicCrystals(List<class_1799> items, Fraction weight) implements class_5632 {
    
    public static final Codec<SonicCrystals> CODEC = class_1799.field_24671.listOf().xmap(SonicCrystals::new, SonicCrystals::items);
    public static final class_9139<class_9129, SonicCrystals> STREAM_CODEC = class_1799.field_48349.method_56433(class_9135.method_56363()).method_56432(SonicCrystals::new, SonicCrystals::items);

    public static final SonicCrystals EMPTY = new SonicCrystals(List.of());

    private static final Fraction WEIGHT = Fraction.getFraction(1, ItemSonic.TOOLTIP_MAX_WEIGHT);

    public SonicCrystals(List<class_1799> list) {
        this(list, computeContentWeight(list));
    }

    private static Fraction computeContentWeight(List<class_1799> list) {
        Fraction fraction = Fraction.ZERO;

        for(class_1799 itemstack : list) {
            fraction = fraction.add(WEIGHT.multiplyBy(Fraction.getFraction(itemstack.method_7947(), 1)));
        }

        return fraction;
    }

    public class_1799 getItemUnsafe(int i) {
        return this.items.get(i);
    }

    public @Nullable class_1799 getItem(int i) {
        if (i < 0 || i >= this.items.size())
            return null;

        return getItemUnsafe(i);
    }

    public Iterable<class_1799> itemsCopy() {
        return Lists.transform(this.items, class_1799::method_7972);
    }

    public int size() {
        return this.items.size();
    }

    public Fraction weight() {
        return this.weight;
    }

    public boolean isEmpty() {
        return this.items.isEmpty();
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean equals(Object object) {
        if (this == object) return true;

        if (object instanceof SonicCrystals(List<class_1799> items1, Fraction weight1))
            return this.weight.equals(weight1) && class_1799.method_57362(this.items, items1);

        return false;
    }

    @Override
    @SuppressWarnings("deprecation")
    public int hashCode() {
        return class_1799.method_57361(this.items);
    }

    @Override
    public String toString() {
        return "SonicCrystals" + this.items;
    }

    public static class Mutable {
        private final List<class_1799> items;
        private Fraction weight;

        public Mutable(SonicCrystals arg) {
            this.items = new ArrayList<>(arg.items);
            this.weight = arg.weight;
        }

        public SonicCrystals.Mutable clearItems() {
            this.items.clear();
            this.weight = Fraction.ZERO;
            return this;
        }

        private int getMaxAmountToAdd() {
            Fraction fraction = Fraction.ONE.subtract(this.weight);
            return Math.max(fraction.divideBy(WEIGHT).intValue(), 0);
        }

        public int tryInsert(class_1799 arg) {
            if (arg.method_7960() || !arg.method_7909().method_31568())
                return 0;

            int i = Math.min(arg.method_7947(), this.getMaxAmountToAdd());

            if (i == 0) {
                return 0;
            } else {
                this.weight = this.weight.add(WEIGHT.multiplyBy(Fraction.getFraction(i, 1)));
                this.items.addFirst(arg.method_7971(i));

                return i;
            }
        }

        public int tryTransfer(class_1735 arg, class_1657 arg2) {
            class_1799 itemstack = arg.method_7677();
            int i = this.getMaxAmountToAdd();
            return this.tryInsert(arg.method_32753(itemstack.method_7947(), i, arg2));
        }

        @Nullable
        public class_1799 removeOne() {
            if (this.items.isEmpty())
                return null;

            class_1799 itemstack = this.items.removeFirst().method_7972();
            this.weight = this.weight.subtract(WEIGHT.multiplyBy(Fraction.getFraction(itemstack.method_7947(), 1)));

            return itemstack;
        }

        public Fraction weight() {
            return this.weight;
        }

        public SonicCrystals toImmutable() {
            return new SonicCrystals(List.copyOf(this.items), this.weight);
        }
    }
}
