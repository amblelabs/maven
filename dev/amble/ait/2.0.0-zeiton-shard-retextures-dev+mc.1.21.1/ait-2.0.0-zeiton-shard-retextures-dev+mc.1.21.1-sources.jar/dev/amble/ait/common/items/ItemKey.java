package dev.amble.ait.common.items;

import net.minecraft.class_1792;

public class ItemKey extends class_1792 {
    public ItemKey(class_1793 properties) {
        super(properties);
    }
}
