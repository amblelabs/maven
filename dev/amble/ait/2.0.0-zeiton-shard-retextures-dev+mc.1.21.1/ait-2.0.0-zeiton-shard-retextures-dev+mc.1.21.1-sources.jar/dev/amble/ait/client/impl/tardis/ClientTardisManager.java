package dev.amble.ait.client.impl.tardis;

import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.TardisManager;
import dev.amble.ait.api.tardis.event.init.TardisLifecycleEvents;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jspecify.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_2487;
import net.minecraft.class_638;

public class ClientTardisManager implements TardisManager<Tardis> {

    private static @Nullable ClientTardisManager INSTANCE;

    private final Object2ObjectMap<UUID, Tardis> lookup = new Object2ObjectOpenHashMap<>();

    public ClientTardisManager() {
        if (INSTANCE != null)
            INSTANCE.clear();

        INSTANCE = this;
    }

    public void tick() {
        for (Tardis stargate : this.lookup.values()) {
            stargate.tick();
        }
    }

    @Override
    public void add(Tardis tardis) {
        this.lookup.put(tardis.id(), tardis);
    }

    public void upsert(class_2487 tag) {
        UUID id = tag.method_25926(Tardis.ID_TAG);
        Tardis tardis = this.get(id);

        if (tardis == null) {
            tardis = Tardis.fromNbt(tag, true);
            this.add(tardis);

            TardisLifecycleEvents.handleLoaded(this, tardis);
        } else {
            tardis.updateStates(tag, true, false);
        }
    }

    @Override
    public void remove(UUID id) {
        this.lookup.remove(id);
    }

    @Override
    public boolean contains(UUID id) {
        return lookup.containsKey(id);
    }

    @Override
    public @Nullable Tardis get(UUID id) {
        return lookup.get(id);
    }

    private void clear() {
        this.lookup.clear();
    }

    public static @Nullable ClientTardisManager get(class_638 level) {
        return (ClientTardisManager) TardisManager.asManagerLevel(level).ait$getTardisManager();
    }
}