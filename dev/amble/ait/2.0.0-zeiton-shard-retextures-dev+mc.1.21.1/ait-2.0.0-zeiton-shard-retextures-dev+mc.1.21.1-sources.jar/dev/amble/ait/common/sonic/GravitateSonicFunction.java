package dev.amble.ait.common.sonic;

import dev.amble.ait.api.mod.sonic.SonicCrystal;
import dev.amble.ait.common.I18n;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3966;

public class GravitateSonicFunction implements SonicCrystal.SonicFunction {
    @Override
    public class_1799 preview() {
        return new class_1799(class_1802.field_27063);
    }

    @Override
    public class_2561 name() {
        return I18n.FUNC_ON_GRAVITATE;
    }

    @Override
    public int maxTime() {
        return 2 * 20; // 2 seconds
    }

    @Override
    public int tick(class_1799 stack, class_1937 level, class_1309 user, int ticks, int ticksLeft) {
        if (canActivate(ticks)) {
            class_239 hitResult = SonicCrystal.SonicFunction.getHitResult(user);

            System.out.println(hitResult);


            if (hitResult instanceof class_3966 entityHitResult) {
                if (!(user instanceof class_1657 player)) return SonicCrystal.SonicFunction.HALT;
                class_1309 target = (class_1309) entityHitResult.method_17782();
                target.method_26082(new class_1293(class_1294.field_5902, 200), player);
                level.method_8396(null, target.method_24515(), class_3417.field_26980, class_3419.field_15248, 1.0F, 2.0F);
                return SonicCrystal.SonicFunction.HALT;
            }
        }

        return 1;
    }

    private static boolean canActivate(int ticks) {
        return ticks >= 10;
    }
}
