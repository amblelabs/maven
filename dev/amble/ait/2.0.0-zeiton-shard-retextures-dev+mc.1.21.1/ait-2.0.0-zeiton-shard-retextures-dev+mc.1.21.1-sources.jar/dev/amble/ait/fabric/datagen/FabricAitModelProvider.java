package dev.amble.ait.fabric.datagen;

import dev.amble.ait.common.lib.AitBlocks;
import dev.amble.ait.common.lib.AitItems;
import dev.amble.lib.fabric.datagen.FabricAmbleModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;

public class FabricAitModelProvider extends FabricAmbleModelProvider {

    public FabricAitModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 gen) {
        // will use later
    }

    @Override
    public void generateItemModels(class_4915 gen) {
        gen.method_25733(AitItems.SCREWDRIVER, class_4943.field_22940);

        // Police box item
        gen.method_25733(AitBlocks.EXTERIOR_BLOCK.method_8389(), class_4943.field_22938);

        // Zeiton shards
        gen.method_25733(AitItems.SHARD_AMETHYST, class_4943.field_22938);
        gen.method_25733(AitItems.SHARD_BASIC, class_4943.field_22938);
        gen.method_25733(AitItems.SHARD_GRAVITY, class_4943.field_22938);
        gen.method_25733(AitItems.SHARD_OVERCHARGED, class_4943.field_22938);
        gen.method_25733(AitItems.SHARD_QUARTZ, class_4943.field_22938);
        gen.method_25733(AitItems.SHARD_REFRACTION, class_4943.field_22938);
        gen.method_25733(AitItems.SHARD_RESONATING, class_4943.field_22938);
        gen.method_25733(AitItems.SHARD_SCULK, class_4943.field_22938);

        // Keys
        gen.method_25733(AitItems.IRON_KEY, class_4943.field_22940);
        gen.method_25733(AitItems.GOLD_KEY, class_4943.field_22940);
        gen.method_25733(AitItems.NETHERITE_KEY, class_4943.field_22940);
        gen.method_25733(AitItems.CLASSIC_KEY, class_4943.field_22940);
        gen.method_25733(AitItems.KEY_CHAIN, class_4943.field_22938);

        // Tardis components
        gen.method_25733(AitItems.LIGHTBULB, class_4943.field_22938);
    }
}
