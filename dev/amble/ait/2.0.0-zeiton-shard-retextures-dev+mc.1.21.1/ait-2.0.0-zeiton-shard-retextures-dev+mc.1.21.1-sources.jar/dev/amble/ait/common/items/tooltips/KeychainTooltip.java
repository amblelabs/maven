package dev.amble.ait.common.items.tooltips;

import dev.amble.ait.common.items.ItemKeychain;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_5632;

public record KeychainTooltip(ItemKeychain.KeychainContents contents) implements class_5632 {
    public List<class_1799> items() {
        return contents.itemsCopy();
    }

    public int size() {
        return contents.size();
    }
}