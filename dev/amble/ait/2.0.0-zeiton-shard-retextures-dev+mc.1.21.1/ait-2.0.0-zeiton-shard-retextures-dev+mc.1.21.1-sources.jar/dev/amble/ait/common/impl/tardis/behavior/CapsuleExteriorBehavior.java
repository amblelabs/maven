package dev.amble.ait.common.impl.tardis.behavior;

import dev.amble.ait.api.tardis.Tardis;
import dev.amble.ait.api.tardis.event.block.ExteriorInteractionEvents;
import dev.amble.ait.api.util.TeleportUtil;
import dev.amble.ait.common.impl.tardis.state.DesktopState;
import dev.amble.ait.common.impl.tardis.state.DimensionState;
import dev.amble.ait.common.impl.tardis.state.DoorState;
import dev.amble.ait.common.impl.tardis.state.ExteriorState;
import dev.amble.ait.common.lib.AitSounds;
import dev.drtheo.ecs.behavior.TBehavior;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

public class CapsuleExteriorBehavior implements TBehavior, ExteriorInteractionEvents {

    @Override
    public void exterior$useWithoutItem(Tardis tardis, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        openDoors(tardis, level, pos, player);
    }

    @Override
    public void exterior$useWithItem(Tardis tardis, class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        openDoors(tardis, level, pos, player);
    }

    @Override
    public void exterior$entityInside(Tardis tardis, class_1937 level, class_2680 state, class_2338 blockPos, class_1297 entity) {
        DimensionState dim = tardis.state(DimensionState.state);
        DesktopState desktopState = tardis.state(DesktopState.state);

        DoorState doorState = tardis.state(DoorState.state);

        if (doorState.closed()) return;

        class_2338 bPos = desktopState.doorPos;
        int rot = desktopState.doorRot;

        if (bPos == null) {
            bPos = new class_2338(0, 64, 0);
        }

        TeleportUtil.teleportWithOffset(entity, dim.level.get(), bPos, rot);
    }

    public static void openDoors(Tardis tardis, class_1937 level, class_2338 pos, class_1657 player) {
        if (level.field_9236) {
            return;
        }

        DoorState door = tardis.state(DoorState.state);

        // temporary until I implement proper interaction permissions - Loqor
        boolean canInteractWith = tardis.hasState(DesktopState.state) &&
                tardis.hasState(ExteriorState.state);

        if (!canInteractWith) {
            player.method_7353(class_2561.method_43470("\uD83D\uDD12"), true);
            level.method_8396(null, pos, AitSounds.KNOCK, class_3419.field_15245, 1,
                    0.01f);
            return;
        }

        if (door.closed()) { // closed
            door.rightOpen = true;

            if (player.method_5715()) {
                door.leftOpen = true;
            }

            level.method_8396(null, pos, AitSounds.DOOR_OPEN, class_3419.field_15245, 0.5f, 1.0f);
        } else if (door.rightOpen && !door.leftOpen) { // only right open
            if (player.method_5715()) {
                door.rightOpen = false; // if sneaking, close the only open door (right)
            } else {
                door.leftOpen = true; // otherwise, open the other door
            }

            level.method_8396(null, pos, AitSounds.DOOR_OPEN, class_3419.field_15245, 0.5f, 1.0f);
        } else { // both open
            door.rightOpen = false;
            door.leftOpen = false;

            level.method_8396(null, pos, AitSounds.DOOR_CLOSE, class_3419.field_15245, 0.6f, 1.0f);
        }

        tardis.markDirty();
    }
}
