package dev.amble.ait.client.renderer;

import dev.amble.ait.common.components.SonicCrystals;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_5684;
import org.apache.commons.lang3.math.Fraction;

@Environment(EnvType.CLIENT)
public class ClientSonicTooltip implements class_5684 {

	private static final class_2960 BACKGROUND_SPRITE = class_2960.method_60656("container/bundle/background");

	private static final int MARGIN_Y = 4;
	private static final int BORDER_WIDTH = 1;
	private static final int SLOT_SIZE_X = 18;
	private static final int SLOT_SIZE_Y = 20;

	private final SonicCrystals contents;

	public ClientSonicTooltip(SonicCrystals bundleContents) {
		this.contents = bundleContents;
	}

	@Override
	public int method_32661() {
		return this.backgroundHeight() + MARGIN_Y;
	}

	@Override
	public int method_32664(class_327 font) {
		return this.backgroundWidth();
	}

	private int backgroundWidth() {
		return this.gridSizeX() * SLOT_SIZE_X + BORDER_WIDTH * 2;
	}

	private int backgroundHeight() {
		return this.gridSizeY() * SLOT_SIZE_Y + BORDER_WIDTH * 2;
	}

	@Override
	public void method_32666(class_327 font, int i, int j, class_332 guiGraphics) {
		int k = this.gridSizeX();
		int l = this.gridSizeY();
		guiGraphics.method_52706(BACKGROUND_SPRITE, i, j, this.backgroundWidth(), this.backgroundHeight());
		boolean bl = this.contents.weight().compareTo(Fraction.ONE) >= 0;
		int m = 0;

		for (int n = 0; n < l; n++) {
			for (int o = 0; o < k; o++) {
				int p = i + o * SLOT_SIZE_X + BORDER_WIDTH;
				int q = j + n * SLOT_SIZE_Y + BORDER_WIDTH;
				this.renderSlot(p, q, m++, bl, guiGraphics, font);
			}
		}
	}

	private void renderSlot(int i, int j, int k, boolean bl, class_332 guiGraphics, class_327 font) {
		if (k >= this.contents.size()) {
			this.blit(guiGraphics, i, j, bl ? ClientSonicTooltip.Texture.BLOCKED_SLOT : ClientSonicTooltip.Texture.SLOT);
		} else {
			class_1799 itemStack = this.contents.getItemUnsafe(k);
			this.blit(guiGraphics, i, j, ClientSonicTooltip.Texture.SLOT);
			guiGraphics.method_51428(itemStack, i + BORDER_WIDTH, j + BORDER_WIDTH, k);
			guiGraphics.method_51431(font, itemStack, i + BORDER_WIDTH, j + BORDER_WIDTH);
			if (k == 0) {
				class_465.method_33285(guiGraphics, i + BORDER_WIDTH, j + BORDER_WIDTH, 0);
			}
		}
	}

	private void blit(class_332 guiGraphics, int i, int j, ClientSonicTooltip.Texture texture) {
		guiGraphics.method_52707(texture.sprite, i, j, 0, texture.w, texture.h);
	}

	private int gridSizeX() {
		return Math.max(2, (int)Math.ceil(Math.sqrt(this.contents.size() + (float) BORDER_WIDTH)));
	}

	private int gridSizeY() {
		return (int)Math.ceil((this.contents.size() + (float) BORDER_WIDTH) / this.gridSizeX());
	}

	@Environment(EnvType.CLIENT)
	enum Texture {
		BLOCKED_SLOT(class_2960.method_60656("container/bundle/blocked_slot"), 18, 20),
		SLOT(class_2960.method_60656("container/bundle/slot"), 18, 20);

		public final class_2960 sprite;
		public final int w;
		public final int h;

		@SuppressWarnings("SameParameterValue")
        Texture(final class_2960 resourceLocation, final int j, final int k) {
			this.sprite = resourceLocation;
			this.w = j;
			this.h = k;
		}
	}
}
