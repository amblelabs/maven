package dev.amble.ait.common.impl.tardis.state;

import dev.amble.ait.api.AitAPI;
import dev.drtheo.ecs.state.NbtSerializer;
import dev.drtheo.ecs.state.TState;
import net.minecraft.class_2487;

public class DematState implements TState<DematState>, NbtSerializer {

    public int dematTimerTicks = -1;
    public static final int DEMAT_TIME = 14 * 20;

    public static final TState.Type<DematState> state = new TState.NbtBacked<>(AitAPI.modLoc("demat"), 0) {
        @Override
        public DematState fromNbt(class_2487 nbt, boolean isClient) {
            DematState dematState = new DematState();

            dematState.dematTimerTicks = nbt.method_10550("DematTimerTicks");

            return dematState;
        }
    };

    @Override
    public void toNbt(class_2487 nbt, boolean isClient) {
        nbt.method_10569("DematTimerTicks", dematTimerTicks);
    }

    @Override
    public TState.Type<DematState> type() {
        return state;
    }
}