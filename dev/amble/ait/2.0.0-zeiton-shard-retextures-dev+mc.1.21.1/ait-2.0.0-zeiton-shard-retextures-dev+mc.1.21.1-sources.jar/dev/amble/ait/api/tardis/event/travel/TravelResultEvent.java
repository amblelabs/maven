package dev.amble.ait.api.tardis.event.travel;

import dev.drtheo.ecs.event.TEvent;
import dev.drtheo.ecs.event.TEvents;

import java.util.function.Function;

public class TravelResultEvent implements TEvent.Result<TardisTravelEvents, Boolean> {

    private boolean result = true;
    private final Function<TardisTravelEvents, Boolean> invoker;

    public TravelResultEvent(Function<TardisTravelEvents, Boolean> invoker) {
        this.invoker = invoker;
    }

    @Override
    public void handleAll(Iterable<TardisTravelEvents> subscribed) {
        boolean ok = true;

        for (TardisTravelEvents e : subscribed) {
            ok = TEvent.handleSilent(this, e, () -> invoker.apply(e), false);

            // Stop calling others once cancelled/failed. Idk if this is useful or not for the behavior. - Loqor
            if (!ok) break;
        }

        this.result = ok;
    }

    @Override
    public Boolean result() {
        return result;
    }

    @Override
    public TEvents.BaseType<TardisTravelEvents> type() {
        return TardisTravelEvents.event;
    }
}