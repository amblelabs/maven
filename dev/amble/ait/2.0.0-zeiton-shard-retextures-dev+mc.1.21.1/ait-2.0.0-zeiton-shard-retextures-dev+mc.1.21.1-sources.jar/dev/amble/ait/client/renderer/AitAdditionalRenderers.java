package dev.amble.ait.client.renderer;

import dev.amble.ait.common.I18n;
import dev.amble.ait.common.lib.AitItems;
import dev.amble.ait.xplat.IXplatAbstractions;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class AitAdditionalRenderers {

    private static final class_1799 ITEM_ICON = new class_1799(AitItems.SHARD_GRAVITY);

    @SuppressWarnings("unused")
    public static void overlayGui(class_332 graphics, class_9779 deltaTracker) {
        class_310 minecraft = class_310.method_1551();

        if (!minecraft.field_1690.field_1842 && IXplatAbstractions.INSTANCE.isUnstable()) {
            class_327 font = class_310.method_1551().field_1772;
            graphics.method_60649(font, I18n.OVERLAY_UNSTABLE, 16 + 4 + 2, 8, 1, 0xffffff);
            graphics.method_51445(ITEM_ICON, 4, 4);
        }
    }
}
