package dev.amble.ait.api.mod;

import static dev.amble.ait.api.AitAPI.modLoc;

import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class AitTags {
    public static final class Items {

        public static final class_6862<class_1792> ZEITON_SHARDS = create("zeiton_shards");
        public static final class_6862<class_1792> KEYS = create("keys");

        public static class_6862<class_1792> create(String name) {
            return create(modLoc(name));
        }

        public static class_6862<class_1792> create(class_2960 id) {
            return class_6862.method_40092(class_7924.field_41197, id);
        }
    }

    public static final class Blocks {

        @SuppressWarnings("unused")
        public static class_6862<class_2248> create(String name) {
            return class_6862.method_40092(class_7924.field_41254, modLoc(name));
        }
    }

    public static final class Entities {

        @SuppressWarnings("unused")
        public static class_6862<class_1299<?>> create(String name) {
            return class_6862.method_40092(class_7924.field_41266, modLoc(name));
        }
    }
}