package dev.amble.ait.client.screen;

import dev.amble.ait.client.AitKeybinds;
import dev.amble.ait.client.screen.wheel.*;
import dev.amble.ait.client.screen.wheel.action.Action;
import dev.amble.ait.common.items.ItemCrystal;
import dev.amble.ait.common.items.ItemSonic;
import dev.amble.ait.common.components.SonicCrystals;
import dev.amble.ait.common.lib.AitComponents;
import dev.amble.ait.common.network.SonicFunctionPayload;
import dev.amble.ait.api.mod.sonic.SonicCrystal;
import dev.amble.ait.xplat.IClientXplatAbstractions;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_310;

/**
 * @author drtheodor
 * From hex-spell-wheel
 */
public class SonicWheelScreen extends AbstractWheelScreen {

    // Outer ring radii
    public static final float OUTER_INNER_RADIUS = 55f;
    public static final float OUTER_OUTER_RADIUS = 90f;

    // Inner ring radii
    public static final float INNER_INNER_RADIUS = 15f;
    public static final float INNER_OUTER_RADIUS = 50f;

    private final WidgetSet outer;
    private final WidgetSet inner;

    public SonicWheelScreen(WidgetSet outer, WidgetSet inner) {
        this.outer = outer;
        this.inner = inner;
    }

    @Override
    protected void method_25426() {
        int cx = field_22789 / 2;
        int cy = field_22790 / 2;

        outer.forEach((slot, widget) -> {
            if (widget != null) method_37063(new WheelOptionWidget(
                cx, cy, OUTER_INNER_RADIUS, OUTER_OUTER_RADIUS, slot, widget, true));
        });

        inner.forEach((slot, widget) -> {
            if (widget != null) method_37063(new WheelOptionWidget(
                cx, cy, INNER_INNER_RADIUS, INNER_OUTER_RADIUS, slot, widget, true));
        });
    }

    @Override
    public boolean method_25404(int i, int j, int k) {
        if (AitKeybinds.SONIC_WHEEL.method_1417(i, j)) {
            this.method_25419();
            return true;
        }

        if (super.method_25404(i, j, k))
            return true;

        class_304[] hotbar = Objects.requireNonNull(field_22787).field_1690.field_1852;

        //noinspection ForLoopReplaceableByForEach - TODO: use index for quick keybinds
        for (int l = 0; l < hotbar.length; l++) {
            if (hotbar[l].method_1417(i, j)) {
//                this.simulateClick(l);
                return true;
            }
        }

        return false;
    }

    public static @Nullable AbstractWheelScreen tryCreate(class_1799 stack) {
        return tryCreate(stack, WidgetSet.create(new Widget[0]));
    }

    private static @Nullable AbstractWheelScreen tryCreate(class_1799 stack, WidgetSet outer) {
        SonicCrystals crystals = stack.method_57824(AitComponents.SONIC_CRYSTALS);
        if (crystals == null) return null;

        @Nullable Widget[] inner = new @Nullable Widget[] {
                null, // TOP_LEFT
                ListFunctionsAction.widget(stack, crystals, 0), // TOP
                null, // TOP_RIGHT

                ListFunctionsAction.widget(stack, crystals, 1), // LEFT
                ListFunctionsAction.widget(stack, crystals, 2), // RIGHT

                null, // BOTTOM_LEFT
                ListFunctionsAction.widget(stack, crystals, 3), // BOTTOM
                null, // BOTTOM_RIGHT
        };

        return new SonicWheelScreen(outer, WidgetSet.create(inner));
    }

    record ListFunctionsAction(class_1799 sonic, SonicCrystal crystal, int crystalIdx) implements Action {

        static Widget widget(class_1799 sonic, SonicCrystals crystals, int crystalIdx) {
            class_1799 crystalStack = crystals.getItem(crystalIdx);
            if (crystalStack == null) return Widget.empty();

            SonicCrystal crystal = ((ItemCrystal) crystalStack.method_7909()).getCrystal();
            return Widget.fromStack(crystalStack, new ListFunctionsAction(sonic, crystal, crystalIdx), true);
        }

        @Override
        public void run(class_310 client, Widget widget) {
            Widget[] outer = new Widget[8];

            int i = 0;
            for (SonicCrystal.SonicFunction function : crystal.functions()) {
                outer[i] = new Widget(function.name(), function.preview(), new SonicFunctionAction(sonic, crystalIdx * 8 + i), false);
                i++;
            }

            client.method_1507(SonicWheelScreen.tryCreate(sonic, WidgetSet.create(outer, Widget.empty())));
        }
    }

    record SonicFunctionAction(class_1799 sonic, int funcIdx) implements Action {

        @Override
        public void run(class_310 client, Widget widget) {
            IClientXplatAbstractions.INSTANCE.sendPacketToServer(new SonicFunctionPayload(funcIdx));
            ItemSonic.setFunction(sonic, funcIdx);
        }
    }
}