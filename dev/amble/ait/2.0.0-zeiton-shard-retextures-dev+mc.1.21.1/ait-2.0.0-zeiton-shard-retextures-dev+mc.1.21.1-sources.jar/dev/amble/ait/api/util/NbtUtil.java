package dev.amble.ait.api.util;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import net.minecraft.class_1937;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class NbtUtil {

    public static DataResult<class_5321<class_1937>> dimensionCodec(class_2520 tag) {
        Codec<class_5321<class_1937>> keyCodec = class_5321.method_39154(class_7924.field_41223);
        return keyCodec.parse(class_2509.field_11560, tag);
    }

}
