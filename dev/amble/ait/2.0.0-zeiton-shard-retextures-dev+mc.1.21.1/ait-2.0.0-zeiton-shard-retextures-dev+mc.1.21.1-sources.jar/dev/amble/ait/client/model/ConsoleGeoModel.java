package dev.amble.ait.client.model;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.common.blocks.ConsoleBlockEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class ConsoleGeoModel extends GeoModel<ConsoleBlockEntity> {

    @SuppressWarnings("removal")
    @Override
    public class_2960 getModelResource(ConsoleBlockEntity entity) {
        return AitAPI.modLoc("geo/blockentities/" + entity.getModelName() + ".geo.json");
    }

    @SuppressWarnings("removal")
    @Override
    public class_2960 getTextureResource(ConsoleBlockEntity entity) {
        return AitAPI.modLoc("textures/blockentities/consoles/" + entity.getTextureName() + ".png");
    }

    @Override
    public class_2960 getAnimationResource(ConsoleBlockEntity entity) {
        return AitAPI.modLoc("animations/blockentities/" + entity.getAnimationName() + ".animation.json");
    }
}

