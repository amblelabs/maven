package dev.amble.ait.common.impl.tardis.state;

import dev.amble.ait.api.AitAPI;
import dev.drtheo.ecs.state.NbtSerializer;
import dev.drtheo.ecs.state.TState;
import org.jspecify.annotations.Nullable;

import java.lang.ref.WeakReference;
import net.minecraft.class_2487;
import net.minecraft.class_3218;

public class DimensionState implements TState<DimensionState>, NbtSerializer {

    public static final Type<DimensionState> state = new NbtBacked<>(AitAPI.modLoc("dimension"), 0) {
        @Override
        public DimensionState fromNbt(class_2487 nbt, boolean isClient) {
            return new DimensionState();
        }

        @Override
        public @Nullable class_2487 encode(DimensionState state, boolean isClient) {
            // don't sync.
            if (isClient) return null;

            return super.encode(state, false);
        }
    };

    @SuppressWarnings("NotNullFieldNotInitialized") // we initialize it later in #onPostLoaded and #onLoaded
    public WeakReference<class_3218> level;

    @Override
    public Type<DimensionState> type() {
        return state;
    }

    @Override
    public void toNbt(class_2487 nbt, boolean isClient) { }
}
