package dev.amble.ait.common.entities;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2945;

public class ConsoleControlEntity extends class_1297 {
    public ConsoleControlEntity(class_1299<?> type, class_1937 level) {
        super(type, level);
    }

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        return super.method_5688(player, hand);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {

    }

    @Override
    protected void method_5749(class_2487 compound) {

    }

    @Override
    protected void method_5652(class_2487 compound) {

    }
}
