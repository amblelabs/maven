package dev.amble.ait.api.tardis.ars;

import dev.amble.ait.api.tardis.Tardis;
import java.util.Map;
import java.util.UUID;

public record ArsContext(Tardis tardis, Map<UUID, Room> rooms) {

    public Room getRoomById(UUID id) {
        return this.rooms.get(id);
    }
}
