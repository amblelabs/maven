@NullMarked
package dev.amble.ait.api.tardis.event.travel;

import org.jspecify.annotations.NullMarked;