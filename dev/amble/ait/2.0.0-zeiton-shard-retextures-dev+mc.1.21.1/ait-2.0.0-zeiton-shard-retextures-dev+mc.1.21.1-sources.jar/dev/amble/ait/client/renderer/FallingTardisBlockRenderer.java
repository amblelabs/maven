package dev.amble.ait.client.renderer;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.client.model.FallingTardisGeoModel;
import dev.amble.ait.common.entities.FallingTardisBlockEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

public class FallingTardisBlockRenderer extends GeoEntityRenderer<FallingTardisBlockEntity> {

    public FallingTardisBlockRenderer(class_5617.class_5618 context) {
        super(context, new FallingTardisGeoModel());
        addRenderLayer(new FallingTardisEmissiveLayer(this));
    }

    @Override
    protected void applyRotations(FallingTardisBlockEntity animatable, class_4587 poseStack,
                                  float ageInTicks, float rotationYaw, float partialTick, float nativeScale) {
        // No-op: skip the default 180° Y rotation from GeoEntityRenderer.
        // We handle rotation via the ROTATION blockstate in preRender instead.
    }

    @Override
    public class_1921 getRenderType(FallingTardisBlockEntity entity, class_2960 texture,
                                    @Nullable class_4597 bufferSource, float partialTick) {
        return AITRenderLayers.tardisTranslucent(texture);
    }

    @Override
    public void preRender(class_4587 poseStack, FallingTardisBlockEntity entity, BakedGeoModel model,
                          @Nullable class_4597 bufferSource, @Nullable class_4588 buffer,
                          boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                          int colour) {
        if (!isReRender) {
            int rotation = entity.getRotation();
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation * -45f));

            int doorState = entity.getDoorStateOrdinal();
            float rightY = (float) Math.toRadians(-77.5);
            float leftY = (float) Math.toRadians(77.5);

            setDoorBone(model, "door_r", doorState >= 1 ? rightY : 0);
            setDoorBone(model, "RDoor", doorState >= 1 ? rightY : 0);
            setDoorBone(model, "door_l", doorState >= 2 ? leftY : 0);
            setDoorBone(model, "LDoor", doorState >= 2 ? leftY : 0);
        }
    }

    @Override
    public void actuallyRender(class_4587 poseStack, FallingTardisBlockEntity entity, BakedGeoModel model,
                               @Nullable class_1921 renderType, class_4597 bufferSource, @Nullable class_4588 buffer,
                               boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                               int colour) {
        float alpha = entity.getAlpha();
        int packedColor = ((int) (alpha * 255) << 24) | 0xFFFFFF;

        if (alpha < 1.0f && bufferSource instanceof class_4597.class_4598 immediate) {
            class_2960 texture = getGeoModel().getTextureResource(entity, this);

            class_1921 depthType = AITRenderLayers.tardisDepth(texture);
            class_4588 depthConsumer = bufferSource.getBuffer(depthType);
            super.actuallyRender(poseStack, entity, model, depthType, bufferSource, depthConsumer,
                    isReRender, partialTick, packedLight, packedOverlay, 0xFFFFFFFF);
            immediate.method_22994(depthType);

            class_4588 frontConsumer = bufferSource.getBuffer(renderType);
            super.actuallyRender(poseStack, entity, model, renderType, bufferSource, frontConsumer,
                    isReRender, partialTick, packedLight, packedOverlay, packedColor);
            immediate.method_22994(renderType);
        } else {
            super.actuallyRender(poseStack, entity, model, renderType, bufferSource, buffer,
                    isReRender, partialTick, packedLight, packedOverlay, packedColor);
        }
    }

    private static void setDoorBone(BakedGeoModel model, String name, float rotY) {
        model.getBone(name).ifPresent(bone -> bone.setRotY(rotY));
    }

    private static class FallingTardisEmissiveLayer extends GeoRenderLayer<FallingTardisBlockEntity> {

        private static final int FULLBRIGHT = 0xF000F0;

        public FallingTardisEmissiveLayer(GeoRenderer<FallingTardisBlockEntity> renderer) {
            super(renderer);
        }

        @Override
        public void render(class_4587 poseStack, FallingTardisBlockEntity entity, BakedGeoModel bakedModel,
                           @Nullable class_1921 renderType, class_4597 bufferSource,
                           @Nullable class_4588 buffer, float partialTick, int packedLight, int packedOverlay) {
            class_2960 baseTexture = getGeoModel().getTextureResource(entity, getRenderer());
            String basePath = baseTexture.method_12832();
            String emissivePath = basePath.replace(".png", "_e.png");
            class_2960 emissiveTexture = AitAPI.modLoc(emissivePath);

            if (class_310.method_1551().method_1478().method_14486(emissiveTexture).isEmpty()) return;

            float alpha = entity.getAlpha();
            int packedColor = ((int) (alpha * 255) << 24) | 0xFFFFFF;

            class_1921 emissiveType = AITRenderLayers.tardisEmissiveCullZOffset(emissiveTexture, true);

            if (alpha < 1.0f && bufferSource instanceof class_4597.class_4598 immediate) {
                class_1921 depthType = AITRenderLayers.tardisDepth(emissiveTexture);
                class_4588 depthConsumer = bufferSource.getBuffer(depthType);
                for (GeoBone bone : bakedModel.topLevelBones()) {
                    getRenderer().renderRecursively(poseStack, entity, bone, depthType, bufferSource,
                            depthConsumer, true, partialTick, FULLBRIGHT, packedOverlay, 0xFFFFFFFF);
                }
                immediate.method_22994(depthType);

                class_4588 emissiveConsumer = bufferSource.getBuffer(emissiveType);
                for (GeoBone bone : bakedModel.topLevelBones()) {
                    getRenderer().renderRecursively(poseStack, entity, bone, emissiveType, bufferSource,
                            emissiveConsumer, true, partialTick, FULLBRIGHT, packedOverlay, packedColor);
                }
                immediate.method_22994(emissiveType);
            } else {
                class_4588 emissiveConsumer = bufferSource.getBuffer(emissiveType);
                for (GeoBone bone : bakedModel.topLevelBones()) {
                    getRenderer().renderRecursively(poseStack, entity, bone, emissiveType, bufferSource,
                            emissiveConsumer, true, partialTick, FULLBRIGHT, packedOverlay, packedColor);
                }
            }
        }
    }
}
