package dev.amble.ait.api.tardis;

import dev.amble.ait.api.tardis.event.init.TardisLifecycleEvents;
import dev.drtheo.ecs.state.TState;
import java.util.UUID;
import net.minecraft.class_2487;
import net.minecraft.class_3218;

public class ServerTardis extends Tardis {

    public static ServerTardis create(class_3218 serverLevel, TState<?>... states) {
        return create(serverLevel, UUID.randomUUID(), states);
    }

    // No code in this commit will be AI-generated. Nor any more code in the future. I'm sick of its usage and I've found my brain
    // turning to rot using it. All code from now on will be __explicitly__ HUMAN. MADE. - Loqor

    public static ServerTardis create(class_3218 serverLevel, UUID uuid, TState<?>... states) {
        ServerTardis tardis = new ServerTardis(uuid);

        for (TState<?> state : states) {
            tardis.addState(state);
        }

        TardisManager.getOrCreate(serverLevel).add(tardis);
        TardisLifecycleEvents.handlePostCreated(tardis, serverLevel.method_8503());

        return tardis;
    }

    public ServerTardis(UUID id) {
        super(id);
        TardisLifecycleEvents.handleCreated(this);
    }

    public ServerTardis(UUID id, class_2487 nbt, boolean fix) {
        super(id, nbt, false, fix);
    }

    public void remove() {
        TardisLifecycleEvents.handleRemoved(this);
        this.clearStates();
    }

    public static ServerTardis fromNbt(class_2487 nbt) {
        UUID id = nbt.method_25926(ID_TAG);
        return new ServerTardis(id, nbt, true);
    }
}