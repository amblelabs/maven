package dev.amble.ait.common.impl.tardis.state;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.util.NbtUtil;
import dev.drtheo.ecs.state.NbtSerializer;
import dev.drtheo.ecs.state.TState;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_4208;
import net.minecraft.class_5321;
import org.jetbrains.annotations.NotNull;
import oshi.util.tuples.Pair;

public class ExteriorState implements TState<ExteriorState>, NbtSerializer {

    public ExteriorState(class_4208 globalPos, int rotation) {
        this.exteriorPos = globalPos;
        this.exteriorRot = rotation;
    }

    // Prevents null stuff, basically a bullshit location. - Loqor
    public ExteriorState() {
        this(new class_4208(class_1937.field_25179, new class_2338(0, 64, 0)), 0);
    }

    public class_4208 exteriorPos;
    public int exteriorRot; // GlobalPos doesn't store the direction, so we can use a separate value. - Loqor

    public static final Type<ExteriorState> state = new NbtBacked<>(AitAPI.modLoc("exterior"), 0) {
        @Override
        public ExteriorState fromNbt(class_2487 nbt, boolean isClient) {
            ExteriorState exteriorState = new ExteriorState();

            class_2520 dimTag = nbt.method_10580("dimension");
            class_5321<class_1937> dimension = NbtUtil.dimensionCodec(dimTag).getOrThrow();

            class_2338 blockPos = class_2512.method_10691(nbt, "position").orElse(new class_2338(0, 64, 0));
            exteriorState.exteriorPos = class_4208.method_19443(dimension, blockPos);

            exteriorState.exteriorRot = nbt.method_10550("rotation");

            return exteriorState;
        }
    };

    @Override
    public Type<ExteriorState> type() {
        return state;
    }

    @Override
    public void toNbt(@NotNull class_2487 nbt, boolean isClient) {
        nbt.method_10582("dimension", exteriorPos.comp_2207().method_29177().toString());
        nbt.method_10566("position", class_2512.method_10692(exteriorPos.comp_2208()));
        nbt.method_10569("rotation", exteriorRot);
    }

    public void updateExteriorPos(class_4208 globalPos) {
        updateExteriorPos(globalPos, this.exteriorRot);
    }

    public void updateExteriorPos(int rot) {
        updateExteriorPos(this.exteriorPos, rot);
    }

    public void updateExteriorPos(class_4208 globalPos, int rot) {
        this.exteriorPos = globalPos;
        this.exteriorRot = rot;
    }
}
