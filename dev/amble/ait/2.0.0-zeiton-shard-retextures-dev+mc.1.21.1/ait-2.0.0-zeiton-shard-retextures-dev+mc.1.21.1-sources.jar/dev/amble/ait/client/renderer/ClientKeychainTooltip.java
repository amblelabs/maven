package dev.amble.ait.client.renderer;

import dev.amble.ait.common.items.ItemKeychain;
import dev.amble.ait.common.items.tooltips.KeychainTooltip;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;

@Environment(EnvType.CLIENT)
public class ClientKeychainTooltip implements class_5684 {

    private static final class_2960 BACKGROUND_SPRITE = class_2960.method_60656("container/bundle/background");

    private static final int MARGIN_Y = 4;
    private static final int BORDER_WIDTH = 1;
    private static final int SLOT_SIZE_X = 18;
    private static final int SLOT_SIZE_Y = 18;
    private static final int SLOTS_PER_ROW = 5;

    private final ItemKeychain.KeychainContents contents;

    public ClientKeychainTooltip(KeychainTooltip tooltip) {
        this.contents = tooltip.contents();
    }

    @Override
    public int method_32661() {
        return SLOT_SIZE_Y + BORDER_WIDTH * 2 + MARGIN_Y;
    }

    @Override
    public int method_32664(class_327 font) {
        return SLOTS_PER_ROW * SLOT_SIZE_X + BORDER_WIDTH * 2;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        class_310 minecraft = class_310.method_1551();

        handleMouseInput(x, y, minecraft);

        guiGraphics.method_52706(BACKGROUND_SPRITE, x, y, this.method_32664(font), SLOT_SIZE_Y + BORDER_WIDTH * 2);

        for (int col = 0; col < SLOTS_PER_ROW; col++) {
            int slotIndex = col;
            int slotX = x + col * SLOT_SIZE_X + BORDER_WIDTH;
            int slotY = y + BORDER_WIDTH;

            if (slotIndex < contents.size()) {
                boolean isSelected = (slotIndex == this.contents.selectedIndex());
                renderSlotWithItem(slotX, slotY, slotIndex, isSelected, guiGraphics, font);
            } else {
                renderEmptySlot(slotX, slotY, guiGraphics);
            }
        }
    }

    private void renderSlotWithItem(int x, int y, int index, boolean isSelected, class_332 guiGraphics, class_327 font) {
        class_1799 itemStack = this.contents.getItem(index);

        this.blit(guiGraphics, x, y, Texture.SLOT);

        guiGraphics.method_51428(itemStack, x + BORDER_WIDTH, y + BORDER_WIDTH, index);
        guiGraphics.method_51431(font, itemStack, x + BORDER_WIDTH, y + BORDER_WIDTH);

        if (isSelected) {
            guiGraphics.method_25294(x + BORDER_WIDTH, y + BORDER_WIDTH,
                    x + SLOT_SIZE_X - BORDER_WIDTH, y + SLOT_SIZE_Y - BORDER_WIDTH,
                    0x80FFFFFF);
        }
    }

    private void renderEmptySlot(int x, int y, class_332 guiGraphics) {
        this.blit(guiGraphics, x, y, Texture.SLOT);
    }

    private void handleMouseInput(int tooltipX, int tooltipY, class_310 minecraft) {
        double mouseX = minecraft.field_1729.method_1603() * minecraft.method_22683().method_4486() / minecraft.method_22683().method_4480();
        double mouseY = minecraft.field_1729.method_1604() * minecraft.method_22683().method_4502() / minecraft.method_22683().method_4507();

        if (minecraft.field_1729.method_1608()) {
            for (int col = 0; col < SLOTS_PER_ROW; col++) {
                int slotIndex = col;
                if (slotIndex >= this.contents.size()) continue;

                int slotX = tooltipX + col * SLOT_SIZE_X + BORDER_WIDTH;
                int slotY = tooltipY + BORDER_WIDTH;

                if (mouseX >= slotX && mouseX < slotX + SLOT_SIZE_X &&
                        mouseY >= slotY && mouseY < slotY + SLOT_SIZE_Y) {

                    class_1799 keychain = minecraft.field_1724.method_6047();
                    ItemKeychain.selectSlot(keychain, slotIndex);
                    break;
                }
            }
        }
    }

    private void blit(class_332 guiGraphics, int i, int j, ClientKeychainTooltip.Texture texture) {
        guiGraphics.method_52707(texture.sprite, i, j, 0, texture.w, texture.h);
    }

    @Environment(EnvType.CLIENT)
    enum Texture {
        BLOCKED_SLOT(class_2960.method_60656("container/bundle/blocked_slot"), 18, 20),
        SLOT(class_2960.method_60656("container/bundle/slot"), 18, 20);

        public final class_2960 sprite;
        public final int w;
        public final int h;

        Texture(final class_2960 resourceLocation, final int j, final int k) {
            this.sprite = resourceLocation;
            this.w = j;
            this.h = k;
        }
    }
}