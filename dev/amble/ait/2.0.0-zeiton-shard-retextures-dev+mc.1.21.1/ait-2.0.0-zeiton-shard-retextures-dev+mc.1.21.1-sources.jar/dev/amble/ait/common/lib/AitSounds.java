package dev.amble.ait.common.lib;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_3414;

import static dev.amble.ait.api.AitAPI.modLoc;

public class AitSounds {
    public static void registerSounds(BiConsumer<class_3414, class_2960> r) {
        for (var e : SOUNDS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    private static final Map<class_2960, class_3414> SOUNDS = new LinkedHashMap<>();

    // Sounds!!
    public static final class_3414 DOOR_OPEN = sound("tardis/door_open");
    public static final class_3414 DOOR_CLOSE = sound("tardis/door_close");
    public static final class_3414 LAND_THUD = sound("tardis/land_thud");
    public static final class_3414 DEMAT = sound("tardis/demat");
    public static final class_3414 FLIGHT_LOOP = sound("tardis/flight_loop");
    public static final class_3414 KEY_LOCK = sound("tardis/key_lock");
    public static final class_3414 KEY_UNLOCK = sound("tardis/key_unlock");
    public static final class_3414 MAT = sound("tardis/mat");
    public static final class_3414 KNOCK = sound("tardis/knock");

    private static class_3414 sound(String name) {
        var id = modLoc(name);
        var sound = class_3414.method_47908(id);
        var old = SOUNDS.put(id, sound);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        return sound;
    }
}
