package dev.amble.ait.common.impl.tardis.behavior;

import dev.amble.ait.api.AitAPI;
import dev.amble.ait.api.tardis.ServerTardis;
import dev.amble.ait.common.blocks.ExteriorBlockEntity;
import dev.amble.ait.common.impl.tardis.state.ExteriorState;
import dev.amble.ait.common.impl.tardis.state.TravelState;
import dev.amble.ait.common.lib.AitBlockEntities;
import dev.amble.ait.common.lib.AitBlocks;
import dev.drtheo.ecs.behavior.TBehavior;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4208;
import net.minecraft.server.MinecraftServer;

public class RematBehavior implements TBehavior {

    public static RematBehavior getInstance() {
        return new RematBehavior();
    }

    public void rematerialize(ServerTardis tardis, MinecraftServer server) {
        TravelState travel = tardis.state(TravelState.state);
        class_4208 destination = travel.destinationPos;
        int rotation = travel.destinationRot;

        class_3218 destinationWorld = server.method_3847(destination.comp_2207());

        AitAPI.LOGGER.info("Rematerializing in {} at {}", destination.comp_2207(), destination.comp_2208());

        if (destinationWorld == null) return;

        class_2680 blockState = AitBlocks.EXTERIOR_BLOCK.method_9564();
        destinationWorld.method_8652(destination.comp_2208(), blockState, class_2248.field_31031);
        ExteriorBlockEntity blockEntity = AitBlockEntities.EXTERIOR_BLOCK_ENTITY.method_11032(destination.comp_2208(), blockState);
        if (blockEntity == null) return;
        destinationWorld.method_8438(blockEntity);
        blockEntity.link(tardis);

        tardis.addState(new ExteriorState(destination, rotation));
    }
}
