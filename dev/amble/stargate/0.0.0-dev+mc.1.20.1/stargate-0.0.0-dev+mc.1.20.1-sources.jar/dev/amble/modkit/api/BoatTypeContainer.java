package dev.amble.modkit.api;

import java.lang.reflect.Field;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;

public abstract class BoatTypeContainer implements RegistryContainer2<BoatTypeContainer.Holder> {

    protected static ABoatType register(class_1792 item, class_1792 chest, class_2248 block) {
        return new Holder(new Pending(item, chest, block));
    }

    protected static ABoatType registerNormal(class_1792 item, class_2248 block) {
        return register(item, null, block);
    }

    protected static ABoatType registerChest(class_1792 item, class_2248 block) {
        return register(null, item, block);
    }

    record Pending(class_1792 item, class_1792 chest, class_2248 block) implements ABoatType {

        @Override
        public class_1690.class_1692 get() {
            throw new IllegalStateException("This boat type was not registered yet!");
        }

        public ABoatType register(class_2960 id) {
            return BoatTypeRegistry.register(id, this.item, this.chest, this.block);
        }
    }

    public static final class Holder implements ABoatType {

        ABoatType child;

        Holder(ABoatType child) {
            this.child = child;
        }

        @Override
        public class_1690.class_1692 get() {
            return child.get();
        }
    }

    public Class<Holder> getTargetClass() {
        return Holder.class;
    }

    @Override
    public void postProcessField(class_2960 identifier, Holder value, Field field) {
        // Promotion
        value.child = ((Pending) value.child).register(identifier);
    }

    @Override
    public void finish() {
        BoatTypeRegistry.apply();
    }
}
