package dev.amble.modkit.api;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3468;
import net.minecraft.class_3959;
import net.minecraft.class_5712;
import net.minecraft.class_7264;

public class ABoatItem extends class_1792 {

    private static final Predicate<class_1297> RIDERS = class_1301.field_6155.and(class_1297::method_5863);
    private final ABoatType type;
    private final boolean chest;

    public ABoatItem(boolean chest, ABoatType type, class_1792.class_1793 settings) {
        super(settings);
        this.chest = chest;
        this.type = type;
    }

    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);
        class_239 hitResult = method_7872(world, user, class_3959.class_242.field_1347);

        if (hitResult.method_17783() == class_239.class_240.field_1333)
            return class_1271.method_22430(itemStack);

        class_243 vec3d = user.method_5828(1.0F);

        List<class_1297> list = world.method_8333(user, user.method_5829().method_18804(vec3d.method_1021(5.0F)).method_1014(1.0F), RIDERS);

        if (!list.isEmpty()) {
            class_243 vec3d2 = user.method_33571();

            for(class_1297 entity : list) {
                class_238 box = entity.method_5829().method_1014(entity.method_5871());
                if (box.method_1006(vec3d2)) {
                    return class_1271.method_22430(itemStack);
                }
            }
        }

        if (hitResult.method_17783() != class_239.class_240.field_1332)
            return class_1271.method_22430(itemStack);

        class_1690 boatEntity = this.createEntity(world, hitResult);
        boatEntity.method_47884(this.type.get());
        boatEntity.method_36456(user.method_36454());

        if (!world.method_8587(boatEntity, boatEntity.method_5829())) {
            return class_1271.method_22431(itemStack);
        } else {
            if (!world.method_8608()) {
                world.method_8649(boatEntity);
                world.method_43275(user, class_5712.field_28738, hitResult.method_17784());

                if (!user.method_31549().field_7477)
                    itemStack.method_7934(1);
            }

            user.method_7259(class_3468.field_15372.method_14956(this));
            return class_1271.method_29237(itemStack, world.method_8608());
        }
    }

    private class_1690 createEntity(class_1937 world, class_239 hitResult) {
        return this.chest ? new class_7264(world, hitResult.method_17784().field_1352, hitResult.method_17784().field_1351, hitResult.method_17784().field_1350) : new class_1690(world, hitResult.method_17784().field_1352, hitResult.method_17784().field_1351, hitResult.method_17784().field_1350);
    }
}
