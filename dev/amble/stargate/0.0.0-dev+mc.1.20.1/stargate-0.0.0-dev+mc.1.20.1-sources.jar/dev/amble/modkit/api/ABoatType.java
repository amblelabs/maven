package dev.amble.modkit.api;

import net.minecraft.class_1690;

public interface ABoatType {
    class_1690.class_1692 get();
}
