package dev.amble.modkit.api;

import dev.amble.lib.util.LazyObject;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;

public class BoatTypeRegistry {

    private static class_1792[] TYPE2ITEM;
    private static class_1792[] CTYPE2ITEM;

    private static final BoatItemConsumer CONSUMER = new BoatItemConsumer() {

        @Override
        public void init(int size) {
            TYPE2ITEM = new class_1792[size];
            CTYPE2ITEM = new class_1792[size];
        }

        @Override
        public void accept(class_1690.class_1692 type, class_1792 normal, class_1792 chest) {
            TYPE2ITEM[type.ordinal()] = normal;
            CTYPE2ITEM[type.ordinal()] = chest;
        }
    };

    private static final List<Entry> entries = new ArrayList<>();

    public static LazyBoatType register(class_2960 id, class_1792 item, class_1792 chest, class_2248 block) {
        Entry entry = new Entry(id, item, chest, block);
        entries.add(entry);

        return entry.lazyGetter();
    }

    public static class_1792 getItem(class_1690.class_1692 type, boolean chest) {
        return (chest ? CTYPE2ITEM : TYPE2ITEM)[type.ordinal()];
    }

    public static void apply() {
        ((CustomBoatTypes) (Object) class_1690.class_1692.field_7727).amble$recalc(entries, CONSUMER);
    }

    public interface BoatItemConsumer {
        void init(int size);
        void accept(class_1690.class_1692 type, class_1792 normal, class_1792 chest);
    }

    public interface CustomBoatTypes {
        void amble$recalc(List<Entry> entries, BoatItemConsumer consumer);
    }

    public record Entry(class_2960 id, class_1792 item, class_1792 chest, class_2248 block) {

        public String getPath() {
            return id.method_12836() + "/" + id.method_12832();
        }

        public String getEnumName() {
            return id.method_12836().toUpperCase() + "_" + id.method_12832().replace('/', '_').toUpperCase();
        }

        public LazyBoatType lazyGetter() {
            return new LazyBoatType(this);
        }
    }

    public static class LazyBoatType extends LazyObject<class_1690.class_1692> implements ABoatType {

        public LazyBoatType(Entry entry) {
            super(() -> class_1690.class_1692.method_7561(entry.getPath()), class_1690.class_1692.field_7727);
        }
    }
}
