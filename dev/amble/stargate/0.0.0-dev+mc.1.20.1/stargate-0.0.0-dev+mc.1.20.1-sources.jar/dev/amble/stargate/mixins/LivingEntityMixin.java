package dev.amble.stargate.mixins;

import dev.amble.stargate.util.TeleportableEntity;
import net.minecraft.class_1309;
import net.minecraft.class_2487;
import net.minecraft.class_5132;
import dev.amble.stargate.init.StargateAttributes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public class LivingEntityMixin implements TeleportableEntity {

    @Unique
    private int stargate$ticks;

    @Inject(method = "createLivingAttributes", at = @At("RETURN"))
    private static void addAttributes(CallbackInfoReturnable<class_5132.class_5133> cir) {
        cir.getReturnValue().method_26867(StargateAttributes.SPACIAL_RESISTANCE);
    }

    @Inject(method = "tick", at = @At("RETURN"))
    public void tick(CallbackInfo ci) {
        this.stargate$tickTicks();
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("RETURN"))
    public void toNbt(class_2487 nbt, CallbackInfo ci) {
        if (stargate$ticks != 0)
            nbt.method_10569("StargateTpState", stargate$ticks);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("RETURN"))
    public void fromNbt(class_2487 nbt, CallbackInfo ci) {
        this.stargate$ticks = nbt.method_10550("StargateTpState");
    }

    @Override
    public int stargate$ticks() {
        return stargate$ticks;
    }

    @Override
    public void stargate$setTicks(int ticks) {
        this.stargate$ticks = ticks;
    }
}
