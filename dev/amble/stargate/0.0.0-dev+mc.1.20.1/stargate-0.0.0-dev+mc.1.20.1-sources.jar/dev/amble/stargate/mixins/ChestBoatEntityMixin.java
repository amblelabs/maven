package dev.amble.stargate.mixins;

import dev.amble.modkit.api.BoatTypeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_7264;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_7264.class, priority = 999)
public abstract class ChestBoatEntityMixin extends class_1690 {

    public ChestBoatEntityMixin(class_1299<? extends class_1690> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "asItem", at = @At("HEAD"), cancellable = true)
    public void asItem(CallbackInfoReturnable<class_1792> cir) {
        class_1792 item = BoatTypeRegistry.getItem(this.method_47885(), true);

        if (item != null)
            cir.setReturnValue(item);
    }
}
