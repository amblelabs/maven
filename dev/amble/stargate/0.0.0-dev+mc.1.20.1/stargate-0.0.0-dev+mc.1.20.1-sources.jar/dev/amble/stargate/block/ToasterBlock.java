package dev.amble.stargate.block;

import dev.amble.lib.block.ABlock;
import dev.amble.lib.block.ABlockSettings;
import dev.amble.lib.block.behavior.base.BlockWithEntityBehavior;
import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.stargate.StargateMod;
import dev.amble.stargate.block.entities.ToasterBlockEntity;
import dev.amble.stargate.init.StargateBlocks;
import dev.amble.stargate.init.StargateItems;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

@SuppressWarnings({"deprecation", "UnstableApiUsage"})
public class ToasterBlock extends ABlock implements class_2343 {

    protected static final class_265 SHAPE = class_2248.method_9541(5, 1, 5, 11, 7, 11);

    private static final class_2338[] POSITIONS_NORTH = buildPositions(class_2350.field_11043);
    private static final class_2338[] POSITIONS_EAST = buildPositions(class_2350.field_11034);

    private static final class_2248[] requiredBlocks = {
            class_2246.field_10085, // up
            class_2246.field_10085, // east
            class_2246.field_10085, // west
            StargateBlocks.NAQUADAH_BLOCK, // down
            class_2246.field_27128, // upEast
            class_2246.field_27128, // upWest
            class_2246.field_27128, // downEast
            class_2246.field_27128 // downWest
    };

    private static class_2338[] buildPositions(class_2350 facing) {
        class_2338 zero = class_2338.field_10980;

        return new class_2338[] {
                zero.method_10084(),
                zero.method_10093(facing.method_10170()),
                zero.method_10093(facing.method_10160()),
                zero.method_10074(),
                zero.method_10084().method_10093(facing.method_10170()),
                zero.method_10084().method_10093(facing.method_10160()),
                zero.method_10074().method_10093(facing.method_10170()),
                zero.method_10074().method_10093(facing.method_10160())
        };
    }

    public ToasterBlock(ABlockSettings settings) {
        super(settings,
                HorizontalBlockBehavior.withPlacement(true),
                new BlockWithEntityBehavior.Ticking(ToasterBlockEntity::new)
        );
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos,
                              class_1657 player,
                              class_1268 hand, class_3965 hit) {
        if (!(world instanceof class_3218 serverWorld)) return class_1269.field_5811;

        class_1799 stack = player.method_5998(hand);

        if (stack.method_7960()) {
            class_2350 facing = HorizontalBlockBehavior.getFacing(state);
            class_2338[] positions = facing == class_2350.field_11043 || facing == class_2350.field_11035
                    ? POSITIONS_NORTH : POSITIONS_EAST;

            class_2338[] finalPos = new class_2338[positions.length];

            for (int i = 0; i < finalPos.length; i++) {
                class_2338 blockPos = pos.method_10081(positions[i]);
                finalPos[i] = blockPos;

                class_2680 block = world.method_8320(blockPos);

                if (block.method_26204() != requiredBlocks[i]) {
                    StargateMod.LOGGER.debug("Block {}@{} != {}", block.method_26204(), blockPos, requiredBlocks[i]);
                    return class_1269.field_5811;
                }
            }

            for (class_2338 clearPos : finalPos) {
                world.method_22352(clearPos, false);
            }

            StargateItems.ORLIN_STARGATE.place(serverWorld, pos.method_10074(), facing);
            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }
}