package dev.amble.stargate.client.renderers;

import dev.amble.stargate.block.entities.StargateRingBlockEntity;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4696;
import net.minecraft.class_5614;
import net.minecraft.class_827;

public class RingBlockEntityRenderer implements class_827<StargateRingBlockEntity> {

    public RingBlockEntityRenderer(class_5614.class_5615 ctx) {}

    @Override
    public void render(StargateRingBlockEntity entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        if (entity.getBlockSet() != null) {
            class_2680 blockState = entity.getBlockSet();
            matrices.method_22903();
            class_310.method_1551().method_1541().method_3355(blockState, entity.method_11016(), entity.method_10997(), matrices, vertexConsumers.getBuffer(class_4696.method_23679(blockState)), true, class_310.method_1551().field_1687.method_8409());
            matrices.method_22909();
        }
    }

}