package dev.amble.stargate.api;

import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.state.stargate.*;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_7922;
import java.util.function.Supplier;

public class GateKernelRegistry {

    private static final class_5321<class_2378<Entry>> KEY = class_5321.method_29180(StargateMod.id("kernel"));
    private static final class_7922<Entry> REGISTRY = FabricRegistryBuilder
            .createDefaulted(KEY, MilkyWayState.ID).buildAndRegister();

    public static class_7922<Entry> get() {
        return REGISTRY;
    }

    public static final Entry MILKY_WAY = register(MilkyWayState.ID, MilkyWayState::new);
    public static final Entry ORLIN = register(OrlinState.ID, OrlinState::new);
    public static final Entry PEGASUS = register(PegasusState.ID, PegasusState::new);
    public static final Entry DESTINY = register(DestinyState.ID, DestinyState::new);

    public static Entry register(String path, Supplier<GateIdentityState> creator) {
        return register(StargateMod.id(path), creator);
    }

    public static Entry register(class_2960 id, Supplier<GateIdentityState> creator) {
        return class_2378.method_10230(REGISTRY, id, new Entry(creator));
    }

    public record Entry(Supplier<GateIdentityState> creator) {

        public Stargate create(class_3218 world, class_2338 pos, class_2350 direction) {
            return new ServerStargate(creator.get(), world, pos, direction);
        }

        public Stargate load(class_2487 nbt, boolean isClient) {
            return isClient ? new Stargate(creator.get(), nbt, true) : new ServerStargate(creator.get(), nbt);
        }
    }
}
