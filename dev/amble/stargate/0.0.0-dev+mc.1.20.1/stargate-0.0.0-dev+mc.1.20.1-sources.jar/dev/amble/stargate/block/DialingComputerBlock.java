package dev.amble.stargate.block;

import dev.amble.lib.block.ABlock;
import dev.amble.lib.block.ABlockSettings;
import dev.amble.lib.block.behavior.base.BlockWithEntityBehavior;
import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.stargate.StargateMod;
import dev.amble.stargate.block.entities.DialingComputerBlockEntity;
import dev.amble.stargate.util.VoxelShapeUtil;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3726;

@SuppressWarnings({"UnstableApiUsage", "deprecation"})
public class DialingComputerBlock extends ABlock implements class_2343 {

    public static final class_2960 OPEN = StargateMod.id("block/dialing_computer/open");

    protected static final class_265 SHAPE = class_2248.method_9541(8, 1, 6, 14, 12, 14);

    public DialingComputerBlock(ABlockSettings settings) {
        super(settings,
                HorizontalBlockBehavior.withPlacement(true),
                BlockWithEntityBehavior.Ticking.withInvisibleModel(DialingComputerBlockEntity::new)
        );
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return VoxelShapeUtil.rotateShapeH(class_2350.field_11043, HorizontalBlockBehavior.getFacing(state), SHAPE);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return VoxelShapeUtil.rotateShapeH(class_2350.field_11043, HorizontalBlockBehavior.getFacing(state), SHAPE);
    }
}
