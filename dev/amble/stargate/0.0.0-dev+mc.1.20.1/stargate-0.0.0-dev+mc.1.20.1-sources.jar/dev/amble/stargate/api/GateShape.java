package dev.amble.stargate.api;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public interface GateShape {
    void place(class_2680 state, class_1937 world, class_2338 corePos, class_2350 direction);
    void destroy(class_1937 world, class_2338 corePos, class_2350 direction);
    boolean verify(class_2680 state, class_1922 view, class_2338 corePos, class_2350 direction);

    static GateShape generated(String shape) {
        return new GeneratedShape(shape).prepare();
    }

    GateShape EMPTY = new Const(List.of());

    GateShape DEFAULT = generated("""
				_________
				_________
				___XXX___/
				__X___X__/
				_X_____X_//
				_X_____X_///
				_X_____X_////
				__X___X__
				___X_X___.
				""");

    class Const implements GateShape {

        private final Iterable<class_2338> built;

        public Const(Iterable<class_2338> built) {
            this.built = built;
        }

        @Override
        public void place(class_2680 state, class_1937 world, class_2338 corePos, class_2350 direction) {
            for (class_2338 pair : this.built) {
                class_2338 pos = rotate(pair, corePos, direction);
                world.method_8501(pos, state);
            }
        }

        @Override
        public void destroy(class_1937 world, class_2338 corePos, class_2350 direction) {
            for (class_2338 pair : this.built) {
                class_2338 pos = rotate(pair, corePos, direction);
                world.method_8650(pos, false);
            }
        }

        @Override
        public boolean verify(class_2680 state, class_1922 view, class_2338 corePos, class_2350 direction) {
            for (class_2338 pair : this.built) {
                class_2338 pos = rotate(pair, corePos, direction);
                class_2680 placed = view.method_8320(pos);

                if (placed.method_26204() != state.method_26204())
                    return false;
            }

            return true;
        }

        private static class_2338 rotate(class_2338 pos, class_2338 offset, class_2350 facing) {
            pos = rotate(pos.method_10263(), pos.method_10264(), facing);
            return pos.method_10081(offset);
        }

        public static class_2338 rotate(int x, int y, class_2350 facing) {
            return switch (facing) {
                case field_11043 -> new class_2338(x, y, 0);
                case field_11035 -> new class_2338(-x, y, 0);
                case field_11039 -> new class_2338(0, y, x);
                case field_11034 -> new class_2338(0, y, -x);
                default -> class_2338.field_10980;
            };
        }
    }

    abstract class Built {

        protected abstract Iterable<class_2338> build();

        protected GateShape prepare() {
            return new Const(this.build());
        }
    }

    class GeneratedShape extends Built {

        private final String shape;

        public GeneratedShape(String shape) {
            this.shape = shape;
        }

        @Override
        protected Iterable<class_2338> build() {
            Set<class_2338> ringPositions = new HashSet<>();
            List<String> list = shape.lines().toList();

            int height = list.size();
            int width = list.stream().mapToInt(String::length).max().orElse(0);
            int xOffset = width / 2;
            int yOffset = height / 2;

            for (int j = 0; j < height; j++) {
                String line = list.get(j);

                for (int i = 0; i < line.length(); i++) {
                    if (line.charAt(i) != 'X') continue;

                    // Center both horizontally and vertically
                    ringPositions.add(new class_2338(i - xOffset + 2, yOffset - j + 4, 0));
                }
            }

            return ringPositions;
        }
    }
}
