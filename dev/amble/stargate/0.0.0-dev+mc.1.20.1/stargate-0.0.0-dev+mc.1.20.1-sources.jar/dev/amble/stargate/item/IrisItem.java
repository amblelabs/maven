package dev.amble.stargate.item;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.state.IrisState;
import dev.amble.stargate.api.state.IrisTier;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.init.StargateIrisTiers;
import dev.amble.stargate.init.StargateItems;
import dev.amble.stargate.util.NbtUtil;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;

public class IrisItem extends class_1792 {

    private final IrisTier tier;

    public IrisItem(IrisTier tier, class_1793 settings) {
        super(settings);

        this.tier = tier;
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        if (context.method_8045().method_8608()) return class_1269.field_5811;

        if (!(context.method_8045().method_8321(context.method_8037()) instanceof StargateBlockEntity be) || !be.isLinked())
            return class_1269.field_5811;

        Stargate stargate = be.asGate();

        if (stargate.hasState(IrisState.state))
            return class_1269.field_5811;

        context.method_8041().method_7934(1);
        stargate.addState(new IrisState(tier));

        return class_1269.field_5812;
    }
}
