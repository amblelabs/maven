package dev.amble.stargate.api.event.tp;

import dev.amble.stargate.api.ServerStargate;
import dev.amble.stargate.api.Stargate;
import dev.drtheo.yaar.event.TEvents;
import net.minecraft.class_1309;

public interface StargateTpEvents extends TEvents {

    Type<StargateTpEvents> event = new Type<>(StargateTpEvents.class);

    StargateTpEvent.Result onGateTp(ServerStargate from, ServerStargate to, class_1309 living);
}
