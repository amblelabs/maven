package dev.amble.stargate.api.address;

import com.google.gson.JsonParser;
import dev.amble.lib.AmbleKit;
import dev.amble.stargate.StargateMod;
import it.unimi.dsi.fastutil.chars.CharObjectImmutablePair;
import it.unimi.dsi.fastutil.objects.Object2CharArrayMap;
import it.unimi.dsi.fastutil.objects.Object2CharMap;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import java.io.Reader;
import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public class GlyphOriginRegistry implements IdentifiableResourceReloadListener {

    @SuppressWarnings("unchecked")
    private final class_5321<class_1937>[] REGISTRY = new class_5321[Glyph.ALPHABET_LENGTH];
    private final Object2CharMap<class_5321<class_1937>> REVERSE = new Object2CharArrayMap<>();

    private static GlyphOriginRegistry instance;

    public static GlyphOriginRegistry get() {
        return instance;
    }

    public static void init() {
        instance = new GlyphOriginRegistry();
//        ResourceManagerHelper.get(ResourceType.SERVER_DATA).registerReloadListener(instance = new GlyphOriginRegistry());
    }

    private GlyphOriginRegistry() {
        this.clear();
        this.register(class_1937.field_25179, '7');
    }

    private void clear() {
        Arrays.fill(REGISTRY, null);
        REVERSE.clear();
        REVERSE.defaultReturnValue('*');
    }

    private static final String SUBPATH = "point_of_origin";

    // TODO: figure out why the fuck this causes a thread lock
    @Override
    public CompletableFuture<Void> method_25931(class_4045 synchronizer, class_3300 manager, class_3695 prepareProfiler, class_3695 applyProfiler, Executor prepareExecutor, Executor applyExecutor) {
        return CompletableFuture.supplyAsync(() -> {
            Map<class_2960, class_3298> resources = manager.method_14488(SUBPATH, f -> f.method_12832().endsWith(".json"));

            //noinspection unchecked
            CharObjectImmutablePair<class_2960>[] pairs = new CharObjectImmutablePair[resources.size()];

            int i = 0;
            for (class_2960 id : resources.keySet()) {
                try (Reader reader = manager.getResourceOrThrow(id).method_43039()) {
                    char created = JsonParser.parseReader(reader).getAsJsonObject()
                            .getAsJsonPrimitive("glyph").getAsString().charAt(0);

                    class_2960 dimId = new class_2960(id.method_12836(),
                            id.method_12832().substring(SUBPATH.length() + 1, // 'point_of_origin/'
                                    id.method_12832().length() - 5) // .json
                    );

                    pairs[i++] = new CharObjectImmutablePair<>(created, dimId);
                } catch (Exception e) {
                    AmbleKit.LOGGER.error("Error occurred while loading resource json {}", id.toString(), e);
                }
            }

            return pairs;
        }, prepareExecutor).thenComposeAsync(pairs -> {
            this.clear();

            for (CharObjectImmutablePair<class_2960> pair : pairs) {
                this.register(class_5321.method_29179(class_7924.field_41223, pair.second()), pair.firstChar());
            }

            return CompletableFuture.completedFuture(null);
        }, applyExecutor);
    }

    public void register(class_5321<class_1937> key, char c) {
        REGISTRY[Glyph.charToIdx(c)] = key;
        REVERSE.put(key, c);
    }

    public void register(class_5321<class_1937> key, int idx) {
        REGISTRY[idx] = key;
        REVERSE.put(key, Glyph.idxToChar(idx));
    }

    public class_5321<class_1937> dimForGlyph(char c) {
        return REGISTRY[Glyph.charToIdx(c)];
    }

    public char glyphForDim(class_5321<class_1937> key) {
        return REVERSE.computeIfAbsent(key, this::allocate);
    }

    private char allocate(class_5321<class_1937> key) {
        for (int i = 0; i < REGISTRY.length; i++) {
            if (REGISTRY[i] == null) {
                char c = Glyph.idxToChar(i);
                register(key, c);

                return c;
            }
        }

        return REVERSE.defaultReturnValue();
    }

    @Override
    public class_2960 getFabricId() {
        return StargateMod.id(SUBPATH);
    }
}
