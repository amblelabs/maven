package dev.amble.stargate.entities;

import dev.amble.stargate.api.address.Glyph;
import dev.amble.stargate.block.entities.DHDBlockEntity;
import dev.amble.stargate.init.StargateEntities;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2561;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.entity.*;

public class DHDControlEntity extends class_1297 {

    private class_2338 dhdPos;

    private char symbol;
    private class_4048 dimensions = StargateEntities.DHD_CONTROL_TYPE.method_18386();

    public DHDControlEntity(class_1299<? extends class_1297> entityType, class_1937 world) {
        super(entityType, world);
    }

    public DHDControlEntity(class_1937 world, char symbol, class_4048 dimensions, class_2338 dhdPos) {
        this(StargateEntities.DHD_CONTROL_TYPE, world);

        this.symbol = symbol;
        this.dimensions = dimensions;

        this.dhdPos = dhdPos;
    }

    @Override
    protected void method_5693() { }

    @Override
    public boolean method_5740() {
        return true;
    }

    @Override
    public boolean method_5863() {
        return true;
    }

    @Override
    public void method_36209() {
        if (this.dhdPos != null && this.method_37908().method_8321(this.dhdPos) instanceof DHDBlockEntity dhd)
            dhd.markNeedsControl();
    }

    @Override
    public void method_5652(class_2487 nbt) {
        if (dhdPos != null)
            nbt.method_10566("dhd", class_2512.method_10692(this.dhdPos));

        nbt.method_10548("width", dimensions.field_18067);
        nbt.method_10548("height", dimensions.field_18068);
    }

    @Override
    public void method_5749(class_2487 nbt) {
        class_2487 dhd = nbt.method_10562("dhd");

        if (dhd != null)
            this.dhdPos = class_2512.method_10691(dhd);

        if (nbt.method_10545("width") && nbt.method_10545("height")) {
            float width = nbt.method_10583("width");
            float height = nbt.method_10583("height");

            this.dimensions = class_4048.method_18385(width, height);
            this.method_18382();
        }
    }

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        this.run(player, false);
        return class_1269.field_5812;
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (!(source.method_5529() instanceof class_1657 player)) return false;

        this.run(player, true);
        return true;
    }

    @Override
    public class_2561 method_5477() {
        return Glyph.asText(this.symbol);
    }

    @Override
    public class_4048 method_18377(class_4050 pose) {
        return dimensions;
    }

    @Override
    public void method_5773() {
        if (this.method_37908().method_8608())
            return;

        if (this.dhdPos == null)
            this.method_31472();
    }

    private void run(class_1657 player, boolean leftClick) {
        if (this.method_37908().method_8608())
            return;

        if (this.method_37908().method_8321(this.dhdPos) instanceof DHDBlockEntity dhd) {
            dhd.onUseControl(player, this.method_37908(), this, leftClick);
        } else {
            this.method_31472();
        }
    }

    public char getSymbol() {
        return symbol;
    }
}
