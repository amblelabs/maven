package dev.amble.stargate.api.event.block;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.drtheo.yaar.event.TEvent;
import dev.drtheo.yaar.event.TEvents;
import dev.drtheo.yaar.state.StateResolveError;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public record StargateBlockTickEvent(Stargate stargate, StargateBlockEntity entity, class_1937 world, class_2338 pos, class_2680 state) implements TEvent.Notify<StargateBlockTickEvents> {

    @Override
    public TEvents.BaseType<StargateBlockTickEvents> type() {
        return StargateBlockTickEvents.event;
    }

    @Override
    public void handle(StargateBlockTickEvents handler) throws StateResolveError {
        handler.block$tick(stargate, entity, world, pos, state);
    }

    public record Random(Stargate stargate, class_1937 world, class_2338 pos, class_2680 state, net.minecraft.class_5819 random) implements TEvent.Notify<StargateBlockTickEvents> {

        @Override
        public void handle(StargateBlockTickEvents handler) throws StateResolveError {
            handler.block$randomDisplayTick(stargate, world, pos, state, random);
        }

        @Override
        public TEvents.BaseType<StargateBlockTickEvents> type() {
            return StargateBlockTickEvents.event;
        }
    }
}
