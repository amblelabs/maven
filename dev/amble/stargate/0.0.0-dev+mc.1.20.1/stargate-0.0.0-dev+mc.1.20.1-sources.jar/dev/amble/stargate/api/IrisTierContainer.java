package dev.amble.stargate.api;

import dev.amble.lib.container.RegistryContainer;
import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.state.IrisTier;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.minecraft.class_2348;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import java.lang.reflect.Field;

public interface IrisTierContainer extends RegistryContainer<IrisTier> {

    class_5321<class_2378<IrisTier>> REGISTRY_KEY = class_5321.method_29180(StargateMod.id("iris_tier"));
    class_2348<IrisTier> REGISTRY = FabricRegistryBuilder.createDefaulted(REGISTRY_KEY, StargateMod.id("iron"))
            .buildAndRegister();

    @Override
    default void postProcessField(class_2960 identifier, IrisTier value, Field field) {
        value.setRegistryKey(class_5321.method_29179(REGISTRY_KEY, identifier));
    }

    @Override
    default Class<IrisTier> getTargetClass() {
        return IrisTier.class;
    }

    @Override
    default class_2378<IrisTier> getRegistry() {
        return REGISTRY;
    }
}
