package dev.amble.stargate.api.event.block;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.drtheo.yaar.event.TEvent;
import dev.drtheo.yaar.event.TEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public final class StargateBlockUseEvent implements TEvent.Result<StargateBlockUseEvents, Boolean> {

    private final Stargate stargate;
    private final StargateBlockEntity blockEntity;
    private final class_1657 player;
    private final class_1937 world;
    private final class_2680 state;
    private final class_2338 pos;
    private final class_1268 hand;
    private final class_3965 blockHit;

    private boolean result;

    public StargateBlockUseEvent(Stargate stargate, StargateBlockEntity blockEntity, class_1657 player, class_1937 world, class_2680 state, class_2338 pos, class_1268 hand, class_3965 blockHit) {
        this.stargate = stargate;
        this.blockEntity = blockEntity;
        this.player = player;
        this.world = world;
        this.state = state;
        this.pos = pos;
        this.hand = hand;
        this.blockHit = blockHit;
    }

    @Override
    public TEvents.BaseType<StargateBlockUseEvents> type() {
        return StargateBlockUseEvents.event;
    }

    @Override
    public Boolean result() {
        return result;
    }

    @Override
    public void handleAll(Iterable<StargateBlockUseEvents> iterable) {
        for (StargateBlockUseEvents events : iterable) {
            if (TEvent.handleSilent(this, events, () -> events.onUse(stargate, blockEntity, player, world, state, pos, hand, blockHit), false)) {
                this.result = true;
                return;
            }
        }
    }
}
