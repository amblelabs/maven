package dev.amble.stargate.effect;

import dev.amble.stargate.init.StargateAttributes;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_1291;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_4081;

public class SpacialDynamicEffect extends class_1291 {

    public static final UUID ATTRIBUTE_ID = UUID.fromString("6d279977-e573-41ec-8f57-7d9ac97b561e");

    public SpacialDynamicEffect() {
        super(class_4081.field_18271, 0x0000000);

        this.method_5566(StargateAttributes.SPACIAL_RESISTANCE, ATTRIBUTE_ID.toString(), 10, class_1322.class_1323.field_6328);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return false;
    }

    @Override
    public void method_5572(class_1309 entity, int amplifier) { }

    @Override
    public void method_5564(@Nullable class_1297 source, @Nullable class_1297 attacker, class_1309 target, int amplifier, double proximity) { }
}
