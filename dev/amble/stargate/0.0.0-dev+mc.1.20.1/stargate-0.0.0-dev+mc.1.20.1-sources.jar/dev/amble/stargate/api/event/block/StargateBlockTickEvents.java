package dev.amble.stargate.api.event.block;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.drtheo.yaar.event.TEvents;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public interface StargateBlockTickEvents extends TEvents {

    Type<StargateBlockTickEvents> event = new Type<>(StargateBlockTickEvents.class);

    void block$tick(Stargate stargate, StargateBlockEntity entity, class_1937 world, class_2338 pos, class_2680 state);

    default void block$randomDisplayTick(Stargate stargate, class_1937 world, class_2338 pos, class_2680 state, class_5819 random) { }
}
