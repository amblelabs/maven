package dev.amble.stargate.client.renderers;

import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.stargate.StargateMod;
import dev.amble.stargate.block.entities.DialingComputerBlockEntity;
import dev.amble.stargate.client.models.DialingComputerModel;
import dev.amble.stargate.client.util.EmissionUtil;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;

public class DialingComputerRenderer implements class_827<DialingComputerBlockEntity> {

    public static final class_2960 TEXTURE = new class_2960(StargateMod.MOD_ID, "textures/blockentities/computer.png");
    public static final class_2960 EMISSION = new class_2960(StargateMod.MOD_ID, "textures/blockentities/computer_emission.png");

    private final DialingComputerModel model;

    public DialingComputerRenderer(class_5614.class_5615 ctx) {
        this.model = new DialingComputerModel();
    }

    @Override
    public void render(DialingComputerBlockEntity entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        matrices.method_22903();
        matrices.method_46416(0.5f, 1.5f, 0.5f);

        float k = HorizontalBlockBehavior.getFacing(entity.method_11010()).method_10144();

        matrices.method_22907(class_7833.field_40715.rotationDegrees(k));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(180f));

        EmissionUtil.render2Layers(model, TEXTURE, EMISSION, true, matrices, vertexConsumers, light, overlay);

        matrices.method_22909();
    }
}
