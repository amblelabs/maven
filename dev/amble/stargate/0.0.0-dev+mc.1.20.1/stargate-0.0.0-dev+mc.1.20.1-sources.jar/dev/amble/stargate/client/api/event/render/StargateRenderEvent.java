package dev.amble.stargate.client.api.event.render;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.client.api.state.stargate.ClientAbstractStargateState;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.client.renderers.StargateBlockEntityRenderer;
import dev.drtheo.yaar.event.TEvent;
import dev.drtheo.yaar.event.TEvents;
import dev.drtheo.yaar.state.StateResolveError;
import net.minecraft.class_3695;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public record StargateRenderEvent(Stargate stargate, ClientAbstractStargateState<?> clientState, StargateBlockEntity entity, StargateBlockEntityRenderer renderer, class_3695 profiler, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay, float tickDelta) implements TEvent.Notify<StargateRenderEvents> {

    public StargateRenderEvent(Stargate stargate, StargateBlockEntity entity, StargateBlockEntityRenderer renderer, class_3695 profiler, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay, float tickDelta) {
        this(stargate, stargate.stateOrNull(ClientAbstractStargateState.state), entity, renderer, profiler, matrices, vertexConsumers, light, overlay, tickDelta);
    }

    @Override
    public TEvents.BaseType<StargateRenderEvents> type() {
        return StargateRenderEvents.event;
    }

    @Override
    public void handle(StargateRenderEvents handler) throws StateResolveError {
        profiler.method_15396(handler.getClass().getSimpleName());
        handler.render(stargate, clientState, entity, renderer, profiler, matrices, vertexConsumers, light, overlay, tickDelta);
        profiler.method_15407();
    }
}
