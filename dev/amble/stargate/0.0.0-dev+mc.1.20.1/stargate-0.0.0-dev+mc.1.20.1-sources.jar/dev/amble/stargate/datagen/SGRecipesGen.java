package dev.amble.stargate.datagen;

import dev.amble.lib.datagen.recipe.AmbleRecipeProvider;
import dev.amble.stargate.init.StargateBlocks;
import dev.amble.stargate.init.StargateItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2246;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_7800;

public class SGRecipesGen extends AmbleRecipeProvider {

    public SGRecipesGen(FabricDataOutput output) {
        super(output);

        addShapelessRecipe(class_2450.method_10448(class_7800.field_40642, StargateItems.ADDRESS_CARTOUCHE, 1)
                .method_10454(class_1802.field_8407)
                .method_10454(class_1802.field_8634)
                .method_10442(method_32807(class_1802.field_8407), method_10426(class_1802.field_8407))
                .method_10442(method_32807(class_1802.field_8634), method_10426(class_1802.field_8634)));

        addShapedRecipe(class_2447.method_10436(class_7800.field_40642, StargateItems.IRIS_BLADE, 1)
                .method_10435("iris")
                .method_10439("II ")
                .method_10439("  N")
                .method_10439("   ")
                .method_10434('I', StargateItems.NAQUADAH_INGOT)
                .method_10434('N', StargateItems.NAQUADAH_NUGGET)
                .method_10429(method_32807(StargateItems.NAQUADAH_INGOT), method_10426(StargateItems.NAQUADAH_INGOT))
                .method_10429(method_32807(StargateItems.NAQUADAH_NUGGET), method_10426(StargateItems.NAQUADAH_NUGGET)));

        addShapedRecipe(class_2447.method_10436(class_7800.field_40642, StargateItems.IRIS_FRAME, 1)
                .method_10435("iris")
                .method_10439("NIN")
                .method_10439("I I")
                .method_10439("NIN")
                .method_10434('N', class_1802.field_8675)
                .method_10434('I', class_1802.field_8620)
                .method_10429(method_32807(StargateItems.NAQUADAH_INGOT), method_10426(StargateItems.NAQUADAH_INGOT))
                .method_10429(method_32807(StargateItems.NAQUADAH_NUGGET), method_10426(StargateItems.NAQUADAH_NUGGET)));

        addShapedRecipe(class_2447.method_10436(class_7800.field_40642, StargateItems.GOLD_IRIS, 1)
                .method_10435("iris")
                .method_10439("BBB")
                .method_10439("BFB")
                .method_10439("BBB")
                .method_10434('F', StargateItems.IRIS_FRAME)
                .method_10434('B', StargateItems.IRIS_BLADE)
                .method_10429(method_32807(StargateItems.IRIS_FRAME), method_10426(StargateItems.IRIS_FRAME))
                .method_10429(method_32807(StargateItems.IRIS_BLADE), method_10426(StargateItems.IRIS_BLADE)));

        addShapedRecipe(class_2447.method_10436(class_7800.field_40642, StargateBlocks.NAQUADAH_BLOCK, 1)
                .method_10435("naquadah")
                .method_10439("III")
                .method_10439("III")
                .method_10439("III")
                .method_10434('I', StargateItems.NAQUADAH_INGOT)
                .method_10429(method_32807(StargateItems.NAQUADAH_INGOT), method_10426(StargateItems.NAQUADAH_INGOT)));

        addShapedRecipe(class_2447.method_10436(class_7800.field_40642, StargateBlocks.RAW_NAQUADAH_BLOCK, 1)
                .method_10435("naquadah")
                .method_10439("RRR")
                .method_10439("RRR")
                .method_10439("RRR")
                .method_10434('R', StargateItems.RAW_NAQUADAH)
                .method_10429(method_32807(StargateItems.RAW_NAQUADAH), method_10426(StargateItems.RAW_NAQUADAH)));


        addShapedRecipe(
                class_2447.method_10436(class_7800.field_40642, StargateItems.NAQUADAH_INGOT, 1)
                        .method_10435("naquadah")
                        .method_10439("NNN")
                        .method_10439("NNN")
                        .method_10439("NNN")
                        .method_10434('N', StargateItems.NAQUADAH_NUGGET)
                        .method_10429(method_32807(StargateItems.NAQUADAH_NUGGET), method_10426(StargateItems.NAQUADAH_NUGGET)),
                new class_2960("stargate", "naquadah_ingot_recipe_from_nugget")
        );

        addShapelessRecipe(
                class_2450.method_10448(class_7800.field_40642, StargateItems.NAQUADAH_INGOT, 9)
                        .method_10452("naquadah")
                        .method_10454(StargateBlocks.NAQUADAH_BLOCK)
                        .method_10442(method_32807(StargateBlocks.NAQUADAH_BLOCK), method_10426(StargateBlocks.NAQUADAH_BLOCK)),
                new class_2960("stargate", "naquadah_ingot_recipe_from_block")
        );

        addShapelessRecipe(
                class_2450.method_10448(class_7800.field_40642, StargateItems.RAW_NAQUADAH, 9)
                        .method_10452("naquadah")
                        .method_10454(StargateBlocks.RAW_NAQUADAH_BLOCK)
                        .method_10442(method_32807(StargateBlocks.RAW_NAQUADAH_BLOCK), method_10426(StargateBlocks.RAW_NAQUADAH_BLOCK)),
                new class_2960("stargate", "raw_naquadah_recipe_from_block")
        );

        addBlastFurnaceRecipe(class_2454.method_10473(class_1856.method_8091(StargateItems.RAW_NAQUADAH),
                        class_7800.field_40642,StargateItems.NAQUADAH_INGOT, 0.2f, 500)
                .method_10469(method_32807(StargateItems.RAW_NAQUADAH), method_10426(StargateItems.RAW_NAQUADAH)));

        addShapelessRecipe(class_2450.method_10448(class_7800.field_40642, StargateItems.NAQUADAH_NUGGET,9)
                .method_10452("naquadah")
                .method_10454(StargateItems.NAQUADAH_INGOT)
                .method_10442(method_32807(StargateItems.NAQUADAH_INGOT), method_10426(StargateItems.NAQUADAH_INGOT)));

        addShapedRecipe(
                class_2447.method_10436(class_7800.field_40636, StargateItems.COPPER_COIL, 8)
                        .method_10439(" C ")
                        .method_10439("CWC")
                        .method_10439(" C ")
                        .method_10434('C', class_1802.field_27022)
                        .method_10429(method_32807(class_1802.field_27022), method_10426(class_1802.field_27022))
                        .method_10433('W', class_3489.field_15537));

        addShapedRecipe(
                class_2447.method_10436(class_7800.field_40642, StargateItems.EMPTY_CONTAINER, 1)
                        .method_10439("GIG")
                        .method_10439("G G")
                        .method_10439(" G ")
                        .method_10434('G', class_2246.field_10033)
                        .method_10434('I', class_1802.field_8620)
                        .method_10429(method_32807(class_2246.field_10033), method_10426(class_2246.field_10033))
                        .method_10429(method_32807(class_1802.field_8620), method_10426(class_1802.field_8620)));

        addShapedRecipe(
                class_2447.method_10437(class_7800.field_40636, StargateBlocks.TOASTER)
                        .method_10439("ICI")
                        .method_10439("ICI")
                        .method_10439("SRS")
                        .method_10434('I', class_1802.field_8620)
                        .method_10429(method_32807(class_1802.field_8620), method_10426(class_1802.field_8620))
                        .method_10434('C', StargateItems.COPPER_COIL)
                        .method_10429(method_32807(StargateItems.COPPER_COIL), method_10426(StargateItems.COPPER_COIL))
                        .method_10434('S', class_1802.field_8551)
                        .method_10429(method_32807(class_1802.field_8551), method_10426(class_1802.field_8551))
                        .method_10434('R', class_1802.field_8725)
                        .method_10429(method_32807(class_1802.field_8725), method_10426(class_1802.field_8725)));

        addShapedRecipe(
                class_2447.method_10436(class_7800.field_40642, StargateItems.CONTROL_CRYSTAL_RED, 1)
                        .method_10435("crystal")
                        .method_10439("DAD")
                        .method_10439("RAR")
                        .method_10439(" R ")
                        .method_10434('A', class_1802.field_27063)
                        .method_10434('R', class_1802.field_8725)
                        .method_10434('D', class_1802.field_8264)
                        .method_10429(method_32807(class_1802.field_27063), method_10426(class_1802.field_27063))
                        .method_10429(method_32807(class_1802.field_8725), method_10426(class_1802.field_8725))
                        .method_10429(method_32807(class_1802.field_8264), method_10426(class_1802.field_8264)));

        addShapedRecipe(
                class_2447.method_10436(class_7800.field_40642, StargateItems.CONTROL_CRYSTAL_YELLOW, 1)
                        .method_10435("crystal")
                        .method_10439("DAD")
                        .method_10439("RAR")
                        .method_10439(" R ")
                        .method_10434('A', class_1802.field_27063)
                        .method_10434('R', class_1802.field_8725)
                        .method_10434('D', class_1802.field_8192)
                        .method_10429(method_32807(class_1802.field_27063), method_10426(class_1802.field_27063))
                        .method_10429(method_32807(class_1802.field_8725), method_10426(class_1802.field_8725))
                        .method_10429(method_32807(class_1802.field_8192), method_10426(class_1802.field_8192)));

        addShapedRecipe(
                class_2447.method_10436(class_7800.field_40642, StargateItems.CONTROL_CRYSTAL_BLUE, 1)
                        .method_10435("crystal")
                        .method_10439("DAD")
                        .method_10439("RAR")
                        .method_10439(" R ")
                        .method_10434('A', class_1802.field_27063)
                        .method_10434('R', class_1802.field_8725)
                        .method_10434('D', class_1802.field_8345)
                        .method_10429(method_32807(class_1802.field_27063), method_10426(class_1802.field_27063))
                        .method_10429(method_32807(class_1802.field_8725), method_10426(class_1802.field_8725))
                        .method_10429(method_32807(class_1802.field_8345), method_10426(class_1802.field_8345)));

        addShapedRecipe(
                class_2447.method_10436(class_7800.field_40642, StargateItems.CONTROL_CRYSTAL_MASTER, 1)
                        .method_10435("crystal")
                        .method_10439("DAD")
                        .method_10439("RAR")
                        .method_10439(" R ")
                        .method_10434('A', class_1802.field_27063)
                        .method_10434('R', class_2246.field_10002)
                        .method_10434('D', class_1802.field_8264)
                        .method_10429(method_32807(class_1802.field_27063), method_10426(class_1802.field_27063))
                        .method_10429(method_32807(class_2246.field_10002), method_10426(class_2246.field_10002))
                        .method_10429(method_32807(class_1802.field_8264), method_10426(class_1802.field_8264)));

        addShapedRecipe(
                class_2447.method_10436(class_7800.field_40637, StargateBlocks.DHD, 1)
                        .method_10439("NPN")
                        .method_10439("BMY")
                        .method_10439("NRN")
                        .method_10434('N', StargateBlocks.NAQUADAH_BLOCK)
                        .method_10434('R', StargateItems.CONTROL_CRYSTAL_RED)
                        .method_10434('B', StargateItems.CONTROL_CRYSTAL_BLUE)
                        .method_10434('Y', StargateItems.CONTROL_CRYSTAL_YELLOW)
                        .method_10434('M', StargateItems.CONTROL_CRYSTAL_MASTER)
                        .method_10434('P', class_1802.field_8781)
                        .method_10429(method_32807(StargateBlocks.NAQUADAH_BLOCK), method_10426(StargateBlocks.NAQUADAH_BLOCK))
                        .method_10429(method_32807(StargateItems.CONTROL_CRYSTAL_RED), method_10426(StargateItems.CONTROL_CRYSTAL_RED))
                        .method_10429(method_32807(StargateItems.CONTROL_CRYSTAL_BLUE), method_10426(StargateItems.CONTROL_CRYSTAL_BLUE))
                        .method_10429(method_32807(StargateItems.CONTROL_CRYSTAL_YELLOW), method_10426(StargateItems.CONTROL_CRYSTAL_YELLOW))
                        .method_10429(method_32807(StargateItems.CONTROL_CRYSTAL_MASTER), method_10426(StargateItems.CONTROL_CRYSTAL_MASTER))
                        .method_10429(method_32807(class_1802.field_8781), method_10426(class_1802.field_8781)));
    }
}
