package dev.amble.stargate.api.state.stargate;

import dev.amble.stargate.StargateMod;
import net.minecraft.class_2960;

public class MilkyWayState extends GateIdentityState implements C8Gates {

    public static final class_2960 ID = StargateMod.id("milky_way");

    public MilkyWayState() {
        super(ID);
    }
}
