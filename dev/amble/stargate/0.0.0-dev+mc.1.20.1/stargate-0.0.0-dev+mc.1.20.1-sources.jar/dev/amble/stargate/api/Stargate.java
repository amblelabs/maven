package dev.amble.stargate.api;

import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.event.init.StargateLoadedEvents;
import dev.amble.stargate.api.event.init.StargateUpdateEvents;
import dev.amble.stargate.api.event.tick.StargateTickEvent;
import dev.amble.stargate.api.event.state.StateAddedEvent;
import dev.amble.stargate.api.event.state.StateRemovedEvent;
import dev.amble.stargate.api.state.GateState;
import dev.amble.stargate.api.state.address.GlobalAddressState;
import dev.amble.stargate.api.state.stargate.GateIdentityState;
import dev.amble.stargate.init.StargateBlocks;
import dev.amble.stargate.init.StargateYAARs;
import dev.amble.stargate.service.Services;
import dev.drtheo.yaar.event.TEvents;
import dev.drtheo.yaar.state.NbtSerializer;
import dev.drtheo.yaar.state.TState;
import dev.drtheo.yaar.state.TStateContainer;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2481;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class Stargate extends TStateContainer.Delegate implements NbtSerializer, StargateLike {

    protected final class_5321<class_1937> dimension;
    protected final class_2338 pos;
    protected final class_2350 facing;

    protected TState.Type<? extends GateState<?>> curState;

    protected final boolean isClient;
    protected boolean dirty;

    protected Stargate(GateIdentityState identity, class_3218 world, class_2338 pos, class_2350 direction) {
        super(StargateYAARs.States.createArrayHolder());

        this.isClient = false;

        this.dimension = world.method_27983();
        this.pos = pos;
        this.facing = direction;

        identity.shape.place(StargateBlocks.RING.method_9564(), world, pos, direction);
        this.addState(identity);

        this.setGateState(this.fallbackGateState());
    }

    public static Stargate fromNbt(class_2487 nbt, boolean isClient) {
        class_2960 id = new class_2960(nbt.method_10558("Id"));
        return GateKernelRegistry.get().method_10223(id).load(nbt, isClient);
    }

    public Stargate(GateIdentityState identity, class_2487 nbt, boolean isClient) {
        super(StargateYAARs.States.createArrayHolder());

        this.isClient = isClient;

        class_2487 pos = nbt.method_10562("Pos");
        this.dimension = class_5321.method_29179(class_7924.field_41223, new class_2960(pos.method_10558("dimension")));
        this.pos = class_2512.method_10691(pos);
        this.facing = class_2350.method_10143(pos.method_10571("facing"));

        this.addState(identity);
        this.updateStates(nbt, isClient);

        StargateLoadedEvents.handleLoad(this);
    }

    public void tick() {
        TEvents.handle(new StargateTickEvent(this));
    }

    @Override
    public @NotNull Stargate asGate() {
        return this;
    }

    public boolean isClient() {
        return isClient;
    }

    public GateIdentityState kernel() {
        return resolveState(GateIdentityState.state);
    }

    public long globalAddress() {
        return resolveState(GlobalAddressState.state).address();
    }

    public long globalId() {
        return resolveState(GlobalAddressState.state).getAsLong();
    }

    //region Gate state
    public @NotNull TState.Type<? extends GateState<?>> getGateStateType() {
        return curState;
    }

    public @NotNull GateState<?> getGateState() {
        return (GateState<?>) stateOrNull((TState.Type<?>) curState);
    }

    public void setGateState(GateState<?> state) {
        this.curState = state.type();
        this.addState(state);
    }
    //endregion

    //region Global position stuff
    public class_5321<class_1937> dimension() {
        return dimension;
    }

    // optimize using WeakReference if this causes a bottleneck
    public @Nullable class_1937 world() {
        return Services.WORLDS.getWorld(dimension, isClient);
    }

    public void playSound(class_3414 event) {
        this.world().method_45447(null, this.pos(), event, class_3419.field_15245);
    }

    public class_2338 pos() {
        return pos;
    }

    public class_2350 facing() {
        return facing;
    }
    //endregion

    //region State handling & serialization
    public boolean dirty() {
        return dirty;
    }

    public void markDirty() {
        this.dirty = true;
    }

    public void unmarkDirty() {
        this.dirty = false;
    }

    public void updateStates(class_2487 nbt, boolean isClient) {
        class_2487 states = nbt.method_10562("States");

        for (String key : states.method_10541()) {
            if (StargateYAARs.States.get(new class_2960(key)) instanceof TState.NbtBacked<?> serializable) {
                class_2520 state = states.method_10580(key);

                if (state instanceof class_2487 compound) {
                    this.addState(serializable.decode(compound, isClient));
                } else {
                    this.removeState(serializable);
                }
            }
        }

        class_2960 prevStateId = new class_2960(nbt.method_10558("prevState"));
        TState.Type<?> type = StargateYAARs.States.get(prevStateId);

        if (type == null || this.stateOrNull(type) == null) {
            StargateMod.LOGGER.warn("Bad state: '{}', fixing", prevStateId);
            this.setGateState(this.fallbackGateState());

            StargateUpdateEvents.handleUpdate(this);
            return;
        }

        StargateUpdateEvents.handleUpdate(this);
        //noinspection unchecked - trust me bro
        this.curState = (TState.Type<? extends GateState<?>>) type;
    }

    private GateState<?> fallbackGateState() {
        return new GateState.Closed();
    }

    @Override
    @Contract(mutates = "this")
    public boolean addState(@NotNull TState<?> state) {
        boolean result = super.addState(state);

        if (result)
            TEvents.handle(new StateAddedEvent(this, state));

        return result;
    }

    @Override
    @Contract(mutates = "this")
    public <T extends TState<T>> @Nullable T removeState(@NotNull TState.Type<T> type) {
        T result = super.removeState(type);

        if (result != null)
            TEvents.handle(new StateRemovedEvent(this, result));

        return result;
    }

    @Contract(mutates = "this")
    public <T extends TState<T>> @Nullable T removeState(@NotNull T state) {
        return this.removeState(state.type());
    }

    @Override
    public void toNbt(@NotNull class_2487 nbt, boolean isClient) {
        nbt.method_10582("Id", this.kernel().id.toString());

        class_2487 pos = class_2512.method_10692(this.pos);
        pos.method_10582("dimension", this.dimension.method_29177().toString());
        pos.method_10567("facing", (byte) this.facing.method_10146());
        nbt.method_10566("Pos", pos);

        class_2487 states = new class_2487();
        this.forEachState((i, state) -> stateToNbt(states, i, state, isClient));

        nbt.method_10566("States", states);
        nbt.method_10582("prevState", this.curState.id().toString());
    }

    @SuppressWarnings("rawtypes")
    private <T extends TState<T>> void stateToNbt(class_2487 nbt, int i, @Nullable TState<T> state, boolean isClient) {
        if (state == null) {
            // do the diffing only if we're serializing for client
            if (isClient) nbt.method_10566(StargateYAARs.States.get(i).id().toString(), class_2481.field_21026);

            return;
        }

        TState.Type<T> type = state.type();

        if (!(type instanceof TState.NbtBacked backed))
            return;

        //noinspection unchecked
        nbt.method_10566(type.id().toString(), backed.encode(state, isClient));
    }
    //endregion

    @Override
    public int hashCode() {
        return pos.hashCode();
    }
}
