package dev.amble.stargate.mixins;

import dev.amble.modkit.api.BoatTypeRegistry;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1690.class, priority = 999)
public abstract class BoatEntityMixin {

    @Shadow public abstract class_1690.class_1692 getVariant();

    @Inject(method = "asItem", at = @At("HEAD"), cancellable = true)
    public void asItem(CallbackInfoReturnable<class_1792> cir) {
        class_1792 item = BoatTypeRegistry.getItem(this.getVariant(), false);

        if (item != null)
            cir.setReturnValue(item);
    }
}
