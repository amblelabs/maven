package dev.amble.stargate.api.state.stargate;

import dev.amble.stargate.StargateMod;
import net.minecraft.class_2960;

public class DestinyState extends GateIdentityState {

    public static final class_2960 ID = StargateMod.id("destiny");

    public DestinyState() {
        super(ID);
    }
}
