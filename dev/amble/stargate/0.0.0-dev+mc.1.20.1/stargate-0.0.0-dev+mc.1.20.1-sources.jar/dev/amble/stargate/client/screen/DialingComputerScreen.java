package dev.amble.stargate.client.screen;

import dev.amble.stargate.StargateMod;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class DialingComputerScreen extends class_437 {

    private static final class_2960 TEXTURE = StargateMod.id("textures/gui/dialing_computer.png");

    private static final int bgHeight = 154;
    private static final int bgWidth = 256;

    private static final int bgBorder = 9;

    public DialingComputerScreen() {
        super(class_2561.method_43471("screen.stargate.computer.title"));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        int top = (this.field_22790 - bgHeight) / 2;
        int left = (this.field_22789 - bgWidth) / 2;

        context.method_25302(TEXTURE, left, top, 0, 0, bgWidth, bgHeight);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // close when E is pressed
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }

        if (field_22787.field_1690.field_1822.method_1417(keyCode, scanCode)) {
            this.method_25419();
            return true;
        }

        return false;
    }
}
