package dev.amble.stargate.api.event.block;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.drtheo.yaar.event.TEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public interface StargateBlockUseEvents extends TEvents {

    Type<StargateBlockUseEvents> event = new Type<>(StargateBlockUseEvents.class);

    boolean onUse(Stargate stargate, StargateBlockEntity blockEntity, class_1657 player, class_1937 world, class_2680 state, class_2338 pos, class_1268 hand, class_3965 blockHit);
}
