package dev.amble.stargate.api.behavior;

import dev.amble.lib.util.ServerLifecycleHooks;
import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.ServerStargate;
import dev.amble.stargate.api.event.tp.StargateTpEvent;
import dev.amble.stargate.api.event.tp.StargateTpEvents;
import dev.amble.stargate.init.StargateCriterions;
import dev.drtheo.yaar.behavior.TBehavior;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_161;
import net.minecraft.class_3222;

public class StargateTpEffectsBehavior implements TBehavior, StargateTpEvents {

    private static class_161 PASSED_THROUGH_GATE;

    private static class_161 getPassThroughAdv() {
        return PASSED_THROUGH_GATE == null ? PASSED_THROUGH_GATE = ServerLifecycleHooks.get().method_3851().method_12896(StargateMod.id("passed_through")) : PASSED_THROUGH_GATE;
    }

    public static boolean hasPassedThroughBefore(class_3222 player) {
        return player.method_14236().method_12882(getPassThroughAdv()).method_740();
    }

    @Override
    public StargateTpEvent.Result onGateTp(ServerStargate from, ServerStargate to, class_1309 living) {
        if (living instanceof class_3222 player && !hasPassedThroughBefore(player)) {
            player.method_6092(new class_1293(class_1294.field_5916, 20 * 4,
                    2, false, false, true));

            StargateCriterions.PASSED_THROUGH.trigger(player);
        }

        if (living.method_32316())
            living.method_32317(100);

        return StargateTpEvent.Result.PASS;
    }
}
