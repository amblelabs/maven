package dev.amble.stargate.api.address;

import it.unimi.dsi.fastutil.ints.IntArraySet;
import it.unimi.dsi.fastutil.ints.IntSet;
import java.security.SecureRandom;
import net.minecraft.class_1937;
import net.minecraft.class_3532;
import net.minecraft.class_5321;

public class AddressProvider {

    static final int BITS_PER_COORD = getBitsNeeded(Glyph.ALPHABET_LENGTH);
    static final int MASK = (1 << BITS_PER_COORD) - 1;

    private static int getBitsNeeded(int max) {
        return class_3532.method_15384(Math.log(max) / Math.log(2));
    }

    private static int readAt(long address, int index) {
        int shift = index * BITS_PER_COORD;
        return (int) ((address >> shift) & MASK) - 1;
    }

    private static long packI(int index, int value) {
        return packI(index, (long) value);
    }

    private static long packI(int index, long value) {
        int shift = index * BITS_PER_COORD;
        return ((value + 1) << shift);
    }

    public static long pack(String address, int len) {
        char[] chars = address.toCharArray();
        int[] nums = new int[len];

        for (int i = 0; i < len; i++) {
            nums[i] = Glyph.charToIdx(chars[i]);
        }

        return pack(nums, Glyph.ALPHABET_LENGTH);
    }

    public static long pack(int[] numbers) {
        return pack(numbers, Glyph.ALPHABET_LENGTH);
    }

    public static int length(long address) {
        return (63 - Long.numberOfLeadingZeros(address)) / BITS_PER_COORD + 1;
    }

    public static String asString(long packed, int len) {
        char[] chars = new char[len];

        for (int i = 0; i < len; i++) {
            chars[i] = Glyph.ALL[AddressProvider.readAt(packed, i)];
        }

        return new String(chars);
    }

    public static long pack(int[] numbers, int k) {
        if (numbers.length == 0) throw new IllegalArgumentException();

        // Validate input
        int maxPossible = (1 << BITS_PER_COORD) - 1;

        for (int num : numbers) {
            if (num < 0 || num > k)
                throw new IllegalArgumentException("Number " + num + " is not in range [0, " + k + "]");

            if (num > maxPossible)
                throw new IllegalArgumentException("Number " + num + " requires more than " + BITS_PER_COORD + " bits");
        }

        // Check if we can fit all numbers in a single long
        if ((long) numbers.length * BITS_PER_COORD > 64) {
            throw new IllegalArgumentException("Cannot pack " + numbers.length + " numbers with " +
                    BITS_PER_COORD + " bits each in a single long (64 bits total)");
        }

        long packed = 0L;

        // Pack numbers from right to left (least significant to most significant)
        for (int i = 0; i < numbers.length; i++) {
            packed |= packI(i, numbers[i]);
        }

        return packed;
    }

    // 1 target (z) + 1 origin (y) + 6 id (x)
    // [xxxxxx][y][z]
    //  012345  6  7
    public static class Local extends AddressProvider {

        // TODO: set random seed to world seed maybe?
        private static final SecureRandom RANDOM = new SecureRandom();

        static final long ID_MASK = (1L << BITS_PER_COORD * 6) - 1;

        public static long getId(long packed) {
            return packed & ID_MASK;
        }

        public static char getTargetChar(long packed) {
            return Glyph.ALL[AddressProvider.readAt(packed, 6)];
        }

        public static class_5321<class_1937> getTarget(long packed) {
            return GlyphOriginRegistry.get().dimForGlyph(getTargetChar(packed));
        }

        public static char getOriginChar(long packed) {
            return Glyph.ALL[AddressProvider.readAt(packed, length(packed) - 1)];
        }

        // FIXME: make this better, maybe?
        public static long generate(class_5321<class_1937> world) {
            IntSet set = new IntArraySet();

            char poi = GlyphOriginRegistry.get().glyphForDim(world);
            int poiI = Glyph.charToIdx(poi);

            while (set.size() != 5) {
                int a = RANDOM.nextInt(Glyph.ALPHABET_LENGTH);

                if (a == poiI)
                    continue;

                set.add(a);
            }

            long packed = pack(set.toArray(new int[0]));
            return packed | AddressProvider.packI(6, poiI);
        }
    }

    // 1 target (y) + 6 id (x)
    // [xxxxxxxx][y]
    //  01234567  8
    public static class Global extends AddressProvider {

        // TODO: set random seed to world seed maybe?
        private static final SecureRandom RANDOM = new SecureRandom();

        static final long ID_MASK = (1L << BITS_PER_COORD * 8) - 1;

        public static long getId(long packed) {
            return packed & ID_MASK;
        }

        public static char getTargetChar(long packed) {
            return Glyph.ALL[AddressProvider.readAt(packed, 8)];
        }

        public static class_5321<class_1937> getTarget(long packed) {
            return GlyphOriginRegistry.get().dimForGlyph(getTargetChar(packed));
        }

        /// FIXME: make this better, maybe?
        public static long generate(class_5321<class_1937> dim) {
            IntSet set = new IntArraySet();

            char poi = GlyphOriginRegistry.get().glyphForDim(dim);
            int poiI = Glyph.charToIdx(poi);

            while (set.size() != 8) {
                int a = RANDOM.nextInt(Glyph.ALPHABET_LENGTH);

                if (a == poiI)
                    continue;

                set.add(a);
            }

            long packed = pack(set.toArray(new int[0]));
            return packed | AddressProvider.packI(8, poiI);
        }

        public static String asString(long packed) {
            return AddressProvider.asString(packed, 9);
        }
    }
}