package dev.amble.stargate.service;

import net.minecraft.class_1836;

public interface TooltipService {

    default TooltipContextExt create(class_1836 context) {
        throw new IllegalStateException("Tried to create extended tooltip context on server!");
    }
}
