package dev.amble.stargate.init;

import dev.amble.stargate.StargateMod;
import net.minecraft.class_1282;
import net.minecraft.class_1937;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public class StargateDamages {

    public static final class_5321<class_8110> FLOW = of("flow");

    public static class_1282 flow(class_1937 world) {
        return of(world, FLOW);
    }

    public static class_1282 of(class_1937 world, class_5321<class_8110> key) {
        return new class_1282(world.method_30349().method_30530(class_7924.field_42534).method_40290(key));
    }

    private static class_5321<class_8110> of(String name) {
        return class_5321.method_29179(class_7924.field_42534, StargateMod.id(name));
    }
}
