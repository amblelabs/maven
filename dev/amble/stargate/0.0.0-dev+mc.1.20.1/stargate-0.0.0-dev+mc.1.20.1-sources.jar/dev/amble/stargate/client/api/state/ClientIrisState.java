package dev.amble.stargate.client.api.state;

import dev.amble.stargate.StargateMod;
import dev.drtheo.yaar.state.TState;
import net.minecraft.class_7094;

public class ClientIrisState implements TState<ClientIrisState> {

    public static final Type<ClientIrisState> state = new Type<>(StargateMod.id("iris/client"));

    public final class_7094 CLOSE_STATE = new class_7094();
    public final class_7094 OPEN_STATE = new class_7094();

    public int ticks;
    public boolean stopOpening;

    @Override
    public Type<ClientIrisState> type() {
        return state;
    }
}
