package dev.amble.stargate.init;

import dev.amble.lib.container.impl.SoundContainer;
import dev.amble.stargate.StargateMod;
import net.minecraft.class_3414;

public class StargateSounds implements SoundContainer {
	public static final class_3414 GATE_OPEN = create("gate_open");
	public static final class_3414 GATE_CLOSE = create("gate_close");
	public static final class_3414 GATE_FAIL = create("gate_fail");
	public static final class_3414 GATE_TELEPORT = create("gate_teleport");
	public static final class_3414 WORMHOLE_LOOP = create("wormhole_loop");
	public static final class_3414 CHEVRON_LOCK = create("chevron_lock");
	public static final class_3414 RING_LOOP = create("ring_loop");
	public static final class_3414 RING_START = create("ring_start");
	public static final class_3414 DHD_PRESS = create("dhd_press");

	// Toaster
	public static final class_3414 TOASTER = create("toaster");
	public static final class_3414 TOASTER_ACTIVE = create("toaster_active");
	public static final class_3414 DING = create("ding");

	// Iris
	public static final class_3414 IRIS_HIT = create("iris_hit");
	public static final class_3414 IRIS_CLOSE = create("iris_close");
	public static final class_3414 IRIS_OPEN = create("iris_open");

	public static class_3414 create(String name) {
		return class_3414.method_47908(StargateMod.id(name));
	}
}
