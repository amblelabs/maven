package dev.amble.stargate.api.behavior;

import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.lib.util.TeleportUtil;
import dev.amble.stargate.api.ServerStargate;
import dev.amble.stargate.api.address.Glyph;
import dev.amble.stargate.util.TeleportableEntity;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.event.tick.StargateTickEvents;
import dev.amble.stargate.api.event.tp.StargateTpEvent;
import dev.amble.stargate.api.event.address.AddressResolveEvent;
import dev.amble.stargate.api.event.block.StargateBlockTickEvents;
import dev.amble.stargate.api.event.state.gate.StargateGateStateEvents;
import dev.amble.stargate.api.state.GateState;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.init.StargateSounds;
import dev.drtheo.yaar.behavior.Resolve;
import dev.drtheo.yaar.behavior.TBehavior;
import dev.drtheo.yaar.behavior.TBehaviorRegistry;
import dev.drtheo.yaar.event.TEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.util.math.*;
import java.util.List;

public interface GenericGateBehaviors {

    static void registerAll() {
        TBehaviorRegistry.register(Closed::new);
        TBehaviorRegistry.register(Opening::new);
        TBehaviorRegistry.register(Open::new);
    }

    class Closed implements TBehavior, StargateTickEvents {

        @Resolve
        private final GateManagerBehavior manager = behavior();

        @Override
        public void tick(Stargate someGate) {
            GateState.Closed closed = someGate.state(GateState.Closed.state);

            if (!(someGate instanceof ServerStargate stargate)) {
                if (closed.locking)
                    closed.timer = (closed.timer + 1) % calculateDelay(closed);

                return;
            }

            int length = closed.address.length();
            closed.locking = length > closed.locked;

            // fixup broken state
            if (length < closed.locked) {
                closed.locked = length;
                closed.timer = 0;

                stargate.markDirty();
                return;
            }

            if (!closed.locking || closed.timer++ < GateState.Closed.TICKS_PER_GLYPH2) return;

            closed.timer = 0;
            closed.locked++;

            stargate.playSound(StargateSounds.CHEVRON_LOCK);
            stargate.markDirty();

            // TODO: add energy handling.
            AddressResolveEvent.Result resolved = TEvents.handle(new AddressResolveEvent(stargate, closed.address, closed.locked));

            if (!(resolved instanceof AddressResolveEvent.Result.Route route)) {
                // if FAILed *OR* PASSed through all resolvers with no result and the address length >= to max chevrons of this gate, then fail
                if (resolved instanceof AddressResolveEvent.Result.Fail || closed.locked >= stargate.kernel().maxChevrons)
                    this.fail(stargate);

                return;
            }

            manager.set(stargate, new GateState.Opening(route.stargate(), true));
            manager.set(route.stargate(), new GateState.Opening(null, false));

            route.stargate().markDirty();
        }

        public static int calculateDelay(int curGlyph, int nextGlyph) {
            return Math.abs(nextGlyph - curGlyph) * GateState.Closed.TICKS_PER_GLYPH;
        }

        public static int calculateDelay(GateState.Closed closed) {
            char curGlyph = closed.locked != 0 ? closed.address.charAt(closed.locked - 1) : (char) (Glyph.ALL.length / 2);
            char nextGlyph = closed.address.charAt(closed.locked);

            return calculateDelay(
                    Glyph.charToIdx(curGlyph),
                    Glyph.charToIdx(nextGlyph)
            );
        }

        public void fail(Stargate stargate) {
            stargate.playSound(StargateSounds.GATE_FAIL);
            manager.set(stargate, new GateState.Closed());
        }
    }

    class Opening implements TBehavior, StargateGateStateEvents, StargateTickEvents {

        static final float p0 = 0;
        static final float p1 = 22;
        static final float p2 = -12;
        static final float p3 = 0;

        @Override
        public void onStateChanged(Stargate stargate, GateState<?> oldState, GateState<?> newState) {
            if (newState.gateState() == GateState.StateType.OPENING)
                stargate.playSound(StargateSounds.GATE_OPEN);
        }

        @Resolve
        private final GateManagerBehavior manager = behavior();

        @Override
        public void tick(Stargate stargate) {
            GateState.Opening opening = stargate.state(GateState.Opening.state);

            // Adjust Bezier control points and t-mapping to linger longer near p1 and p2
            float t = (float) opening.timer / (GateState.Opening.TICKS_PER_KAWOOSH * 1.25f);

            // Remap t to ease in and out, spending more time near p1 and p2
            // Use a custom curve: t' = 3t^2 - 2t^3 (smoothstep), then stretch the middle
            float tPrime = class_3532.method_15363((float) (3 * Math.pow(t, 2) - 2 * Math.pow(t, 3)), 0, 1);

            opening.kawooshHeight = (float) (
                    Math.pow(1 - tPrime, 3) * p0 +
                            3 * Math.pow(1 - tPrime, 2) * tPrime * p1 +
                            3 * (1 - tPrime) * Math.pow(tPrime, 2) * p2 +
                            Math.pow(tPrime, 3) * p3
            );

            if (opening.timer++ <= GateState.Opening.TICKS_PER_KAWOOSH || tPrime != 1) return;

            opening.kawooshHeight = 0;
            opening.timer = 0;

            if (stargate.isClient()) return;

            // Handle missing gates by address gracefully
            if (opening.caller && opening.target != null) {
                // TODO: add distance/protocol compat checks here
                manager.set(stargate, new GateState.Open(opening.target, true));
                manager.set(opening.target, new GateState.Open(stargate, false));
            } else {
                manager.set(stargate, new GateState.Closed());
            }
        }
    }

    class Open implements TBehavior, StargateTickEvents, StargateBlockTickEvents, StargateGateStateEvents {

        @Resolve
        private final GateManagerBehavior manager = behavior();

        @Override
        public void onStateChanged(Stargate stargate, GateState<?> oldState, GateState<?> newState) {
            if (oldState.gateState() == GateState.StateType.OPEN
                    && newState.gateState() == GateState.StateType.CLOSED)
                stargate.playSound(StargateSounds.GATE_CLOSE);
        }

        @Override
        public void tick(Stargate stargate) {
            if (stargate.isClient()) return;

            GateState.Open open = stargate.state(GateState.Open.state);

            // handle abnormal state
            if (open.target == null) {
                manager.set(stargate, new GateState.Closed());
                return;
            }

            if (open.timer++ > GateState.Open.TICKS_PER_OPEN) {
                open.timer = 0;

                manager.set(stargate, new GateState.Closed());
                manager.set(open.target, new GateState.Closed());
            }
        }

        @Override
        public void block$randomDisplayTick(Stargate stargate, class_1937 world, class_2338 pos, class_2680 state, class_5819 random) {
            if (random.method_43048(100) < 5) {
                world.method_45447(null, pos, StargateSounds.WORMHOLE_LOOP, class_3419.field_15245);
            }
        }

        @Override
        public void block$tick(Stargate someGate, StargateBlockEntity entity, class_1937 world, class_2338 pos, class_2680 state) {
            if (!(someGate instanceof ServerStargate stargate)) return;
            if (world.method_8510() % GateState.Open.TELEPORT_FREQUENCY != 0) return;

            class_2350 facing = HorizontalBlockBehavior.getFacing(state);
            class_238 box = stargate.kernel().forDirection(facing).method_996(pos);

            GateState.Open open = stargate.state(GateState.Open.state);
            List<class_1297> entities = world.method_8333(null, box, e -> e.method_5805() && !e.method_7325());

            for (class_1297 e : entities) {
                if (e instanceof class_1309 living)
                    tryTeleportFrom(stargate, open, living);
            }
        }

        public void tryTeleportFrom(ServerStargate stargate, GateState.Open open, class_1309 entity) {
            if (!(entity instanceof TeleportableEntity holder) || holder.stargate$updateAndGetTicks(GateState.Open.TELEPORT_DELAY) != 0)
                return;

            ServerStargate target = (ServerStargate) open.target;
            if (target == null) return; // this is most likely false, since we do a check every tick, but just in case...

            class_2338 targetBlockPos = target.pos();
            class_3218 targetWorld = target.world();

            StargateTpEvent.Result result = TEvents.handle(new StargateTpEvent(stargate, target, entity));
            if (result == StargateTpEvent.Result.DENY) return;

            class_2338 pos = stargate.pos();
            class_243 offset = entity.method_19538().method_1020(pos.method_46558().method_1023(0, 0.5, 0));

            entity.method_37908().method_8396(null, pos, StargateSounds.GATE_TELEPORT, class_3419.field_15245, 1f, 1);
            targetWorld.method_8396(null, targetBlockPos, StargateSounds.GATE_TELEPORT, class_3419.field_15245, 1f, 1);

            // Retain entity velocity but reorient it towards the target stargate
            class_243 velocity = entity.method_18798();
            class_243 direction = targetBlockPos.method_46558().method_1020(pos.method_46558()).method_1029();

            double speed = velocity.method_1033();
            class_243 newVelocity = direction.method_1021(speed);

            TeleportUtil.teleport(entity, targetWorld,
                    targetBlockPos.method_46558().method_1019(offset)/*.add(0, yOffset, 0)*/,
                    target.facing().method_10144()
            );

            entity.method_18799(newVelocity);
            holder.stargate$setTicks(GateState.Open.TELEPORT_DELAY);
        }
    }
}
