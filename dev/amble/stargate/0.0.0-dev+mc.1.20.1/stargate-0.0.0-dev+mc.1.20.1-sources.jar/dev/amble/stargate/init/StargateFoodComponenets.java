package dev.amble.stargate.init;


import net.minecraft.class_4174;

public class StargateFoodComponenets {

    public static final class_4174 TOAST = new class_4174.class_4175()
            .method_19238(2)
            .method_19237(0.1f)
            .method_19241()
            .method_19242();
}
