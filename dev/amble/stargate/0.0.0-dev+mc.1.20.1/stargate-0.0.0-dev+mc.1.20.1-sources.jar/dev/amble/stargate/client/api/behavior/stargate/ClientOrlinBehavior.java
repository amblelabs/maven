package dev.amble.stargate.client.api.behavior.stargate;

import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.event.init.StargateLoadedEvents;
import dev.amble.stargate.api.state.GateState;
import dev.amble.stargate.api.state.stargate.OrlinState;
import dev.amble.stargate.client.api.state.stargate.ClientOrlinState;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.client.renderers.StargateBlockEntityRenderer;
import dev.amble.stargate.client.util.EmissionUtil;
import net.minecraft.class_3695;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;

public class ClientOrlinBehavior extends ClientAbstractStargateBehavior<ClientOrlinState> implements StargateLoadedEvents {

    public ClientOrlinBehavior() {
        super(OrlinState.class, ClientOrlinState.class);
    }

    @Override
    protected ClientOrlinState createClientState(Stargate stargate) {
        return new ClientOrlinState();
    }

    @Override
    protected void customRender(Stargate stargate, ClientOrlinState clientState, StargateBlockEntity entity, StargateBlockEntityRenderer renderer, class_3695 profiler, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay, float tickDelta) {
        matrices.method_46416(0.5f, 1.5f, 0.5f);

        float k = HorizontalBlockBehavior.getFacing(entity.method_11010()).method_10144();

        matrices.method_22907(class_7833.field_40715.rotationDegrees(k));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(180f));
        matrices.method_22905(1, 1, 1);

        boolean bl = stargate.getGateState().gateState() != GateState.StateType.CLOSED;
        EmissionUtil.render2Layers(clientState.model(), clientState.texture, clientState.emission, bl, matrices, vertexConsumers, light, overlay);
    }
}
