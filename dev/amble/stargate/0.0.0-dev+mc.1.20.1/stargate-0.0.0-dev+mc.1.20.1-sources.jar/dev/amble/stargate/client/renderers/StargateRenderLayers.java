package dev.amble.stargate.client.renderers;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import java.util.function.BiFunction;

@Environment(EnvType.CLIENT)
public abstract class StargateRenderLayers extends class_1921 {

    private static final BiFunction<class_2960, Boolean, class_1921> EMISSIVE_CULL_Z_OFFSET = class_156
            .method_34865((texture, affectsOutline) -> {
                class_4668.class_4683 texture2 = new class_4668.class_4683(texture, false, false);
                class_4688 multiPhaseParameters = class_1921.class_4688.method_23598()
                        .method_34578(class_4668.field_29414)
                        .method_34577(texture2)
                        .method_23603(field_21345)
                        .method_23615(class_4668.field_21370)
                        .method_23607(class_4668.field_22241)
                        .method_23608(field_21383)
                        .method_23616(field_21350)
                        .method_23604(class_4668.field_21348)
                        .method_23617(false);
                return class_1921.method_24049("emissive_cull_z_offset",
                        class_290.field_1580, class_293.class_5596.field_27382, 256,
                        false, true, multiPhaseParameters);
            });

    public StargateRenderLayers(String name, class_293 vertexFormat, class_293.class_5596 drawMode, int expectedBufferSize, boolean hasCrumbling, boolean translucent, Runnable startAction, Runnable endAction) {
        super(name, vertexFormat, drawMode, expectedBufferSize, hasCrumbling, translucent, startAction, endAction);
    }

    public static class_1921 emissiveCullZOffset(class_2960 texture, boolean affectsOutline) {
        return EMISSIVE_CULL_Z_OFFSET.apply(texture, affectsOutline);
    }
}
