package dev.amble.stargate.client.animations;// Save this class in your mod and generate all required imports

import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;

/**
 * @author Loqor
 */
public class StargateAnimations {
	public static final class_7184 IRIS_CLOSE = class_7184.class_7185.method_41818(3.0F)
			.method_41820("blade1", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade1", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade5", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade5", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade9", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade9", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade13", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade13", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade17", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade17", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade3", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade3", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade7", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade7", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade11", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade11", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade15", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade15", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade2", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade2", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade4", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade4", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade6", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade6", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade8", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade8", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade10", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade10", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade12", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade12", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade14", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade14", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade16", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade16", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade18", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade18", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(0.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41821();

	public static final class_7184 LOCK_SYMBOL = class_7184.class_7185.method_41818(2.3333F)
			.method_41820("chev7", new class_7179(class_7179.class_7183.field_37886,
					new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.5F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(1.0F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(1.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			))
			.method_41820("chev_light7", new class_7179(class_7179.class_7183.field_37886,
					new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.5F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(1.0F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(1.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			))
			.method_41820("chev7bottom", new class_7179(class_7179.class_7183.field_37886,
					new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.5F, class_7187.method_41823(0.0F, 1.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(1.0F, class_7187.method_41823(0.0F, 1.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(1.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			))
			.method_41820("chev_light7bottom", new class_7179(class_7179.class_7183.field_37886,
					new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.5F, class_7187.method_41823(0.0F, 1.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(1.0F, class_7187.method_41823(0.0F, 1.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(1.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			))
			.method_41821();

	public static final class_7184 IRIS_OPEN = class_7184.class_7185.method_41818(3.0F)
			.method_41820("blade1", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade1", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade5", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade5", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade9", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade9", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade13", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade13", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade17", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade17", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade3", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade3", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade7", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade7", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade11", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade11", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade15", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade15", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade2", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade2", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade4", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade4", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade6", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade6", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade8", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade8", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade10", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade10", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade12", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade12", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade14", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade14", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade16", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade16", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade18", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -67.5F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("blade18", new class_7179(class_7179.class_7183.field_37888,
					new class_7186(2.25F, class_7187.method_41822(1.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41822(0.0F, 1.0F, 1.0F), class_7179.class_7181.field_37885)
			))
			.method_41821();
}