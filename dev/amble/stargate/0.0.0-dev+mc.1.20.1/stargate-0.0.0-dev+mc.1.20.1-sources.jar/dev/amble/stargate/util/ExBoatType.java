package dev.amble.stargate.util;

import dev.amble.lib.util.LazyObject;
import net.minecraft.class_1690;

public interface ExBoatType {

    LazyObject<class_1690.class_1692> NAQUADAH = new LazyObject<>(() -> class_1690.class_1692.method_7561("naquadah"));
}
