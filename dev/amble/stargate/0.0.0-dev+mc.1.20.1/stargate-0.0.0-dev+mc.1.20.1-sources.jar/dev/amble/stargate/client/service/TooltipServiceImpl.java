package dev.amble.stargate.client.service;

import dev.amble.stargate.service.TooltipContextExt;
import dev.amble.stargate.service.TooltipService;
import net.minecraft.class_1836;
import net.minecraft.class_437;

public class TooltipServiceImpl implements TooltipService {

    @Override
    public TooltipContextExt create(class_1836 context) {
        return new TooltipContextExtImpl(context);
    }

    private record TooltipContextExtImpl(class_1836 ctx) implements TooltipContextExt {

        @Override
            public boolean isShiftDown() {
                return class_437.method_25442();
            }

            @Override
            public boolean isAltDown() {
                return class_437.method_25443();
            }

            @Override
            public boolean isControlDown() {
                return class_437.method_25441();
            }

            @Override
            public boolean method_8035() {
                return ctx.method_8035();
            }

            @Override
            public boolean method_47370() {
                return ctx.method_47370();
            }
        }
}
