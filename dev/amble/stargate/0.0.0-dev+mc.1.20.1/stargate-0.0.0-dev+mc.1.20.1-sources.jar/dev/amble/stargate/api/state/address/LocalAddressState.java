package dev.amble.stargate.api.state.address;

import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.address.AddressProvider;
import dev.drtheo.yaar.state.NbtSerializer;
import dev.drtheo.yaar.state.TState;
import org.jetbrains.annotations.NotNull;

import java.util.function.LongSupplier;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_5321;

public record LocalAddressState(long address) implements TState<LocalAddressState>, NbtSerializer, LongSupplier {

    public static final Type<LocalAddressState> state = new NbtBacked<>(StargateMod.id("address/local")) {

        @Override
        public LocalAddressState fromNbt(@NotNull class_2487 nbt, boolean isClient) {
            return new LocalAddressState(nbt.method_10537("address"));
        }
    };

    public LocalAddressState(class_5321<class_1937> world, class_2338 pos) {
        this(AddressProvider.Local.generate(world));
    }

    @Override
    public Type<LocalAddressState> type() {
        return state;
    }

    @Override
    public void toNbt(@NotNull class_2487 nbt, boolean isClient) {
        nbt.method_10544("address", address);
    }

    @Override
    public long getAsLong() {
        return AddressProvider.Local.getId(address);
    }
}
