package dev.amble.stargate.service;

import dev.amble.stargate.api.data.StargateData;
import dev.amble.stargate.api.data.StargateServerData;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1937;
import net.minecraft.class_3218;

public interface StargateDataProviderService {

    default StargateData<?> getClient() {
        throw new RuntimeException(new IllegalAccessException("Tried to access client stargate data on server!"));
    }

    default @Nullable StargateData<?> get(class_1937 world) {
        return world instanceof class_3218 serverWorld ? StargateServerData.get(serverWorld) : getClient();
    }

    default void accept(class_1937 world, Consumer<StargateData<?>> consumer) {
        if (world instanceof class_3218 serverWorld) {
            StargateServerData.accept(serverWorld, consumer::accept);
        } else {
            consumer.accept(getClient());
        }
    }

    default <R> @Nullable R apply(class_1937 world, Function<StargateData<?>, R> func) {
        if (world instanceof class_3218 serverWorld) {
            return StargateServerData.apply(serverWorld, func::apply);
        } else {
            return func.apply(getClient());
        }
    }

    default @NotNull StargateData<?> getOrCreate(class_1937 world) {
        return world instanceof class_3218 serverWorld ? StargateServerData.getOrCreate(serverWorld) : getClient();
    }
}
