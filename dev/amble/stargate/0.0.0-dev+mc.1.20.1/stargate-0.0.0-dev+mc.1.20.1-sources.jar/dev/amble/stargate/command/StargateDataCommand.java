package dev.amble.stargate.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.data.StargateRef;
import net.minecraft.class_2168;
import net.minecraft.class_2487;
import net.minecraft.class_2512;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class StargateDataCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("stargate")
                .then(method_9247("data").then(method_9244("global_address", LongArgumentType.longArg(0)).executes(context -> {
                    long address = LongArgumentType.getLong(context, "global_address");

                    Stargate gate = StargateRef.resolveGlobal(address, false);
                    if (gate == null) return -1;

                    class_2487 nbt = new class_2487();
                    gate.toNbt(nbt, false);

                    context.getSource().method_9226(() -> class_2512.method_32270(nbt), false);
                    return Command.SINGLE_SUCCESS;
                }))));
    }
}
