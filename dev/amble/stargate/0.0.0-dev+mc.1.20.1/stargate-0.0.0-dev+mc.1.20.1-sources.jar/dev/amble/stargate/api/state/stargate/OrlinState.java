package dev.amble.stargate.api.state.stargate;

import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.GateShape;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2960;

public class OrlinState extends GateIdentityState {

    public static final class_2960 ID = StargateMod.id("orlin");

    public static final class_238 NS_BOX = new class_238(class_2338.field_10980).method_1009(0, 0, 0).method_1009(0, 1, 0);
    public static final class_238 WE_BOX = new class_238(class_2338.field_10980).method_1009(0, 0, 0).method_1009(0, 1, 0);

    public OrlinState() {
        super(ID);

        this.northSouthBox = NS_BOX;
        this.westEastBox = WE_BOX;

        this.shape = GateShape.EMPTY;
    }
}
