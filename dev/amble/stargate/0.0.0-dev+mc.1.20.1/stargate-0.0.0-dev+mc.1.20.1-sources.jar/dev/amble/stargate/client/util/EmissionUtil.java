package dev.amble.stargate.client.util;

import dev.amble.stargate.client.renderers.StargateRenderLayers;
import dev.amble.stargate.compat.Compat;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5597;

public class EmissionUtil {

    public static void render2Layers(class_5597<?> model, class_2960 baseTexture, class_2960 emission, boolean hasEmission, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        if (hasEmission && Compat.hasIris())
            model.method_2828(matrices, vertexConsumers.getBuffer(StargateRenderLayers.emissiveCullZOffset(emission, true)), 0xF000F0, overlay, 1, 1, 1, 1);

        model.method_2828(matrices, vertexConsumers.getBuffer(class_1921.method_23576(baseTexture)), light, overlay, 1, 1, 1, 1);

        if (hasEmission && !Compat.hasIris())
            model.method_2828(matrices, vertexConsumers.getBuffer(StargateRenderLayers.emissiveCullZOffset(emission, true)), 0xF000F0, overlay, 1, 1, 1, 1);
    }
}
