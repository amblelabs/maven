package dev.amble.stargate.api.address;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.amble.lib.api.Identifiable;
import dev.amble.stargate.StargateMod;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5699;
import net.minecraft.class_7924;

public record Glyph(class_5321<class_1937> world, char glyph) implements Identifiable {

    public static final Codec<Glyph> CODEC = class_5699.method_42114(RecordCodecBuilder.create(instance -> instance.group(
            class_2960.field_25139.fieldOf("dimension").forGetter(g -> g.world.method_29177()),
            Codec.STRING.fieldOf("glyph").forGetter(symbol -> String.valueOf(symbol.glyph()))
    ).apply(instance, Glyph::new)));

    public static final int ALPHABET_LENGTH = 36;
    private static final char ALPHABET_START = '7';

    public static final char[] ALL;

    static {
        ALL = new char[ALPHABET_LENGTH];

        for (char i = 0; i < ALPHABET_LENGTH; i++) {
            ALL[i] = (char) (ALPHABET_START + i);
        }
    }

    private static final char ALPHABET_END = ALL[ALPHABET_LENGTH - 1];

//    static {
//        char[] chars = new char[ALPHABET_LENGTH];
//        for (char i = 0; i < ALPHABET_LENGTH; i++) {
//            chars[i] = (char) (i + ALPHABET_START_OFFSET);
//        }
//
//        ALL = chars;
//        ALPHABET = new String(chars);
//    }

    private static final class_2960 FONT_ID = StargateMod.id("stargate");
    private static final class_2583 STYLE = class_2583.field_24360.method_27704(FONT_ID);

    public static char idxToChar(int idx) {
        return (char) (idx + ALPHABET_START);
    }

    public static int charToIdx(char c) {
        return c - ALPHABET_START;
    }

    public static class_2561 asText(String s) {
        return class_2561.method_43470(s).method_10862(STYLE);
    }

    public static class_2561 asText(char c) {
        return class_2561.method_43470(String.valueOf(c)).method_10862(STYLE);
    }

    private Glyph(class_2960 dimension, String glyph) {
        this(dimension, glyph.charAt(0));
    }

    public Glyph(class_2960 dimension, char glyph) {
        this(class_5321.method_29179(class_7924.field_41223, dimension), glyph);
    }

    public Glyph(class_5321<class_1937> world, char glyph) {
        this.world = world;
        this.glyph = validate(glyph);
    }

    // Validate that the input is present in ALL, otherwise return ALL[0].
    public static char validate(char input) {
        return ALPHABET_START >= input && input <= ALPHABET_END ? input : ALPHABET_START;
    }

    public static Glyph fromInputStream(InputStream stream) {
        return fromJson(JsonParser.parseReader(new InputStreamReader(stream)).getAsJsonObject());
    }

    public static Glyph fromJson(JsonObject json) {
        AtomicReference<Glyph> created = new AtomicReference<>();

        CODEC.decode(JsonOps.INSTANCE, json).get().ifLeft(planet -> created.set(planet.getFirst())).ifRight(err -> {
            created.set(null);
            StargateMod.LOGGER.error("Error decoding datapack symbol: {}", err);
        });

        return created.get();
    }

    @Override
    public class_2960 id() {
        return world.method_29177();
    }
}
