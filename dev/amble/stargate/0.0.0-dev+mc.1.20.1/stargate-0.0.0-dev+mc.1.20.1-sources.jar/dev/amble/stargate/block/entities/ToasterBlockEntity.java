package dev.amble.stargate.block.entities;

import dev.amble.lib.blockentity.ABlockEntity;
import dev.amble.stargate.init.StargateBlockEntities;
import dev.amble.stargate.init.StargateItems;
import dev.amble.stargate.init.StargateSounds;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

public class ToasterBlockEntity extends ABlockEntity {

    private int cookingTicks;
    private class_1799 heldItem = class_1799.field_8037;

    public ToasterBlockEntity(class_2338 pos, class_2680 state) {
        super(StargateBlockEntities.TOASTER, pos, state);
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        nbt.method_10569("cookingTicks", cookingTicks);
        nbt.method_10566("heldItem", heldItem.method_7953(new class_2487()));
    }

    @Override
    public void method_11014(class_2487 nbt) {
        this.cookingTicks = nbt.method_10550("cookingTicks");
        this.heldItem = class_1799.method_7915(nbt.method_10562("heldItem"));
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (this.cookingTicks > 0) {
            this.cookingTicks--;
            return;
        }

        class_1799 result = this.cookItem();

        class_243 spawnPosition = pos.method_46558().method_1031(0, 0.4, 0);
        class_1542 toastEntity = new class_1542(world, spawnPosition.field_1352, spawnPosition.field_1351, spawnPosition.field_1350, result);

        world.method_8649(toastEntity);

        world.method_8396(
                null,
                pos,
                StargateSounds.TOASTER,
                class_3419.field_15245,
                0.75F,
                1.0F
        );

        world.method_8396(
                null,
                pos,
                StargateSounds.DING,
                class_3419.field_15245,
                1.0F,
                1.0F
        );

        this.heldItem = class_1799.field_8037;
        this.cookingTicks = 0;
    }

    @Override
    public class_1269 onUse(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_1799 stack = player.method_5998(hand);

        this.cookingTicks = 10;
        this.heldItem = stack.method_51164();

        world.method_8396(
                null,
                pos,
                StargateSounds.TOASTER,
                class_3419.field_15245,
                1.0F,
                1.5F
        );

        world.method_8396(
                null,
                pos,
                StargateSounds.TOASTER_ACTIVE,
                class_3419.field_15245,
                1.0F,
                1.0F
        );

        return class_1269.field_5811;
    }

    private class_1799 cookItem() {
        if (heldItem.method_7909() == class_1802.field_8229) return new class_1799(StargateItems.TOAST);
        if (heldItem.method_7909() == StargateItems.TOAST) return new class_1799(StargateItems.BURNT_TOAST);

        return heldItem;
    }
}
