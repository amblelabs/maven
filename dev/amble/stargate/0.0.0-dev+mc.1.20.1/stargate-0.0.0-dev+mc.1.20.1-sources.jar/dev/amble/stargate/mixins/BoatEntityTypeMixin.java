package dev.amble.stargate.mixins;

import dev.amble.modkit.api.BoatTypeRegistry;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import java.util.function.IntFunction;
import net.minecraft.class_1690;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_3542;
import net.minecraft.class_7995;

@Mixin(class_1690.class_1692.class)
public class BoatEntityTypeMixin implements BoatTypeRegistry.CustomBoatTypes {

    @Mutable @Shadow @Final private static class_1690.class_1692[] field_7724;
    @Mutable @Shadow @Final public static class_3542.class_7292<class_1690.class_1692> CODEC;
    @Mutable @Shadow @Final private static IntFunction<class_1690.class_1692> BY_ID;

    @Invoker("<init>")
    public static class_1690.class_1692 stargate$init(String internalName, int ordinal, class_2248 baseBlock, String name) {
        throw new AssertionError();
    }

    @Unique
    private static class_1690.class_1692 stargate$init(BoatTypeRegistry.Entry entry, int offset) {
        return stargate$init(entry.getEnumName(),
                field_7724.length + offset,
                entry.block(), entry.getPath()
        );
    }

    @Override
    public void amble$recalc(List<BoatTypeRegistry.Entry> entries, BoatTypeRegistry.BoatItemConsumer consumer) {
        int l = field_7724.length;

        class_1690.class_1692[] variants = new class_1690.class_1692[l + entries.size()];
        System.arraycopy(field_7724, 0, variants, 0, l);

        consumer.init(variants.length);
        consumer.accept(class_1690.class_1692.field_7727, class_1802.field_8533, class_1802.field_38216);
        consumer.accept(class_1690.class_1692.field_7728, class_1802.field_8486, class_1802.field_38217);
        consumer.accept(class_1690.class_1692.field_7729, class_1802.field_8442, class_1802.field_38218);
        consumer.accept(class_1690.class_1692.field_7730, class_1802.field_8730, class_1802.field_38212);
        consumer.accept(class_1690.class_1692.field_7725, class_1802.field_8094, class_1802.field_38213);
        consumer.accept(class_1690.class_1692.field_42681, class_1802.field_42706, class_1802.field_42707);
        consumer.accept(class_1690.class_1692.field_7723, class_1802.field_8138, class_1802.field_38214);
        consumer.accept(class_1690.class_1692.field_37506, class_1802.field_37531, class_1802.field_38215);
        consumer.accept(class_1690.class_1692.field_40161, class_1802.field_40224, class_1802.field_40225);

        for (int i = 0; i < entries.size(); i++) {
            BoatTypeRegistry.Entry entry = entries.get(i);
            class_1690.class_1692 type = variants[l + i] = stargate$init(entry, i);

            consumer.accept(type, entry.item(), entry.chest());
        }

        field_7724 = variants;

        CODEC = class_3542.method_28140(class_1690.class_1692::values);
        BY_ID = class_7995.<class_1690.class_1692>method_47914(Enum::ordinal, variants, class_7995.class_7996.field_41664);
    }
}
