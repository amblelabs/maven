package dev.amble.stargate.client.renderers.overlays;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.amble.stargate.StargateMod;
import dev.amble.stargate.client.renderers.portal.WormholeRenderer;
import dev.amble.stargate.client.renderers.SpaceSkyRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1802;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_291;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import net.minecraft.class_758;
import net.minecraft.class_7833;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public class WormholeOverlay implements HudRenderCallback {

    private final class_310 client = class_310.method_1551();

    @Override
    public void onHudRender(class_332 drawContext, float v) {
        if (!class_310.method_1551().field_1724.method_6047().method_31574(class_1802.field_8802)) return;
        WormholeRenderer renderer = new WormholeRenderer("wormhole");
        class_4587 stack = drawContext.method_51448();
        Matrix4f projectionMatrix = class_310.method_1551().field_1773.method_22973(class_310.method_1551().field_1690.method_41808().method_41753());
        /*for (int y = 0; y < MinecraftClient.getInstance().getWindow().getScaledHeight(); y++) {
            float t = (float) y / MinecraftClient.getInstance().getWindow().getScaledHeight();
            int r = (int) (20 + 80 * t);
            int g = (int) (20 + 10 * t);
            int b = (int) (40 + 120 * t);
            int color = (0xFF << 24) | (r << 16) | (g << 8) | b;
            drawContext.fill(
                    0, y,
                    MinecraftClient.getInstance().getWindow().getScaledWidth(), y + 1,
                    color
            );
        }*/
        stack.method_22903();
        stack.method_22907(class_7833.field_40718.rotationDegrees(-405f));
        stack.method_22905(100, 100, 100);
        renderSpace(stack/*, () -> BackgroundRenderer.setFogBlack(), MinecraftClient.getInstance().worldRenderer.getStarsBuffer()*/, client.field_1687, v, projectionMatrix);
        stack.method_22909();
        stack.method_22903();
        stack.method_46416(drawContext.method_51421() / 2f, drawContext.method_51443() / 2f, 5000);
        stack.method_22907(class_7833.field_40718.rotationDegrees(class_310.method_1551().field_1724.field_6012 / 50f * 360f));
        stack.method_22907(class_7833.field_40714.rotationDegrees((float) Math.sin(class_310.method_1551().field_1724.field_6012 / 50f * 2f)));
        stack.method_22905(11f, 12f, 5.5f);
        RenderSystem.depthMask(false);
        renderer.renderWormhole(stack);
        RenderSystem.depthMask(true);
        //renderer.renderWormholeLayer(stack, 1.5f);
        //renderer.renderWormholeLayer(stack, 2.5f);
        stack.method_22909();
    }

    public static void renderSpace(class_4587 matrices/*, Runnable fogCallback, VertexBuffer starsBuffer*/, class_638 world, float tickDelta, Matrix4f projectionMatrix) {
        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();

        matrices.method_22903();
        matrices.method_22907(class_7833.field_40718.rotationDegrees(-405f));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(world.method_30274(tickDelta) * 360.0f + 300f));
        matrices.method_22905(100, 100, 100);

        drawSpace(tessellator, bufferBuilder, matrices);

        matrices.method_22903();
        matrices.method_22907(class_7833.field_40716.rotationDegrees(90.0f));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(world.method_30274(tickDelta) * 360.0f));

        RenderSystem.setShaderColor(0.5f, 0.5f, 0.5f, 1);
        class_758.method_23792();

        /*starsBuffer.bind();
        starsBuffer.draw(matrices.peek().getPositionMatrix(), projectionMatrix,
                GameRenderer.getPositionProgram());*/

        class_291.method_1354();
        //fogCallback.run();

        RenderSystem.depthMask(false);
        RenderSystem.depthFunc(GL11.GL_ALWAYS);
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.defaultBlendFunc();
        matrices.method_22909();
        matrices.method_22909();

        // Planet Rendering
        /*Vec3d cameraPos = MinecraftClient.getInstance().gameRenderer.getCamera().getPos();
        matrices.push();
        renderStarBody(false, matrices, SUN,
                new Vec3d(cameraPos.getX() + 270, cameraPos.getY() - 120, cameraPos.getZ() + 0), new
                        Vector3f(12f, 12f, 12f),
                new Vector3f(12, 45, 0),
                true,
                new Vector3f(0.3f, 0.15f, 0.01f));

        renderSkyBody(tallDrinkOfWater + (Direction.fromRotation(tallDrinkOfWater).equals(Direction.WEST) || Direction.fromRotation(tallDrinkOfWater).equals(Direction.EAST) ? -90f : 90f), false, matrices, AITMod.id("textures/environment/earth.png"),
                new Vec3d(cameraPos.getX() - 530, cameraPos.getY() + 40, cameraPos.getZ() + 10), new
                        Vector3f(76f, 76f, 76f),
                new Vector3f(-22.5f, 45f, 0), true, true,
                new Vector3f(0.18f, 0.35f, 0.60f));
        RenderSystem.depthMask(true);
        RenderSystem.depthFunc(GL11.GL_LESS);
        matrices.pop();*/
    }

    private static void drawSpace(class_289 tessellator, class_287 bufferBuilder, class_4587 matrices) {
        RenderSystem.setShaderColor(0.25f, 0.25f, 0.25f, 1);
        SpaceSkyRenderer cubeMap = new SpaceSkyRenderer(StargateMod.id("textures/environment/space_sky/panorama"));
        cubeMap.draw(tessellator, bufferBuilder, matrices);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1);
    }
}
