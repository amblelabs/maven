package dev.amble.stargate.util;

import net.minecraft.class_2350;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;

public class VoxelShapeUtil {

    public static class_265 rotateShapeH(class_2350 from, class_2350 to, class_265 shape) {
        class_265[] buffer = new class_265[]{shape, class_259.method_1073()};

        int times = (to.method_10161() - from.method_10161() + 4) % 4;

        for (int i = 0; i < times; i++) {
            buffer[0].method_1089((minX, minY, minZ, maxX, maxY, maxZ) -> buffer[1] = class_259.method_1082(buffer[1],
                    class_259.method_1081(1 - maxZ, minY, minX, 1 - minZ, maxY, maxX), class_247.field_1366));
            buffer[0] = buffer[1];
            buffer[1] = class_259.method_1073();
        }

        return buffer[0];
    }
}
