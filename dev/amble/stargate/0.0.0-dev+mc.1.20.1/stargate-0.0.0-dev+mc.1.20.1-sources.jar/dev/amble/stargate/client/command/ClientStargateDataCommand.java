package dev.amble.stargate.client.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.client.api.data.StargateClientData;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_2487;
import net.minecraft.class_2512;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class ClientStargateDataCommand {

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(literal("stargate-client")
                .then(literal("data").then(argument("address", LongArgumentType.longArg(0)).executes(context -> {
                    long address = LongArgumentType.getLong(context, "address");
                    class_2487 nbt = new class_2487();

                    Stargate stargate = StargateClientData.get().getById(address);
                    if (stargate == null) return -1;

                    stargate.toNbt(nbt, true);

                    context.getSource().sendFeedback(class_2512.method_32270(nbt));
                    return Command.SINGLE_SUCCESS;
                })))
        );
    }
}
