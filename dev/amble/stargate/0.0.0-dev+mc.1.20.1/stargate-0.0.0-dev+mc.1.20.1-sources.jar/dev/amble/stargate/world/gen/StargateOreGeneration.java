package dev.amble.stargate.world.gen;

import dev.amble.stargate.world.StargatePlacedFeatures;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1972;
import net.minecraft.class_2893;

public class StargateOreGeneration {

    public static void generateOres(){
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_9424),
                class_2893.class_2895.field_13176, StargatePlacedFeatures.NAQUADAH_ORE_PLACED_KEY);
    }
}
