package dev.amble.stargate.init;

import dev.amble.lib.block.ABlockSettings;
import dev.amble.lib.container.impl.BlockContainer;
import dev.amble.lib.container.impl.NoBlockItem;
import dev.amble.lib.datagen.util.AutomaticModel;
import dev.amble.lib.datagen.util.NoBlockDrop;
import dev.amble.lib.datagen.util.NoEnglish;
import dev.amble.lib.datagen.util.PickaxeMineable;
import dev.amble.lib.item.AItemSettings;
import dev.amble.stargate.block.*;
import dev.amble.stargate.block.stargates.OrlinGateBlock;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2766;
import net.minecraft.class_3619;
import net.minecraft.class_3620;

@SuppressWarnings("unused")
public class StargateBlocks extends BlockContainer {

	@PickaxeMineable(tool = PickaxeMineable.Tool.IRON)
	@NoEnglish
	@NoBlockItem
	public static final StargateBlock GENERIC_GATE = new StargateBlock(ABlockSettings.method_9637()
			.method_22488().method_29292().method_51368(class_2766.field_12653).method_9629(5.5F, 10.0F)
			.method_50012(class_3619.field_15975).method_9631(light -> 3));

	@PickaxeMineable(tool = PickaxeMineable.Tool.IRON)
	@NoEnglish
	@NoBlockItem
	public static final StargateBlock ORLIN_GATE = new OrlinGateBlock(new ABlockSettings()
			.method_22488().method_29292().method_51368(class_2766.field_12653).method_9629(5.5F, 10.0F)
			.method_50012(class_3619.field_15975).method_9631(light -> 3));

	@PickaxeMineable(tool = PickaxeMineable.Tool.IRON)
	@NoEnglish
	@AutomaticModel(justItem = true)
	public static final class_2248 DHD = new DHDBlock(new ABlockSettings().method_22488().method_29292().method_51368(class_2766.field_12653).method_9629(0.5F, 6.0F)
			.method_50012(class_3619.field_15975).method_9631(light -> 3));
	
	@NoBlockItem
	public static final class_2248 RING = new StargateRingBlock(new ABlockSettings().method_22488().method_29292().method_51368(class_2766.field_12653).method_9629(0.5F, 6.0F)
			.method_50012(class_3619.field_15975).method_9631(light -> 3));

	@AutomaticModel
	@NoEnglish
	public static final class_2248 PEANUT = new class_2248(new ABlockSettings().itemSettings(new AItemSettings()));

	@NoEnglish
	@NoBlockDrop
	public static final class_2248 LIQUID_NAQUADAH_BLOCK = new LiquidNaquadahFluidBlock(StargateFluids.LIQUID_NAQUADAH_STILL,
			ABlockSettings.method_9637().itemSettings(new AItemSettings()).method_31710(class_3620.field_16001).method_51371()
					.method_9634().method_9632(100.0F).method_50012(class_3619.field_15971).method_42327().method_51177()
					.method_9626(class_2498.field_44608));

	@AutomaticModel
	@NoEnglish
	@NoBlockDrop
	@PickaxeMineable(tool = PickaxeMineable.Tool.DIAMOND)
	public static final class_2248 NAQUADAH_ORE = new class_2248(ABlockSettings.method_9637().method_22488().method_29292()
			.method_9629(10.0F, 6.0F).method_50012(class_3619.field_15974).method_9626(class_2498.field_22151));

	@AutomaticModel
	@NoEnglish
	@PickaxeMineable(tool = PickaxeMineable.Tool.DIAMOND)
	public static final class_2248 NAQUADAH_BLOCK = new class_2248(ABlockSettings.method_9637().method_22488().method_29292()
			.method_9629(25.0F, 9.0F).method_50012(class_3619.field_15974).method_9626(class_2498.field_22150));

	@AutomaticModel
	@NoEnglish
	@PickaxeMineable(tool = PickaxeMineable.Tool.DIAMOND)
	public static final class_2248 RAW_NAQUADAH_BLOCK = new class_2248(ABlockSettings.method_9637().method_22488().method_29292()
			.method_9629(15.0F, 7.5F).method_50012(class_3619.field_15974).method_9626(class_2498.field_22150));

    @NoEnglish
    @PickaxeMineable(tool = PickaxeMineable.Tool.STONE)
    public static final class_2248 TOASTER = new ToasterBlock(ABlockSettings.method_9637().method_22488().method_29292()
            .method_9629(10.0F, 1.0F).method_50012(class_3619.field_15974).method_9626(class_2498.field_11533));

    @NoEnglish
    @PickaxeMineable(tool = PickaxeMineable.Tool.STONE)
    public static final class_2248 COMPUTER = new DialingComputerBlock(ABlockSettings.method_9637().method_22488()
            .method_9629(10.0F, 1.0F).method_50012(class_3619.field_15974).method_9626(class_2498.field_11533));

	@Override
	public class_1792.class_1793 createBlockItemSettings(class_2248 block) {
		return new AItemSettings().group(StargateItemGroups.MAIN);
	}
}
