package dev.amble.stargate.api.data;

import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.address.AddressProvider;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.service.Services;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1937;
import net.minecraft.class_2960;

public interface StargateData<T extends Stargate> {

    class_2960 SYNC = StargateMod.id("sync");
    class_2960 SYNC_ALL = StargateMod.id("sync_all");
    class_2960 REMOVE = StargateMod.id("remove");

    static @Nullable StargateData<?> get(class_1937 world) {
        return Services.GATES.get(world);
    }

    static void accept(class_1937 world, Consumer<StargateData<?>> consumer) {
        Services.GATES.accept(world, consumer);
    }

    static <R> @Nullable R apply(class_1937 world, Function<StargateData<?>, R> func) {
        return Services.GATES.apply(world, func);
    }

    static @NotNull StargateData<?> getOrCreate(class_1937 world) {
        return Services.GATES.getOrCreate(world);
    }

    default void removeLocal(long address) {
        removeId(AddressProvider.Local.getId(address));
    }

    default void removeGlobal(long address) {
        removeId(AddressProvider.Global.getId(address));
    }

    default void addLocal(long address, T stargate) {
        addId(AddressProvider.Local.getId(address), stargate);
    }

    default void addGlobal(long address, T stargate) {
        addId(AddressProvider.Global.getId(address), stargate);
    }

    default @Nullable T getLocal(long address) {
        return getById(AddressProvider.Local.getId(address));
    }

    default @Nullable T getGlobal(long address) {
        return getById(AddressProvider.Global.getId(address));
    }

    void addId(long id, T stargate);
    void removeId(long id);
    boolean containsId(long id);
    @Nullable T getById(long id);
}
