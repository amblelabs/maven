package dev.amble.stargate.block.entities;

import dev.amble.lib.blockentity.ABlockEntity;
import dev.amble.stargate.init.StargateBlockEntities;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2512;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class StargateRingBlockEntity extends ABlockEntity {

    private class_2680 blockSet;

    public StargateRingBlockEntity(class_2338 pos, class_2680 state) {
        super(StargateBlockEntities.RING, pos, state);
    }

    @Override
    public class_1269 onUse(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!player.method_5715()) return class_1269.field_5811;

        class_1799 heldItem = player.method_5998(hand);

        if (heldItem.method_7960()) {
            this.setBlockSet(null);
            this.method_5431();
            return class_1269.field_5812;
        }

        if (!(heldItem.method_7909() instanceof class_1747 blockItem))
            return class_1269.field_5811;

        if (blockItem.method_7711().method_9564() != this.getBlockSet()) {
            this.setBlockSet(blockItem.method_7711().method_9605(new class_1750(player, hand, player.method_6047(), hit)));
            this.method_5431();

            return class_1269.field_5812;
        }

        return class_1269.field_5814;
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        if (this.blockSet != null) nbt.method_10566("blockSet", class_2512.method_10686(this.blockSet));

        super.method_11007(nbt);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        this.blockSet = class_2680.field_24734.parse(class_2509.field_11560, nbt.method_10562("blockSet")).result().orElse(null);

        super.method_11014(nbt);
    }

    public void setBlockSet(class_2680 state) {
        this.blockSet = state;

        this.method_5431();
        this.sync();
    }

    public class_2680 getBlockSet() {
        return this.blockSet;
    }
}