package dev.amble.stargate.api.state;

import dev.amble.stargate.api.behavior.IrisBehavior;
import net.minecraft.class_5321;

public interface IrisTier {

    abstract class Impl implements IrisTier {

        private class_5321<IrisTier> key;

        @Override
        public void setRegistryKey(class_5321<IrisTier> key) {
            this.key = key;
        }

        @Override
        public class_5321<IrisTier> getRegistryKey() {
            return key;
        }
    }

    int maxDurability();

    void setRegistryKey(class_5321<IrisTier> key);
    class_5321<IrisTier> getRegistryKey();

    default void onBroken(IrisBehavior.IrisDamageCtx ctx) { }
}
