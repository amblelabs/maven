package dev.amble.stargate.world;

import dev.amble.stargate.StargateMod;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_5843;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class StargatePlacedFeatures {

    public static final class_5321<class_6796> NAQUADAH_ORE_PLACED_KEY = registerKey("naquadah_ore_placed");

    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatureRegistryEntryLookup = context.method_46799(class_7924.field_41239);

        register(context, NAQUADAH_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(StargateConfiguredFeature.NAQUADAH_ORE_KEY),
                StargateOrePlacement.modifiersWithCount(1,
                        class_6795.method_39634(class_5843.method_33841(-64), class_5843.method_33841(0))));
    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, new class_2960(StargateMod.MOD_ID, name));
    }

    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }
}
