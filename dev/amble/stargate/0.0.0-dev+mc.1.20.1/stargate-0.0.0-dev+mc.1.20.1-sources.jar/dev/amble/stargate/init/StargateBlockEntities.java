package dev.amble.stargate.init;

import dev.amble.lib.container.impl.BlockEntityContainer;
import dev.amble.stargate.block.entities.*;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2591;

public class StargateBlockEntities implements BlockEntityContainer {
	public static final class_2591<StargateBlockEntity> GENERIC_STARGATE = FabricBlockEntityTypeBuilder.create(StargateBlockEntity::new, StargateBlocks.GENERIC_GATE).build();
	public static final class_2591<DHDBlockEntity> DHD = FabricBlockEntityTypeBuilder.create(DHDBlockEntity::new, StargateBlocks.DHD).build();
	public static final class_2591<StargateRingBlockEntity> RING = FabricBlockEntityTypeBuilder.create(StargateRingBlockEntity::new, StargateBlocks.RING).build();
	public static final class_2591<ToasterBlockEntity> TOASTER = FabricBlockEntityTypeBuilder.create(ToasterBlockEntity::new, StargateBlocks.TOASTER).build();
	public static final class_2591<DialingComputerBlockEntity> COMPUTER = FabricBlockEntityTypeBuilder.create(DialingComputerBlockEntity::new, StargateBlocks.COMPUTER).build();
}
