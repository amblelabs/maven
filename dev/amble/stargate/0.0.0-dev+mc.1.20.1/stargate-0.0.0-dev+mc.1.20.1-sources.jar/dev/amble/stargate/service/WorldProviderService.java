package dev.amble.stargate.service;

import dev.amble.lib.util.ServerLifecycleHooks;
import net.minecraft.class_1937;
import net.minecraft.class_5321;

public interface WorldProviderService {

    default class_1937 getWorld(class_5321<class_1937> world, boolean isClient) {
        if (isClient) throw new IllegalStateException("Attempted to get client world on server!");
        return ServerLifecycleHooks.get().method_3847(world);
    }
}
