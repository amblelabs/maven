package dev.amble.stargate.block.entities;

import dev.amble.stargate.block.DialingComputerBlock;
import dev.amble.stargate.init.StargateBlockEntities;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

public class DialingComputerBlockEntity extends NearestLinkingBlockEntity {

    public DialingComputerBlockEntity(class_2338 pos, class_2680 state) {
        super(StargateBlockEntities.COMPUTER, pos, state, true);
    }

    @Override
    public class_1269 onUse(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (player instanceof class_3222 serverPlayer) {
            ServerPlayNetworking.send(serverPlayer, DialingComputerBlock.OPEN, PacketByteBufs.create());
            return class_1269.field_21466;
        }

        return class_1269.field_5812;
    }
}
