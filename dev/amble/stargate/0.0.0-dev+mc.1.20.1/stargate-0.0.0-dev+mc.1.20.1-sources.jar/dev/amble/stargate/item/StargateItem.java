package dev.amble.stargate.item;

import dev.amble.stargate.api.GateKernelRegistry;
import dev.amble.stargate.block.StargateBlock;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.init.StargateBlocks;
import net.minecraft.class_1747;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;

public class StargateItem extends class_1747 {

    public final GateKernelRegistry.Entry creator;

    public StargateItem(class_1793 settings, GateKernelRegistry.Entry creator) {
        this(settings, StargateBlocks.GENERIC_GATE, creator);
    }

    private StargateItem(class_1793 settings, StargateBlock block, GateKernelRegistry.Entry entry) {
        super(block, settings);
        this.creator = entry;
    }

    public void place(class_3218 world, class_2338 pos, class_2350 direction) {
        class_2680 state = StargateBlocks.GENERIC_GATE.method_9564().method_11657(class_2741.field_12481, direction);
        world.method_8501(pos, state);

        if (world.method_8321(pos) instanceof StargateBlockEntity be)
            be.onPlacedWithKernel(world, state, this.creator);
    }

    @Override
    public String method_7876() {
        return this.method_7869();
    }

    public GateKernelRegistry.Entry getCreator() {
        return this.creator;
    }
}
