package dev.amble.stargate.datagen;

import dev.amble.lib.datagen.advancement.AmbleAdvancementProvider;
import dev.amble.stargate.advancement.BreakIrisCriterion;
import dev.amble.stargate.init.StargateBlocks;
import dev.amble.stargate.init.StargateCriterions;
import dev.amble.stargate.init.StargateIrisTiers;
import dev.amble.stargate.init.StargateItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_161;
import net.minecraft.class_2066;

@SuppressWarnings("unused")
public class SGAdvancementGen extends AmbleAdvancementProvider {

    public SGAdvancementGen(FabricDataOutput output) {
        super(output);

        class_161 root = create("root").icon(StargateBlocks.GENERIC_GATE)
                .noToast().silent().background("textures/block/raw_naquadah_block.png")
                .condition("root", class_2066.class_2068.method_8959(
                        StargateItems.ORLIN_STARGATE, StargateItems.DESTINY_STARGATE,
                        StargateItems.MILKY_WAY_STARGATE, StargateItems.PEGASUS_STARGATE
                )).build();

        class_161 rawNaquadah = challenge(root, "obtain_raw_naquadah").icon(StargateItems.RAW_NAQUADAH)
                .condition("obtain_raw_naquadah", class_2066.class_2068.method_8959(StargateItems.RAW_NAQUADAH))
                .hidden().build();

        class_161 addressCartouche = goal(root, "obtain_address_cartouche").icon(StargateItems.ADDRESS_CARTOUCHE)
                .condition("obtain_address_cartouche", class_2066.class_2068.method_8959(StargateItems.ADDRESS_CARTOUCHE))
                .hidden().build();

        class_161 liquidNaquadah = goal(rawNaquadah, "obtain_liquid_naquadah").icon(StargateItems.LIQUID_NAQUADAH)
                .condition("obtain_liquid_naquadah", class_2066.class_2068.method_8959(StargateItems.LIQUID_NAQUADAH))
                .hidden().build();

        class_161 toaster = goal(root, "obtain_toaster").icon(StargateBlocks.TOASTER)
                .condition("obtain_toaster", class_2066.class_2068.method_8959(StargateBlocks.TOASTER))
                .hidden().build();

        class_161 burntToast = challenge(toaster, "obtain_burnt_toast").icon(StargateItems.BURNT_TOAST)
                .condition("obtain_burnt_toast", class_2066.class_2068.method_8959(StargateItems.BURNT_TOAST))
                .hidden().build();

        class_161 passedThrough = challenge(root, "passed_through").icon(StargateItems.DESTINY_STARGATE)
                .condition("has_passed_through", StargateCriterions.PASSED_THROUGH.conditions()).build();

        class_161 goldenIris = goal(root, "golden_iris").icon(StargateItems.GOLD_IRIS)
                .condition("was_broken", BreakIrisCriterion.Conditions.create(StargateIrisTiers.GOLD))
                .build();
    }
}
