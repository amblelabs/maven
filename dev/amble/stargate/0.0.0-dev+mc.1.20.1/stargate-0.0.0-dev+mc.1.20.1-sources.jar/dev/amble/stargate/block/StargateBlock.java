package dev.amble.stargate.block;

import dev.amble.lib.block.ABlockSettings;
import dev.amble.lib.block.AWaterloggableBlock;
import dev.amble.lib.block.behavior.base.BlockWithEntityBehavior;
import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.event.block.StargateBlockUseEvent;
import dev.amble.stargate.api.event.block.StargateBlockTickEvent;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.drtheo.yaar.event.TEvents;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_5819;

// uses unstable amblekit feat/ports block behavior api
@SuppressWarnings("UnstableApiUsage")
public class StargateBlock extends AWaterloggableBlock implements class_2343 {

	public StargateBlock(ABlockSettings settings) {
		super(settings,
				BlockWithEntityBehavior.Ticking.withInvisibleModel(StargateBlockEntity::new),
				HorizontalBlockBehavior.withPlacement(true)
		);
	}

	@Override
	public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (hand != class_1268.field_5808 || !(world.method_8321(pos) instanceof StargateBlockEntity be))
            return class_1269.field_5811;

		Stargate stargate = be.asGate();

		if (stargate == null)
			return class_1269.field_5811;

		boolean success = TEvents.handle(new StargateBlockUseEvent(stargate, be, player, world, state, pos, hand, hit));

		if (success)
			return class_1269.field_5812;

		if (!player.method_5715() || world.method_8608()) return class_1269.field_5811;

		class_1799 heldItem = player.method_5998(hand);
        class_2680 newSetState = null;

        if (!heldItem.method_7960() && heldItem.method_7909() instanceof class_1747 blockItem)
            newSetState = blockItem.method_7711().method_9605(new class_1750(player, hand, heldItem, hit));

        if (newSetState != null) {
            be.setBlockSet(newSetState);
            be.method_5431();

			return class_1269.field_5812;
        }

		return class_1269.field_5811;
	}

	@Override
	public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
		if (!(world.method_8321(pos) instanceof StargateBlockEntity be) || !be.isLinked()) return;

		be.acceptGate(stargate -> TEvents.handle(
				new StargateBlockTickEvent.Random(stargate, world, pos, state, random)
		));
	}
}
