package dev.amble.stargate.client.api.event.render;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.client.api.state.stargate.ClientAbstractStargateState;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.client.renderers.StargateBlockEntityRenderer;
import dev.drtheo.yaar.event.TEvents;
import net.minecraft.class_3695;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public interface StargateRenderEvents extends TEvents {

    Type<StargateRenderEvents> event = new Type<>(StargateRenderEvents.class);

    void render(Stargate stargate, ClientAbstractStargateState<?> state, StargateBlockEntity entity, StargateBlockEntityRenderer renderer, class_3695 profiler, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay, float tickDelta);
}
