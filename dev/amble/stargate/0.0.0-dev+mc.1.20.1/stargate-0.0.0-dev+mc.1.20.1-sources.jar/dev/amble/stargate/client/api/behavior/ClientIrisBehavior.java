package dev.amble.stargate.client.api.behavior;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.event.block.StargateBlockTickEvents;
import dev.amble.stargate.api.event.init.StargateLoadedEvents;
import dev.amble.stargate.api.event.init.StargateUpdateEvents;
import dev.amble.stargate.api.state.GateState;
import dev.amble.stargate.api.state.IrisState;
import dev.amble.stargate.client.api.state.ClientIrisState;
import dev.amble.stargate.client.api.state.stargate.ClientAbstractStargateState;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.client.animations.StargateAnimations;
import dev.amble.stargate.client.api.event.render.StargateAnimateEvents;
import dev.amble.stargate.client.models.MilkyWayGateModel;
import dev.drtheo.yaar.behavior.TBehavior;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3695;
import net.minecraft.class_7094;

public class ClientIrisBehavior implements TBehavior, StargateBlockTickEvents, StargateAnimateEvents, StargateUpdateEvents, StargateLoadedEvents {

    @Override
    public void onLoaded(Stargate stargate) {
        this.checkAndAttach(stargate);
    }

    @Override
    public void onUpdate(Stargate stargate) {
        this.checkAndAttach(stargate);
    }

    private void checkAndAttach(Stargate stargate) {
        if (stargate.isClient() && stargate.hasState(IrisState.state) && !stargate.hasState(ClientIrisState.state))
            stargate.addState(new ClientIrisState());
    }

    @Override
    public void block$tick(Stargate stargate, StargateBlockEntity entity, class_1937 world, class_2338 pos, class_2680 state) {
        if (!world.method_8608())
            return;

        ClientAbstractStargateState clientState = stargate.resolveState(ClientAbstractStargateState.state);

        IrisState irisState = stargate.state(IrisState.state);
        ClientIrisState clientIrisState = stargate.state(ClientIrisState.state);

        if (clientIrisState.ticks > 0) clientIrisState.ticks--;
        else clientIrisState.stopOpening = true;

        GateState.Closed closed = stargate.stateOrNull(GateState.Closed.state);

        if (closed != null && closed.locking) {
            clientIrisState.CLOSE_STATE.method_41325();
            clientIrisState.OPEN_STATE.method_41325();
            return;
        }

        class_7094 openState = clientIrisState.OPEN_STATE;
        class_7094 closeState = clientIrisState.CLOSE_STATE;
        int age = clientState.age;

        if (irisState.open) {
            closeState.method_41324(age);
            openState.method_41325();
            clientIrisState.stopOpening = false;
        } else {
            if (!clientIrisState.stopOpening) {
                closeState.method_41325();
                openState.method_41324(age);
            }

            if (openState.method_41327()) clientIrisState.ticks = 3 * 20;
        }
    }

    @Override
    public void animate(StargateBlockEntity block, Stargate stargate, ClientAbstractStargateState<?> state, class_3695 profiler) {
        if (!(state.model() instanceof MilkyWayGateModel model)) return;

        ClientIrisState clientIrisState = stargate.stateOrNull(ClientIrisState.state);
        boolean renderIris = false;

        if (clientIrisState != null) {
            renderIris = clientIrisState.CLOSE_STATE.method_41327() || clientIrisState.OPEN_STATE.method_41327();

            model.method_43781(clientIrisState.CLOSE_STATE, StargateAnimations.IRIS_CLOSE, state.age);
            model.method_43781(clientIrisState.OPEN_STATE, StargateAnimations.IRIS_OPEN, state.age);
        }

        // TODO: make the iris a separate model
        model.iris.field_3665 = renderIris;
    }
}
