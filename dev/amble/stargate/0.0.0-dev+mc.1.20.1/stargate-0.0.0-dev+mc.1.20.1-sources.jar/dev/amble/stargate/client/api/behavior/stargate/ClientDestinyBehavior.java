package dev.amble.stargate.client.api.behavior.stargate;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.state.stargate.DestinyState;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.client.api.state.stargate.ClientDestinyState;
import dev.amble.stargate.client.renderers.StargateBlockEntityRenderer;
import net.minecraft.class_3695;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_630;

public class ClientDestinyBehavior extends ClientAbstractStargateBehavior.Spinning<ClientDestinyState> {

    public ClientDestinyBehavior() {
        super(DestinyState.class, ClientDestinyState.class);
    }

    @Override
    protected ClientDestinyState createClientState(Stargate stargate) {
        return new ClientDestinyState();
    }

    @Override
    protected void preRender(Stargate stargate, ClientDestinyState clientState, StargateBlockEntity entity, StargateBlockEntityRenderer renderer, class_3695 profiler, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay, float tickDelta) {
        super.preRender(stargate, clientState, entity, renderer, profiler, matrices, vertexConsumers, light, overlay, tickDelta);

        class_630 root = clientState.model().method_32008();
        root.field_3674 = renderGlyphs(root.field_3674, 180f, clientState, matrices, vertexConsumers, stargate, light);
    }
}
