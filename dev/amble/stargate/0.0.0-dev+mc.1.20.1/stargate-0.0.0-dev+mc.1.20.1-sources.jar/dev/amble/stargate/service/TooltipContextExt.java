package dev.amble.stargate.service;

import net.minecraft.class_1836;

// TODO: move to Amble
public interface TooltipContextExt extends class_1836 {
    boolean isShiftDown();
    boolean isAltDown();
    boolean isControlDown();
}
