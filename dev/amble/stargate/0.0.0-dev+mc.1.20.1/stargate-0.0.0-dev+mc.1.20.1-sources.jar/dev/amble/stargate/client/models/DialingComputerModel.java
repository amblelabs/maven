package dev.amble.stargate.client.models;

import dev.amble.lib.client.model.BlockEntityModel;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class DialingComputerModel extends BlockEntityModel {

    private final class_630 root;

    public DialingComputerModel() {
        this(getTexturedModelData().method_32109());
    }

    private DialingComputerModel(class_630 root) {
        this.root = root;
    }

    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();
        class_5610 monitor = modelPartData.method_32117(
            "monitor",
            class_5606.method_32108()
                .method_32101(0, 30)
                .method_32098(
                    -4.0F,
                    0.6F,
                    -4.0F,
                    8.0F,
                    1.0F,
                    8.0F,
                    new class_5605(0.0F)
                )
                .method_32101(12, 45)
                .method_32098(
                    -1.0F,
                    -0.4F,
                    -1.0F,
                    2.0F,
                    1.0F,
                    2.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(7.9401F, 22.4F, 3.0863F, 0.0F, 0.1309F, 0.0F)
        );

        class_5610 cube_r1 = monitor.method_32117(
            "cube_r1",
            class_5606.method_32108()
                .method_32101(38, 19)
                .method_32098(
                    -5.0F,
                    -9.0F,
                    2.0F,
                    10.0F,
                    7.0F,
                    3.0F,
                    new class_5605(0.0F)
                )
                .method_32101(0, 0)
                .method_32098(
                    -6.0F,
                    -11.0F,
                    -6.0F,
                    12.0F,
                    11.0F,
                    8.0F,
                    new class_5605(0.0F)
                )
                .method_32101(32, 30)
                .method_32098(
                    -6.0F,
                    -11.0F,
                    -6.0F,
                    12.0F,
                    11.0F,
                    1.0F,
                    new class_5605(0.15F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -0.1309F, 0.3054F, 0.0F)
        );

        class_5610 keyboard = modelPartData.method_32117(
            "keyboard",
            class_5606.method_32108()
                .method_32101(0, 19)
                .method_32098(
                    -7.0F,
                    -1.0F,
                    -12.0F,
                    14.0F,
                    1.0F,
                    5.0F,
                    new class_5605(0.0F)
                )
                .method_32101(0, 25)
                .method_32098(
                    -7.0F,
                    -1.2F,
                    -12.0F,
                    14.0F,
                    0.0F,
                    5.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32090(4.0F, 24.0F, 4.0F)
        );

        class_5610 iris_hand_print = modelPartData.method_32117(
            "iris_hand_print",
            class_5606.method_32108()
                .method_32101(42, 46)
                .method_32098(
                    -8.0F,
                    -1.0F,
                    -4.0F,
                    5.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                )
                .method_32101(-5, 59)
                .method_32098(
                    -8.0F,
                    -0.1F,
                    2.0F,
                    13.0F,
                    0.0F,
                    5.0F,
                    new class_5605(0.0F)
                )
                .method_32101(40, 9)
                .method_32098(
                    -8.0F,
                    -4.0F,
                    -4.0F,
                    0.0F,
                    4.0F,
                    6.0F,
                    new class_5605(0.0F)
                )
                .method_32101(40, 9)
                .method_32098(
                    -3.0F,
                    -4.0F,
                    -4.0F,
                    0.0F,
                    4.0F,
                    6.0F,
                    new class_5605(0.0F)
                )
                .method_32101(40, 6)
                .method_32098(
                    -8.0F,
                    -2.0F,
                    -1.0F,
                    5.0F,
                    1.0F,
                    3.0F,
                    new class_5605(0.0F)
                )
                .method_32101(32, 42)
                .method_32098(
                    -8.0F,
                    -3.0F,
                    0.0F,
                    5.0F,
                    1.0F,
                    2.0F,
                    new class_5605(0.0F)
                )
                .method_32101(0, 45)
                .method_32098(
                    -8.0F,
                    -4.0F,
                    1.0F,
                    5.0F,
                    1.0F,
                    1.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32090(0.0F, 24.0F, 1.0F)
        );

        class_5610 cube_r2 = iris_hand_print.method_32117(
            "cube_r2",
            class_5606.method_32108()
                .method_32101(28, 58)
                .method_32098(
                    -3.0F,
                    -0.4F,
                    -2.5F,
                    5.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                )
                .method_32101(0, 39)
                .method_32098(
                    -3.0F,
                    -0.5F,
                    -2.5F,
                    5.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(-5.0F, -1.6F, -1.5F, 0.6109F, 0.0F, 0.0F)
        );
        return class_5607.method_32110(modelData, 64, 64);
    }

    @Override
    public class_630 method_32008() {
        return root;
    }
}
