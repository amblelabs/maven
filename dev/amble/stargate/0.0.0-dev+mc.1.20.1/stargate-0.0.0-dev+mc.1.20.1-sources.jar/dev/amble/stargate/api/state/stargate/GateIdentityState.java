package dev.amble.stargate.api.state.stargate;

import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.GateShape;
import dev.drtheo.yaar.state.TState;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2960;

public abstract class GateIdentityState implements TState<GateIdentityState> {

    public static final class_238 NS_DEFAULT = new class_238(class_2338.field_10980).method_1009(2, 2, 0).method_1009(0, 3, 0);
    public static final class_238 WE_DEFAULT = new class_238(class_2338.field_10980).method_1009(0, 2, 2).method_1009(0, 3, 0);

    public static final Type<GateIdentityState> state = new Type<>(StargateMod.id("gate"));

    public class_238 northSouthBox = NS_DEFAULT;
    public class_238 westEastBox = WE_DEFAULT;

    public int maxChevrons = 9;
    public GateShape shape = GateShape.DEFAULT;

    public final class_2960 id;

    public GateIdentityState(class_2960 id) {
        this.id = id;
    }

    public class_238 forDirection(class_2350 direction) {
        return direction == class_2350.field_11043 || direction == class_2350.field_11035 ? northSouthBox : westEastBox;
    }

    @Override
    public Type<GateIdentityState> type() {
        return state;
    }
}
