package dev.amble.stargate.block.entities;

import com.mojang.serialization.DataResult;
import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.stargate.api.GateKernelRegistry;
import dev.amble.stargate.api.ServerStargate;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.event.block.StargateBlockTickEvent;
import dev.amble.stargate.init.StargateBlockEntities;
import dev.amble.stargate.item.StargateItem;
import dev.amble.stargate.util.LambdaUtil;
import dev.drtheo.yaar.event.TEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2512;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;

public class StargateBlockEntity extends StargateLinkableBlockEntity {

	public boolean requiresPlacement = false;
	private class_2680 blockSet;

	public StargateBlockEntity(class_2338 pos, class_2680 state) {
		super(StargateBlockEntities.GENERIC_STARGATE, pos, state);
	}

	@Override
	protected void method_11007(class_2487 nbt) {
		if (this.blockSet != null) {
			nbt.method_10566("blockSet", class_2512.method_10686(this.blockSet));
		}
		super.method_11007(nbt);
	}

	@Override
	public void method_11014(class_2487 nbt) {
		DataResult<class_2680> blockStateDataResult = class_2680.field_24734.parse(class_2509.field_11560, nbt.method_10562("blockSet"));
		this.setBlockSet(blockStateDataResult.result().orElse(null));
		super.method_11014(nbt);
	}

	@Override
	public void amble$onStructurePlaced(class_2487 nbt) {
		super.amble$onStructurePlaced(nbt);
		this.requiresPlacement = true;
	}

	public void setBlockSet(class_2680 state) {
		this.blockSet = state;

		this.method_5431();
		this.sync();
	}

	public class_2680 getBlockSet() {
		return this.blockSet;
	}

	@Override
	public void onBreak(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState) {
		this.acceptGate(LambdaUtil.cast(ServerStargate::remove));
		super.onBreak(state, world, pos, newState); // unlink the gate, free the chunk
	}

	@Override
	public void onPlaced(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
		if (!(world instanceof class_3218 serverWorld) || !(stack.method_7909() instanceof StargateItem item)) return;

		this.onPlacedWithKernel(serverWorld, state, item.getCreator());
	}

	public void onPlacedWithKernel(class_3218 world, class_2680 state, GateKernelRegistry.Entry entry) {
		this.requiresPlacement = false;

		class_2350 facing = HorizontalBlockBehavior.getFacing(state);
		Stargate stargate = entry.create(world, field_11867, facing);

		this.link(stargate);
	}

	@Override
	public void tick(class_1937 world, class_2338 blockPos, class_2680 blockState) {
		this.acceptGate(stargate -> TEvents.handle(
				new StargateBlockTickEvent(stargate, this, world, blockPos, blockState)
		));
	}
}
