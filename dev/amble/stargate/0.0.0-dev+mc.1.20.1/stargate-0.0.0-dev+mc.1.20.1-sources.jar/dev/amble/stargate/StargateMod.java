package dev.amble.stargate;

import dev.amble.lib.container.RegistryContainer;
import dev.amble.modkit.api.RegistryContainer2;
import dev.amble.stargate.api.address.GlyphOriginRegistry;
import dev.amble.stargate.api.data.StargateServerData;
import dev.amble.stargate.command.StargateDataCommand;
import dev.amble.stargate.init.*;
import dev.amble.stargate.world.gen.StargateWorldGeneration;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StargateMod implements ModInitializer {

	public static final String MOD_ID = "stargate";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		StargateArgumentTypes.register();

		CommandRegistrationCallback.EVENT.register((dispatcher, access, env) -> {
			StargateDataCommand.register(dispatcher);
		});

		StargateYAARs.init();
		StargateCriterions.init();

		RegistryContainer.register(StargateItemGroups.class, MOD_ID);
		RegistryContainer.register(StargateItems.class, MOD_ID);
		RegistryContainer.register(StargateBlocks.class, MOD_ID);
		RegistryContainer.register(StargateBlockEntities.class, MOD_ID);
		RegistryContainer.register(StargateEntities.class, MOD_ID);
		RegistryContainer.register(StargateSounds.class, MOD_ID);
		RegistryContainer.register(StargateAttributes.class, MOD_ID);
		RegistryContainer.register(StargateStatusEffects.class, MOD_ID);
		RegistryContainer.register(StargateFluids.class, MOD_ID);
		RegistryContainer.register(StargateIrisTiers.class, MOD_ID);

		RegistryContainer2.register(StargateBoatTypes.class, MOD_ID);
		GlyphOriginRegistry.init();

		StargateWorldGeneration.generateStargateWorldGen();
		StargateServerData.init();
	}

	public static class_2960 id(String path) {
		return new class_2960(MOD_ID, path);
	}
}