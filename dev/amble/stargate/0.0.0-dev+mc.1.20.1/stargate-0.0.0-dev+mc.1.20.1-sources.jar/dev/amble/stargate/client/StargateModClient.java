package dev.amble.stargate.client;

import dev.amble.stargate.block.DialingComputerBlock;
import dev.amble.stargate.client.api.data.StargateClientData;
import dev.amble.stargate.client.command.ClientStargateDataCommand;
import dev.amble.stargate.client.command.ClientStargateDumpCommand;
import dev.amble.stargate.client.init.StargateClientYAARs;
import dev.amble.stargate.client.renderers.*;
import dev.amble.stargate.client.renderers.overlays.WormholeOverlay;
import dev.amble.stargate.client.renderers.portal.PortalRendering;
import dev.amble.stargate.client.screen.DialingComputerScreen;
import dev.amble.stargate.client.service.ClientServices;
import dev.amble.stargate.init.StargateBlockEntities;
import dev.amble.stargate.init.StargateBlocks;
import dev.amble.stargate.init.StargateEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_5616;

public class StargateModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> {
            ClientStargateDataCommand.register(dispatcher);
            ClientStargateDumpCommand.register(dispatcher);
        });

        ClientPlayNetworking.registerGlobalReceiver(DialingComputerBlock.OPEN, (client, handler, buf, sender) -> {
            client.method_1507(new DialingComputerScreen());
        });

        registerBlockEntityRenderers();
        setupBlockRendering();
        registerEntityRenderers();

        WorldRenderEvents.AFTER_ENTITIES.register(PortalRendering::render);
        HudRenderCallback.EVENT.register(new WormholeOverlay());

        StargateClientYAARs.init();
        StargateClientData.init();

        ClientServices.init();
    }

    public void registerBlockEntityRenderers() {
        class_5616.method_32144(StargateBlockEntities.GENERIC_STARGATE, StargateBlockEntityRenderer::new);

        class_5616.method_32144(StargateBlockEntities.DHD, DHDBlockEntityRenderer::new);
        class_5616.method_32144(StargateBlockEntities.RING, RingBlockEntityRenderer::new);

        class_5616.method_32144(StargateBlockEntities.COMPUTER, DialingComputerRenderer::new);
    }

    public void registerEntityRenderers() {
        EntityRendererRegistry.register(StargateEntities.DHD_CONTROL_TYPE, DHDControlEntityRenderer::new);
    }

    public static void setupBlockRendering() {
        BlockRenderLayerMap.INSTANCE.putBlock(StargateBlocks.GENERIC_GATE, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(StargateBlocks.ORLIN_GATE, class_1921.method_23581());
    }
}

