package dev.amble.stargate.api.event.tp;

import dev.amble.stargate.api.ServerStargate;
import dev.amble.stargate.api.Stargate;
import dev.drtheo.yaar.event.TEvents;
import dev.drtheo.yaar.event.impl.TriStateTEvent;
import net.minecraft.class_1309;

public class StargateTpEvent extends TriStateTEvent<StargateTpEvents> {

    private final ServerStargate from;
    private final ServerStargate to;
    private final class_1309 living;

    public StargateTpEvent(ServerStargate from, ServerStargate to, class_1309 living) {
        this.from = from;
        this.to = to;
        this.living = living;
    }

    @Override
    public TEvents.BaseType<StargateTpEvents> type() {
        return StargateTpEvents.event;
    }

    @Override
    public dev.drtheo.yaar.event.impl.TriStateTEvent.Result handle(StargateTpEvents handler) {
        return handler.onGateTp(from, to, living);
    }
}
