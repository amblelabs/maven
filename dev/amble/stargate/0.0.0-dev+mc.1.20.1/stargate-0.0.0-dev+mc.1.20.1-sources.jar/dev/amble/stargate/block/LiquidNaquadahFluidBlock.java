package dev.amble.stargate.block;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3609;

public class LiquidNaquadahFluidBlock extends class_2404 {

    public LiquidNaquadahFluidBlock(class_3609 fluid, class_2251 settings) {
        super(fluid, settings);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        if (!world.field_9236 && entity instanceof class_1657 player) {
            player.method_6092(new class_1293(class_1294.field_5919, 60, 1, true, false, true));
        }
    }

    @Override
    public float method_23349() {
        return 0.4F;
    }
}