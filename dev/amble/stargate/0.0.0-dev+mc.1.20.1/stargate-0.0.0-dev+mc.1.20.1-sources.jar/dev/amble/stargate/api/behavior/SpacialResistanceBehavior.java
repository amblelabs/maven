package dev.amble.stargate.api.behavior;

import dev.amble.stargate.api.ServerStargate;
import dev.amble.stargate.api.event.tp.StargateTpEvent;
import dev.amble.stargate.api.event.tp.StargateTpEvents;
import dev.amble.stargate.api.state.GateState;
import dev.amble.stargate.init.StargateAttributes;
import dev.amble.stargate.init.StargateDamages;
import dev.drtheo.yaar.behavior.TBehavior;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1324;
import net.minecraft.class_1937;

public class SpacialResistanceBehavior implements TBehavior, StargateTpEvents {

    @Override
    public StargateTpEvent.Result onGateTp(ServerStargate from, ServerStargate to, class_1309 living) {
        GateState.Open open = from.state(GateState.Open.state);

        class_1937 world = living.method_37908();
        class_1282 flow = StargateDamages.flow(world);

        if (!open.caller && !living.method_5679(flow)) {
            class_1320 attribute = StargateAttributes.SPACIAL_RESISTANCE;
            class_1324 spacialResistance = living.method_5996(attribute);

            float resistance = (float) (spacialResistance == null
                    ? attribute.method_6169() : spacialResistance.method_6194());

            resistance = 1 - resistance / 100;

            living.method_5643(flow, living.method_6063() * resistance);

            // TODO: add energy conversion
            if (!living.method_5805())
                return StargateTpEvent.Result.DENY;
        }

        return StargateTpEvent.Result.PASS;
    }
}
