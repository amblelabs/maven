package dev.amble.stargate.client.api.behavior.stargate;

import dev.amble.stargate.api.address.Glyph;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4597;
import net.minecraft.class_5481;
import org.joml.Matrix4f;

public class GlyphCache {

    private static final int MAX_GLYPHS = Glyph.ALL.length;
    private static GlyphCache INSTANCE;

    private final class_327 renderer;

    public final class_5481[] texts = new class_5481[MAX_GLYPHS];
    public final float[] widths = new float[MAX_GLYPHS];

    private GlyphCache() {
        this.renderer = class_310.method_1551().field_1772;

        for (int i = 0; i < MAX_GLYPHS; i++) {
            class_5481 text = Glyph.asText(Glyph.ALL[i]).method_30937();

            texts[i] = text;
            widths[i] = renderer.method_30880(text) / -2f;
        }
    }

    public void draw(int index, float y, int color, boolean shadow, Matrix4f matrix, class_4597 vertexConsumers, class_327.class_6415 layer, int backgroundColor, int light) {
        renderer.method_22942(texts[index], widths[index], y, color, shadow, matrix, vertexConsumers, layer, backgroundColor, light);
    }

    public static GlyphCache get() {
        return INSTANCE == null ? INSTANCE = new GlyphCache() : INSTANCE;
    }
}
