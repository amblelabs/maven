package dev.amble.stargate.block;

import dev.amble.lib.block.ABlock;
import dev.amble.lib.block.ABlockSettings;
import dev.amble.lib.block.behavior.base.BlockWithEntityBehavior;
import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.stargate.block.entities.DHDBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

@SuppressWarnings({"UnstableApiUsage", "deprecation"})
public class DHDBlock extends ABlock implements class_2343 {

	public static final class_265 DHDSHAPE = class_2248.method_9541(4.0F, 0.0F, 4.0F, 12.0F, 14.0F, 12.0F);

	public DHDBlock(ABlockSettings settings) {
		super(settings, HorizontalBlockBehavior.withPlacement(true),
				BlockWithEntityBehavior.Ticking.withInvisibleModel(DHDBlockEntity::new));
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
		return DHDSHAPE;
	}
}
