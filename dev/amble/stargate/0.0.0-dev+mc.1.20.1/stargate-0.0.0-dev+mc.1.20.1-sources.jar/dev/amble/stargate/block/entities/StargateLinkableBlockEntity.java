package dev.amble.stargate.block.entities;

import dev.amble.lib.blockentity.ABlockEntity;
import dev.amble.lib.blockentity.StructurePlaceableBlockEntity;
import dev.amble.stargate.api.data.StargateRef;
import dev.amble.stargate.api.data.StargateServerData;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import dev.amble.stargate.api.data.StargateLinkable;
import dev.amble.stargate.api.Stargate;
import org.jetbrains.annotations.Nullable;

public abstract class StargateLinkableBlockEntity extends ABlockEntity implements StargateLinkable, StructurePlaceableBlockEntity {

	protected final StargateRef ref = new StargateRef(this::method_10997);

	public StargateLinkableBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
	}

	@Override
	public @Nullable Stargate asGate() {
		return ref.asGate();
	}

	@Override
	public boolean isLinked() {
		return ref.isLinked();
	}

	@Override
	public void method_11014(class_2487 nbt) {
		super.method_11014(nbt);

		this.ref.readNbt(nbt);
    }

	@Override
	protected void method_11007(class_2487 nbt) {
		super.method_11007(nbt);
		this.ref.writeNbt(nbt);
    }

	@Override
	public boolean link(@Nullable Stargate gate) {
		if (!ref.link(gate))
			return false;

		this.method_5431();
		this.sync();
		return true;
	}

	@Override
	public boolean link(long address) {
		if (!ref.link(address)) return false;

		this.method_5431();
		this.sync();
		return true;
	}

	@Override
	public void unlink() {
		ref.unlink();
		this.method_5431();
		this.sync();
	}

	@Override
	public void onBreak(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState) {
		this.unlink(); // frees the dangling stargate mark
	}

	@Override
	public class_2487 method_16887() {
		if (field_11863 instanceof class_3218 serverWorld)
			StargateServerData.accept(serverWorld, data -> data.mark(this));

		return method_38244();
	}

    @Override
	public void amble$onStructurePlaced(class_2487 nbt) {
		nbt.method_10551("Address");
	}
}
