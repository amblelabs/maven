package dev.amble.stargate.util;

import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2514;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7922;
import net.minecraft.nbt.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class NbtUtil {

    private static boolean isOf(class_2520 element, int type) {
        int i = element == null ? class_2520.field_33250 : element.method_10711();
        return i == type || (type == class_2520.field_33263 && class_2520.field_33251 <= i && i <= class_2520.field_33256);
    }

    public static long getLong(class_2487 nbt, String key, long def) {
        class_2520 l = nbt.method_10580(key);

        if (l != null && isOf(l, class_2520.field_33263)) {
            try {
                return ((class_2514) l).method_10699();
            } catch (ClassCastException ignored) { }
        }

        return def;
    }

    @SuppressWarnings("DataFlowIssue")
    public static @Nullable class_2960 getId(class_2487 nbt, String key) {
        return getId(nbt, key, null);
    }

    public static @NotNull class_2960 getId(class_2487 nbt, String key, class_2960 def) {
        class_2520 l = nbt.method_10580(key);

        if (l != null && isOf(l, class_2520.field_33258)) {
            try {
                return new class_2960(l.method_10714());
            } catch (ClassCastException ignored) { }
        }

        return def;
    }

    public static void putId(class_2487 nbt, String key, class_2960 id) {
        nbt.method_10582(key, id.toString());
    }

    public static <T> class_5321<T> getRegistryKey(class_2487 nbt, String key, class_2378<T> registry, class_5321<T> def) {
        class_2960 id = getId(nbt, key);

        if (id == null)
            return def;

        return class_5321.method_29179(registry.method_30517(), id);
    }

    public static <T> @NotNull class_5321<T> getRegistryKey(class_2487 nbt, String key, class_2378<T> registry, class_2960 def) {
        class_2960 id = getId(nbt, key, def);
        return class_5321.method_29179(registry.method_30517(), id);
    }

    public static <T> @NotNull class_5321<T> getRegistryKey(class_2487 nbt, String key, class_7922<T> registry) {
        return getRegistryKey(nbt, key, registry, registry.method_10137());
    }

    public static <T> @Nullable class_5321<T> getRegistryKey(class_2487 nbt, String key, class_2378<T> registry) {
        return getRegistryKey(nbt, key, registry, (class_5321<T>) null);
    }

    public static <T> void putRegistryKey(class_2487 nbt, String key, class_5321<T> registryKey) {
        putId(nbt, key, registryKey.method_29177());
    }

    public static <T> @Nullable T getRegistered(class_2487 nbt, String key, class_2378<T> registry, class_2960 def) {
        class_5321<T> regKey = getRegistryKey(nbt, key, registry, def);
        return registry.method_29107(regKey);
    }

    public static <T> @Nullable T getRegistered(class_2487 nbt, String key, class_7922<T> registry) {
        return getRegistered(nbt, key, registry, registry.method_10137());
    }

    public static <T> @Nullable T getRegistered(class_2487 nbt, String key, class_2378<T> registry, class_5321<T> def) {
        class_5321<T> regKey = getRegistryKey(nbt, key, registry, def);
        return registry.method_29107(regKey);
    }

    public static <T> @NotNull T getRegistered(class_2487 nbt, String key, class_2378<T> registry, class_6880<T> def) {
        return getRegistered(nbt, key, registry, def.comp_349());
    }

    public static <T> @NotNull T getRegistered(class_2487 nbt, String key, class_2378<T> registry, T def) {
        class_5321<T> regKey = getRegistryKey(nbt, key, registry);
        if (regKey == null) return def;

        T t = registry.method_29107(regKey);
        return t != null ? t : def;
    }

    @SuppressWarnings("DataFlowIssue")
    public static <T> @Nullable T getRegistered(class_2487 nbt, String key, class_2378<T> registry) {
        return getRegistered(nbt, key, registry, (T) null);
    }

    public static <T> @Nullable class_6880<T> getRegistryEntry(class_2487 nbt, String key, class_2378<T> registry, class_2960 def) {
        class_5321<T> regKey = getRegistryKey(nbt, key, registry, def);
        return registry.method_40264(regKey).orElse(null);
    }

    public static <T> @Nullable class_6880<T> getRegistryEntry(class_2487 nbt, String key, class_7922<T> registry) {
        return getRegistryEntry(nbt, key, registry, registry.method_10137());
    }

    public static <T> @Nullable class_6880<T> getRegistryEntry(class_2487 nbt, String key, class_2378<T> registry, class_5321<T> def) {
        class_5321<T> regKey = getRegistryKey(nbt, key, registry, def);
        return registry.method_40264(regKey).orElse(null);
    }

    public static <T> @NotNull class_6880<T> getRegistryEntry(class_2487 nbt, String key, class_2378<T> registry, class_6880<T> def) {
        class_5321<T> regKey = getRegistryKey(nbt, key, registry);
        return regKey == null ? def : registry.method_40264(regKey).map(o -> (class_6880<T>) o).orElse(def);
    }

    @SuppressWarnings("DataFlowIssue")
    public static <T> @Nullable class_6880<T> getRegistryEntry(class_2487 nbt, String key, class_2378<T> registry) {
        return getRegistryEntry(nbt, key, registry, (class_6880<T>) null);
    }

    public static <T> void putRegistryEntry(class_2487 nbt, String key, class_6880<T> entry) {
        putRegistryKey(nbt, key, entry.method_40230().get());
    }
}
