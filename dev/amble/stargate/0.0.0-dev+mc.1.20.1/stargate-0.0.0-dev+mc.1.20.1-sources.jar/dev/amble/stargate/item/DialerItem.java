package dev.amble.stargate.item;

import dev.amble.stargate.api.address.AddressProvider;
import dev.amble.stargate.api.data.StargateLinkable;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.state.GateState;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

/**
 * right click to link to stargate
 * right click on stargate to dial
 */
public class DialerItem extends StargateLinkableItem {

	public DialerItem(class_1793 settings) {
		super(settings, true);
	}

	@Override
	public class_1269 method_7884(class_1838 context) {
		if (context.method_8045().method_8608()) return super.method_7884(context);

		class_3218 world = (class_3218) context.method_8045();
		class_2338 pos = context.method_8037();
		class_1799 hand = context.method_8041();

		if (world.method_8321(pos) instanceof StargateLinkable be) {
			Stargate gate = be.asGate();

			if (gate == null) return class_1269.field_5814;

			if (!isLinked(hand)) {
				this.link(hand, gate);
				return class_1269.field_5812;
			}

			Stargate target = StargateLinkableItem.getStargate(world, hand);
			if (target == null) return class_1269.field_5814;

			GateState.Closed closed = gate.stateOrNull(GateState.Closed.state);

			if (closed != null) {
				closed.address = AddressProvider.Global.asString(target.globalAddress());
				gate.markDirty();
			}

			hand.method_7934(1);
			return class_1269.field_5812;
		}

		return super.method_7884(context);
	}

	@Override
	public void method_7851(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip, class_1836 context) {
		tooltip.add(class_2561.method_43471("tooltip.stargate.dialer.hint").method_27692(class_124.field_1064)
				.method_27692(class_124.field_1056));

		super.method_7851(stack, world, tooltip, context);
	}
}
