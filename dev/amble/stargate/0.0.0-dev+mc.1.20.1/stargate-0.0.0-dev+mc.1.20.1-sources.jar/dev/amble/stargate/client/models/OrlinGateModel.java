package dev.amble.stargate.client.models;

import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class OrlinGateModel extends BaseStargateModel {

	public final class_630 stargate;
	public final class_630 chevron7;
	public final class_630 chevron1;
	public final class_630 chevron2;
	public final class_630 chevron3;
	public final class_630 chevron4;
	public final class_630 chevron5;
	public final class_630 chevron6;
	public final class_630 chevron8;
	public final class_630 chevron9;

	public OrlinGateModel() {
		class_630 root = getTexturedModelData().method_32109();

		this.stargate = root.method_32086("stargate");

		class_630 gate = this.stargate.method_32086("gate");
		class_630 innerlayer = gate.method_32086("innerlayer");

		this.chevron7 = innerlayer.method_32086("chevron7");
		this.chevron1 = innerlayer.method_32086("chevron1");
		this.chevron2 = innerlayer.method_32086("chevron2");
		this.chevron3 = innerlayer.method_32086("chevron3");
		this.chevron4 = innerlayer.method_32086("chevron4");
		this.chevron5 = innerlayer.method_32086("chevron5");
		this.chevron6 = innerlayer.method_32086("chevron6");
		this.chevron8 = innerlayer.method_32086("chevron8");
		this.chevron9 = innerlayer.method_32086("chevron9");
	}

	@Override
	public class_630 method_32008() {
		return stargate;
	}

	@Override
	public class_630[] bakeChevronLights() {
		return new class_630[] {
				chevron1, chevron2, chevron3,
				chevron4, chevron5, chevron6,
				chevron7, chevron8, chevron9
		};
	}

	public static class_5607 getTexturedModelData() {
		class_5609 modelData = new class_5609();
		class_5610 modelPartData = modelData.method_32111();
		class_5610 stargate = modelPartData.method_32117("stargate", class_5606.method_32108(), class_5603.method_32090(0.0F, 24.0F, 0.0F));

		class_5610 base = stargate.method_32117("base", class_5606.method_32108().method_32101(0, 17).method_32098(-24.0F, -1.0F, 6.0F, 48.0F, 1.0F, 2.0F, new class_5605(0.0F))
		.method_32101(0, 0).method_32098(-24.0F, -17.0F, 0.0F, 48.0F, 17.0F, 0.0F, new class_5605(0.0F))
		.method_32101(0, 21).method_32098(-24.0F, -1.0F, -14.0F, 48.0F, 1.0F, 2.0F, new class_5605(0.0F))
		.method_32101(0, 25).method_32098(-24.0F, -1.0F, -12.0F, 2.0F, 1.0F, 18.0F, new class_5605(0.0F))
		.method_32101(41, 25).method_32098(22.0F, -1.0F, -12.0F, 2.0F, 1.0F, 18.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 gate = stargate.method_32117("gate", class_5606.method_32108(), class_5603.method_32090(0.0F, -24.0F, 0.5F));

		class_5610 innerlayer = gate.method_32117("innerlayer", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 cube_r1 = innerlayer.method_32117("cube_r1", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F));

		class_5610 cube_r2 = innerlayer.method_32117("cube_r2", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.7453F));

		class_5610 cube_r3 = innerlayer.method_32117("cube_r3", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F));

		class_5610 cube_r4 = innerlayer.method_32117("cube_r4", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F));

		class_5610 cube_r5 = innerlayer.method_32117("cube_r5", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F));

		class_5610 cube_r6 = innerlayer.method_32117("cube_r6", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0472F));

		class_5610 cube_r7 = innerlayer.method_32117("cube_r7", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 cube_r8 = innerlayer.method_32117("cube_r8", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F));

		class_5610 cube_r9 = innerlayer.method_32117("cube_r9", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.4435F));

		class_5610 cube_r10 = innerlayer.method_32117("cube_r10", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F));

		class_5610 cube_r11 = innerlayer.method_32117("cube_r11", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.4435F));

		class_5610 cube_r12 = innerlayer.method_32117("cube_r12", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F));

		class_5610 cube_r13 = innerlayer.method_32117("cube_r13", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0472F));

		class_5610 cube_r14 = innerlayer.method_32117("cube_r14", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F));

		class_5610 cube_r15 = innerlayer.method_32117("cube_r15", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.7453F));

		class_5610 cube_r16 = innerlayer.method_32117("cube_r16", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F));

		class_5610 cube_r17 = innerlayer.method_32117("cube_r17", class_5606.method_32108().method_32101(63, 67).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F));

		class_5610 chevron7 = innerlayer.method_32117("chevron7", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 cube_r18 = chevron7.method_32117("cube_r18", class_5606.method_32108().method_32101(46, 76).method_32098(-3.5F, 16.0F, -3.0F, 7.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 chevron1 = innerlayer.method_32117("chevron1", class_5606.method_32108(), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F));

		class_5610 cube_r19 = chevron1.method_32117("cube_r19", class_5606.method_32108().method_32101(46, 76).method_32098(-3.5F, 16.0F, -3.0F, 7.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 chevron2 = innerlayer.method_32117("chevron2", class_5606.method_32108(), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F));

		class_5610 cube_r20 = chevron2.method_32117("cube_r20", class_5606.method_32108().method_32101(46, 76).method_32098(-3.5F, 16.0F, -3.0F, 7.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 chevron3 = innerlayer.method_32117("chevron3", class_5606.method_32108(), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F));

		class_5610 cube_r21 = chevron3.method_32117("cube_r21", class_5606.method_32108().method_32101(46, 76).method_32098(-3.5F, 16.0F, -3.0F, 7.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 chevron4 = innerlayer.method_32117("chevron4", class_5606.method_32108(), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F));

		class_5610 cube_r22 = chevron4.method_32117("cube_r22", class_5606.method_32108().method_32101(46, 76).method_32098(-3.5F, 16.0F, -3.0F, 7.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 chevron5 = innerlayer.method_32117("chevron5", class_5606.method_32108(), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F));

		class_5610 cube_r23 = chevron5.method_32117("cube_r23", class_5606.method_32108().method_32101(46, 76).method_32098(-3.5F, 16.0F, -3.0F, 7.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 chevron6 = innerlayer.method_32117("chevron6", class_5606.method_32108(), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F));

		class_5610 cube_r24 = chevron6.method_32117("cube_r24", class_5606.method_32108().method_32101(46, 76).method_32098(-3.5F, 16.0F, -3.0F, 7.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 chevron8 = innerlayer.method_32117("chevron8", class_5606.method_32108(), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F));

		class_5610 cube_r25 = chevron8.method_32117("cube_r25", class_5606.method_32108().method_32101(46, 76).method_32098(-3.5F, 16.0F, -3.0F, 7.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 chevron9 = innerlayer.method_32117("chevron9", class_5606.method_32108(), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F));

		class_5610 cube_r26 = chevron9.method_32117("cube_r26", class_5606.method_32108().method_32101(46, 76).method_32098(-3.5F, 16.0F, -3.0F, 7.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 outerlayer = gate.method_32117("outerlayer", class_5606.method_32108().method_32101(63, 75).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.25F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 cube_r27 = outerlayer.method_32117("cube_r27", class_5606.method_32108().method_32101(63, 59).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.251F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0472F));

		class_5610 cube_r28 = outerlayer.method_32117("cube_r28", class_5606.method_32108().method_32101(63, 75).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.25F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F));

		class_5610 cube_r29 = outerlayer.method_32117("cube_r29", class_5606.method_32108().method_32101(63, 59).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.251F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F));

		class_5610 cube_r30 = outerlayer.method_32117("cube_r30", class_5606.method_32108().method_32101(63, 75).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.25F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F));

		class_5610 cube_r31 = outerlayer.method_32117("cube_r31", class_5606.method_32108().method_32101(63, 59).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.251F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.7453F));

		class_5610 cube_r32 = outerlayer.method_32117("cube_r32", class_5606.method_32108().method_32101(63, 75).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.25F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F));

		class_5610 cube_r33 = outerlayer.method_32117("cube_r33", class_5606.method_32108().method_32101(63, 59).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.251F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 cube_r34 = outerlayer.method_32117("cube_r34", class_5606.method_32108().method_32101(63, 75).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.25F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F));

		class_5610 cube_r35 = outerlayer.method_32117("cube_r35", class_5606.method_32108().method_32101(63, 59).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.251F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.4435F));

		class_5610 cube_r36 = outerlayer.method_32117("cube_r36", class_5606.method_32108().method_32101(63, 75).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.25F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F));

		class_5610 cube_r37 = outerlayer.method_32117("cube_r37", class_5606.method_32108().method_32101(63, 59).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.251F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.4435F));

		class_5610 cube_r38 = outerlayer.method_32117("cube_r38", class_5606.method_32108().method_32101(63, 75).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.25F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F));

		class_5610 cube_r39 = outerlayer.method_32117("cube_r39", class_5606.method_32108().method_32101(63, 59).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.251F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0472F));

		class_5610 cube_r40 = outerlayer.method_32117("cube_r40", class_5606.method_32108().method_32101(63, 75).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.25F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F));

		class_5610 cube_r41 = outerlayer.method_32117("cube_r41", class_5606.method_32108().method_32101(63, 59).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.251F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.7453F));

		class_5610 cube_r42 = outerlayer.method_32117("cube_r42", class_5606.method_32108().method_32101(63, 75).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.25F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F));

		class_5610 cube_r43 = outerlayer.method_32117("cube_r43", class_5606.method_32108().method_32101(63, 59).method_32098(-3.5F, 16.0F, -2.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.251F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F));

		class_5610 steps = stargate.method_32117("steps", class_5606.method_32108().method_32101(105, 57).method_32098(-8.0F, -6.0F, -10.0F, 1.0F, 1.0F, 6.0F, new class_5605(0.0F))
		.method_32101(34, 101).method_32098(-8.0F, -6.0F, -4.0F, 1.0F, 6.0F, 1.0F, new class_5605(0.0F))
		.method_32101(105, 93).method_32098(-8.0F, -6.0F, -11.0F, 1.0F, 4.0F, 1.0F, new class_5605(0.0F))
		.method_32101(105, 73).method_32098(-8.0F, -3.0F, -15.0F, 1.0F, 1.0F, 4.0F, new class_5605(0.0F))
		.method_32101(106, 50).method_32098(-8.0F, -3.0F, -16.0F, 1.0F, 3.0F, 1.0F, new class_5605(0.0F))
		.method_32101(43, 45).method_32098(-7.0F, -2.5F, -15.5F, 14.0F, 0.0F, 5.0F, new class_5605(0.0F))
		.method_32101(0, 45).method_32098(-7.0F, -5.5F, -10.5F, 14.0F, 0.0F, 7.0F, new class_5605(0.0F))
		.method_32101(105, 65).method_32098(7.0F, -6.0F, -10.0F, 1.0F, 1.0F, 6.0F, new class_5605(0.0F))
		.method_32101(106, 44).method_32098(7.0F, -6.0F, -11.0F, 1.0F, 4.0F, 1.0F, new class_5605(0.0F))
		.method_32101(105, 79).method_32098(7.0F, -3.0F, -15.0F, 1.0F, 1.0F, 4.0F, new class_5605(0.0F))
		.method_32101(63, 106).method_32098(7.0F, -3.0F, -16.0F, 1.0F, 3.0F, 1.0F, new class_5605(0.0F))
		.method_32101(105, 85).method_32098(7.0F, -6.0F, -4.0F, 1.0F, 6.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));
		return class_5607.method_32110(modelData, 128, 128);
	}
}