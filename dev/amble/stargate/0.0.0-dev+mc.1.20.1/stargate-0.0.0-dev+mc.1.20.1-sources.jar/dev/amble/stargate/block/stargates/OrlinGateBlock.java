package dev.amble.stargate.block.stargates;

import dev.amble.lib.block.ABlockSettings;
import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.stargate.api.GateKernelRegistry;
import dev.amble.stargate.block.StargateBlock;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.init.StargateSounds;
import dev.amble.stargate.util.VoxelShapeUtil;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings({"deprecation", "UnstableApiUsage"})
public class OrlinGateBlock extends StargateBlock {

    private static final class_265 SHAPE = class_259.method_1081(0.0F, 0.0F, 0.0F, 16.0F / 16, 8.0F / 16f, 1.0f);

    public OrlinGateBlock(ABlockSettings settings) {
        super(settings);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return VoxelShapeUtil.rotateShapeH(class_2350.field_11043, HorizontalBlockBehavior.getFacing(state), SHAPE);
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return VoxelShapeUtil.rotateShapeH(class_2350.field_11043, HorizontalBlockBehavior.getFacing(state), SHAPE);
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        super.method_9567(world, pos, state, placer, stack);

        if (world instanceof class_3218 serverWorld && world.method_8321(pos) instanceof StargateBlockEntity sg) {
            sg.onPlacedWithKernel(serverWorld, state, GateKernelRegistry.ORLIN);
            world.method_8396(null, pos, StargateSounds.DING, class_3419.field_15245, 1.0f, 1.0f);
        }
    }
}
