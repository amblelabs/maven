package dev.amble.stargate.client.renderers;

import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.client.api.event.render.StargateRenderEvent;
import dev.amble.stargate.api.state.GateState;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.client.renderers.portal.PortalRendering;
import dev.drtheo.yaar.event.TEvents;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3695;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4696;
import net.minecraft.class_5614;
import net.minecraft.class_827;

public class StargateBlockEntityRenderer implements class_827<StargateBlockEntity> {

    public StargateBlockEntityRenderer(class_5614.class_5615 ctx) { }

    @Override
    public void render(StargateBlockEntity entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        class_3695 profiler = class_310.method_1551().method_16011();
        profiler.method_15396("stargate");

        if (entity.getBlockSet() != null) {
            matrices.method_22903();

            class_2680 blockState = entity.getBlockSet();
            class_310.method_1551().method_1541().method_3355(blockState,
                    entity.method_11016(), entity.method_10997(), matrices, vertexConsumers.getBuffer(
                            class_4696.method_23679(blockState)), true, entity.method_10997().field_9229
            );

            matrices.method_22909();
        }

        Stargate gate = entity.asGate();
        if (gate == null) return;

        matrices.method_22903();
        TEvents.handle(new StargateRenderEvent(gate, entity, this, profiler, matrices, vertexConsumers, light, overlay, tickDelta));
        matrices.method_22909();

        if (gate.getGateState().gateState() != GateState.StateType.CLOSED) PortalRendering.QUEUE.add(entity);

        profiler.method_15407();
    }
}