package dev.amble.stargate.api;

import dev.amble.stargate.api.data.StargateServerData;
import dev.amble.stargate.api.event.address.StargateRemoveEvent;
import dev.amble.stargate.api.event.init.StargateCreatedEvents;
import dev.amble.stargate.api.state.stargate.GateIdentityState;
import dev.drtheo.yaar.event.TEvents;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_3218;

public class ServerStargate extends Stargate {

    public ServerStargate(GateIdentityState identity, class_3218 world, class_2338 pos, class_2350 direction) {
        super(identity, world, pos, direction);
        StargateCreatedEvents.handleCreation(this);
    }

    public ServerStargate(GateIdentityState identity, class_2487 nbt) {
        super(identity, nbt, false);
    }

    @Override
    public @NotNull ServerStargate asGate() {
        return (ServerStargate) super.asGate();
    }

    @Override
    public @NotNull class_3218 world() {
        return (class_3218) Objects.requireNonNull(super.world());
    }

    public void remove() {
        class_3218 world = this.world();

        this.kernel().shape.destroy(world, pos, facing);
        TEvents.handle(new StargateRemoveEvent(StargateServerData.get(world), this));
    }
}
