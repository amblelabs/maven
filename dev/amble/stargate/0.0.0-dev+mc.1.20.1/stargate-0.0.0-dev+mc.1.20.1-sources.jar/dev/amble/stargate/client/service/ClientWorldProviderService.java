package dev.amble.stargate.client.service;

import dev.amble.stargate.service.WorldProviderService;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_638;

public class ClientWorldProviderService implements WorldProviderService {

    @Override
    public class_1937 getWorld(class_5321<class_1937> dimension, boolean isClient) {
        if (isClient) {
            class_638 world = class_310.method_1551().field_1687;
            return world != null && dimension.equals(world.method_27983()) ? world : null;
        }

        return WorldProviderService.super.getWorld(dimension, false);
    }
}
