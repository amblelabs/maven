package dev.amble.stargate.api.event.address;

import dev.amble.stargate.api.ServerStargate;
import dev.amble.stargate.api.address.AddressProvider;
import dev.drtheo.yaar.event.TEvent;
import dev.drtheo.yaar.event.TEvents;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class AddressResolveEvent implements TEvent.Result<AddressResolveEvents, AddressResolveEvent.Result> {

    private final ServerStargate stargate;
    private final long address;
    private final int length;

    private dev.amble.stargate.api.event.address.AddressResolveEvent.Result result = PASS;

    public AddressResolveEvent(ServerStargate stargate, String address, int length) {
        this.stargate = stargate;
        this.address = AddressProvider.pack(address, length);
        this.length = length;
    }

    @Override
    public TEvents.BaseType<AddressResolveEvents> type() {
        return AddressResolveEvents.event;
    }

    @Override
    public void handleAll(Iterable<AddressResolveEvents> subscribed) {
        for (AddressResolveEvents e : subscribed) {
            dev.amble.stargate.api.event.address.AddressResolveEvent.Result result = TEvent.handleSilent(this, e, () -> e.resolve(stargate, address, length), PASS);

            if (result == PASS) continue;

            this.result = result;
            return;
        }
    }

    @Override
    public dev.amble.stargate.api.event.address.AddressResolveEvent.Result result() {
        return result;
    }

    public static final dev.amble.stargate.api.event.address.AddressResolveEvent.Result PASS = new dev.amble.stargate.api.event.address.AddressResolveEvent.Result.Pass();
    public static final dev.amble.stargate.api.event.address.AddressResolveEvent.Result FAIL = new dev.amble.stargate.api.event.address.AddressResolveEvent.Result.Fail();

    public static dev.amble.stargate.api.event.address.AddressResolveEvent.Result route(@NotNull ServerStargate stargate, long openCost, long costPerTick) {
        return new dev.amble.stargate.api.event.address.AddressResolveEvent.Result.Route(stargate, openCost, costPerTick);
    }

    public static dev.amble.stargate.api.event.address.AddressResolveEvent.Result routeOrFail(@Nullable ServerStargate stargate, long openCost, long costPerTick) {
        return stargate == null ? FAIL : route(stargate, openCost, costPerTick);
    }

    public sealed interface Result {

        record Fail() implements dev.amble.stargate.api.event.address.AddressResolveEvent.Result { }

        record Route(ServerStargate stargate, long openCost, long costPerTick) implements dev.amble.stargate.api.event.address.AddressResolveEvent.Result { }

        record Pass() implements dev.amble.stargate.api.event.address.AddressResolveEvent.Result { }
    }
}
