package dev.amble.stargate.client.api.behavior.stargate;

import dev.amble.lib.block.behavior.horizontal.HorizontalBlockBehavior;
import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.address.Glyph;
import dev.amble.stargate.api.event.init.StargateLoadedEvents;
import dev.amble.stargate.api.event.tick.StargateTickEvents;
import dev.amble.stargate.api.state.GateState;
import dev.amble.stargate.api.state.stargate.GateIdentityState;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.client.api.event.render.StargateAnimateEvent;
import dev.amble.stargate.client.api.event.render.StargateRenderEvents;
import dev.amble.stargate.client.api.state.stargate.ClientAbstractStargateState;
import dev.amble.stargate.client.models.BaseStargateModel;
import dev.amble.stargate.client.renderers.StargateBlockEntityRenderer;
import dev.amble.stargate.client.util.EmissionUtil;
import dev.drtheo.yaar.behavior.TBehavior;
import dev.drtheo.yaar.event.TEvents;
import dev.drtheo.yaar.state.StateResolveError;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_3695;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_630;
import net.minecraft.class_7833;

public abstract class ClientAbstractStargateBehavior<
    T extends ClientAbstractStargateState<?>
> implements
    TBehavior,
    StargateRenderEvents,
    StargateLoadedEvents,
    StargateTickEvents {

    private final Class<T> clazz;
    private final Class<? extends GateIdentityState> identity;

    public ClientAbstractStargateBehavior(
        Class<? extends GateIdentityState> identity,
        Class<T> clazz
    ) {
        this.clazz = clazz;
        this.identity = identity;
    }

    protected abstract T createClientState(Stargate stargate);

    @Override
    public void onLoaded(Stargate stargate) {
        if (
            stargate.isClient() &&
            identity.isInstance(stargate.state(GateIdentityState.state))
        ) stargate.addState(this.createClientState(stargate));
    }

    @Override
    public void tick(Stargate stargate) {
        if (!stargate.isClient()) return;

        stargate.resolveState(ClientAbstractStargateState.state).age++;
    }

    @Override
    public void render(
        Stargate stargate,
        ClientAbstractStargateState<?> clientState,
        StargateBlockEntity entity,
        StargateBlockEntityRenderer renderer,
        class_3695 profiler,
        class_4587 matrices,
        class_4597 vertexConsumers,
        int light,
        int overlay,
        float tickDelta
    ) {
        this.customRender(
            stargate,
            this.tryCastState(stargate, clientState),
            entity,
            renderer,
            profiler,
            matrices,
            vertexConsumers,
            light,
            overlay,
            tickDelta
        );
    }

    protected T tryCastState(
        Stargate stargate,
        ClientAbstractStargateState<?> clientState
    ) {
        // TODO: create an abstract exception class that will get caught by stuff and make StateResolveError extend it
        //  StateResolveError will print stacktraces in debug.
        if (!clazz.isInstance(clientState)) throw StateResolveError.create(
            stargate,
            ClientAbstractStargateState.state
        );

        return (T) clientState;
    }

    protected void customRender(
        Stargate stargate,
        T clientState,
        StargateBlockEntity entity,
        StargateBlockEntityRenderer renderer,
        class_3695 profiler,
        class_4587 matrices,
        class_4597 vertexConsumers,
        int light,
        int overlay,
        float tickDelta
    ) {
        matrices.method_46416(0.5f, 1.4f, 0.5f);

        final float k = HorizontalBlockBehavior.getFacing(
            entity.method_11010()
        ).method_10144();

        matrices.method_22907(class_7833.field_40715.rotationDegrees(k));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(180f));
        matrices.method_22905(1, 1, 1);

        this.preRender(
            stargate,
            clientState,
            entity,
            renderer,
            profiler,
            matrices,
            vertexConsumers,
            light,
            overlay,
            tickDelta
        );
        boolean anyVisible = this.updateChevronVisibility(
            stargate,
            clientState.model()
        );

        profiler.method_15396("render2layer");
        EmissionUtil.render2Layers(
            clientState.model(),
            clientState.texture,
            clientState.emission,
            anyVisible,
            matrices,
            vertexConsumers,
            light,
            overlay
        );
        profiler.method_15407();
    }

    protected void preRender(
        Stargate stargate,
        T clientState,
        StargateBlockEntity entity,
        StargateBlockEntityRenderer renderer,
        class_3695 profiler,
        class_4587 matrices,
        class_4597 vertexConsumers,
        int light,
        int overlay,
        float tickDelta
    ) {
        profiler.method_15396("animate");
        TEvents.handle(
            new StargateAnimateEvent(entity, stargate, clientState, profiler)
        );
        profiler.method_15407();
    }

    public boolean updateChevronVisibility(
        Stargate stargate,
        BaseStargateModel model
    ) {
        GateState<?> state = stargate.getGateState();

        boolean visible = state.gateState() != GateState.StateType.CLOSED;
        int locked =
            state instanceof GateState.Closed closed ? closed.locked : -1;

        class_630[] chevrons = model.chevrons;

        for (int i = 0; i < chevrons.length; i++) {
            if (chevrons[i] != null) chevrons[i].field_3665 =
                visible || i < locked;
        }

        return visible || locked != 0;
    }

    public abstract static class Spinning<
        T extends ClientAbstractStargateState<?>
    > extends ClientAbstractStargateBehavior<T> {

        public Spinning(
            Class<? extends GateIdentityState> identity,
            Class<T> clazz
        ) {
            super(identity, clazz);
        }

        private static final int MAX_GLYPHS = Glyph.ALL.length;

        public static boolean shouldRenderGlyphs(
            class_310 client,
            Stargate stargate
        ) {
            class_243 pos = client.field_1773.method_19418().method_19326();
            return class_243.method_24953(stargate.pos()).method_24802(pos, 16);
        }

        public static float renderGlyphs(
            float rot,
            final float initialRot,
            final ClientAbstractStargateState<?> glyphState,
            final class_4587 matrices,
            final class_4597 vertexConsumers,
            final Stargate gate,
            final int light
        ) {
            final class_310 client = class_310.method_1551();
            rot = (rot * 180) / class_3532.field_29844;

            if (shouldRenderGlyphs(client, gate)) {
                final GlyphCache cache = GlyphCache.get();
                final class_2350 direction = gate.facing();

                final boolean northern =
                    direction.method_10166() == class_2350.class_2351.field_11051;
                final int multiplier = -direction.method_10171().method_10181();

                final float xOffset =
                    (northern
                        ? direction.method_10148()
                        : direction.method_10165()) *
                    0.3f *
                    multiplier;
                final float zOffset =
                    (northern
                        ? direction.method_10165()
                        : direction.method_10148()) *
                    0.24f *
                    multiplier;

                matrices.method_22903();
                matrices.method_46416(0, -2.05f, 0);
                matrices.method_46416(xOffset, 0.05f, zOffset);
                matrices.method_22905(0.025f, 0.025f, 0.025f);

                final GateState.Closed closed = gate.stateOrNull(
                    GateState.Closed.state
                );
                final int lockingChevronIdx =
                    closed != null && (closed.locked > 0 || closed.locking)
                        ? closed.locked
                        : -1; // TODO: in theory, closed.locked > 0 check is redundant
                final int selectedGlyphIdx =
                    closed != null &&
                    lockingChevronIdx != -1 &&
                    lockingChevronIdx < closed.address.length()
                        ? closed.glyphIdxAtChevron(lockingChevronIdx)
                        : -1;

                if (closed != null && closed.locking) {
                    float rotProgress =
                        (float) closed.timer /
                        (float) GateState.Closed.TICKS_PER_GLYPH2;

                    // FIXME: make this calculation be done in rad instead of deg
                    float selectedRot = class_3532.method_15393(
                        initialRot + (360f * selectedGlyphIdx) / MAX_GLYPHS
                    );

                    System.out.println(
                        "rot: " +
                            rot +
                            "/" +
                            selectedRot +
                            "; " +
                            rotProgress * 100 +
                            "%"
                    );
                    rot +=
                        class_3532.method_15393(
                            selectedRot * rotProgress - rot
                        ) +
                        (360f * (closed.locked % 2 == 0 ? -1 : 1));
                }

                matrices.method_22907(class_7833.field_40718.rotationDegrees(rot));

                for (int i = 0; i < MAX_GLYPHS; i++) {
                    final boolean isInDial =
                        closed != null && closed.address$contains(Glyph.ALL[i]);
                    final boolean isSelected =
                        isInDial && i == selectedGlyphIdx;

                    final float angle = (2 * class_3532.field_29844 * i) / MAX_GLYPHS;
                    final int color = isInDial
                        ? 0x5c5c73
                        : glyphState.glyphColor;
                    final int glyphLight = isSelected ? 0xf000f0 : light;

                    matrices.method_22903();

                    matrices.method_46416(
                        class_3532.method_15374(angle) * 117,
                        class_3532.method_15362(angle) * 117,
                        0
                    );

                    // rotate the symbols towards the gate
                    matrices.method_22907(
                        class_7833.field_40717.rotationDegrees(
                            (float) (initialRot + Math.toDegrees(angle))
                        )
                    );

                    cache.draw(
                        i,
                        -4,
                        color,
                        false,
                        matrices.method_23760().method_23761(),
                        vertexConsumers,
                        class_327.class_6415.field_33995,
                        0,
                        glyphLight
                    );

                    matrices.method_22909();
                }

                matrices.method_22909();
            }

            return (rot * class_3532.field_29844) / 180f;
        }
    }
}
