package dev.amble.stargate.client.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.client.render.*;

public class SpaceSkyRenderer {
    public static final Quaternionf[] LOOKUP = new Quaternionf[]{null, class_7833.field_40714.rotationDegrees(90.0f),
            class_7833.field_40714.rotationDegrees(-90.0f), class_7833.field_40714.rotationDegrees(180.0f),
            class_7833.field_40718.rotationDegrees(90.0f), class_7833.field_40718.rotationDegrees(-90.0f), null};
    private static final int FACES_COUNT = 6;
    private final class_2960[] faces = new class_2960[6];

    public SpaceSkyRenderer(class_2960 faces) {
        for (int i = 0; i < 6; ++i) {
            this.faces[i] = faces.method_45136(faces.method_12832() + "_" + i + ".png");
        }
    }

    public void draw(class_289 tessellator, class_287 bufferBuilder, class_4587 matrixStack) {
        RenderSystem.enableBlend();
        RenderSystem.setShader(class_757::method_34543);
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();

        for (int k = 0; k < 6; ++k) {
            matrixStack.method_22903();
            Quaternionf rot = LOOKUP[k];

            if (rot != null) {
                matrixStack.method_22907(rot);
            }

            Matrix4f matrix4f = matrixStack.method_23760().method_23761();

            RenderSystem.setShaderTexture(0, this.faces[k]);
            bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1575);
            int l = 255;
            bufferBuilder.method_22918(matrix4f,-100.0f, -100.0f, -100.0f).method_22913(0.0f, 0.0f).method_1336(255, 255, 255, l).method_1344();
            bufferBuilder.method_22918(matrix4f,-100.0f, -100.0f, 100.0f).method_22913(0.0f, 1.0f).method_1336(255, 255, 255, l).method_1344();
            bufferBuilder.method_22918(matrix4f,100.0f, -100.0f, 100.0f).method_22913(1.0f, 1.0f).method_1336(255, 255, 255, l).method_1344();
            bufferBuilder.method_22918(matrix4f,100.0f, -100.0f, -100.0f).method_22913(1.0f, 0.0f).method_1336(255, 255, 255, l).method_1344();
            tessellator.method_1350();
            matrixStack.method_22909();
        }
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }
}
