package dev.amble.stargate.init;

import dev.amble.lib.container.RegistryContainer;
import dev.amble.stargate.effect.AncientGeneTherapyEffect;
import dev.amble.stargate.effect.SpacialDynamicEffect;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public class StargateStatusEffects implements RegistryContainer<class_1291> {

    public static final class_1291 SPACIAL_DYNAMIC = new SpacialDynamicEffect();
    public static final class_1291 ANCIENT_GENE_THERAPY = new AncientGeneTherapyEffect();

    @Override
    public Class<class_1291> getTargetClass() {
        return class_1291.class;
    }

    @Override
    public class_2378<class_1291> getRegistry() {
        return class_7923.field_41174;
    }
}
