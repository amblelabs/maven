package dev.amble.stargate.init;

import dev.amble.lib.container.RegistryContainer;
import java.lang.reflect.Field;
import net.minecraft.class_1320;
import net.minecraft.class_1329;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class StargateAttributes implements RegistryContainer<class_1320> {

    public static final class_1320 SPACIAL_RESISTANCE = of("attribute.stargate.spacial_resistance", 0, 0, 100);

    private static class_1320 of(String translation, double fallback, double min, double max) {
        return new class_1329(translation, fallback, min, max).method_26829(true);
    }

    @Override
    public Class<class_1320> getTargetClass() {
        return class_1320.class;
    }

    @Override
    public class_2378<class_1320> getRegistry() {
        return class_7923.field_41190;
    }

    @Override
    public void postProcessField(class_2960 identifier, class_1320 value, Field field) {

    }
}
