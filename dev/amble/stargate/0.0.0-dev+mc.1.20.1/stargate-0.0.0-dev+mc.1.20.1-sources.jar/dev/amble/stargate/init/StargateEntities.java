package dev.amble.stargate.init;

import dev.amble.lib.container.impl.EntityContainer;
import dev.amble.stargate.entities.DHDControlEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_4048;

public class StargateEntities implements EntityContainer {

    public static final class_1299<DHDControlEntity> DHD_CONTROL_TYPE = FabricEntityTypeBuilder
            .<DHDControlEntity>create(class_1311.field_17715, DHDControlEntity::new)
            .dimensions(class_4048.method_18384(0.125f, 0.125f))
            .build();
}
