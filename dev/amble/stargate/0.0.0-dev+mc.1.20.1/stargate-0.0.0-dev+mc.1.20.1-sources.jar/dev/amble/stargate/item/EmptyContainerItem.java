package dev.amble.stargate.item;

import dev.amble.stargate.init.StargateItems;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2263;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2402;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5328;
import net.minecraft.class_5633;
import net.minecraft.class_5712;
import net.minecraft.item.*;
import org.jetbrains.annotations.Nullable;

public class EmptyContainerItem extends class_1792 implements class_5633 {
    private final class_3611 fluid;

    public EmptyContainerItem(class_3611 fluid, class_1792.class_1793 settings) {
        super(settings);
        this.fluid = fluid;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);
        class_3965 blockHitResult = method_7872(world, user, this.fluid == class_3612.field_15906 ? class_3959.class_242.field_1345 : class_3959.class_242.field_1348);
        if (blockHitResult.method_17783() == class_239.class_240.field_1333) {
            return class_1271.method_22430(itemStack);
        } else if (blockHitResult.method_17783() != class_239.class_240.field_1332) {
            return class_1271.method_22430(itemStack);
        } else {
            class_2338 blockPos = blockHitResult.method_17777();
            class_2350 direction = blockHitResult.method_17780();
            class_2338 blockPos2 = blockPos.method_10093(direction);
            if (world.method_8505(user, blockPos) && user.method_7343(blockPos2, direction, itemStack)) {
                class_2680 blockState = world.method_8320(blockPos);

                if (this.fluid == class_3612.field_15906) {
                    if (blockState.method_26204() instanceof class_2263 fluidDrainable) {
                        class_1799 itemStack2 = fluidDrainable.method_9700(world, blockPos, blockState);
                        if (!itemStack2.method_7960()) {
                            user.method_7259(class_3468.field_15372.method_14956(this));
                            fluidDrainable.method_32351().ifPresent((sound) -> user.method_5783(sound, 1.0F, 1.0F));
                            world.method_33596(user, class_5712.field_28167, blockPos);
                            class_1799 itemStack3 = class_5328.method_30012(itemStack, user, itemStack2);
                            if (!world.field_9236) {
                                class_174.field_1208.method_8932((class_3222)user, itemStack2);
                            }
                            return class_1271.method_29237(itemStack3, world.method_8608());
                        }
                    }
                    return class_1271.method_22431(itemStack);
                } else {
                    class_2338 blockPos3 = blockState.method_26204() instanceof class_2402 && this.fluid == class_3612.field_15910 ? blockPos : blockPos2;
                    if (this.method_7731(user, world, blockPos3, blockHitResult)) {
                        this.method_7728(user, world, itemStack, blockPos3);
                        if (user instanceof class_3222) {
                            class_174.field_1191.method_23889((class_3222)user, blockPos3, itemStack);
                        }
                        user.method_7259(class_3468.field_15372.method_14956(this));
                        return class_1271.method_29237(getEmptiedStack(itemStack, user), world.method_8608());
                    } else {
                        return class_1271.method_22431(itemStack);
                    }
                }
            } else {
                return class_1271.method_22431(itemStack);
            }
        }
    }

    public static class_1799 getEmptiedStack(class_1799 stack, class_1657 player) {
        return !player.method_31549().field_7477 ? new class_1799(StargateItems.EMPTY_CONTAINER) : stack;
    }

    @Override
    public boolean method_7731(@Nullable class_1657 player, class_1937 world, class_2338 pos, @Nullable class_3965 hitResult) {
        if (!(this.fluid instanceof class_3609)) return false;

        class_2680 blockState = world.method_8320(pos);
        class_2248 block = blockState.method_26204();

        // Prevent replacing water
        if (block == class_2246.field_10382) return false;

        boolean bl = blockState.method_26188(this.fluid);
        if (!bl && !blockState.method_26215() && !(block instanceof class_2402 fillable && fillable.method_10310(world, pos, blockState, this.fluid))) {
            return hitResult != null && this.method_7731(player, world, hitResult.method_17777().method_10093(hitResult.method_17780()), null);
        } else if (blockState.method_26227().method_15771() && blockState.method_26227().method_15772() == this.fluid) {
            return true;
        } else if (block instanceof class_2402 fillable && this.fluid == class_3612.field_15910) {
            fillable.method_10310(world, pos, blockState, ((class_3609) this.fluid).method_15729(false).method_15772());
            this.playEmptyingSound(player, world, pos);
            return true;
        }

        if (!world.method_8608() && bl && !blockState.method_51176()) world.method_22352(pos, true);

        if (world.method_8652(pos, this.fluid.method_15785().method_15759(), 11) || blockState.method_26227().method_15771()) {
            this.playEmptyingSound(player, world, pos);
            return true;
        } else {
            return false;
        }
    }

    protected void playEmptyingSound(@Nullable class_1657 player, class_1936 world, class_2338 pos) {
        world.method_8396(player, pos, class_3417.field_14826, class_3419.field_15245, 1.0F, 1.0F);
        world.method_33596(player, class_5712.field_28166, pos);
    }
}