package dev.amble.stargate.init;

import dev.amble.lib.container.impl.ItemContainer;
import dev.amble.lib.datagen.util.AutomaticModel;
import dev.amble.lib.datagen.util.NoEnglish;
import dev.amble.lib.item.AItemSettings;
import dev.amble.modkit.api.ABoatItem;
import dev.amble.stargate.api.GateKernelRegistry;
import dev.amble.stargate.item.*;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_3612;
import org.jetbrains.annotations.Nullable;

public class StargateItems extends ItemContainer {

	@AutomaticModel
	@NoEnglish
	public static final class_1792 ADDRESS_CARTOUCHE = new DialerItem(new AItemSettings().method_7889(1));

	// Stargates
	@NoEnglish public static final StargateItem MILKY_WAY_STARGATE = new StargateItem(new AItemSettings(), GateKernelRegistry.MILKY_WAY);
	@NoEnglish public static final StargateItem ORLIN_STARGATE = new StargateItem(new AItemSettings(), GateKernelRegistry.ORLIN);
	@NoEnglish public static final StargateItem DESTINY_STARGATE = new StargateItem(new AItemSettings(), GateKernelRegistry.DESTINY);
	@NoEnglish public static final StargateItem PEGASUS_STARGATE = new StargateItem(new AItemSettings(), GateKernelRegistry.PEGASUS);

	//Naquadah
	@AutomaticModel
	@NoEnglish
	public static final class_1792 RAW_NAQUADAH = new class_1792(new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 NAQUADAH_INGOT = new class_1792(new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 NAQUADAH_NUGGET = new class_1792(new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 NAQUADAH_BOAT = new ABoatItem(false, StargateBoatTypes.NAQUADAH, new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 NAQUADAH_CHEST_BOAT = new ABoatItem(true, StargateBoatTypes.NAQUADAH, new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 EMPTY_CONTAINER = new EmptyContainerItem(class_3612.field_15906, new AItemSettings().method_7889(16));

	@AutomaticModel
	@NoEnglish
	public static final class_1792 COPPER_COIL = new class_1792(new AItemSettings());

	// Iris
	@AutomaticModel
	@NoEnglish
	public static final class_1792 IRIS_BLADE = new class_1792(new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 IRIS_FRAME = new class_1792(new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 IRON_IRIS = new IrisItem(StargateIrisTiers.IRON, new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 GOLD_IRIS = new IrisItem(StargateIrisTiers.GOLD, new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 CONTROL_CRYSTAL_YELLOW = new class_1792(new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 CONTROL_CRYSTAL_BLUE = new class_1792(new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 CONTROL_CRYSTAL_RED = new class_1792(new AItemSettings());

	@AutomaticModel
	@NoEnglish
	public static final class_1792 CONTROL_CRYSTAL_MASTER = new class_1792(new AItemSettings());

	@NoEnglish
	public static final class_1792 LIQUID_NAQUADAH = new EmptyContainerItem(StargateFluids.LIQUID_NAQUADAH_STILL, new FabricItemSettings().method_7896(StargateItems.EMPTY_CONTAINER).method_7889(1));

    @AutomaticModel
    @NoEnglish
    public static final class_1792 TOAST = new class_1792(new AItemSettings().group(StargateItemGroups.MAIN).method_19265(StargateFoodComponenets.TOAST));

    @AutomaticModel
    @NoEnglish
    public static final class_1792 BURNT_TOAST = new class_1792(new AItemSettings().group(StargateItemGroups.MAIN).method_19265(StargateFoodComponenets.TOAST));

	@Override
	public @Nullable class_1761 getDefaultGroup() {
		return StargateItemGroups.MAIN;
	}
}
