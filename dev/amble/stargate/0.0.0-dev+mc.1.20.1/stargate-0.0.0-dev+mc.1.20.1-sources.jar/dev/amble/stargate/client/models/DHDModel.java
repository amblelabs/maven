package dev.amble.stargate.client.models;

import dev.amble.lib.client.model.BlockEntityModel;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class DHDModel extends BlockEntityModel {

    public final class_630 dhd;
    public final class_630 main;
    public final class_630 area;
    public final class_630 dialbutton;
    public final class_630 dialbuttonlight;
    public final class_630 rings;
    public final class_630 bottom;
    public final class_630 lights;
    public final class_630 button1;
    public final class_630 button2;
    public final class_630 button3;
    public final class_630 button4;
    public final class_630 button5;
    public final class_630 button6;
    public final class_630 button7;
    public final class_630 button8;
    public final class_630 button9;
    public final class_630 button10;
    public final class_630 button11;
    public final class_630 button12;
    public final class_630 button13;
    public final class_630 button14;
    public final class_630 button15;
    public final class_630 button16;
    public final class_630 button17;
    public final class_630 button18;
    public final class_630 bits;
    public final class_630 button37;
    public final class_630 button38;
    public final class_630 button39;
    public final class_630 button40;
    public final class_630 button41;
    public final class_630 button42;
    public final class_630 button43;
    public final class_630 button44;
    public final class_630 button45;
    public final class_630 button46;
    public final class_630 button47;
    public final class_630 button48;
    public final class_630 button49;
    public final class_630 button50;
    public final class_630 button51;
    public final class_630 button52;
    public final class_630 button53;
    public final class_630 button54;
    public final class_630 top;
    public final class_630 lights2;
    public final class_630 button19;
    public final class_630 button20;
    public final class_630 button21;
    public final class_630 button22;
    public final class_630 button23;
    public final class_630 button24;
    public final class_630 button25;
    public final class_630 button26;
    public final class_630 button27;
    public final class_630 button28;
    public final class_630 button29;
    public final class_630 button30;
    public final class_630 button31;
    public final class_630 button32;
    public final class_630 button33;
    public final class_630 button34;
    public final class_630 button35;
    public final class_630 button36;
    public final class_630 bits2;
    public final class_630 button55;
    public final class_630 button56;
    public final class_630 button57;
    public final class_630 button58;
    public final class_630 button59;
    public final class_630 button60;
    public final class_630 button61;
    public final class_630 button62;
    public final class_630 button63;
    public final class_630 button64;
    public final class_630 button65;
    public final class_630 button66;
    public final class_630 button67;
    public final class_630 button68;
    public final class_630 button69;
    public final class_630 button70;
    public final class_630 button71;
    public final class_630 button72;
    public final class_630 bone;
    public final class_630 bone4;
    public final class_630 bone2;
    public final class_630 bone3;

    public DHDModel() {
        this(getTexturedModelData().method_32109());
    }

    private DHDModel(class_630 root) {
        this.dhd = root.method_32086("dhd");
        this.main = this.dhd.method_32086("main");
        this.area = this.main.method_32086("area");
        this.dialbutton = this.main.method_32086("dialbutton");
        this.dialbuttonlight = this.main.method_32086("dialbuttonlight");
        this.rings = this.main.method_32086("rings");
        this.bottom = this.rings.method_32086("bottom");
        this.lights = this.bottom.method_32086("lights");
        this.button1 = this.lights.method_32086("button1");
        this.button2 = this.lights.method_32086("button2");
        this.button3 = this.lights.method_32086("button3");
        this.button4 = this.lights.method_32086("button4");
        this.button5 = this.lights.method_32086("button5");
        this.button6 = this.lights.method_32086("button6");
        this.button7 = this.lights.method_32086("button7");
        this.button8 = this.lights.method_32086("button8");
        this.button9 = this.lights.method_32086("button9");
        this.button10 = this.lights.method_32086("button10");
        this.button11 = this.lights.method_32086("button11");
        this.button12 = this.lights.method_32086("button12");
        this.button13 = this.lights.method_32086("button13");
        this.button14 = this.lights.method_32086("button14");
        this.button15 = this.lights.method_32086("button15");
        this.button16 = this.lights.method_32086("button16");
        this.button17 = this.lights.method_32086("button17");
        this.button18 = this.lights.method_32086("button18");
        this.bits = this.bottom.method_32086("bits");
        this.button37 = this.bits.method_32086("button37");
        this.button38 = this.bits.method_32086("button38");
        this.button39 = this.bits.method_32086("button39");
        this.button40 = this.bits.method_32086("button40");
        this.button41 = this.bits.method_32086("button41");
        this.button42 = this.bits.method_32086("button42");
        this.button43 = this.bits.method_32086("button43");
        this.button44 = this.bits.method_32086("button44");
        this.button45 = this.bits.method_32086("button45");
        this.button46 = this.bits.method_32086("button46");
        this.button47 = this.bits.method_32086("button47");
        this.button48 = this.bits.method_32086("button48");
        this.button49 = this.bits.method_32086("button49");
        this.button50 = this.bits.method_32086("button50");
        this.button51 = this.bits.method_32086("button51");
        this.button52 = this.bits.method_32086("button52");
        this.button53 = this.bits.method_32086("button53");
        this.button54 = this.bits.method_32086("button54");
        this.top = this.rings.method_32086("top");
        this.lights2 = this.top.method_32086("lights2");
        this.button19 = this.lights2.method_32086("button19");
        this.button20 = this.lights2.method_32086("button20");
        this.button21 = this.lights2.method_32086("button21");
        this.button22 = this.lights2.method_32086("button22");
        this.button23 = this.lights2.method_32086("button23");
        this.button24 = this.lights2.method_32086("button24");
        this.button25 = this.lights2.method_32086("button25");
        this.button26 = this.lights2.method_32086("button26");
        this.button27 = this.lights2.method_32086("button27");
        this.button28 = this.lights2.method_32086("button28");
        this.button29 = this.lights2.method_32086("button29");
        this.button30 = this.lights2.method_32086("button30");
        this.button31 = this.lights2.method_32086("button31");
        this.button32 = this.lights2.method_32086("button32");
        this.button33 = this.lights2.method_32086("button33");
        this.button34 = this.lights2.method_32086("button34");
        this.button35 = this.lights2.method_32086("button35");
        this.button36 = this.lights2.method_32086("button36");
        this.bits2 = this.top.method_32086("bits2");
        this.button55 = this.bits2.method_32086("button55");
        this.button56 = this.bits2.method_32086("button56");
        this.button57 = this.bits2.method_32086("button57");
        this.button58 = this.bits2.method_32086("button58");
        this.button59 = this.bits2.method_32086("button59");
        this.button60 = this.bits2.method_32086("button60");
        this.button61 = this.bits2.method_32086("button61");
        this.button62 = this.bits2.method_32086("button62");
        this.button63 = this.bits2.method_32086("button63");
        this.button64 = this.bits2.method_32086("button64");
        this.button65 = this.bits2.method_32086("button65");
        this.button66 = this.bits2.method_32086("button66");
        this.button67 = this.bits2.method_32086("button67");
        this.button68 = this.bits2.method_32086("button68");
        this.button69 = this.bits2.method_32086("button69");
        this.button70 = this.bits2.method_32086("button70");
        this.button71 = this.bits2.method_32086("button71");
        this.button72 = this.bits2.method_32086("button72");
        this.bone = this.dhd.method_32086("bone");
        this.bone4 = this.dhd.method_32086("bone4");
        this.bone2 = this.dhd.method_32086("bone2");
        this.bone3 = this.dhd.method_32086("bone3");
    }

    @SuppressWarnings("unused")
    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();
        class_5610 dhd = modelPartData.method_32117(
            "dhd",
            class_5606.method_32108()
                .method_32101(0, 23)
                .method_32098(
                    -5.0F,
                    -15.0F,
                    -4.0F,
                    10.0F,
                    15.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32090(0.0F, 24.0F, 0.0F)
        );

        class_5610 cube_r1 = dhd.method_32117(
            "cube_r1",
            class_5606.method_32108()
                .method_32101(39, 23)
                .method_32098(
                    -6.0F,
                    -9.0F,
                    -3.0F,
                    12.0F,
                    9.0F,
                    3.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, -9.0F, 5.0F, -0.3927F, 0.0F, 0.0F)
        );

        class_5610 main = dhd.method_32117(
            "main",
            class_5606.method_32108(),
            class_5603.method_32091(0.0F, -10.5F, -5.0F, 0.4363F, 0.0F, 0.0F)
        );

        class_5610 area = main.method_32117(
            "area",
            class_5606.method_32108()
                .method_32101(2, 2)
                .method_32098(
                    -11.0F,
                    -13.0845F,
                    -10.1495F,
                    26.0F,
                    1.0F,
                    19.0F,
                    new class_5605(0.002F)
                )
                .method_32101(39, 36)
                .method_32098(
                    -1.5F,
                    -15.1345F,
                    -4.0995F,
                    7.0F,
                    0.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32090(-2.0F, 11.6345F, 8.1495F)
        );

        class_5610 cube_r2 = area.method_32117(
            "cube_r2",
            class_5606.method_32108()
                .method_32101(98, 80)
                .method_32098(
                    -10.1768F,
                    -2.0F,
                    11.8232F,
                    8.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(5.8063F, -11.6355F, -5.4244F, 0.0F, 0.7854F, 0.0F)
        );

        class_5610 cube_r3 = area.method_32117(
            "cube_r3",
            class_5606.method_32108()
                .method_32101(108, 8)
                .method_32098(
                    -9.1154F,
                    -2.0F,
                    -0.2218F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                16.8532F,
                -11.6355F,
                -3.2627F,
                0.0F,
                1.0908F,
                0.0F
            )
        );

        class_5610 cube_r4 = area.method_32117(
            "cube_r4",
            class_5606.method_32108()
                .method_32101(108, 16)
                .method_32098(
                    -9.0F,
                    -2.0F,
                    -0.75F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(
                14.4315F,
                -11.6355F,
                6.6341F,
                0.0F,
                -1.5708F,
                0.0F
            )
        );

        class_5610 cube_r5 = area.method_32117(
            "cube_r5",
            class_5606.method_32108()
                .method_32101(108, 4)
                .method_32098(
                    -9.1154F,
                    -2.0F,
                    -0.7782F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                16.8532F,
                -11.6355F,
                2.5309F,
                0.0F,
                -1.0908F,
                0.0F
            )
        );

        class_5610 cube_r6 = area.method_32117(
            "cube_r6",
            class_5606.method_32108()
                .method_32101(78, 104)
                .method_32098(
                    -9.1768F,
                    -2.0F,
                    -0.8232F,
                    5.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(
                15.7044F,
                -11.6345F,
                -2.3784F,
                0.0F,
                -0.7854F,
                0.0F
            )
        );

        class_5610 cube_r7 = area.method_32117(
            "cube_r7",
            class_5606.method_32108()
                .method_32101(98, 76)
                .method_32098(
                    2.1768F,
                    -2.0F,
                    11.8232F,
                    8.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(
                -1.8051F,
                -11.6365F,
                -5.4238F,
                0.0F,
                -0.7854F,
                0.0F
            )
        );

        class_5610 cube_r8 = area.method_32117(
            "cube_r8",
            class_5606.method_32108()
                .method_32101(108, 0)
                .method_32098(
                    5.1154F,
                    -2.0F,
                    -0.2218F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                -12.852F,
                -11.6365F,
                -3.262F,
                0.0F,
                -1.0908F,
                0.0F
            )
        );

        class_5610 cube_r9 = area.method_32117(
            "cube_r9",
            class_5606.method_32108()
                .method_32101(108, 12)
                .method_32098(
                    5.0F,
                    -2.0F,
                    -0.75F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(
                -10.4302F,
                -11.6365F,
                6.6348F,
                0.0F,
                1.5708F,
                0.0F
            )
        );

        class_5610 cube_r10 = area.method_32117(
            "cube_r10",
            class_5606.method_32108()
                .method_32101(105, 106)
                .method_32098(
                    5.1154F,
                    -2.0F,
                    -0.7782F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(-12.852F, -11.6365F, 2.5316F, 0.0F, 1.0908F, 0.0F)
        );

        class_5610 cube_r11 = area.method_32117(
            "cube_r11",
            class_5606.method_32108()
                .method_32101(65, 104)
                .method_32098(
                    4.1768F,
                    -2.0F,
                    -0.8232F,
                    5.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(
                -11.7031F,
                -11.6355F,
                -2.3777F,
                0.0F,
                0.7854F,
                0.0F
            )
        );

        class_5610 cube_r12 = area.method_32117(
            "cube_r12",
            class_5606.method_32108()
                .method_32101(105, 102)
                .method_32098(
                    -7.617F,
                    -1.0F,
                    -0.8643F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(5.6356F, -12.6345F, -9.7887F, 0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r13 = area.method_32117(
            "cube_r13",
            class_5606.method_32108()
                .method_32101(53, 104)
                .method_32098(
                    -4.117F,
                    -1.0F,
                    -0.8643F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(6.0984F, -12.6345F, -9.7887F, 0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r14 = area.method_32117(
            "cube_r14",
            class_5606.method_32108()
                .method_32101(105, 98)
                .method_32098(
                    -3.6285F,
                    -1.0F,
                    -0.7891F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                -2.0984F,
                -12.6345F,
                -9.7887F,
                0.0F,
                0.3054F,
                0.0F
            )
        );

        class_5610 cube_r15 = area.method_32117(
            "cube_r15",
            class_5606.method_32108()
                .method_32101(105, 94)
                .method_32098(
                    -0.3715F,
                    -1.0F,
                    -0.7891F,
                    4.0F,
                    2.0F,
                    1.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(
                6.0984F,
                -12.6345F,
                -9.7887F,
                0.0F,
                -0.3054F,
                0.0F
            )
        );

        class_5610 dialbutton = main.method_32117(
            "dialbutton",
            class_5606.method_32108()
                .method_32101(24, 47)
                .method_32098(
                    -2.0F,
                    -1.5F,
                    -1.75F,
                    4.0F,
                    2.0F,
                    4.0F,
                    new class_5605(0.0F)
                )
                .method_32101(8, 47)
                .method_32098(
                    -2.0F,
                    -1.5F,
                    -1.75F,
                    4.0F,
                    2.0F,
                    4.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32090(0.0F, -2.9F, 7.3F)
        );

        class_5610 dialbuttonlight = main.method_32117(
            "dialbuttonlight",
            class_5606.method_32108()
                .method_32101(24, 53)
                .method_32098(
                    -2.0F,
                    -1.5F,
                    -1.75F,
                    4.0F,
                    2.0F,
                    4.0F,
                    new class_5605(0.0F)
                )
                .method_32101(8, 53)
                .method_32098(
                    -2.0F,
                    -1.5F,
                    -1.75F,
                    4.0F,
                    2.0F,
                    4.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32090(0.0F, -2.9F, 7.3F)
        );

        class_5610 rings = main.method_32117(
            "rings",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, -1.5F, 7.5F)
        );

        class_5610 bottom = rings.method_32117(
            "bottom",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r16 = bottom.method_32117(
            "cube_r16",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.6981F, 0.0F)
        );

        class_5610 cube_r17 = bottom.method_32117(
            "cube_r17",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.0472F, 0.0F)
        );

        class_5610 cube_r18 = bottom.method_32117(
            "cube_r18",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.3963F, 0.0F)
        );

        class_5610 cube_r19 = bottom.method_32117(
            "cube_r19",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 3.1416F, 1.3963F, 3.1416F)
        );

        class_5610 cube_r20 = bottom.method_32117(
            "cube_r20",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 1.0472F, 3.1416F)
        );

        class_5610 cube_r21 = bottom.method_32117(
            "cube_r21",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 0.6981F, 3.1416F)
        );

        class_5610 cube_r22 = bottom.method_32117(
            "cube_r22",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 0.3491F, 3.1416F)
        );

        class_5610 cube_r23 = bottom.method_32117(
            "cube_r23",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 0.0F, 3.1416F)
        );

        class_5610 cube_r24 = bottom.method_32117(
            "cube_r24",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.3491F, 0.0F)
        );

        class_5610 cube_r25 = bottom.method_32117(
            "cube_r25",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.7925F, 0.0F)
        );

        class_5610 cube_r26 = bottom.method_32117(
            "cube_r26",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.4435F, 0.0F)
        );

        class_5610 cube_r27 = bottom.method_32117(
            "cube_r27",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.0944F, 0.0F)
        );

        class_5610 cube_r28 = bottom.method_32117(
            "cube_r28",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.7453F, 0.0F)
        );

        class_5610 cube_r29 = bottom.method_32117(
            "cube_r29",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.3963F, 0.0F)
        );

        class_5610 cube_r30 = bottom.method_32117(
            "cube_r30",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.0472F, 0.0F)
        );

        class_5610 cube_r31 = bottom.method_32117(
            "cube_r31",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.6981F, 0.0F)
        );

        class_5610 cube_r32 = bottom.method_32117(
            "cube_r32",
            class_5606.method_32108()
                .method_32101(73, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    1.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.3491F, 0.0F)
        );

        class_5610 lights = bottom.method_32117(
            "lights",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, -0.05F, 0.0F)
        );

        class_5610 button1 = lights.method_32117(
            "button1",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 button2 = lights.method_32117(
            "button2",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.3491F, 0.0F)
        );

        class_5610 button3 = lights.method_32117(
            "button3",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.6981F, 0.0F)
        );

        class_5610 button4 = lights.method_32117(
            "button4",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.0472F, 0.0F)
        );

        class_5610 button5 = lights.method_32117(
            "button5",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.3963F, 0.0F)
        );

        class_5610 button6 = lights.method_32117(
            "button6",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.7453F, 0.0F)
        );

        class_5610 button7 = lights.method_32117(
            "button7",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.0944F, 0.0F)
        );

        class_5610 button8 = lights.method_32117(
            "button8",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    0.0F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.3214F, 0.0F, 0.383F, 0.0F, -2.4435F, 0.0F)
        );

        class_5610 button9 = lights.method_32117(
            "button9",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.7925F, 0.0F)
        );

        class_5610 button10 = lights.method_32117(
            "button10",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 3.1416F, 0.0F)
        );

        class_5610 button11 = lights.method_32117(
            "button11",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.7925F, 0.0F)
        );

        class_5610 button12 = lights.method_32117(
            "button12",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.4435F, 0.0F)
        );

        class_5610 button13 = lights.method_32117(
            "button13",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.0944F, 0.0F)
        );

        class_5610 button14 = lights.method_32117(
            "button14",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.7453F, 0.0F)
        );

        class_5610 button15 = lights.method_32117(
            "button15",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.3963F, 0.0F)
        );

        class_5610 button16 = lights.method_32117(
            "button16",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.0472F, 0.0F)
        );

        class_5610 button17 = lights.method_32117(
            "button17",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.6981F, 0.0F)
        );

        class_5610 button18 = lights.method_32117(
            "button18",
            class_5606.method_32108()
                .method_32101(67, 6)
                .method_32098(
                    -1.5F,
                    -1.0F,
                    -0.5F,
                    3.0F,
                    0.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.3491F, 0.0F)
        );

        class_5610 bits = bottom.method_32117(
            "bits",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, -0.1F, 0.0F)
        );

        class_5610 button37 = bits.method_32117(
            "button37",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 button38 = bits.method_32117(
            "button38",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.3491F, 0.0F)
        );

        class_5610 button39 = bits.method_32117(
            "button39",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.6981F, 0.0F)
        );

        class_5610 button40 = bits.method_32117(
            "button40",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.0472F, 0.0F)
        );

        class_5610 button41 = bits.method_32117(
            "button41",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.3963F, 0.0F)
        );

        class_5610 button42 = bits.method_32117(
            "button42",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.7453F, 0.0F)
        );

        class_5610 button43 = bits.method_32117(
            "button43",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.0944F, 0.0F)
        );

        class_5610 button44 = bits.method_32117(
            "button44",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.75F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.3214F, 0.0F, 0.383F, 0.0F, -2.4435F, 0.0F)
        );

        class_5610 button45 = bits.method_32117(
            "button45",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.7925F, 0.0F)
        );

        class_5610 button46 = bits.method_32117(
            "button46",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 3.1416F, 0.0F)
        );

        class_5610 button47 = bits.method_32117(
            "button47",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.7925F, 0.0F)
        );

        class_5610 button48 = bits.method_32117(
            "button48",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.4435F, 0.0F)
        );

        class_5610 button49 = bits.method_32117(
            "button49",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.0944F, 0.0F)
        );

        class_5610 button50 = bits.method_32117(
            "button50",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.7453F, 0.0F)
        );

        class_5610 button51 = bits.method_32117(
            "button51",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.3963F, 0.0F)
        );

        class_5610 button52 = bits.method_32117(
            "button52",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.0472F, 0.0F)
        );

        class_5610 button53 = bits.method_32117(
            "button53",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.6981F, 0.0F)
        );

        class_5610 button54 = bits.method_32117(
            "button54",
            class_5606.method_32108()
                .method_32101(83, 6)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    2.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.3491F, 0.0F)
        );

        class_5610 top = rings.method_32117(
            "top",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32090(0.0F, -1.0F, 0.0F)
        );

        class_5610 cube_r33 = top.method_32117(
            "cube_r33",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 3.1416F, 1.3963F, 3.1416F)
        );

        class_5610 cube_r34 = top.method_32117(
            "cube_r34",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 1.0472F, 3.1416F)
        );

        class_5610 cube_r35 = top.method_32117(
            "cube_r35",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.3963F, 0.0F)
        );

        class_5610 cube_r36 = top.method_32117(
            "cube_r36",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 0.6981F, 3.1416F)
        );

        class_5610 cube_r37 = top.method_32117(
            "cube_r37",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 0.3491F, 3.1416F)
        );

        class_5610 cube_r38 = top.method_32117(
            "cube_r38",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 0.0F, 3.1416F)
        );

        class_5610 cube_r39 = top.method_32117(
            "cube_r39",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.6981F, 0.0F)
        );

        class_5610 cube_r40 = top.method_32117(
            "cube_r40",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.0472F, 0.0F)
        );

        class_5610 cube_r41 = top.method_32117(
            "cube_r41",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.3491F, 0.0F)
        );

        class_5610 cube_r42 = top.method_32117(
            "cube_r42",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, -0.6981F, 3.1416F)
        );

        class_5610 cube_r43 = top.method_32117(
            "cube_r43",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, -1.0472F, 3.1416F)
        );

        class_5610 cube_r44 = top.method_32117(
            "cube_r44",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, -0.3491F, 3.1416F)
        );

        class_5610 cube_r45 = top.method_32117(
            "cube_r45",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.3963F, 0.0F)
        );

        class_5610 cube_r46 = top.method_32117(
            "cube_r46",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.0472F, 0.0F)
        );

        class_5610 cube_r47 = top.method_32117(
            "cube_r47",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, -1.3963F, 3.1416F)
        );

        class_5610 cube_r48 = top.method_32117(
            "cube_r48",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.6981F, 0.0F)
        );

        class_5610 cube_r49 = top.method_32117(
            "cube_r49",
            class_5606.method_32108()
                .method_32101(2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    1.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.3491F, 0.0F)
        );

        class_5610 lights2 = top.method_32117(
            "lights2",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, -0.05F, 0.0F)
        );

        class_5610 button19 = lights2.method_32117(
            "button19",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 button20 = lights2.method_32117(
            "button20",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.3491F, 0.0F)
        );

        class_5610 button21 = lights2.method_32117(
            "button21",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.6981F, 0.0F)
        );

        class_5610 button22 = lights2.method_32117(
            "button22",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.0472F, 0.0F)
        );

        class_5610 button23 = lights2.method_32117(
            "button23",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.3963F, 0.0F)
        );

        class_5610 button24 = lights2.method_32117(
            "button24",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.7453F, 0.0F)
        );

        class_5610 button25 = lights2.method_32117(
            "button25",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.0944F, 0.0F)
        );

        class_5610 button26 = lights2.method_32117(
            "button26",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.4435F, 0.0F)
        );

        class_5610 button27 = lights2.method_32117(
            "button27",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.7925F, 0.0F)
        );

        class_5610 button28 = lights2.method_32117(
            "button28",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 3.1416F, 0.0F)
        );

        class_5610 button29 = lights2.method_32117(
            "button29",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.7925F, 0.0F)
        );

        class_5610 button30 = lights2.method_32117(
            "button30",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.4435F, 0.0F)
        );

        class_5610 button31 = lights2.method_32117(
            "button31",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.0944F, 0.0F)
        );

        class_5610 button32 = lights2.method_32117(
            "button32",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.7453F, 0.0F)
        );

        class_5610 button33 = lights2.method_32117(
            "button33",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.3963F, 0.0F)
        );

        class_5610 button34 = lights2.method_32117(
            "button34",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.0472F, 0.0F)
        );

        class_5610 button35 = lights2.method_32117(
            "button35",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.6981F, 0.0F)
        );

        class_5610 button36 = lights2.method_32117(
            "button36",
            class_5606.method_32108()
                .method_32101(-2, 14)
                .method_32098(
                    -1.0F,
                    -1.0F,
                    -0.25F,
                    2.0F,
                    0.0F,
                    6.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.3491F, 0.0F)
        );

        class_5610 bits2 = top.method_32117(
            "bits2",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, -0.3F, 0.0F)
        );

        class_5610 button55 = bits2.method_32117(
            "button55",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 button56 = bits2.method_32117(
            "button56",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.3491F, 0.0F)
        );

        class_5610 button57 = bits2.method_32117(
            "button57",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.6981F, 0.0F)
        );

        class_5610 button58 = bits2.method_32117(
            "button58",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.0472F, 0.0F)
        );

        class_5610 button59 = bits2.method_32117(
            "button59",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.3963F, 0.0F)
        );

        class_5610 button60 = bits2.method_32117(
            "button60",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.7453F, 0.0F)
        );

        class_5610 button61 = bits2.method_32117(
            "button61",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.0944F, 0.0F)
        );

        class_5610 button62 = bits2.method_32117(
            "button62",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.4435F, 0.0F)
        );

        class_5610 button63 = bits2.method_32117(
            "button63",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -2.7925F, 0.0F)
        );

        class_5610 button64 = bits2.method_32117(
            "button64",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 3.1416F, 0.0F)
        );

        class_5610 button65 = bits2.method_32117(
            "button65",
            class_5606.method_32108()
                .method_32101(14, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.7925F, 0.0F)
        );

        class_5610 button66 = bits2.method_32117(
            "button66",
            class_5606.method_32108()
                .method_32101(15, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.4435F, 0.0F)
        );

        class_5610 button67 = bits2.method_32117(
            "button67",
            class_5606.method_32108()
                .method_32101(15, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 2.0944F, 0.0F)
        );

        class_5610 button68 = bits2.method_32117(
            "button68",
            class_5606.method_32108()
                .method_32101(15, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.7453F, 0.0F)
        );

        class_5610 button69 = bits2.method_32117(
            "button69",
            class_5606.method_32108()
                .method_32101(15, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.3963F, 0.0F)
        );

        class_5610 button70 = bits2.method_32117(
            "button70",
            class_5606.method_32108()
                .method_32101(15, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.0472F, 0.0F)
        );

        class_5610 button71 = bits2.method_32117(
            "button71",
            class_5606.method_32108()
                .method_32101(15, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.6981F, 0.0F)
        );

        class_5610 button72 = bits2.method_32117(
            "button72",
            class_5606.method_32108()
                .method_32101(15, 14)
                .method_32098(
                    -0.5F,
                    -0.8F,
                    3.5F,
                    1.0F,
                    0.0F,
                    2.0F,
                    new class_5605(0.1F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.3491F, 0.0F)
        );

        class_5610 bone = dhd.method_32117(
            "bone",
            class_5606.method_32108(),
            class_5603.method_32091(4.5F, -1.0F, -4.5F, 0.0F, -0.3927F, 0.0F)
        );

        class_5610 cube_r50 = bone.method_32117(
            "cube_r50",
            class_5606.method_32108()
                .method_32101(0, 98)
                .method_32098(
                    0.0F,
                    -11.0F,
                    -1.5F,
                    3.0F,
                    11.0F,
                    3.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                0.5629F,
                -9.5433F,
                0.5629F,
                -0.6155F,
                -0.5236F,
                0.9553F
            )
        );

        class_5610 cube_r51 = bone.method_32117(
            "cube_r51",
            class_5606.method_32108()
                .method_32101(13, 104)
                .method_32098(
                    0.0F,
                    -6.0F,
                    -1.5F,
                    3.0F,
                    6.0F,
                    3.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                -1.0607F,
                -4.0F,
                -1.0607F,
                -0.3655F,
                -0.7119F,
                0.5299F
            )
        );

        class_5610 cube_r52 = bone.method_32117(
            "cube_r52",
            class_5606.method_32108()
                .method_32101(26, 104)
                .method_32098(
                    -1.5F,
                    -4.0F,
                    -1.5F,
                    3.0F,
                    5.0F,
                    3.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.7854F, 0.0F)
        );

        class_5610 bone4 = dhd.method_32117(
            "bone4",
            class_5606.method_32108(),
            class_5603.method_32091(5.5F, -1.0F, 3.5F, 0.0F, -0.3927F, 0.0F)
        );

        class_5610 cube_r53 = bone4.method_32117(
            "cube_r53",
            class_5606.method_32108()
                .method_32101(94, -2)
                .method_32098(
                    -1.5307F,
                    -14.6955F,
                    -1.5F,
                    3.0F,
                    11.0F,
                    4.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                -1.0607F,
                -4.0F,
                -1.0607F,
                -0.3655F,
                -0.7119F,
                0.5299F
            )
        );

        class_5610 cube_r54 = bone4.method_32117(
            "cube_r54",
            class_5606.method_32108()
                .method_32101(97, 52)
                .method_32098(
                    -1.5F,
                    -8.0F,
                    -1.5F,
                    3.0F,
                    9.0F,
                    4.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.7854F, 0.0F)
        );

        class_5610 bone2 = dhd.method_32117(
            "bone2",
            class_5606.method_32108(),
            class_5603.method_32091(-4.5F, -1.0F, -4.5F, 0.0F, 0.3927F, 0.0F)
        );

        class_5610 cube_r55 = bone2.method_32117(
            "cube_r55",
            class_5606.method_32108()
                .method_32101(95, 15)
                .method_32098(
                    -3.0F,
                    -11.0F,
                    -1.5F,
                    3.0F,
                    11.0F,
                    3.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                -0.5629F,
                -9.5433F,
                0.5629F,
                -0.6155F,
                0.5236F,
                -0.9553F
            )
        );

        class_5610 cube_r56 = bone2.method_32117(
            "cube_r56",
            class_5606.method_32108()
                .method_32101(98, 66)
                .method_32098(
                    -3.0F,
                    -6.0F,
                    -1.5F,
                    3.0F,
                    6.0F,
                    3.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                1.0607F,
                -4.0F,
                -1.0607F,
                -0.3655F,
                0.7119F,
                -0.5299F
            )
        );

        class_5610 cube_r57 = bone2.method_32117(
            "cube_r57",
            class_5606.method_32108()
                .method_32101(39, 104)
                .method_32098(
                    -1.5F,
                    -4.0F,
                    -1.5F,
                    3.0F,
                    5.0F,
                    3.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.7854F, 0.0F)
        );

        class_5610 bone3 = dhd.method_32117(
            "bone3",
            class_5606.method_32108(),
            class_5603.method_32091(-5.5F, -1.0F, 3.5F, 0.0F, 0.3927F, 0.0F)
        );

        class_5610 cube_r58 = bone3.method_32117(
            "cube_r58",
            class_5606.method_32108()
                .method_32101(91, 93)
                .method_32098(
                    -1.4693F,
                    -14.6955F,
                    -1.5F,
                    3.0F,
                    11.0F,
                    4.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(
                1.0607F,
                -4.0F,
                -1.0607F,
                -0.3655F,
                0.7119F,
                -0.5299F
            )
        );

        class_5610 cube_r59 = bone3.method_32117(
            "cube_r59",
            class_5606.method_32108()
                .method_32101(94, 29)
                .method_32098(
                    -1.5F,
                    -8.0F,
                    -1.5F,
                    3.0F,
                    9.0F,
                    4.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.7854F, 0.0F)
        );
        return class_5607.method_32110(modelData, 128, 128);
    }

    @Override
    public class_630 method_32008() {
        return dhd;
    }
}
