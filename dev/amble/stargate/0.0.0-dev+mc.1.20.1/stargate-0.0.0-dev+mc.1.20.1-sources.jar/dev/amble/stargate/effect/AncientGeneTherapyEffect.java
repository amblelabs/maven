package dev.amble.stargate.effect;

import dev.amble.stargate.init.StargateStatusEffects;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_4081;

/**
 * Represents the Ancient Gene Therapy effect, which is a status effect that grants
 * the ability to use Ancient technology and provides immunity to certain effects.
 */
public class AncientGeneTherapyEffect extends class_1291 {

    public AncientGeneTherapyEffect() {
        super(class_4081.field_18273, 0x8fbaff);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true;
    }

    public static boolean isAncientified(class_1309 entity) {
        return entity.method_6059(StargateStatusEffects.ANCIENT_GENE_THERAPY);
    }
}
