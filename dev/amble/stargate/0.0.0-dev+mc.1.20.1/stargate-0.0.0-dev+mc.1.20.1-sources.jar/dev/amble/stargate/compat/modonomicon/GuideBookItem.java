package dev.amble.stargate.compat.modonomicon;

import com.klikli_dev.modonomicon.api.ModonomiconConstants;
import com.klikli_dev.modonomicon.item.ModonomiconCustomItemBase;
import dev.amble.lib.item.AItemSettings;
import dev.amble.stargate.StargateMod;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public class GuideBookItem extends ModonomiconCustomItemBase {

    public static final class_2960 BOOK = StargateMod.id("stellar_map");

    public GuideBookItem(AItemSettings properties) {
        super(BOOK, properties);
    }

    @Override
    public class_1799 method_7854() {
        class_1799 stack = super.method_7854();
        class_2487 cmp = stack.method_7948();

        cmp.method_10582(ModonomiconConstants.Nbt.ITEM_BOOK_ID_TAG, BOOK.toString());
        return stack;
    }
}