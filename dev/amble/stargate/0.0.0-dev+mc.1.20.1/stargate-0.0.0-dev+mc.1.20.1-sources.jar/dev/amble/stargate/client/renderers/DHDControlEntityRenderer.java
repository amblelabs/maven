package dev.amble.stargate.client.renderers;

import dev.amble.stargate.entities.DHDControlEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1060;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;

@Environment(value = EnvType.CLIENT)
public class DHDControlEntityRenderer extends class_897<DHDControlEntity> {

    public DHDControlEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    protected void renderLabelIfPresent(DHDControlEntity entity, class_2561 text, class_4587 matrices,
                                        class_4597 vertexConsumers, int light) {
        if (class_310.method_1551().field_1724.method_6079().method_7909() == class_1802.field_8866) {
            matrices.method_22903();
            matrices.method_46416(0, -0.19f, 0);
            matrices.method_22905(0.5f, 0.5f, 0.5f);
            super.method_3926(entity, text, matrices, vertexConsumers, 0xf000f0);
            matrices.method_22909();
        }
    }

    @Override
    public class_2960 getTexture(DHDControlEntity controlEntity) {
        return class_1060.field_5285;
    }
}
