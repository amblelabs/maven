package dev.amble.stargate.client.renderers.portal;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.amble.stargate.StargateMod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_757;
import net.minecraft.client.render.*;

public class WormholeRenderer {
    public final class_2960 TEXTURE_LOCATION;
    public final class_2960 SECOND_LAYER_LOCATION;
    public final class_2960 THIRD_LAYER_LOCATION;
    private final float distortionSpeed;
    private final float distortionSeparationFactor;
    private final float distortionFactor;
    private final float scale;
    private final float speed;
    private float time = 0;

    public WormholeRenderer(class_2960 texture) {
        TEXTURE_LOCATION = texture;
        SECOND_LAYER_LOCATION = new class_2960(texture.method_12836(), texture.method_12832().substring(0, texture.method_12832().length() - 4) +
                "_second" + ".png");
        THIRD_LAYER_LOCATION =new class_2960(texture.method_12836(), texture.method_12832().substring(0, texture.method_12832().length() - 4) +
                "_third" + ".png");
        this.distortionSpeed = 0.5f;
        this.distortionSeparationFactor = 32f;
        this.distortionFactor = 2;
        this.scale = 32f;
        this.speed = 4f;
    }

    public WormholeRenderer(String name) {
        this(StargateMod.id("textures/wormhole/" + name + ".png"));
    }

    public void renderWormhole(class_4587 matrixStack) {

        time += class_310.method_1551().method_1488() / 360f;

        matrixStack.method_22903();
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture(0, TEXTURE_LOCATION);

        matrixStack.method_22905(scale, scale, scale);

        class_310.method_1551().method_1531().method_22813(TEXTURE_LOCATION);
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_1349();

        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1585);

        RenderSystem.setShaderColor(1, 1, 1, 0.5f);
        for (int i = 0; i < 64; ++i) {
            this.renderSection(
                    buffer,
                    i,
                    (class_310.method_1551().field_1724.field_6012 / 200.0f) * -this.speed + time * this.speed, // add time-based scroll
                    (float) Math.sin(i * Math.PI / 64),
                    (float) Math.sin((i + 1) * Math.PI / 64),
                    matrixStack.method_23760().method_23762(),
                    matrixStack.method_23760().method_23761()
            );
        }

        RenderSystem.setShaderColor(1, 1, 1, 1f);

        tessellator.method_1350();
        matrixStack.method_22909();
    }

    public void renderWormholeLayer(class_4587 matrixStack, float scaleFactor) {
        class_2960 currentTexture = scaleFactor == 1.5f ? SECOND_LAYER_LOCATION : THIRD_LAYER_LOCATION;
        if (class_310.method_1551().method_1478().method_14486(currentTexture).isEmpty()) return;
        this.renderWormholeLayer(matrixStack, scaleFactor, currentTexture);
    }

    private void renderWormholeLayer(class_4587 matrixStack, float scaleFactor, class_2960 layer) {

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34498);
        RenderSystem.setShaderTexture(0, layer);

        time += class_310.method_1551().method_1488() / 360f;

        matrixStack.method_22903();

        matrixStack.method_22905(scale / scaleFactor, scale / scaleFactor, scale);

        class_310.method_1551().method_1531().method_22813(layer);
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_1349();

        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1590);

        for (int i = 0; i < 32; ++i) {
            this.renderSection(
                    buffer,
                    i,
                    (class_310.method_1551().field_1724.field_6012 / 200.0f) * -this.speed + time * this.speed, // add time-based scroll
                    (float) Math.sin(i * Math.PI / 32),
                    (float) Math.sin((i + 1) * Math.PI / 32),
                    matrixStack.method_23760().method_23762(),
                    matrixStack.method_23760().method_23761()
            );
        }

        tessellator.method_1350();
        matrixStack.method_22909();

        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    public void renderSection(class_4588 builder, int zOffset, float textureDistanceOffset, float startScale,
                              float endScale, Matrix3f matrix3f, Matrix4f matrix4f) {
        float panel = 1 / 6f;
        float sqrt = (float) Math.sqrt(3) / 2.0f;
        int vOffset = (zOffset * panel + textureDistanceOffset > 1.0) ? zOffset - 6 : zOffset;
        float distortion = this.computeDistortionFactor(time, zOffset);
        float distortionPlusOne = this.computeDistortionFactor(time, zOffset + 1);
        float panelDistanceOffset = panel + textureDistanceOffset;
        float vPanelOffset = (vOffset * panel) + textureDistanceOffset;

        int uOffset = 0;

        float uPanelOffset = uOffset * panel;

        addVertex(builder, matrix3f, matrix4f, 0f, -startScale + distortion, -zOffset, uPanelOffset, vPanelOffset);

        addVertex(builder, matrix3f, matrix4f, 0f, -endScale + distortionPlusOne, -zOffset - 1, uPanelOffset,
                vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, endScale * -sqrt, endScale / -2f + distortionPlusOne, -zOffset - 1,
                uPanelOffset + panel, vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, startScale * -sqrt, startScale / -2f + distortion, -zOffset, uPanelOffset + panel,
                vPanelOffset);

        uOffset = 1;

        uPanelOffset = uOffset * panel;

        addVertex(builder, matrix3f, matrix4f, startScale * -sqrt, startScale / -2f + distortion, -zOffset, uPanelOffset,
                vPanelOffset);

        addVertex(builder, matrix3f, matrix4f, endScale * -sqrt, endScale / -2f + distortionPlusOne, -zOffset - 1, uPanelOffset,
                vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, endScale * -sqrt, endScale / 2f + distortionPlusOne, -zOffset - 1,
                uPanelOffset + panel, vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, startScale * -sqrt, startScale / 2f + distortion, -zOffset, uPanelOffset + panel,
                vPanelOffset);

        uOffset = 2;

        uPanelOffset = uOffset * panel;

        addVertex(builder, matrix3f, matrix4f, 0f, endScale + distortionPlusOne, -zOffset - 1, uPanelOffset + panel,
                vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, 0f, startScale + distortion, -zOffset, uPanelOffset + panel, vPanelOffset);

        addVertex(builder, matrix3f, matrix4f, startScale * -sqrt, startScale / 2f + distortion, -zOffset, uPanelOffset,
                vPanelOffset);

        addVertex(builder, matrix3f, matrix4f, endScale * -sqrt, endScale / 2f + distortionPlusOne, -zOffset - 1, uPanelOffset,
                vOffset * panel + panelDistanceOffset);

        uOffset = 3;

        uPanelOffset = uOffset * panel;

        addVertex(builder, matrix3f, matrix4f, 0f, startScale + distortion, -zOffset, uPanelOffset, vPanelOffset);

        addVertex(builder, matrix3f, matrix4f, 0f, endScale + distortionPlusOne, -zOffset - 1, uPanelOffset,
                vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, endScale * sqrt, (endScale / 2f + distortionPlusOne), -zOffset - 1,
                uPanelOffset + panel, vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, startScale * sqrt, (startScale / 2f + distortion), -zOffset, uPanelOffset + panel,
                vPanelOffset);

        uOffset = 4;

        uPanelOffset = uOffset * panel;

        addVertex(builder, matrix3f, matrix4f, startScale * sqrt, (startScale / 2f + distortion), -zOffset, uPanelOffset,
                vPanelOffset);

        addVertex(builder, matrix3f, matrix4f, endScale * sqrt, endScale / 2f + distortionPlusOne, -zOffset - 1, uPanelOffset,
                vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, endScale * sqrt, endScale / -2f + distortionPlusOne, -zOffset - 1,
                uPanelOffset + panel, vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, startScale * sqrt, startScale / -2f + distortion, -zOffset, uPanelOffset + panel,
                vPanelOffset);

        uOffset = 5;

        uPanelOffset = uOffset * panel;

        addVertex(builder, matrix3f, matrix4f, 0f, -endScale + distortionPlusOne, -zOffset - 1, uPanelOffset + panel,
                vOffset * panel + panelDistanceOffset);

        addVertex(builder, matrix3f, matrix4f, 0f, -startScale + distortion, -zOffset, uPanelOffset + panel, vPanelOffset);

        addVertex(builder, matrix3f, matrix4f, startScale * sqrt, startScale / -2f + distortion, -zOffset, uPanelOffset,
                vPanelOffset);

        addVertex(builder, matrix3f, matrix4f, endScale * sqrt, endScale / -2f + distortionPlusOne, -zOffset - 1, uPanelOffset,
                vOffset * panel + panelDistanceOffset);
    }

    private void addVertex(class_4588 builder, Matrix3f normalMatrix, Matrix4f matrix, float x, float y, float z, float u, float v) {
        builder.method_22918(matrix, x, y, z).method_22915(1, 1, 1, 1f).method_22913(u, v).method_22916(0xF000F0).method_23763(normalMatrix,0, 0.0f, 0).method_1344();
    }

    private float computeDistortionFactor(float time, int t) {
        return (float) (Math.sin(time * this.distortionSpeed * 2.0 * Math.PI + (13 - t) *
                this.distortionSeparationFactor) * this.distortionFactor) / 8;
    }
}
