package dev.amble.stargate.api.behavior;

import dev.amble.stargate.api.ServerStargate;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.api.event.block.StargateBlockUseEvents;
import dev.amble.stargate.api.event.tp.StargateTpEvent;
import dev.amble.stargate.api.event.block.StargateBlockTickEvents;
import dev.amble.stargate.api.event.tp.StargateTpEvents;
import dev.amble.stargate.api.state.IrisState;
import dev.amble.stargate.block.entities.StargateBlockEntity;
import dev.amble.stargate.init.StargateSounds;
import dev.drtheo.yaar.behavior.TBehavior;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

public class IrisBehavior implements TBehavior, StargateTpEvents, StargateBlockTickEvents, StargateBlockUseEvents {

    public static IrisBehavior INSTANCE = null;

    public IrisBehavior() {
        INSTANCE = this;
    }

    @Override
    public StargateTpEvent.Result onGateTp(ServerStargate from, ServerStargate to, class_1309 living) {
        IrisState iris = to.state(IrisState.state);

        if (iris.open)
            return StargateTpEvent.Result.PASS;

        class_1937 targetWorld = to.world();

        living.method_5643(targetWorld.method_48963().method_48822(), Integer.MAX_VALUE);
        targetWorld.method_45447(null, to.pos(), StargateSounds.IRIS_HIT, class_3419.field_15245);

        this.damage(IrisDamageCtx.create().generic(to));
        return StargateTpEvent.Result.DENY;
    }

    @Override
    public void block$tick(Stargate stargate, StargateBlockEntity entity, class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608())
            return;

        IrisState irisState = stargate.state(IrisState.state);
        boolean newState = irisState.open;

        // Play sound only when IRIS state changes
        if (irisState.prevIrisState != newState) {
            class_3414 sound = newState ? StargateSounds.IRIS_CLOSE : StargateSounds.IRIS_OPEN;
            world.method_45447(null, pos, sound, class_3419.field_15245);

            irisState.prevIrisState = newState;
            stargate.markDirty();
        }
    }

    @Override
    public boolean onUse(Stargate stargate, StargateBlockEntity blockEntity, class_1657 player, class_1937 world, class_2680 state, class_2338 pos, class_1268 hand, class_3965 blockHit) {
        if (world.field_9236) return false;

        class_1799 heldItem = player.method_5998(hand);
        if (!heldItem.method_7960()) return false;

        IrisState s = stargate.state(IrisState.state);
        s.open = !s.open;

        stargate.markDirty();
        return true;
    }

    public void damage(IrisDamageCtx ctx) {
        IrisState iris = ctx.stargate.state(IrisState.state);
        this.damage(ctx, iris);
    }

    protected void damage(IrisDamageCtx ctx, IrisState iris) {
        if ((iris.durability -= ctx.damage) <= 0) {
            iris.tier.onBroken(ctx);
            ctx.stargate.removeState(iris);
        }

        ctx.stargate.markDirty();
    }

    public abstract static class IrisDamageCtx {

        private final Stargate stargate;
        private final int damage;

        private IrisDamageCtx(Stargate stargate, int damage) {
            this.stargate = stargate;
            this.damage = damage;
        }

        public Stargate stargate() {
            return stargate;
        }

        public int getDamage() {
            return damage;
        }

        public static Builder create(int damage) {
            return new Builder(damage);
        }

        public static Builder create() {
            return create(1);
        }

        public static class Builder {

            private final int damage;

            public Builder(int damage) {
                this.damage = damage;
            }

            public Generic generic(Stargate stargate) {
                return new Generic(stargate, damage);
            }

            public Impact impact(Stargate from, Stargate to, class_1309 entity) {
                return new Impact(from, to, entity, damage);
            }
        }

        public static class Generic extends IrisDamageCtx {

            private Generic(Stargate stargate, int damage) {
                super(stargate, damage);
            }
        }

        public static class Impact extends IrisDamageCtx {

            private final Stargate from;
            private final class_1309 entity;

            private Impact(Stargate from, Stargate to, class_1309 entity, int damage) {
                super(to, damage);

                this.from = from;
                this.entity = entity;
            }

            public Stargate from() {
                return from;
            }

            public class_1309 by() {
                return entity;
            }
        }
    }
}
