package dev.amble.stargate.init;

import dev.amble.lib.container.impl.FluidContainer;
import dev.amble.stargate.fluid.LiquidNaquadahFluid;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class StargateFluids implements FluidContainer {

    public static final class_3609 LIQUID_NAQUADAH_STILL = new LiquidNaquadahFluid.Still();
    public static final class_3609 LIQUID_NAQUADAH_FLOWING = new LiquidNaquadahFluid.Flowing();

    private static final String STILL_SUFFIX = "_still";
    private static final String FLOWING_SUFFIX = "_flowing";

    private final Map<class_2960, class_3609> fluids = new HashMap<>();

    @Override
    public void postProcessField(class_2960 identifier, class_3611 value, Field field) {
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT)
            this.postProcessClient(identifier, value);
    }

    private void postProcessClient(class_2960 identifier, class_3611 value) {
        if (!(value instanceof class_3609 flowable)) return;

        boolean still = identifier.method_12832().endsWith(STILL_SUFFIX);

        class_2960 realId = identifier.method_45134(s -> s.substring(0, s.length() - (still ? STILL_SUFFIX.length() : FLOWING_SUFFIX.length())));
        class_3609 prev = fluids.put(realId, flowable);

        if (prev != null) {
            class_3609 stillFluid = still ? flowable : prev;
            class_3609 flowingFluid = still ? prev : flowable;

            FluidRenderHandlerRegistry.INSTANCE.register(stillFluid, flowingFluid,
                    new SimpleFluidRenderHandler(
                            realId.method_45134(s -> "block/" + s + STILL_SUFFIX),
                            realId.method_45134(s -> "block/" + s + FLOWING_SUFFIX)
                    ));
        }
    }

    @Override
    public void finish() {
        fluids.clear();
    }
}