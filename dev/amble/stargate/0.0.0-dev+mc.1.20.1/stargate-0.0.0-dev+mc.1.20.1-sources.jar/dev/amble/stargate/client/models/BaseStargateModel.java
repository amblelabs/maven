package dev.amble.stargate.client.models;

import dev.amble.lib.client.model.BlockEntityModel;
import net.minecraft.class_630;
import net.minecraft.class_7094;
import net.minecraft.class_7184;
import net.minecraft.client.model.*;

public abstract class BaseStargateModel extends BlockEntityModel {

    public final class_630[] chevrons;

    public BaseStargateModel() {
        this.chevrons = this.bakeChevronLights();
    }

    public void bake() {
        class_630[] newChevrons = this.bakeChevronLights();
        System.arraycopy(newChevrons, 0, chevrons, 0, newChevrons.length);
    }

    @Override
    public void method_43781(
        class_7094 animationState,
        class_7184 animation,
        float animationProgress
    ) {
        super.method_43781(animationState, animation, animationProgress);
    }

    public abstract class_630[] bakeChevronLights();
}
