package dev.amble.stargate.api.dhd;

import dev.amble.stargate.api.address.Glyph;
import dev.amble.stargate.api.address.GlyphOriginRegistry;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_3532;
import net.minecraft.class_4048;

public class DHDArrangement {

    public static final List<SymbolArrangement> SYMBOLS = new ArrayList<>(Glyph.ALPHABET_LENGTH);

    private static final float innerRadius = 0.3f;
    private static final float outerRadius = 0.45f;

    private static final int innerCount = Glyph.ALPHABET_LENGTH / 2;
    private static final int outerCount = Glyph.ALPHABET_LENGTH - innerCount;

    private static final int offset = 0;
    private static final int otherOffset = 5;

    static {
        reloadArrangement(Glyph.ALL);
    }

    public static void reloadArrangement(char[] glyphs) {
        SYMBOLS.clear();

        System.out.println(innerCount);
        System.out.println(outerCount);

        // Inner ring
        for (int i = 0; i < innerCount; i++) {
            int shiftedIndex = (i + offset) % innerCount;
            float angle = 2 * class_3532.field_29844 * shiftedIndex / innerCount;

            float x = innerRadius * class_3532.method_15374(angle);
            float z = innerRadius * class_3532.method_15362(angle);

            SYMBOLS.add(new SymbolArrangement(
                    glyphs[18 + i],
                    class_4048.method_18384(0.1f, 0.1f),
                    SymbolArrangement.Offset.changing(x, 0.4f, z + 0.25f).rotateX((float) (Math.PI / -7)).rotateZ(0)
            ));
        }

        // Outer ring
        for (int i = 0; i < outerCount; i++) {
            int shiftedIndex = (i + otherOffset) % outerCount;
            float angle = 2 * class_3532.field_29844 * shiftedIndex / outerCount;

            float x = outerRadius * class_3532.method_15374(angle);
            float z = outerRadius * class_3532.method_15362(angle);

            SYMBOLS.add(new SymbolArrangement(
                    glyphs[i],
                    class_4048.method_18384(0.1f, 0.1f),
                    SymbolArrangement.Offset.changing(x, 0.4f, z + 0.25f).rotateX((float) (Math.PI / -7)).rotateZ(0)
            ));
        }
    }

    public static SymbolArrangement poi(class_1937 world) {
        char poi = GlyphOriginRegistry.get().glyphForDim(world.method_27983());

        return new SymbolArrangement(poi,
                class_4048.method_18385(0.2f, 0.2f), SymbolArrangement.Offset.fixed(0, 0.4625f, 0));
    }
}
