package dev.amble.stargate.fluid;

import dev.amble.stargate.init.StargateBlocks;
import dev.amble.stargate.init.StargateFluids;
import dev.amble.stargate.init.StargateItems;
import java.util.Optional;
import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;

public abstract class LiquidNaquadahFluid extends class_3609 {

    @Override
    public class_3611 method_15750() {
        return StargateFluids.LIQUID_NAQUADAH_FLOWING;
    }

    @Override
    public class_3611 method_15751() {
        return StargateFluids.LIQUID_NAQUADAH_STILL;
    }

    @Override
    public class_1792 method_15774() {
        return StargateItems.LIQUID_NAQUADAH;
    }

    @Override
    protected void method_15730(class_1936 world, class_2338 pos, class_2680 state) {
    }

    @Override
    public int method_15733(class_4538 world) {
        return 2; // Prevents fluid from flowing
    }

    @Override
    public class_2680 method_15790(class_3610 state) {
        return StargateBlocks.LIQUID_NAQUADAH_BLOCK.method_9564().method_11657(class_2404.field_11278, method_15741(state));
    }

    @Override
    public boolean method_15780(class_3611 fluid) {
        return fluid == StargateFluids.LIQUID_NAQUADAH_STILL || fluid == StargateFluids.LIQUID_NAQUADAH_FLOWING;
    }

    @Override
    public int method_15739(class_4538 world) {
        return 1; // Prevents fluid from spreading
    }

    @Override
    public boolean method_15777(class_3610 state, class_1922 world, class_2338 pos, class_3611 fluid, class_2350 direction) {
return false;
    }

    @Override
    public int method_15789(class_4538 world) {
        return 10;
    }

    @Override
    public int method_15753(class_1937 world, class_2338 pos, class_3610 oldState, class_3610 newState) {
        int i = this.method_15789(world);
        if (!oldState.method_15769() && !newState.method_15769() && !oldState.method_11654(field_15902) && !newState.method_11654(field_15902) && newState.method_15763(world, pos) > oldState.method_15763(world, pos) && world.method_8409().method_43048(4) != 0) {
            i *= 4;
        }
        return i;
    }

    @Override
    protected boolean method_15737(class_1937 world) {
        return false;
    }

    @Override
    protected boolean method_15795() {
        return true;
    }

    @Override
    protected float method_15784() {
        return 100.0F;
    }

    @Override
    public Optional<class_3414> method_32359() {
        return Optional.of(class_3417.field_14779);
    }

    @Override
    protected void method_15775(class_2689.class_2690<class_3611, class_3610> builder) {
        super.method_15775(builder);
        builder.method_11667(field_15900);
    }

    public static class Still extends LiquidNaquadahFluid {
        @Override
        public int method_15779(class_3610 state) {
            return 8;
        }

        @Override
        public boolean method_15793(class_3610 state) {
            return true;
        }
    }

    public static class Flowing extends LiquidNaquadahFluid {
        @Override
        public int method_15779(class_3610 state) {
            return state.method_11654(field_15900);
        }

        @Override
        public boolean method_15793(class_3610 state) {
            return false;
        }
    }
}