package dev.amble.stargate.world;

import dev.amble.stargate.StargateMod;
import dev.amble.stargate.init.StargateBlocks;
import java.util.List;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3124;
import net.minecraft.class_3481;
import net.minecraft.class_3798;
import net.minecraft.class_3825;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class StargateConfiguredFeature {
    public static final class_5321<class_2975<?, ?>> NAQUADAH_ORE_KEY = registerKey("naquadah_ore");

    public static void bootstrap(class_7891<class_2975<?, ?>> context) {
        class_3825 deepslateReplaceables = new class_3798(class_3481.field_28993);

        List<class_3124.class_5876> overworldNaquadahOre = List.of(
                class_3124.method_33994(deepslateReplaceables, StargateBlocks.NAQUADAH_ORE.method_9564())
        );

        register(context, NAQUADAH_ORE_KEY, class_3031.field_13517, new class_3124(overworldNaquadahOre, 5,0.0f));
    }

    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, StargateMod.id(name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }
}
