package dev.amble.stargate.init;

import dev.amble.lib.container.impl.ItemGroupContainer;
import dev.amble.lib.itemgroup.AItemGroup;
import dev.amble.stargate.StargateMod;
import net.minecraft.class_1799;

public class StargateItemGroups implements ItemGroupContainer {
    public static final AItemGroup MAIN = AItemGroup.builder(StargateMod.id("item_group"))
            .icon(() -> new class_1799(StargateBlocks.DHD))
            .build();
}
