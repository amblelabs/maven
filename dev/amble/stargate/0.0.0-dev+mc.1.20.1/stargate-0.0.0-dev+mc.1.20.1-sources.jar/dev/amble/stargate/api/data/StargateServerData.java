package dev.amble.stargate.api.data;

import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.ServerStargate;
import dev.amble.stargate.api.StargateLike;
import dev.amble.stargate.api.Stargate;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import it.unimi.dsi.fastutil.objects.ReferenceSet;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_18;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.*;

public class StargateServerData extends class_18 implements StargateData<ServerStargate> {

	public static void init() {
		ServerTickEvents.END_WORLD_TICK.register(world -> {
			// FIXME: instead of ticking all gates, it might be better to tick only loaded gates...
			StargateServerData data = StargateServerData.get(world);

			if (data != null)
				data.tick();
		});

		ServerPlayConnectionEvents.JOIN.register((networkHandler, packetSender, minecraftServer) -> {
			class_3222 player = networkHandler.field_14140;
			StargateServerData data = StargateServerData.get((class_3218) player.method_37908());

			if (data != null)
				data.syncAll(List.of(networkHandler.field_14140));
		});
	}

	private final Long2ObjectMap<ServerStargate> lookup = new Long2ObjectOpenHashMap<>();
	private final Long2ObjectMap<ReferenceSet<ServerStargate>> chunk2Gates = new Long2ObjectOpenHashMap<>();
	private final class_3218 world; // lives just as long as the world, shouldn't explode

	private StargateServerData(class_3218 world) {
		this.world = world;
	}

	public void mark(StargateLike gateLike) {
		ServerStargate stargate = (ServerStargate) gateLike.asGate();

		if (stargate != null)
			chunk2Gates.computeIfAbsent(class_1923.method_37232(stargate.pos()),
					l -> new ReferenceOpenHashSet<>()).add(stargate);
	}

	public void unmark(StargateLike gateLike) {
		ServerStargate stargate = (ServerStargate) gateLike.asGate();

		if (stargate != null)
			chunk2Gates.get(class_1923.method_37232(stargate.pos())).remove(stargate);
	}

	public @Nullable Collection<ServerStargate> findByChunk(int chunkX, int chunkZ) {
		return chunk2Gates.get(class_1923.method_8331(chunkX, chunkZ));
	}

	private Collection<class_3222> tracking(Stargate stargate) {
		return PlayerLookup.tracking(world, stargate.pos());
	}

	private void tick() {
		for (ServerStargate stargate : this.lookup.values()) {
			if (!world.method_39999(stargate.pos()))
				continue;

			stargate.tick();

			if (stargate.dirty()) {
				this.syncPartial(stargate.globalId(), stargate, tracking(stargate));
				stargate.unmarkDirty();
			}
		}
	}

	@Override
	public boolean method_79() {
		return true;
	}

	public void syncAll(Collection<class_3222> targets) {
		class_2540 buf = PacketByteBufs.create();
		buf.method_10794(this.toNbt(true));

		targets.forEach(player ->
				ServerPlayNetworking.send(player, SYNC_ALL, buf));
	}

	public void syncPartial(long id, ServerStargate gate, Collection<class_3222> targets) {
		class_2487 nbt = new class_2487();
		gate.toNbt(nbt, true);

		class_2540 buf = PacketByteBufs.create();
		buf.method_10791(id);
		buf.method_10794(nbt);

		targets.forEach(player ->
				ServerPlayNetworking.send(player, SYNC, buf));
	}

	private void removePartial(ServerStargate gate, Collection<class_3222> targets) {
		class_2540 buf = PacketByteBufs.create();
		buf.method_10791(gate.globalAddress());

		targets.forEach(player ->
				ServerPlayNetworking.send(player, REMOVE, buf));
	}

	public <R extends LongSupplier> R generateAddress(class_5321<class_1937> world, class_2338 pos, BiFunction<class_5321<class_1937>, class_2338, R> func) {
		R address = null;

		while (address == null || this.containsId(address.getAsLong())) {
			address = func.apply(world, pos);
		}

		return address;
	}

	@Override
	public void addId(long id, ServerStargate stargate) {
		this.lookup.put(id, stargate);
		this.syncPartial(id, stargate, tracking(stargate));
	}

	@Override
	public void removeId(long id) {
		ServerStargate stargate = lookup.remove(id);
		Collection<ServerStargate> meta = this.chunk2Gates.get(class_1923.method_37232(stargate.pos()));

		meta.remove(stargate);

		this.removePartial(stargate, tracking(stargate));
	}

	@Override
	public boolean containsId(long id) {
		return lookup.containsKey(id);
	}

	@Override
	public @Nullable ServerStargate getById(long id) {
		return lookup.get(id);
	}

	@Override
	public class_2487 method_75(class_2487 nbt) {
		return this.toNbt(false);
	}

	private class_2487 toNbt(boolean sync) {
		class_2487 nbt = new class_2487();
		class_2499 list = new class_2499();

		lookup.values().forEach(stargate -> {
			class_2487 compound = new class_2487();
			stargate.toNbt(compound, sync);

			list.add(compound);
		});

		nbt.method_10566("Network", list);
		return nbt;
	}

	public static StargateServerData loadNbt(class_3218 world, class_2487 nbt) {
		StargateServerData data = new StargateServerData(world);

		class_2499 network = nbt.method_10554("Network", class_2520.field_33260);

		return data;
	}

	public static @NotNull StargateServerData getOrCreate(class_3218 world) {
		return world.method_17983().method_17924(nbt -> loadNbt(world, nbt),
				() -> new StargateServerData(world), StargateMod.MOD_ID);
	}

	public static @Nullable StargateServerData get(class_3218 world) {
		return world.method_17983().method_20786(nbt -> loadNbt(world, nbt), StargateMod.MOD_ID);
	}

	public static void accept(class_3218 world, Consumer<StargateServerData> consumer) {
		StargateServerData data = get(world);
		if (data != null) consumer.accept(data);
	}

	public static <R> @Nullable R apply(class_3218 world, Function<StargateServerData, R> func) {
		StargateServerData data = get(world);
		return data != null ? func.apply(data) : null;
	}
}
