package dev.amble.stargate.advancement;

import com.google.gson.JsonObject;
import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.state.IrisTier;
import net.minecraft.class_195;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3518;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_5267;
import net.minecraft.class_5321;
import org.jetbrains.annotations.Nullable;

public class BreakIrisCriterion extends class_4558<BreakIrisCriterion.Conditions> {

    static final class_2960 ID = StargateMod.id("break_iris");

    public class_2960 method_794() {
        return ID;
    }

    @Override
    public Conditions method_27854(JsonObject jsonObject, class_5258 lootContextPredicate, class_5257 advancementEntityPredicateDeserializer) {
        class_2960 irisTier = getTier(jsonObject);
        return new Conditions(lootContextPredicate, irisTier);
    }

    private static class_2960 getTier(JsonObject root) {
        return new class_2960(class_3518.method_15265(root, "tier"));
    }

    public void trigger(class_3222 player, IrisTier state) {
        this.method_22510(player, conditions -> conditions.test(state.getRegistryKey()));
    }

    public static class Conditions extends class_195 {
        private final @Nullable class_2960 tier;

        public Conditions(class_5258 player, @Nullable class_2960 irisTier) {
            super(BreakIrisCriterion.ID, player);
            this.tier = irisTier;
        }

        public static Conditions create(IrisTier tier) {
            return create(tier.getRegistryKey());
        }

        public static Conditions create(class_5321<IrisTier> tier) {
            return new Conditions(class_5258.field_24388, tier.method_29177());
        }

        public JsonObject method_807(class_5267 predicateSerializer) {
            JsonObject jsonObject = super.method_807(predicateSerializer);

            if (tier != null)
                jsonObject.addProperty("tier", tier.toString());
            return jsonObject;
        }

        public boolean test(class_5321<IrisTier> tier) {
            return this.tier == null || this.tier.equals(tier.method_29177());
        }
    }
}
