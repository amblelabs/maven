package dev.amble.stargate.client.models;

import net.minecraft.class_630;

public class DestinyGateModel extends StargateModel {

	public final class_630 stargate;
	public final class_630 chev_light;
	public final class_630 chev_light2;
	public final class_630 chev_light3;
	public final class_630 chev_light4;
	public final class_630 chev_light5;
	public final class_630 chev_light6;
	public final class_630 chev_light7;
	public final class_630 chev_light8;
	public final class_630 chev_light9;
	public final class_630 chev_light7bottom;
	public final class_630 SymbolRing;
	public final class_630 iris;

	public DestinyGateModel(class_630 root) {
		super(root);

		this.stargate = root.method_32086("stargate");

		class_630 OuterRing = this.stargate.method_32086("OuterRing");
		class_630 lights = OuterRing.method_32086("lights");

		this.chev_light = lights.method_32086("chev_light");
		this.chev_light2 = lights.method_32086("chev_light2");
		this.chev_light3 = lights.method_32086("chev_light3");
		this.chev_light4 = lights.method_32086("chev_light4");
		this.chev_light5 = lights.method_32086("chev_light5");
		this.chev_light6 = lights.method_32086("chev_light6");
		this.chev_light7 = lights.method_32086("chev_light7");
		this.chev_light7bottom = lights.method_32086("chev_light7bottom");
		this.chev_light8 = lights.method_32086("chev_light8");
		this.chev_light9 = lights.method_32086("chev_light9");
		this.SymbolRing = this.stargate.method_32086("SymbolRing");
		this.iris = this.stargate.method_32086("iris");
	}

	@Override
	public class_630 method_32008() {
		return stargate;
	}

	@Override
	public class_630[] bakeChevronLights() {
		return new class_630[] {
				chev_light, chev_light2, chev_light3, chev_light4,
				chev_light5, chev_light6, chev_light7, chev_light7bottom
		};
	}
}