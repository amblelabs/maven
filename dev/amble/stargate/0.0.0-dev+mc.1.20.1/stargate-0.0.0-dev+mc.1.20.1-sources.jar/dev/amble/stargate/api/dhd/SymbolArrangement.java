package dev.amble.stargate.api.dhd;

import dev.amble.stargate.block.DHDBlock;
import dev.amble.stargate.entities.DHDControlEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_4048;
import org.joml.Vector3f;

/**
 * Holds a control which will be run when interacted with, an
 * {@link Vector3f offset} from the centre of the {@link DHDBlock} and
 * a {@link class_4048 scale} for the entity <br>
 * <br>
 * A list of these is gotten by {@link DHDArrangement#SYMBOLS)} and
 * used in {@link DHDControlEntity} to hold its information
 *
 * @author loqor
 * @see DHDControlEntity
 */
public record SymbolArrangement(char symbol, class_4048 scale, Offset offset) {

    public DHDControlEntity createEntity(class_1937 world, class_2338 pos, class_2350 direction) {
        DHDControlEntity controlEntity = new DHDControlEntity(world, symbol, scale, pos);
        controlEntity.method_33574(this.offset.offset(pos.method_46558(), direction));

        world.method_8649(controlEntity);
        return controlEntity;
    }

    public sealed abstract static class Offset extends Vector3f {

        public Offset(float x, float y, float z) {
            super(x, y, z);
        }

        @Override
        public Offset rotateX(float angle) {
            return (Offset) super.rotateX(angle);
        }

        @Override
        public Offset rotateZ(float angle) {
            return (Offset) super.rotateZ(angle);
        }

        public static Offset changing(float x, float y, float z) {
            return new Changing(x, y, z);
        }

        public static Offset fixed(float x, float y, float z) {
            return new Fixed(x, y, z);
        }

        public abstract class_243 offset(class_243 pos, class_2350 direction);

        private static final class Changing extends Offset {

            public Changing(float x, float y, float z) {
                super(x, y, z);
            }

            @Override
            public class_243 offset(class_243 pos, class_2350 direction) {
                float x = this.x;

                if (direction == class_2350.field_11043 || direction == class_2350.field_11035)
                    x = -x;

                return pos.method_1031(
                        x * direction.method_10165() - z * direction.method_10148(), y,
                        x * direction.method_10148() - z * direction.method_10165()
                );
            }
        }

        private static final class Fixed extends Offset {

            public Fixed(float x, float y, float z) {
                super(x, y, z);
            }

            @Override
            public class_243 offset(class_243 pos, class_2350 direction) {
                return pos.method_1031(x, y, z);
            }
        }
    }
}
