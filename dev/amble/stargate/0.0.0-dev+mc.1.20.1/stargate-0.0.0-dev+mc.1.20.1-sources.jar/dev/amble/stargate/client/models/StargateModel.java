package dev.amble.stargate.client.models;

import java.util.function.Function;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public abstract class StargateModel extends BaseStargateModel {

    protected StargateModel(class_630 root) {}

    public static <T extends StargateModel> T create(Function<class_630, T> f) {
        T t = f.apply(getTexturedModelData().method_32109());
        t.bake();
        return t;
    }

    private static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();
        class_5610 stargate = modelPartData.method_32117(
            "stargate",
            class_5606.method_32108(),
            class_5603.method_32091(0.0F, -32.0F, 0.0F, 0.0F, 0.0F, -3.1416F)
        );

        class_5610 OuterRing = stargate.method_32117(
            "OuterRing",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 chev = OuterRing.method_32117(
            "chev",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 chev2 = OuterRing.method_32117(
            "chev2",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 chev3 = OuterRing.method_32117(
            "chev3",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 chev4 = OuterRing.method_32117(
            "chev4",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 chev5 = OuterRing.method_32117(
            "chev5",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 chev6 = OuterRing.method_32117(
            "chev6",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 chev7 = OuterRing.method_32117(
            "chev7",
            class_5606.method_32108()
                .method_32101(70, 51)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 chev7mid = OuterRing.method_32117(
            "chev7mid",
            class_5606.method_32108()
                .method_32101(129, 51)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 chev7bottom = OuterRing.method_32117(
            "chev7bottom",
            class_5606.method_32108()
                .method_32101(0, 68)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 chev8 = OuterRing.method_32117(
            "chev8",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r1 = chev8.method_32117(
            "cube_r1",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 chev9 = OuterRing.method_32117(
            "chev9",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r2 = chev9.method_32117(
            "cube_r2",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 lights = OuterRing.method_32117(
            "lights",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 chev_light = lights.method_32117(
            "chev_light",
            class_5606.method_32108()
                .method_32101(70, 109)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 chev_light2 = lights.method_32117(
            "chev_light2",
            class_5606.method_32108()
                .method_32101(70, 109)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 chev_light3 = lights.method_32117(
            "chev_light3",
            class_5606.method_32108()
                .method_32101(70, 109)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 chev_light4 = lights.method_32117(
            "chev_light4",
            class_5606.method_32108()
                .method_32101(70, 109)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 chev_light5 = lights.method_32117(
            "chev_light5",
            class_5606.method_32108()
                .method_32101(70, 109)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 chev_light6 = lights.method_32117(
            "chev_light6",
            class_5606.method_32108()
                .method_32101(70, 109)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 chev_light7 = lights.method_32117(
            "chev_light7",
            class_5606.method_32108()
                .method_32101(0, 138)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 chev_light7bottom = lights.method_32117(
            "chev_light7bottom",
            class_5606.method_32108()
                .method_32101(70, 89)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 chev_light8 = lights.method_32117(
            "chev_light8",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r3 = chev_light8.method_32117(
            "cube_r3",
            class_5606.method_32108()
                .method_32101(70, 109)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 chev_light9 = lights.method_32117(
            "chev_light9",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r4 = chev_light9.method_32117(
            "cube_r4",
            class_5606.method_32108()
                .method_32101(70, 109)
                .method_32098(
                    -10.0F,
                    46.0F,
                    -4.5F,
                    20.0F,
                    10.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 main = OuterRing.method_32117(
            "main",
            class_5606.method_32108()
                .method_32101(0, 52)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r5 = main.method_32117(
            "cube_r5",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.0F)
                )
                .method_32101(0, 16)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F)
        );

        class_5610 cube_r6 = main.method_32117(
            "cube_r6",
            class_5606.method_32108()
                .method_32101(0, 52)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 cube_r7 = main.method_32117(
            "cube_r7",
            class_5606.method_32108()
                .method_32101(0, 16)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(0, 0)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.4435F)
        );

        class_5610 cube_r8 = main.method_32117(
            "cube_r8",
            class_5606.method_32108()
                .method_32101(0, 52)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 cube_r9 = main.method_32117(
            "cube_r9",
            class_5606.method_32108()
                .method_32101(0, 16)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(0, 0)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.7453F)
        );

        class_5610 cube_r10 = main.method_32117(
            "cube_r10",
            class_5606.method_32108()
                .method_32101(0, 52)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 cube_r11 = main.method_32117(
            "cube_r11",
            class_5606.method_32108()
                .method_32101(0, 16)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(0, 0)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0472F)
        );

        class_5610 cube_r12 = main.method_32117(
            "cube_r12",
            class_5606.method_32108()
                .method_32101(0, 52)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 cube_r13 = main.method_32117(
            "cube_r13",
            class_5606.method_32108()
                .method_32101(0, 16)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(0, 0)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 cube_r14 = main.method_32117(
            "cube_r14",
            class_5606.method_32108()
                .method_32101(0, 16)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(0, 0)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F)
        );

        class_5610 cube_r15 = main.method_32117(
            "cube_r15",
            class_5606.method_32108()
                .method_32101(0, 52)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 cube_r16 = main.method_32117(
            "cube_r16",
            class_5606.method_32108()
                .method_32101(0, 16)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(0, 0)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0472F)
        );

        class_5610 cube_r17 = main.method_32117(
            "cube_r17",
            class_5606.method_32108()
                .method_32101(0, 52)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 cube_r18 = main.method_32117(
            "cube_r18",
            class_5606.method_32108()
                .method_32101(0, 16)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(0, 0)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.7453F)
        );

        class_5610 cube_r19 = main.method_32117(
            "cube_r19",
            class_5606.method_32108()
                .method_32101(0, 52)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 cube_r20 = main.method_32117(
            "cube_r20",
            class_5606.method_32108()
                .method_32101(0, 16)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(0, 0)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.4435F)
        );

        class_5610 cube_r21 = main.method_32117(
            "cube_r21",
            class_5606.method_32108()
                .method_32101(0, 52)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 destiny = OuterRing.method_32117(
            "destiny",
            class_5606.method_32108()
                .method_32101(183, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r22 = destiny.method_32117(
            "cube_r22",
            class_5606.method_32108()
                .method_32101(185, 110)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.0F)
                )
                .method_32101(124, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F)
        );

        class_5610 cube_r23 = destiny.method_32117(
            "cube_r23",
            class_5606.method_32108()
                .method_32101(183, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 cube_r24 = destiny.method_32117(
            "cube_r24",
            class_5606.method_32108()
                .method_32101(124, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(185, 110)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.4435F)
        );

        class_5610 cube_r25 = destiny.method_32117(
            "cube_r25",
            class_5606.method_32108()
                .method_32101(183, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 cube_r26 = destiny.method_32117(
            "cube_r26",
            class_5606.method_32108()
                .method_32101(124, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(185, 110)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.7453F)
        );

        class_5610 cube_r27 = destiny.method_32117(
            "cube_r27",
            class_5606.method_32108()
                .method_32101(183, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 cube_r28 = destiny.method_32117(
            "cube_r28",
            class_5606.method_32108()
                .method_32101(124, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(185, 110)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0472F)
        );

        class_5610 cube_r29 = destiny.method_32117(
            "cube_r29",
            class_5606.method_32108()
                .method_32101(183, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 cube_r30 = destiny.method_32117(
            "cube_r30",
            class_5606.method_32108()
                .method_32101(124, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(185, 110)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 cube_r31 = destiny.method_32117(
            "cube_r31",
            class_5606.method_32108()
                .method_32101(124, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(185, 110)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F)
        );

        class_5610 cube_r32 = destiny.method_32117(
            "cube_r32",
            class_5606.method_32108()
                .method_32101(183, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 cube_r33 = destiny.method_32117(
            "cube_r33",
            class_5606.method_32108()
                .method_32101(124, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(185, 110)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0472F)
        );

        class_5610 cube_r34 = destiny.method_32117(
            "cube_r34",
            class_5606.method_32108()
                .method_32101(183, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 cube_r35 = destiny.method_32117(
            "cube_r35",
            class_5606.method_32108()
                .method_32101(124, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(185, 110)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.7453F)
        );

        class_5610 cube_r36 = destiny.method_32117(
            "cube_r36",
            class_5606.method_32108()
                .method_32101(183, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 cube_r37 = destiny.method_32117(
            "cube_r37",
            class_5606.method_32108()
                .method_32101(124, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.25F)
                )
                .method_32101(185, 110)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.4435F)
        );

        class_5610 cube_r38 = destiny.method_32117(
            "cube_r38",
            class_5606.method_32108()
                .method_32101(183, 142)
                .method_32098(
                    -10.0F,
                    51.0F,
                    -4.5F,
                    20.0F,
                    5.0F,
                    9.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 accessorylights = OuterRing.method_32117(
            "accessorylights",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r39 = accessorylights.method_32117(
            "cube_r39",
            class_5606.method_32108()
                .method_32101(65, 141)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0472F)
        );

        class_5610 cube_r40 = accessorylights.method_32117(
            "cube_r40",
            class_5606.method_32108()
                .method_32101(65, 141)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.7453F)
        );

        class_5610 cube_r41 = accessorylights.method_32117(
            "cube_r41",
            class_5606.method_32108()
                .method_32101(65, 141)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.4435F)
        );

        class_5610 cube_r42 = accessorylights.method_32117(
            "cube_r42",
            class_5606.method_32108()
                .method_32101(65, 141)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F)
        );

        class_5610 cube_r43 = accessorylights.method_32117(
            "cube_r43",
            class_5606.method_32108()
                .method_32101(65, 141)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.4435F)
        );

        class_5610 cube_r44 = accessorylights.method_32117(
            "cube_r44",
            class_5606.method_32108()
                .method_32101(65, 141)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.7453F)
        );

        class_5610 cube_r45 = accessorylights.method_32117(
            "cube_r45",
            class_5606.method_32108()
                .method_32101(65, 141)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0472F)
        );

        class_5610 cube_r46 = accessorylights.method_32117(
            "cube_r46",
            class_5606.method_32108()
                .method_32101(65, 141)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 cube_r47 = accessorylights.method_32117(
            "cube_r47",
            class_5606.method_32108()
                .method_32101(65, 141)
                .method_32098(
                    -10.0F,
                    50.0F,
                    -4.5F,
                    20.0F,
                    6.0F,
                    9.0F,
                    new class_5605(0.255F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F)
        );

        class_5610 SymbolRing = stargate.method_32117(
            "SymbolRing",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 Extras = SymbolRing.method_32117(
            "Extras",
            class_5606.method_32108(),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0873F)
        );

        class_5610 cube_r48 = Extras.method_32117(
            "cube_r48",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.618F)
        );

        class_5610 cube_r49 = Extras.method_32117(
            "cube_r49",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.9671F)
        );

        class_5610 cube_r50 = Extras.method_32117(
            "cube_r50",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.9199F)
        );

        class_5610 cube_r51 = Extras.method_32117(
            "cube_r51",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.2689F)
        );

        class_5610 cube_r52 = Extras.method_32117(
            "cube_r52",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.2217F)
        );

        class_5610 cube_r53 = Extras.method_32117(
            "cube_r53",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.5708F)
        );

        class_5610 cube_r54 = Extras.method_32117(
            "cube_r54",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5236F)
        );

        class_5610 cube_r55 = Extras.method_32117(
            "cube_r55",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.8727F)
        );

        class_5610 cube_r56 = Extras.method_32117(
            "cube_r56",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.1745F)
        );

        class_5610 cube_r57 = Extras.method_32117(
            "cube_r57",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1745F)
        );

        class_5610 cube_r58 = Extras.method_32117(
            "cube_r58",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.8727F)
        );

        class_5610 cube_r59 = Extras.method_32117(
            "cube_r59",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.5236F)
        );

        class_5610 cube_r60 = Extras.method_32117(
            "cube_r60",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.5708F)
        );

        class_5610 cube_r61 = Extras.method_32117(
            "cube_r61",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.2217F)
        );

        class_5610 cube_r62 = Extras.method_32117(
            "cube_r62",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.2689F)
        );

        class_5610 cube_r63 = Extras.method_32117(
            "cube_r63",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.9199F)
        );

        class_5610 cube_r64 = Extras.method_32117(
            "cube_r64",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.618F)
        );

        class_5610 cube_r65 = Extras.method_32117(
            "cube_r65",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.9671F)
        );

        class_5610 Extras2 = SymbolRing.method_32117(
            "Extras2",
            class_5606.method_32108(),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2618F)
        );

        class_5610 cube_r66 = Extras2.method_32117(
            "cube_r66",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.618F)
        );

        class_5610 cube_r67 = Extras2.method_32117(
            "cube_r67",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.9671F)
        );

        class_5610 cube_r68 = Extras2.method_32117(
            "cube_r68",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.9199F)
        );

        class_5610 cube_r69 = Extras2.method_32117(
            "cube_r69",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.2689F)
        );

        class_5610 cube_r70 = Extras2.method_32117(
            "cube_r70",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.2217F)
        );

        class_5610 cube_r71 = Extras2.method_32117(
            "cube_r71",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.5708F)
        );

        class_5610 cube_r72 = Extras2.method_32117(
            "cube_r72",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5236F)
        );

        class_5610 cube_r73 = Extras2.method_32117(
            "cube_r73",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.8727F)
        );

        class_5610 cube_r74 = Extras2.method_32117(
            "cube_r74",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.1745F)
        );

        class_5610 cube_r75 = Extras2.method_32117(
            "cube_r75",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1745F)
        );

        class_5610 cube_r76 = Extras2.method_32117(
            "cube_r76",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.8727F)
        );

        class_5610 cube_r77 = Extras2.method_32117(
            "cube_r77",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.5236F)
        );

        class_5610 cube_r78 = Extras2.method_32117(
            "cube_r78",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.5708F)
        );

        class_5610 cube_r79 = Extras2.method_32117(
            "cube_r79",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.2217F)
        );

        class_5610 cube_r80 = Extras2.method_32117(
            "cube_r80",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.2689F)
        );

        class_5610 cube_r81 = Extras2.method_32117(
            "cube_r81",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.9199F)
        );

        class_5610 cube_r82 = Extras2.method_32117(
            "cube_r82",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.618F)
        );

        class_5610 cube_r83 = Extras2.method_32117(
            "cube_r83",
            class_5606.method_32108()
                .method_32101(179, 42)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.9671F)
        );

        class_5610 Base = SymbolRing.method_32117(
            "Base",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r84 = Base.method_32117(
            "cube_r84",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.4435F)
        );

        class_5610 cube_r85 = Base.method_32117(
            "cube_r85",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 cube_r86 = Base.method_32117(
            "cube_r86",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.7453F)
        );

        class_5610 cube_r87 = Base.method_32117(
            "cube_r87",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 cube_r88 = Base.method_32117(
            "cube_r88",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0472F)
        );

        class_5610 cube_r89 = Base.method_32117(
            "cube_r89",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 cube_r90 = Base.method_32117(
            "cube_r90",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F)
        );

        class_5610 cube_r91 = Base.method_32117(
            "cube_r91",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 cube_r92 = Base.method_32117(
            "cube_r92",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 cube_r93 = Base.method_32117(
            "cube_r93",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0472F)
        );

        class_5610 cube_r94 = Base.method_32117(
            "cube_r94",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 cube_r95 = Base.method_32117(
            "cube_r95",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.7453F)
        );

        class_5610 cube_r96 = Base.method_32117(
            "cube_r96",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 cube_r97 = Base.method_32117(
            "cube_r97",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.4435F)
        );

        class_5610 cube_r98 = Base.method_32117(
            "cube_r98",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 cube_r99 = Base.method_32117(
            "cube_r99",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 cube_r100 = Base.method_32117(
            "cube_r100",
            class_5606.method_32108()
                .method_32101(112, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F)
        );

        class_5610 Base2 = SymbolRing.method_32117(
            "Base2",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1745F)
        );

        class_5610 cube_r101 = Base2.method_32117(
            "cube_r101",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.4435F)
        );

        class_5610 cube_r102 = Base2.method_32117(
            "cube_r102",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 cube_r103 = Base2.method_32117(
            "cube_r103",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.7453F)
        );

        class_5610 cube_r104 = Base2.method_32117(
            "cube_r104",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 cube_r105 = Base2.method_32117(
            "cube_r105",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0472F)
        );

        class_5610 cube_r106 = Base2.method_32117(
            "cube_r106",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 cube_r107 = Base2.method_32117(
            "cube_r107",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F)
        );

        class_5610 cube_r108 = Base2.method_32117(
            "cube_r108",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 cube_r109 = Base2.method_32117(
            "cube_r109",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 cube_r110 = Base2.method_32117(
            "cube_r110",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0472F)
        );

        class_5610 cube_r111 = Base2.method_32117(
            "cube_r111",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 cube_r112 = Base2.method_32117(
            "cube_r112",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.7453F)
        );

        class_5610 cube_r113 = Base2.method_32117(
            "cube_r113",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 cube_r114 = Base2.method_32117(
            "cube_r114",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.4435F)
        );

        class_5610 cube_r115 = Base2.method_32117(
            "cube_r115",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 cube_r116 = Base2.method_32117(
            "cube_r116",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 cube_r117 = Base2.method_32117(
            "cube_r117",
            class_5606.method_32108()
                .method_32101(132, 71)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F)
        );

        class_5610 BaseLights = SymbolRing.method_32117(
            "BaseLights",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 BaseLight1 = BaseLights.method_32117(
            "BaseLight1",
            class_5606.method_32108()
                .method_32101(112, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.05F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 BaseLight2 = BaseLights.method_32117(
            "BaseLight2",
            class_5606.method_32108()
                .method_32101(165, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.051F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r118 = BaseLight2.method_32117(
            "cube_r118",
            class_5606.method_32108()
                .method_32101(165, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.05F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 BaseLight3 = BaseLights.method_32117(
            "BaseLight3",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r119 = BaseLight3.method_32117(
            "cube_r119",
            class_5606.method_32108()
                .method_32101(112, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.05F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 BaseLights2 = SymbolRing.method_32117(
            "BaseLights2",
            class_5606.method_32108(),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1745F)
        );

        class_5610 BaseLight4 = BaseLights2.method_32117(
            "BaseLight4",
            class_5606.method_32108()
                .method_32101(112, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.05F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 BaseLight5 = BaseLights2.method_32117(
            "BaseLight5",
            class_5606.method_32108()
                .method_32101(165, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.051F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r120 = BaseLight5.method_32117(
            "cube_r120",
            class_5606.method_32108()
                .method_32101(165, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.05F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 BaseLight6 = BaseLights2.method_32117(
            "BaseLight6",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r121 = BaseLight6.method_32117(
            "cube_r121",
            class_5606.method_32108()
                .method_32101(112, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.05F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 SymbolRingDestiny = stargate.method_32117(
            "SymbolRingDestiny",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 DestExtras = SymbolRingDestiny.method_32117(
            "DestExtras",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0698F)
        );

        class_5610 cube_r122 = DestExtras.method_32117(
            "cube_r122",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 cube_r123 = DestExtras.method_32117(
            "cube_r123",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.9548F)
        );

        class_5610 cube_r124 = DestExtras.method_32117(
            "cube_r124",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.5359F)
        );

        class_5610 cube_r125 = DestExtras.method_32117(
            "cube_r125",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.6755F)
        );

        class_5610 cube_r126 = DestExtras.method_32117(
            "cube_r126",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.8151F)
        );

        class_5610 cube_r127 = DestExtras.method_32117(
            "cube_r127",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 3.0718F)
        );

        class_5610 cube_r128 = DestExtras.method_32117(
            "cube_r128",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.5133F)
        );

        class_5610 cube_r129 = DestExtras.method_32117(
            "cube_r129",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.6529F)
        );

        class_5610 cube_r130 = DestExtras.method_32117(
            "cube_r130",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 cube_r131 = DestExtras.method_32117(
            "cube_r131",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.9322F)
        );

        class_5610 cube_r132 = DestExtras.method_32117(
            "cube_r132",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 cube_r133 = DestExtras.method_32117(
            "cube_r133",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.234F)
        );

        class_5610 cube_r134 = DestExtras.method_32117(
            "cube_r134",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.3736F)
        );

        class_5610 cube_r135 = DestExtras.method_32117(
            "cube_r135",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.1396F)
        );

        class_5610 cube_r136 = DestExtras.method_32117(
            "cube_r136",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2793F)
        );

        class_5610 cube_r137 = DestExtras.method_32117(
            "cube_r137",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1396F)
        );

        class_5610 cube_r138 = DestExtras.method_32117(
            "cube_r138",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.4189F)
        );

        class_5610 cube_r139 = DestExtras.method_32117(
            "cube_r139",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.5585F)
        );

        class_5610 cube_r140 = DestExtras.method_32117(
            "cube_r140",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 cube_r141 = DestExtras.method_32117(
            "cube_r141",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.8378F)
        );

        class_5610 cube_r142 = DestExtras.method_32117(
            "cube_r142",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 cube_r143 = DestExtras.method_32117(
            "cube_r143",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5585F)
        );

        class_5610 cube_r144 = DestExtras.method_32117(
            "cube_r144",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.4189F)
        );

        class_5610 cube_r145 = DestExtras.method_32117(
            "cube_r145",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2793F)
        );

        class_5610 cube_r146 = DestExtras.method_32117(
            "cube_r146",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.117F)
        );

        class_5610 cube_r147 = DestExtras.method_32117(
            "cube_r147",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.9774F)
        );

        class_5610 cube_r148 = DestExtras.method_32117(
            "cube_r148",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.8378F)
        );

        class_5610 cube_r149 = DestExtras.method_32117(
            "cube_r149",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.2566F)
        );

        class_5610 cube_r150 = DestExtras.method_32117(
            "cube_r150",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.5359F)
        );

        class_5610 cube_r151 = DestExtras.method_32117(
            "cube_r151",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.6755F)
        );

        class_5610 cube_r152 = DestExtras.method_32117(
            "cube_r152",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.8151F)
        );

        class_5610 cube_r153 = DestExtras.method_32117(
            "cube_r153",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.9548F)
        );

        class_5610 cube_r154 = DestExtras.method_32117(
            "cube_r154",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.117F)
        );

        class_5610 cube_r155 = DestExtras.method_32117(
            "cube_r155",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.2566F)
        );

        class_5610 cube_r156 = DestExtras.method_32117(
            "cube_r156",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 cube_r157 = DestExtras.method_32117(
            "cube_r157",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.9774F)
        );

        class_5610 cube_r158 = DestExtras.method_32117(
            "cube_r158",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.234F)
        );

        class_5610 cube_r159 = DestExtras.method_32117(
            "cube_r159",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.3736F)
        );

        class_5610 cube_r160 = DestExtras.method_32117(
            "cube_r160",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.5133F)
        );

        class_5610 cube_r161 = DestExtras.method_32117(
            "cube_r161",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 cube_r162 = DestExtras.method_32117(
            "cube_r162",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.6529F)
        );

        class_5610 cube_r163 = DestExtras.method_32117(
            "cube_r163",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 cube_r164 = DestExtras.method_32117(
            "cube_r164",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.9322F)
        );

        class_5610 cube_r165 = DestExtras.method_32117(
            "cube_r165",
            class_5606.method_32108()
                .method_32101(59, 0)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.0718F)
        );

        class_5610 DestBase = SymbolRingDestiny.method_32117(
            "DestBase",
            class_5606.method_32108()
                .method_32101(132, 89)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                )
                .method_32101(132, 107)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r166 = DestBase.method_32117(
            "cube_r166",
            class_5606.method_32108()
                .method_32101(132, 107)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                )
                .method_32101(132, 89)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 cube_r167 = DestBase.method_32117(
            "cube_r167",
            class_5606.method_32108()
                .method_32101(132, 107)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                )
                .method_32101(132, 89)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 cube_r168 = DestBase.method_32117(
            "cube_r168",
            class_5606.method_32108()
                .method_32101(132, 107)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                )
                .method_32101(132, 89)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 cube_r169 = DestBase.method_32117(
            "cube_r169",
            class_5606.method_32108()
                .method_32101(132, 107)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                )
                .method_32101(132, 89)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 cube_r170 = DestBase.method_32117(
            "cube_r170",
            class_5606.method_32108()
                .method_32101(132, 107)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                )
                .method_32101(132, 89)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 cube_r171 = DestBase.method_32117(
            "cube_r171",
            class_5606.method_32108()
                .method_32101(132, 107)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                )
                .method_32101(132, 89)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 cube_r172 = DestBase.method_32117(
            "cube_r172",
            class_5606.method_32108()
                .method_32101(132, 107)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                )
                .method_32101(132, 89)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 cube_r173 = DestBase.method_32117(
            "cube_r173",
            class_5606.method_32108()
                .method_32101(132, 107)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.25F)
                )
                .method_32101(132, 89)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 cube_r174 = DestBase.method_32117(
            "cube_r174",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.9548F)
        );

        class_5610 cube_r175 = DestBase.method_32117(
            "cube_r175",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.5359F)
        );

        class_5610 cube_r176 = DestBase.method_32117(
            "cube_r176",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.6755F)
        );

        class_5610 cube_r177 = DestBase.method_32117(
            "cube_r177",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.8151F)
        );

        class_5610 cube_r178 = DestBase.method_32117(
            "cube_r178",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 3.0718F)
        );

        class_5610 cube_r179 = DestBase.method_32117(
            "cube_r179",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.5133F)
        );

        class_5610 cube_r180 = DestBase.method_32117(
            "cube_r180",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.6529F)
        );

        class_5610 cube_r181 = DestBase.method_32117(
            "cube_r181",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.9322F)
        );

        class_5610 cube_r182 = DestBase.method_32117(
            "cube_r182",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.234F)
        );

        class_5610 cube_r183 = DestBase.method_32117(
            "cube_r183",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.3736F)
        );

        class_5610 cube_r184 = DestBase.method_32117(
            "cube_r184",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.1396F)
        );

        class_5610 cube_r185 = DestBase.method_32117(
            "cube_r185",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2793F)
        );

        class_5610 cube_r186 = DestBase.method_32117(
            "cube_r186",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1396F)
        );

        class_5610 cube_r187 = DestBase.method_32117(
            "cube_r187",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.4189F)
        );

        class_5610 cube_r188 = DestBase.method_32117(
            "cube_r188",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.5585F)
        );

        class_5610 cube_r189 = DestBase.method_32117(
            "cube_r189",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.8378F)
        );

        class_5610 cube_r190 = DestBase.method_32117(
            "cube_r190",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5585F)
        );

        class_5610 cube_r191 = DestBase.method_32117(
            "cube_r191",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.4189F)
        );

        class_5610 cube_r192 = DestBase.method_32117(
            "cube_r192",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2793F)
        );

        class_5610 cube_r193 = DestBase.method_32117(
            "cube_r193",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.117F)
        );

        class_5610 cube_r194 = DestBase.method_32117(
            "cube_r194",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.9774F)
        );

        class_5610 cube_r195 = DestBase.method_32117(
            "cube_r195",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.8378F)
        );

        class_5610 cube_r196 = DestBase.method_32117(
            "cube_r196",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.2566F)
        );

        class_5610 cube_r197 = DestBase.method_32117(
            "cube_r197",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.5359F)
        );

        class_5610 cube_r198 = DestBase.method_32117(
            "cube_r198",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.6755F)
        );

        class_5610 cube_r199 = DestBase.method_32117(
            "cube_r199",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.8151F)
        );

        class_5610 cube_r200 = DestBase.method_32117(
            "cube_r200",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.9548F)
        );

        class_5610 cube_r201 = DestBase.method_32117(
            "cube_r201",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.117F)
        );

        class_5610 cube_r202 = DestBase.method_32117(
            "cube_r202",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.2566F)
        );

        class_5610 cube_r203 = DestBase.method_32117(
            "cube_r203",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.9774F)
        );

        class_5610 cube_r204 = DestBase.method_32117(
            "cube_r204",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.234F)
        );

        class_5610 cube_r205 = DestBase.method_32117(
            "cube_r205",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.3736F)
        );

        class_5610 cube_r206 = DestBase.method_32117(
            "cube_r206",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.5133F)
        );

        class_5610 cube_r207 = DestBase.method_32117(
            "cube_r207",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.6529F)
        );

        class_5610 cube_r208 = DestBase.method_32117(
            "cube_r208",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.9322F)
        );

        class_5610 cube_r209 = DestBase.method_32117(
            "cube_r209",
            class_5606.method_32108()
                .method_32101(59, 18)
                .method_32098(
                    -9.5F,
                    42.0F,
                    -3.5F,
                    19.0F,
                    10.0F,
                    7.0F,
                    new class_5605(0.0F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.0718F)
        );

        class_5610 InnerRing = stargate.method_32117(
            "InnerRing",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.002F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r210 = InnerRing.method_32117(
            "cube_r210",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.002F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 cube_r211 = InnerRing.method_32117(
            "cube_r211",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.4435F)
        );

        class_5610 cube_r212 = InnerRing.method_32117(
            "cube_r212",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.002F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 cube_r213 = InnerRing.method_32117(
            "cube_r213",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.7453F)
        );

        class_5610 cube_r214 = InnerRing.method_32117(
            "cube_r214",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.002F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 cube_r215 = InnerRing.method_32117(
            "cube_r215",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0472F)
        );

        class_5610 cube_r216 = InnerRing.method_32117(
            "cube_r216",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.002F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 cube_r217 = InnerRing.method_32117(
            "cube_r217",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F)
        );

        class_5610 cube_r218 = InnerRing.method_32117(
            "cube_r218",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 cube_r219 = InnerRing.method_32117(
            "cube_r219",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.002F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 cube_r220 = InnerRing.method_32117(
            "cube_r220",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0472F)
        );

        class_5610 cube_r221 = InnerRing.method_32117(
            "cube_r221",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.002F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 cube_r222 = InnerRing.method_32117(
            "cube_r222",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.7453F)
        );

        class_5610 cube_r223 = InnerRing.method_32117(
            "cube_r223",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.002F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 cube_r224 = InnerRing.method_32117(
            "cube_r224",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.4435F)
        );

        class_5610 cube_r225 = InnerRing.method_32117(
            "cube_r225",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.002F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 cube_r226 = InnerRing.method_32117(
            "cube_r226",
            class_5606.method_32108()
                .method_32101(59, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.001F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F)
        );

        class_5610 InnerRingLayer = InnerRing.method_32117(
            "InnerRingLayer",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.251F)
                ),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        class_5610 cube_r227 = InnerRingLayer.method_32117(
            "cube_r227",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.251F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.7925F)
        );

        class_5610 cube_r228 = InnerRingLayer.method_32117(
            "cube_r228",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.4435F)
        );

        class_5610 cube_r229 = InnerRingLayer.method_32117(
            "cube_r229",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.251F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 2.0944F)
        );

        class_5610 cube_r230 = InnerRingLayer.method_32117(
            "cube_r230",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.7453F)
        );

        class_5610 cube_r231 = InnerRingLayer.method_32117(
            "cube_r231",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.251F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.3963F)
        );

        class_5610 cube_r232 = InnerRingLayer.method_32117(
            "cube_r232",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0472F)
        );

        class_5610 cube_r233 = InnerRingLayer.method_32117(
            "cube_r233",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.251F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6981F)
        );

        class_5610 cube_r234 = InnerRingLayer.method_32117(
            "cube_r234",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3491F)
        );

        class_5610 cube_r235 = InnerRingLayer.method_32117(
            "cube_r235",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3491F)
        );

        class_5610 cube_r236 = InnerRingLayer.method_32117(
            "cube_r236",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.251F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F)
        );

        class_5610 cube_r237 = InnerRingLayer.method_32117(
            "cube_r237",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0472F)
        );

        class_5610 cube_r238 = InnerRingLayer.method_32117(
            "cube_r238",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.251F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.3963F)
        );

        class_5610 cube_r239 = InnerRingLayer.method_32117(
            "cube_r239",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.7453F)
        );

        class_5610 cube_r240 = InnerRingLayer.method_32117(
            "cube_r240",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.251F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.0944F)
        );

        class_5610 cube_r241 = InnerRingLayer.method_32117(
            "cube_r241",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.4435F)
        );

        class_5610 cube_r242 = InnerRingLayer.method_32117(
            "cube_r242",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.251F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -2.7925F)
        );

        class_5610 cube_r243 = InnerRingLayer.method_32117(
            "cube_r243",
            class_5606.method_32108()
                .method_32101(108, 36)
                .method_32098(
                    -8.0F,
                    40.0F,
                    -4.0F,
                    16.0F,
                    4.0F,
                    8.0F,
                    new class_5605(0.25F)
                ),
            class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F)
        );

        class_5610 iris = stargate.method_32117(
            "iris",
            class_5606.method_32108(),
            class_5603.method_32090(0.0F, 0.0F, -2.0F)
        );

        class_5610 blade1 = iris.method_32117(
            "blade1",
            class_5606.method_32108(),
            class_5603.method_32091(-5.0F, 40.0F, 1.0F, 0.0F, 0.0F, 1.5708F)
        );

        class_5610 cube_r244 = blade1.method_32117(
            "cube_r244",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade2 = iris.method_32117(
            "blade2",
            class_5606.method_32108(),
            class_5603.method_32091(5.0F, -40.0F, 1.0F, 0.0F, 0.0F, -1.5708F)
        );

        class_5610 cube_r245 = blade2.method_32117(
            "cube_r245",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade3 = iris.method_32117(
            "blade3",
            class_5606.method_32108(),
            class_5603.method_32091(40.2606F, -2.0219F, 1.0F, 0.0F, 0.0F, -0.1745F)
        );

        class_5610 cube_r246 = blade3.method_32117(
            "cube_r246",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade4 = iris.method_32117(
            "blade4",
            class_5606.method_32108(),
            class_5603.method_32091(-40.2606F, 2.0219F, 1.0F, 0.0F, 0.0F, 2.9671F)
        );

        class_5610 cube_r247 = blade4.method_32117(
            "cube_r247",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade5 = iris.method_32117(
            "blade5",
            class_5606.method_32108(),
            class_5603.method_32091(8.9823F, 39.2978F, 1.0F, 0.0F, 0.0F, 1.2217F)
        );

        class_5610 cube_r248 = blade5.method_32117(
            "cube_r248",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade6 = iris.method_32117(
            "blade6",
            class_5606.method_32108(),
            class_5603.method_32091(-8.9823F, -39.2978F, 1.0F, 0.0F, 0.0F, -1.9199F)
        );

        class_5610 cube_r249 = blade6.method_32117(
            "cube_r249",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade7 = iris.method_32117(
            "blade7",
            class_5606.method_32108(),
            class_5603.method_32091(37.141F, -15.6699F, 1.0F, 0.0F, 0.0F, -0.5236F)
        );

        class_5610 cube_r250 = blade7.method_32117(
            "cube_r250",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade8 = iris.method_32117(
            "blade8",
            class_5606.method_32108(),
            class_5603.method_32091(-37.141F, 15.6699F, 1.0F, 0.0F, 0.0F, 2.618F)
        );

        class_5610 cube_r251 = blade8.method_32117(
            "cube_r251",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade9 = iris.method_32117(
            "blade9",
            class_5606.method_32108(),
            class_5603.method_32091(21.8813F, 33.8557F, 1.0F, 0.0F, 0.0F, 0.8727F)
        );

        class_5610 cube_r252 = blade9.method_32117(
            "cube_r252",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade10 = iris.method_32117(
            "blade10",
            class_5606.method_32108(),
            class_5603.method_32091(-21.8813F, -33.8557F, 1.0F, 0.0F, 0.0F, -2.2689F)
        );

        class_5610 cube_r253 = blade10.method_32117(
            "cube_r253",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade11 = iris.method_32117(
            "blade11",
            class_5606.method_32108(),
            class_5603.method_32091(29.5417F, -27.4278F, 1.0F, 0.0F, 0.0F, -0.8727F)
        );

        class_5610 cube_r254 = blade11.method_32117(
            "cube_r254",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade12 = iris.method_32117(
            "blade12",
            class_5606.method_32108(),
            class_5603.method_32091(-29.5417F, 27.4278F, 1.0F, 0.0F, 0.0F, 2.2689F)
        );

        class_5610 cube_r255 = blade12.method_32117(
            "cube_r255",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade13 = iris.method_32117(
            "blade13",
            class_5606.method_32108(),
            class_5603.method_32091(32.141F, 24.3301F, 1.0F, 0.0F, 0.0F, 0.5236F)
        );

        class_5610 cube_r256 = blade13.method_32117(
            "cube_r256",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade14 = iris.method_32117(
            "blade14",
            class_5606.method_32108(),
            class_5603.method_32091(-32.141F, -24.3301F, 1.0F, 0.0F, 0.0F, -2.618F)
        );

        class_5610 cube_r257 = blade14.method_32117(
            "cube_r257",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade15 = iris.method_32117(
            "blade15",
            class_5606.method_32108(),
            class_5603.method_32091(18.3793F, -35.8776F, 1.0F, 0.0F, 0.0F, -1.2217F)
        );

        class_5610 cube_r258 = blade15.method_32117(
            "cube_r258",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade16 = iris.method_32117(
            "blade16",
            class_5606.method_32108(),
            class_5603.method_32091(-18.3793F, 35.8776F, 1.0F, 0.0F, 0.0F, 1.9199F)
        );

        class_5610 cube_r259 = blade16.method_32117(
            "cube_r259",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade17 = iris.method_32117(
            "blade17",
            class_5606.method_32108(),
            class_5603.method_32091(38.5241F, 11.87F, 1.0F, 0.0F, 0.0F, 0.1745F)
        );

        class_5610 cube_r260 = blade17.method_32117(
            "cube_r260",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );

        class_5610 blade18 = iris.method_32117(
            "blade18",
            class_5606.method_32108(),
            class_5603.method_32091(-38.5241F, -11.87F, 1.0F, 0.0F, 0.0F, -2.9671F)
        );

        class_5610 cube_r261 = blade18.method_32117(
            "cube_r261",
            class_5606.method_32108()
                .method_32101(0, 88)
                .method_32098(
                    -9.0F,
                    -7.0F,
                    -1.0F,
                    18.0F,
                    50.0F,
                    0.0F,
                    new class_5605(0.01F)
                ),
            class_5603.method_32091(5.0F, -40.0F, 0.0F, 0.0F, 0.0175F, 0.0F)
        );
        return class_5607.method_32110(modelData, 256, 256);
    }
}
