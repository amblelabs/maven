package dev.amble.stargate.api.state;

import dev.amble.stargate.StargateMod;
import dev.amble.stargate.api.address.Glyph;
import dev.amble.stargate.api.data.StargateRef;
import dev.amble.stargate.api.Stargate;
import dev.amble.stargate.util.NbtUtil;
import dev.drtheo.yaar.state.NbtSerializer;
import dev.drtheo.yaar.state.TState;
import net.minecraft.class_2487;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface GateState<T extends TState<T> & GateState<T>> extends TState<T> {

    StateType gateState();

    class Closed implements GateState<Closed>, NbtSerializer {

        public static final Type<Closed> state = new NbtBacked<>(StargateMod.id("generic/closed")) {
            @Override
            public Closed fromNbt(@NotNull class_2487 nbt, boolean isClient) {
                return new Closed(nbt);
            }
        };

        public static final int TICKS_PER_GLYPH = 5;

        public static final int TICKS_PER_GLYPH2 = 60;

        public int locked;
        public boolean locking;

        // FIXME: use a fixed size char array here instead
        public String address;
        public int timer;

        public Closed() {
            this.address = "";
        }

        private Closed(class_2487 nbt) {
            this.locked = nbt.method_10550("locked");
            this.locking = nbt.method_10577("locking");
            this.address = nbt.method_10558("address");
        }

        // FIXME(perf)
        public boolean address$contains(char c) {
            return address.indexOf(c) != -1;
        }

        public int glyphIdxAtChevron(int chevronIdx) {
            return Glyph.charToIdx(address.charAt(chevronIdx));
        }

        @Override
        public void toNbt(@NotNull class_2487 nbt, boolean isClient) {
            nbt.method_10569("locked", locked);
            nbt.method_10556("locking", locking);
            nbt.method_10582("address", address);
        }

        @Override
        public Type<Closed> type() {
            return state;
        }

        @Override
        public StateType gateState() {
            return StateType.CLOSED;
        }
    }

    final class Opening implements GateState<Opening>, NbtSerializer {

        public static final Type<Opening> state = new NbtBacked<>(StargateMod.id("generic/opening")) {

            @Override
            public Opening fromNbt(@NotNull class_2487 nbt, boolean isClient) {
                long address = NbtUtil.getLong(nbt, "address", -1);
                boolean caller = nbt.method_10577("caller");
                int timer = nbt.method_10550("timer");
                float kawooshHeight = nbt.method_10583("kawooshHeight");

                return new Opening(StargateRef.resolveGlobal(address, isClient),
                        caller, timer, kawooshHeight);
            }
        };

        public static final int TICKS_PER_KAWOOSH = 4 * 20;

        public final @Nullable Stargate target;
        public final boolean caller;

        public int timer;
        public float kawooshHeight;

        public Opening(Stargate target, boolean caller) {
            this(target, caller, 0, 0);
        }

        private Opening(@Nullable Stargate target, boolean caller, int timer, float kawooshHeight) {
            this.target = target;
            this.caller = caller;

            this.timer = timer;
            this.kawooshHeight = kawooshHeight;
        }

        @Override
        public void toNbt(@NotNull class_2487 nbt, boolean isClient) {
            if (target != null)
                nbt.method_10544("address", target.globalAddress());
            nbt.method_10556("caller", caller);
            nbt.method_10569("timer", timer);
            nbt.method_10548("kawooshHeight", kawooshHeight);
        }

        @Override
        public Type<Opening> type() {
            return state;
        }

        @Override
        public StateType gateState() {
            return StateType.OPENING;
        }
    }

    class Open implements GateState<Open>, NbtSerializer {

        public static final Type<Open> state = new NbtBacked<>(StargateMod.id("generic/open")) {
            @Override
            public Open fromNbt(@NotNull class_2487 nbt, boolean isClient) {
                long address = NbtUtil.getLong(nbt, "address", -1);
                boolean caller = nbt.method_10577("caller");

                return new Open(StargateRef.resolveGlobal(address, isClient), caller);
            }
        };

        public static final int TICKS_PER_OPEN = 60 * 20;
        public static final int TELEPORT_FREQUENCY = 10;
        public static final int TELEPORT_DELAY = 20;

        public final @Nullable Stargate target;
        public final boolean caller;

        public int timer;

        public Open(@Nullable Stargate target, boolean caller) {
            this.target = target;
            this.caller = caller;
        }

        @Override
        public void toNbt(@NotNull class_2487 nbt, boolean isClient) {
            if (target != null)
                nbt.method_10544("address", target.globalAddress());
            nbt.method_10556("caller", this.caller);
        }

        @Override
        public Type<Open> type() {
            return state;
        }

        @Override
        public StateType gateState() {
            return StateType.OPEN;
        }
    }

    enum StateType {
        CLOSED,
        OPENING,
        OPEN
    }
}
